## Summary

<!-- 2-4 bullet points describing what this MR does and why -->

-
-

## Spec Reference

<!-- Required for all MRs that modify src/. Format: "Spec: impl-specs/{filename}.md"
     Hotfix MRs are exempt — add the 'hotfix' label instead. -->

Spec: impl-specs/

## Type of Change

- [ ] Bug fix
- [ ] New feature (NPS / CSAT / BRM / analytics routing)
- [ ] Refactor
- [ ] Configuration change
- [ ] Kafka event contract change (Tier 3 — requires 2 CODEOWNER approvals)
- [ ] Security change (Tier 3 — requires 2 CODEOWNER approvals)
- [ ] Test only

## Test Evidence

<!-- Paste test output or CI build link showing all tests pass -->

```
mvn clean verify — result:
```

Coverage delta: <!-- e.g. "line: 73% → 75%" or "no change" -->

## Checklist

### All MRs
- [ ] Tests added or updated for every changed behaviour
- [ ] Coverage remains ≥ 50% (JaCoCo gate passes)
- [ ] No `System.out.println` — `@Slf4j` used throughout
- [ ] No `@Autowired` field injection — constructor injection only
- [ ] Typed exceptions used (`NotFoundException`, `ServerException`, `BadRequestException`)
- [ ] New public endpoints have `@PreAuthorize` and `@Trace(dispatcher = true)`
- [ ] Spec reference filled in above (or `hotfix` label added)

### If entity / enum changed (Tier 3)
- [ ] Schema change raised in the DB migrations repo and deployment coordinated with DBA team
- [ ] Enum values not renamed if they are serialised as STRING in DB or Kafka events
- [ ] `@Version` not removed from `BaseEntity`

### If Kafka contract changed (Tier 3)
- [ ] Event type string not renamed without consumer coordination
- [ ] Downstream consumers notified / updated
- [ ] CorrelationId interceptors preserved

### If security changed (Tier 3)
- [ ] `PUBLIC_URIS` change reviewed with security lead
- [ ] Session policy remains STATELESS
- [ ] No `permitAll()` added without explicit approval

### Survey domain rules
- [ ] NPS cool-off recorded at trigger, not at response
- [ ] NPS and CSAT eligibility resolved in a single check-in pass
- [ ] CSAT outcome state tagged at trigger (not retrospectively)
- [ ] `failure` and `error` outcome states never merged
- [ ] Survey payloads < 1KB enforced

## Reviewer Focus

<!-- Call out the specific areas you want reviewers to focus on -->

-

## Related Issues / Jira Tickets

<!-- Link to Jira tickets or GitLab issues -->

-
