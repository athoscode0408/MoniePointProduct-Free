# CLAUDE.md — customer-analytics-service

## Project Overview

customer-analytics-service (CAS) is the CX analytics platform for Moniepoint. It is the system of record for in-app survey delivery (NPS, CSAT, BRM), analytics event routing (Braze, Mixpanel, CustomerIO, Google Analytics, Singular), and the check-in pre-commitment eligibility engine that drives survey triggers across Mobile, Web, and POS.

- **Language**: Java 22
- **Framework**: Spring Boot 3.3.3
- **Build**: Maven (single-module)
- **Package root**: `com.moniepoint.loans.cas`
- **Main class**: `CustomerAnalyticsServiceApplication`

---

## Module Structure

```
src/main/java/com/moniepoint/loans/cas/
├── common/              # Shared infrastructure — advice, audit, config, exception, security, util
├── integrations/        # Third-party analytics provider clients (Braze, CustomerIO, GA, Mixpanel, Singular)
├── module/
│   ├── analytics/       # Core domain — survey, event, and check-in logic
│   │   ├── controller/  # REST controllers (versioned: v2, v3 for newer endpoints)
│   │   ├── dto/         # Request/response DTOs (versioned: v1, v2, v3)
│   │   ├── entity/      # JPA entities
│   │   ├── enums/       # Domain enumerations
│   │   ├── repository/  # Storage interfaces (named *Storage, not *Repository)
│   │   ├── service/     # Service interfaces + impl/
│   │   └── validation/  # Custom validation annotations + validators
│   ├── cache/           # Multi-level caching (Redis + Caffeine)
│   ├── job/             # Scheduled jobs (ShedLock conventions apply)
│   └── kafka/           # Kafka listeners and producers
└── outbound/            # Outbound clients — NOS, banner, cosmos, rewards
```

---

## Deployment Topology
- CAS service is deployed as two separate processes
     - an API handler: this receives API requests from clients, fulfills request logic and returns response to caller
     - a background worker: this is a process that's not user facing, it handles consuming events from kafka, as well as quartz recurring jobs
- on each process deployment, the capabilities no needed for the role are disabled by setting JAVA_TOOL_OPTIONS environment variable, these are the settings for disabling unwanted capabilities in a deployment:
    - '-Dspring.main.web-application-type=none': disabled spring web controllers
    - '-Dspring.kafka.listener.auto-startup=false -Dspring.quartz.auto-startup=false': disables kafka and quartz listener auto startup, effectively stopping non API facing worker
    - '-Dspring.liquibase.enabled=false': disables Liquibase on the background worker — DB migrations run once, from the API handler process only, on startup (see [Database Migrations](#database-migrations))
- a k8s service is created to expose the api process for routing within the cluster.
- a k8s ingress is created to expose cas APIs to public internet
- k8s manifests for both processes are available under folder /kubernetes/templates

## Naming Conventions

| Artefact | Convention | Example |
|---|---|---|
| Entity | `{Domain}.java` | `Survey.java` |
| DTO | `{Domain}{Purpose}Request/Response/DTO.java` | `SurveyCreateRequest.java` |
| Service interface | `{Domain}Service.java` | `SurveyService.java` |
| Service impl | `impl/{Domain}ServiceImpl.java` | `SurveyServiceImpl.java` |
| Controller | `{Domain}Controller.java` | `SurveyController.java` |
| Admin controller | `Admin{Domain}Controller.java` | `AdminSurveyController.java` |
| Repository | `{Domain}Storage.java` | `SurveyStorage.java` |
| Kafka listener | `{Domain}Listener.java` | `SurveyEventListener.java` |
| Test | `{ClassUnderTest}Test.java` | `SurveyServiceTest.java` |
| Test double | `Fake{Domain}{Type}.java` | `FakeSurveyStorage.java` |

---

## Entity & Persistence Rules

- All entities extend `BaseEntity` — do not duplicate `id`, `createdBy`, `createdOn`, `lastModifiedBy`, `lastModifiedOn`, `version`.
- `@Version` on `BaseEntity` provides optimistic locking — never remove it.
- Always specify `@Column(nullable = false, length = N)` — do not rely on defaults.
- Use `@Enumerated(EnumType.STRING)` for all enum columns.
- Enum values stored in DB must not be renamed without a migration — rename breaks existing data.

### Database Migrations

- DB migrations live in **this repo**, under `src/main/resources/db/changelog/`, and are applied by
  Liquibase at service startup (see `spring.liquibase.change-log` in `application.yml`). They are no
  longer owned by a separate migration repo/central migration service.
- The service must be idempotent across restarts and redeploys: Liquibase's own `DATABASECHANGELOG` /
  `DATABASECHANGELOGLOCK` tables guarantee a given changeset never runs twice and concurrent processes
  never apply the same changeset in parallel. Do not build a parallel/custom "already ran" check —
  rely on Liquibase's tracking.
- **Never change the `id`, `author`, or `logicalFilePath` of an already-merged changeset**, and never
  edit its SQL in place. Liquibase keys applied changesets on `(id, author, filename)`; changing any of
  the three makes Liquibase treat it as new and re-run it. To fix a mistake in a changeset that has
  already shipped, add a new changeset that corrects it.
- Add new changesets as a new file under `db/changelog/schemas/`, following the existing
  `v{N}_{description}.xml` naming, and register it with an `<include>` in
  `db/changelog/db.changelog-master.xml`. New changesets do not need a `logicalFilePath`.
- Migrations run once, from the API handler process only (`spring.liquibase.enabled=false` on the
  background worker — see [Deployment Topology](#deployment-topology)).
- Coordinate destructive or long-running/blocking DDL (large table rewrites, dropping columns still
  read by in-flight deployments) with the DBA team before merging, same as before.
- See `impl-specs/2026-08-25-liquibase-migrations-in-service.md` for the full rationale behind how
  the existing changesets were carried over without re-running.

**Tier 3 paths — require 2 CODEOWNER approvals:**
- `src/main/java/**/module/analytics/entity/**` — any entity change has DB implications
- `src/main/java/**/module/analytics/enums/**` — enum changes break Kafka consumers if serialised as STRING
- `src/main/java/**/common/security/**` — auth/authz changes affect all endpoints
- `src/main/java/**/module/kafka/**` — Kafka event contract changes require consumer coordination
- `src/main/resources/db/changelog/**` — schema changes carry the same DB risk as entity changes, plus the risk of accidentally breaking migration idempotency (see rules above)

---

## Service Layer Rules

- Constructor injection only — use `@RequiredArgsConstructor`. Never `@Autowired` field injection.
- `@Transactional` on write methods. Read-only queries use `@Transactional(readOnly = true)`.
- Invalidate the relevant cache after every write operation.
- Log structured context (userId, surveyId, correlationId) at `INFO` for business operations, `DEBUG` for internals.
- Sanitise string inputs that become JSON payloads — strip BOM (U+FEFF) and zero-width spaces (U+200B) before serialisation (see `SurveyService.serializeSurvey`).
- Throw typed exceptions from the hierarchy (`NotFoundException`, `ServerException`, `BadRequestException`). Never throw raw `RuntimeException`.

---

## Controller Rules

- Annotate all public endpoints with `@PreAuthorize("hasAuthority(...)")`.
- All public controller methods annotated with `@Trace(dispatcher = true)` (New Relic).
- Return `ResponseEntity<T>` — never return raw domain objects.
- API versioning: new incompatible endpoints go in a new version package (`v3/`, `v4/`). Do not remove old version packages until consumers are migrated.
- Internal/admin endpoints go under `/internal/admin/` prefix with no `@PreAuthorize` (secured by network policy).
- Validate that `userId` / `accountNumber` is non-blank before passing to service — throw `BadRequestException` if blank.

---

## Error Handling Rules

- The global handler is `GenericControllerAdvice` — add new exception mappings there, not in individual controllers.
- `ErrorResponse.build(HttpStatus, message)` is the only way to construct error responses.
- Log all handled exceptions at `WARN` or `ERROR` level with handler name, message, and class.
- Do not swallow exceptions in services — propagate typed exceptions.

---

## Kafka Rules

- Kafka consumers are in `module/kafka/listener/`. One listener class per logical topic group.
- Never rename a Kafka topic key or event type string — existing consumers will break. Add new event types rather than changing existing ones.
- Kafka producers in `module/kafka/` use `KafkaTemplate<String, String>` with JSON serialisation.
- Use `CorrelationIdProducerInterceptor` / `CorrelationIdRecordInterceptor` for tracing across Kafka hops.

---

## Security Rules

- JWT authentication is multi-provider (Cosmos, Moniebook, Monnify) — do not assume a single issuer.
- `SecurityPropertiesConfig.PUBLIC_URIS` controls unauthenticated access — changes require security review.
- Sessions are stateless — never store mutable state in `HttpSession`.
- CSRF is disabled (stateless API) — do not re-enable.
- `COSMOS_ROLE_PREFIX` is the canonical authority prefix — match it in all `@PreAuthorize` expressions.

---

## Testing Rules

- Minimum coverage: **50% line and branch** (enforced by JaCoCo — build fails below threshold).
- Excluded from coverage: DTOs, entities, exceptions, config classes, security, tracing utilities.
- Use **real implementations** for domain logic in unit tests — use fakes (`FakeSurveyStorage`, `FakeCacheService`, etc.) for infrastructure dependencies.
- Use **Mockito** for third-party/integration dependencies (Braze, Kafka, HTTP clients).
- Use **TestContainers** (MySQL, Redis) for repository and integration tests.
- H2 is available for lightweight repository tests.
- Test naming: `{method}_{scenario}_{expectedResult}` — e.g. `createSurvey_stripsBomAndZeroWidthCharsBeforeSave`.
- Add `@Tag("simulation")` to tests that exercise Tier 3 state-transition logic (entity state changes, migration effects).

---

## Survey Domain Rules

These rules encode the product invariants that cannot be violated.

### Survey Categories
- `SurveyCategory.NPS` — relationship-level metric, cadence-based delivery (weekly), never event-triggered.
- `SurveyCategory.CSAT` — journey-level metric, triggered at journey outcome (success/failure/error).
- `SurveyCategory.BRM` — brand relationship measurement (existing capability).

### NPS Rules
- Cool-off: minimum 90 days from trigger date (`last_nps_triggered_date`), applied globally across all NPS measurements.
- Cool-off clock starts at trigger, not at response — applies even on dismissal.
- Weekly sample cap: Personal app 3,200 / Business app 2,134. Never exceed.
- `last_nps_triggered_date` must be written atomically at the point of trigger, not at response.
- NPS and CSAT eligibility must be resolved in a **single check-in pass** — no separate server call.
- Passives (7–8) are excluded from the NPS score formula. Track them separately.

### CSAT Rules
- `CSAT_north = (s × CSAT_success) + (f × CSAT_failure) + (e × CSAT_error)`. Never compute an unweighted average.
- Outcome state (`success`, `failure`, `error`) must be tagged at trigger — never applied retrospectively.
- `failure` and `error` are always distinct tags — never merge.
- Global cool-off applies across all journey measurements per customer, not per journey.

### Payload Constraints (non-negotiable)
- Every survey request/response payload: **< 1KB**.
- Survey-related data per client per day: **< 50KB**.
- Pre-commitment for NPS and CSAT shares a single check-in response payload.

---

## Spec Reference Rule

Every MR that modifies `src/` must reference a merged implementation spec from `impl-specs/`. Format in MR description:
```
Spec: impl-specs/{spec-file}.md
```
Exception: MRs labelled `hotfix` are exempt.

---

## Implementation Spec Directory

Store approved implementation specs in `impl-specs/`. Filename convention:
```
impl-specs/{yyyy-mm-dd}-{feature-slug}.md
```
Example: `impl-specs/2026-05-18-nps-sampling-engine.md`

---

## ADR Directory

Store architecture decision records in `adrs/`. Filename convention:
```
adrs/ADR-{NNN}-{title-kebab-case}.md
```
Example: `adrs/ADR-001-csat-north-computation-strategy.md`

---

## Do Not

- Do not add `@Autowired` field injection — use constructor injection.
- Do not use `System.out.println` — use `@Slf4j` logger.
- Do not catch and swallow exceptions silently.
- Do not rename Kafka event type strings or enum values used in persisted data without a migration.
- Do not add `@SuppressWarnings("unchecked")` without a comment explaining why it is safe.
- Do not bypass security with `permitAll()` for new endpoints without explicit approval.
- Do not compute NPS score without also computing promoter %, passive %, detractor % alongside it.
- Do not compute CSAT_north without displaying s, f, e alongside it.
- Do not merge `failure` and `error` outcome states in CSAT.
