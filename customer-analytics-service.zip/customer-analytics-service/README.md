# Customer Analytics Service

Moniepoint's various services/clients(UI, Mobile, Back-office) require the ability to send customer analytics events to
multiple analytics providers, such as CustomerIO and Mixpanel.
To streamline this process and eliminate code redundancy, a centralised analytics service is needed.
This service will facilitate event delivery across multiple providers, allowing for a unified integration approach.
Additionally, it will enable centralised management of critical aspects like security, scalability, and resiliency,
ensuring a robust and consistent analytics infrastructure across all services.

## Links

* [Technical Specification](./docs/TECHNICAL_SPECIFICATION.md) - Comprehensive technical documentation
* [Technical Flow](https://teamapt.atlassian.net/wiki/spaces/BLS/pages/1660682242/Customer+Analytics+Service)
* [API Documentation](./docs/api)
* [Architecture Diagram](./docs/architecture.puml)

----

## Setup

Dependencies (check the pom.xml for an up-to-date list):

 - JDK 22
 - Maven

If you have no preferred way to install them, check https://sdkman.io/


To run the project you can use maven commands. If you are not familiar with them, please read https://maven.apache.org/guides/getting-started/maven-in-five-minutes.html.

To load the profile configurations and access internal libs, load `settings.xml` to include the [Archiva repo](https://teamapt.atlassian.net/wiki/spaces/MF1/pages/1058013289/Archiva).
Example: `mvn verify --settings settings.xml`. VPN access will be required.

### Configurations

If you do not have the config server setup, environment variables can be read from a local `application.yml` file.
For dev configurations,
check [the dev config repo](https://gitlab.com/tcosmos/moniepoint-loans/environments/dev/config-repos/wclms-dev-config/-/blob/master/customer-analytics-service.yml?ref_type=heads)

### Database Migrations

Database migrations are defined in
the [analytics-service-migration-repo](https://gitlab.com/tcosmos/moniepoint-loans/projects/common/database-migrations/analytics-service-migration-repo).

### Running locally

To have the full service working, before running the customer-analytics-service code you will need a mysql, redis and
kafka instance running.
To run them, run `make dockers-up`.

After setting up the environment variables, you can run the service with your preferred IDE or using maven commands.
After the program launches, you should see the message:

```
o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path '/'
```

that is printed when Tomcat finishes initializing. After that, you can do

```
curl --location 'http://localhost:8080/actuator/health' 
```

to get the status of the server and confirm it was properly initialized

----
