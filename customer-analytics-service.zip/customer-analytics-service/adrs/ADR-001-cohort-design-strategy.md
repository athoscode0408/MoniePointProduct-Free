# ADR-001: Cohort Design Strategy — JsonLogic Rules + Precomputed Membership

## Status

Superseded — updated 2026-05-21. Original decision (Option B, static columns) was accepted for Phase 1 but was superseded before implementation by the Cohort Platform spec (`impl-specs/cohort/2026-05-21-cohort-platform.md`). Option C (dynamic rules) is now the implemented design, using JsonLogic AST instead of SpEL.

## Date

2026-05-19 — updated 2026-05-21

## Context

The NPS Cohort Definition spec (`impl-specs/2026-05-19-nps-cohort-definition.md`) requires CAS to evaluate whether a user belongs to an audience segment (a "cohort") before including them in the weekly NPS sample. Today CAS has no cohort concept: survey eligibility is expressed entirely as SpEL rules on `Survey.rule`, evaluated by `RuleParserHandler` on each analytics event. That mechanism is event-driven and stateless — it has no notion of a named segment that users persistently belong to.

Phase 1 requires **two cohorts**:
- **Personal Banking NPS** — all personal account holders on the Personal App who have been onboarded for at least 60 days and have made at least 1 transaction in the last 30 days.
- **Business Banking NPS** — all business account holders on the Business App satisfying the same age and transaction criteria.

Looking further ahead, CSAT and BRM are also candidates for cohort-scoped delivery, and PMs have asked whether they will be able to define their own cohort rules without requiring an engineering deployment. The Cohort entity name is `Cohort` (not `NpsCohort`) precisely because it will be shared across survey categories.

The team had to decide: **how should a cohort's membership criteria be modelled?**

---

## Options Considered

### Option A: Java constants / enums with hardcoded evaluation logic

Represent each cohort as a Java enum constant (`NPS_PERSONAL_BANKING`, `NPS_BUSINESS_BANKING`) and embed the eligibility logic directly in a switch statement or a per-constant method.

**Pros:**
- Zero DB schema cost
- No migration coordination with the DBA team
- Trivially type-safe at compile time

**Cons:**
- Every new cohort requires a code change, a build, and a deployment — unacceptable for a feature the PRD implies should scale to many segments over time
- Cohort config (e.g. `minAccountAgeDays = 60`) is buried in source code with no operational visibility; changing a threshold requires a new release
- No way for a PM or data analyst to inspect or modify cohort definitions without reading source code
- Non-reusable outside Java — no data team query can introspect cohort definitions
- Adding a CSAT cohort requires forking the enum or adding category-switch logic, creating coupling between survey categories

**Verdict:** Rejected. Inflexible for anything beyond the initial two cohorts.

---

### Option B: DB-seeded rows with static eligibility attribute columns (DECIDED)

Represent each cohort as a row in a `cohort` MySQL table. The row carries static columns that express the eligibility gates directly: `min_account_age_days`, `require_recent_transaction`, `transaction_window_days`, `segment`, `platform`, etc.

New cohorts are added by inserting a new row via a DB migration — no code deployment needed. The evaluation logic in `CohortEligibilityGateImpl` reads these column values and applies the gates uniformly to all rows.

**Pros:**
- New cohorts added via DB row insertion — no code change, no deployment
- Cohort definitions are operationally visible (queryable in MySQL, inspectable by the DBA team)
- `CohortEligibilityGateImpl` logic is generic and reused for every cohort row
- Forward-compatible with a future `rule_definition JSON` column (see §Forward-Looking section)
- Cohort rows can be referenced by FK from `nps_weekly_sample` and `PreprocessedSurvey.cohort_id` — full traceability from a survey instance back to its cohort
- Works for CSAT cohorts without any structural change — just add rows with `survey_category = 'CSAT'`

**Cons:**
- Requires a schema migration to add a new gate type (e.g., a `min_monthly_transaction_volume` column would need a DDL change)
- Gate logic is fixed in Java; not PM-configurable without a code change for truly novel gate types
- Two cohorts at launch — there is a risk of over-engineering even this level of DB modelling for what is, right now, two rows

**Verdict:** Accepted. See Decision section.

---

### Option C: Dynamic JSON rule definition per cohort (future)

Store an arbitrary JSON rule tree in a `rule_definition JSON` column on the `cohort` table. Build a `CohortRuleEngine` (SpEL-based) that evaluates the JSON condition tree against a `UserAttributes` context map.

**Pros:**
- PMs can define arbitrary cohort rules without a code change or a schema migration
- Maps directly to how customer.io, Braze, and Mixpanel model audience segments (see §Forward-Looking section)
- Unlimited expressiveness: any `UserAttributes` field becomes available as a condition operand

**Cons:**
- Requires building a rule engine with its own parser, context binder, validation, and testing infrastructure — estimated ~400–600 additional lines over Option B
- SpEL evaluation on arbitrary user-provided JSON introduces injection and expression-complexity risks that require a security review
- No Phase 1 requirement for dynamic rules — neither cohort in scope requires anything beyond age + transaction recency
- A PM-facing cohort editor UI is also not in scope; without the UI, the JSON column would still require engineering to write the JSON correctly
- Premature generalisation: the "twice per year" NPS cap, the cool-off clock, and the weekly cap are all hardcoded programme rules — dynamic cohort definition would only address membership criteria, not the programme rules themselves

**Verdict:** Rejected for Phase 1. Adopted as the forward-looking evolution target (see §Forward-Looking).

---

## Decision

**We chose Option B — DB-seeded rows with static eligibility attribute columns.**

The `cohort` table will be created with static gate columns (`min_account_age_days`, `require_recent_transaction`, `transaction_window_days`). Two rows are seeded by the DB migration for Personal Banking NPS and Business Banking NPS. The table is owned by engineering, not a PM admin UI. New cohorts are added by raising a DB migration.

---

## Rationale

**Option A** is inflexible for any programme with more than one or two cohort variants. Changing `minAccountAgeDays` from 60 to 90 days would require a full release cycle. As the NPS programme grows (additional segments, CSAT cohorts, A/B-tested thresholds), code-constant management becomes a maintenance burden with zero operational visibility.

**Option C** solves a problem the team does not yet have. Phase 1 has exactly two cohorts. The gate types for both cohorts are identical (account age + recent transaction). Building a rule engine, a JSON schema, a validation layer, and an injection-safe SpEL evaluator for two rows is premature complexity. The engineering investment would produce a system that no one interacts with dynamically until a PM UI is built, which is also not in scope.

**Option B** is the smallest thing that works correctly. New cohorts can be added by a DB row insert (not a code change). The `CohortEligibilityGateImpl` logic is generic. The static columns are fully forward-compatible with Option C: when the team is ready for dynamic rules, a `rule_definition JSON NULL` column is added, and `CohortEligibilityGate.evaluate()` checks whether `ruleDefinition` is populated before falling back to static columns. No existing row needs to change.

---

## Forward-Looking: How Segmentation Tools Approach This Problem

Understanding how mature segmentation platforms model cohorts informs where CAS should eventually go.

### customer.io

customer.io uses **attribute-based JSON condition trees** evaluated against the user's profile at send time. A condition tree looks like:

```json
{
  "type": "and",
  "conditions": [
    { "attribute": "days_since_onboarding", "operator": ">=", "value": 60 },
    { "attribute": "last_transaction_days_ago", "operator": "<=", "value": 30 }
  ]
}
```

No code deployment is required when a PM creates or edits a segment — the JSON is stored and evaluated dynamically. The evaluation engine is the platform itself.

### Braze

Braze models "Segments" as **computed membership tables** refreshed by periodic batch jobs. The PM defines segment rules in a UI-driven query builder; Braze runs SQL-like predicates against the user attribute store and caches the results as an inclusion/exclusion set. Real-time membership checks read from the cached set rather than re-evaluating rules.

### Mixpanel

Mixpanel "Cohorts" are also query-based, evaluating event-property and user-property predicates. Like Braze, membership is pre-computed and cached.

### Implemented CAS direction: JsonLogic AST + BigQuery + Precomputed Membership

**This is the direction actually implemented.** The Cohort Platform spec (`impl-specs/cohort/2026-05-21-cohort-platform.md`) chose the Braze model (precomputed membership) over the customer.io model (in-process evaluation at query time). The implementation:

1. `rule_definition JSON NULL` column on the `cohort` table stores a **JsonLogic AST** (not SpEL). JsonLogic was chosen over SpEL because: (a) no arbitrary code execution surface — structurally injection-safe; (b) directly transpilable to BigQuery SQL via a Visitor-pattern compiler; (c) compatible with visual rule-builder UIs (`react-querybuilder` exports JsonLogic natively).
2. `JsonLogicToSqlCompiler` transpiles the JsonLogic AST to a BigQuery `WHERE` clause. A `CohortFieldRegistry` allowlist prevents arbitrary column access.
3. `CohortResolutionJob` (nightly, `ClusteredJob`) executes the BigQuery query and bulk-upserts matching `user_id` values into the `user_cohorts` table.
4. Consumers (NPS sampling job, future CSAT) query `user_cohorts` via `CohortMembershipRepository.findUsersByCohortId()`. No per-consumer eligibility evaluation — membership is precomputed.

`CohortEligibilityGate` and static gate columns are **not implemented**. They were specified in the archived cohort definition spec but superseded before any code was written.

---

## Consequences

### Positive

- Two Phase 1 cohorts can be defined and activated without any additional Java code — just DB row inserts
- `CohortEligibilityGateImpl` is a single generic implementation, fully unit-testable with no Kafka or SpEL dependencies
- Cohort definitions are visible in the database and to the DBA team without reading source code
- CSAT cohorts can be added in a future spec by inserting `cohort` rows with `survey_category = 'CSAT'` — zero code change
- Full referential integrity: `nps_weekly_sample.cohort_id` and `preprocessed_survey.cohort_id` FK to the `cohort` table; invalid cohort references are caught at the DB level
- Forward-compatible with the `rule_definition JSON` evolution path — adding a new column is a non-breaking, additive schema change

### Negative

- A truly novel gate type (e.g., "user has KYC level >= 3") requires a schema migration AND a code change to `CohortEligibilityGateImpl`
- PMs cannot self-serve cohort creation in Phase 1 — all changes require an engineering DB migration
- For very large numbers of cohorts (dozens), the static-column model becomes wide; the `rule_definition` column becomes more attractive at that scale

### Risks

- **Risk:** A PM requests a new gate type (e.g., city-based cohort, account balance threshold) during Phase 1 development.  
  **Mitigation:** Gate type additions to `CohortEligibilityGateImpl` are isolated, low-risk changes — a new `if` branch and a new column. The schema migration is additive. The risk is delivery velocity, not correctness. Capture the request in the NPS PRD feedback and address in Phase 1.5.

- **Risk:** The `rule_definition` column is added in Phase 2 without updating `CohortEligibilityGate` to handle the fallback correctly, leaving static-column rows unprocessed.  
  **Mitigation:** The Phase 2 spec must explicitly reference this ADR and specify the fallback logic as an acceptance criterion. The `evaluate()` method must be tested with rows that have `ruleDefinition = null` (static path) and rows that have `ruleDefinition != null` (engine path) as separate test cases.

- **Risk:** Engineering forgets to run the cohort seed migration before activating the `nps.programme.enabled` feature flag, causing the sampling job to find zero cohorts and produce an empty weekly sample.  
  **Mitigation:** The rollout plan (§7 of the impl spec) places the DB migration (Step 2) before flag enablement (Step 4). The sampling job logs a `WARN` if no active cohorts are found, and a Grafana alert triggers on `nps.sampling.cohorts_found == 0`.
