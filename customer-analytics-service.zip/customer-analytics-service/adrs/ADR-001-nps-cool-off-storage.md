# ADR-001: NPS Cool-Off State Lives in CAS-Owned MySQL Table, Not Bigtable

## Status

Accepted

## Date

2026-05-19

## Context

The NPS Sampling Programme (impl-specs/2026-05-18-nps-sampling-engine.md) enforces a **90-day global cool-off** per user across all NPS measurements (PRD §10, AC-05.1 through AC-05.6, AC-12.1 through AC-12.5). The cool-off is tracked by `last_nps_triggered_date`, which must be:

1. **Written at trigger time**, not at response time (PRD §10 bullet 3 — "must be recorded at the point of trigger, not at the point of response")
2. **Atomic with the sample-served write** — a single transaction enforces both "this user got served" and "this user is now in cool-off"
3. **Globally consistent** across check-in calls — concurrent logins on two devices must not both succeed in triggering the survey
4. **NPS-specific** — CSAT and BRM have their own cool-off semantics and timeouts (resolved per impl-spec C-05); they should not share storage

The platform's authoritative source of user attributes is **Google Bigtable**, accessed via `UserAttributesStorage.findUser()` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/repository/UserAttributesStorage.java`]. The architecture diagram [VERIFIED: `architecture/c4model/02-container.mmd:43`] declares CAS's relationship to Bigtable as `"Reads user attributes for eligibility"` — **read-only**.

CAS owns MySQL (`Container(mysql, "MySQL", "Relational DB", "Stores survey definitions, provider configuration, and preprocessed survey state")`) and uses it for all writable survey state today (`Survey`, `PreprocessedSurvey`, `SurveyAlert` entities all live in MySQL).

The decision the team faced was: **where does `last_nps_triggered_date` live so that CAS can write it atomically at trigger time?**

## Options Considered

### Option A: Push for Bigtable write capability — store on the user record

Coordinate with the data team to add a write path so CAS can update a `last_nps_triggered_date` column on the Bigtable user record alongside `onboardingDate` and `lastTxnDate`.

**Pros:**
- Co-locates NPS cool-off with the other user attributes it shares an access pattern with
- Eliminates one MySQL table from the CAS schema
- A future "global user state" service could subsume this naturally

**Cons:**
- Bigtable is currently read-only from CAS — opening a write path is a major architectural change requiring data-team approval, possibly a new IAM role, and possibly a new write-side service
- Bigtable's strong-consistency model on per-row writes is sufficient, but coordination with the existing batch-ingestion pipeline that populates `UserAttributes` introduces a contention risk (CAS write vs. batch refresh of the same row)
- Optimistic locking via `@Version` does not exist on Bigtable in the same Spring-friendly way; would need a custom `cas` (compare-and-swap) pattern
- Blocks the NPS spec on an external workstream (data-team timeline unknown)
- BigTable writes from CAS would also need replication to the read-replica that powers the BI Platform — additional plumbing

### Option B: Reuse `PreprocessedSurvey` to track cool-off

Use the existing `PreprocessedSurvey` table to derive cool-off: query for the most recent `PreprocessedSurvey` of category NPS for a given user and check its `created_on` timestamp.

**Pros:**
- Zero new tables
- Reuses existing infrastructure

**Cons:**
- `PreprocessedSurvey` is keyed on `(user, survey_id)` and tracks per-survey instances; cool-off is a per-user, cross-measurement concept
- Querying "most recent NPS row for this user across all measurements" requires a scan-style query over a growing table (24M+ users × multiple measurements over time)
- No clean place to store `trigger_count_year` (required by impl-spec C-11 hard year cap)
- Conflates per-survey lifecycle state with cross-survey programme state — semantic muddle

### Option C: CAS-owned `nps_user_state` MySQL table

Create a dedicated MySQL table `nps_user_state` owned by CAS, with columns:
- `user_id VARCHAR(50) UNIQUE NOT NULL`
- `last_nps_triggered_date DATE NULLABLE`
- `last_nps_response_classification ENUM NULLABLE`
- `trigger_year SMALLINT NULLABLE`
- `trigger_count_year SMALLINT NOT NULL DEFAULT 0`
- `version INTEGER NOT NULL` (inherited from `BaseEntity`, for optimistic locking)
- Standard audit fields from `BaseEntity`

CAS writes this row atomically in the same MySQL transaction as the `nps_weekly_sample.status = SERVED` update.

**Pros:**
- No external dependencies — fully under CAS ownership
- `@Version` optimistic locking handles concurrent double-trigger naturally — second concurrent write gets `OptimisticLockException`, service returns already-served state idempotently
- Pattern is mirrorable for CSAT (`csat_user_state`) and any future survey category — establishes a "per-category user state" template
- MySQL transaction semantics already cover the atomic-with-sample-write requirement
- Table is small relative to `PreprocessedSurvey` — one row per user who has ever been triggered, not one per survey instance
- Bigtable schema does not change

**Cons:**
- Adds another CAS-owned table to operate and back up
- Per-category state means CSAT and any future category each get their own state table — slight duplication in the schema (mitigated by establishing a common naming pattern)
- The user_id stored here is the same identifier used in Bigtable but is duplicated — a `JOIN` across stores is not possible (acceptable because no query requires that)

## Decision

We chose **Option C — CAS-owned `nps_user_state` MySQL table**.

## Rationale

Option A is blocked by an external dependency (data-team write path) on an unknown timeline, contradicting the spec's Phase 1 delivery commitment. Option B conflates two distinct concepts (per-survey lifecycle vs. cross-survey programme state) and produces a query pattern that does not scale to 24M+ users.

Option C aligns with how CAS already manages writable state — every CAS-owned writable entity lives in MySQL — and gives us a clean spot for `trigger_year` and `trigger_count_year` to enforce the impl-spec C-11 year cap. Optimistic locking via `BaseEntity.@Version` solves the concurrent-double-trigger invariant without any custom code: the second concurrent transaction simply fails and the service catches the failure to return the already-served state.

The "per-category state table" pattern is also forward-looking: CSAT will mirror this with `csat_user_state` (resolved per impl-spec C-05), and any future survey category gets its own state table independent of NPS's cool-off, year cap, or classification semantics.

## Consequences

### Positive

- NPS spec is unblocked — no external dependency on data team
- Concurrent double-trigger is invariant-protected at the database level via `@Version` (free)
- CSAT spec can copy this pattern (`csat_user_state`) without renegotiation
- Bigtable schema is unchanged — no coordination cost with the data team for NPS

### Negative

- Adds an additional MySQL table to operate (small — one row per user who has ever been triggered)
- A "global user state across all surveys" concept does not exist yet — engineers must remember each category has its own state table

### Risks

- **Risk:** Two state tables (one for NPS, one for CSAT) become hard to reason about as the platform grows.  
  **Mitigation:** Document the pattern in CLAUDE.md (Survey Domain Rules section) so future survey categories follow it consistently. If a fifth or sixth category appears, revisit and consider extracting a `survey_user_state` umbrella table with a category column.

- **Risk:** MySQL row-level locking contention if a single user has many concurrent NPS check-in attempts.  
  **Mitigation:** Optimistic locking via `@Version` produces immediate `OptimisticLockException` (no wait), and the check-in service treats this as "already-served" and returns the existing state. No retry loop, no lock-wait latency.
