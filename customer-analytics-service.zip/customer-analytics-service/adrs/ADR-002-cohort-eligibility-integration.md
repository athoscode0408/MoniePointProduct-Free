# ADR-002: Cohort Eligibility Integration — Precomputed Membership via Cohort Platform

## Status

Accepted — amended 2026-05-21. The core decision (NPS eligibility does NOT go through the SpEL `RuleParserHandler`) is unchanged. The implementation detail changed: `CohortEligibilityGate` (specified in the original decision) was superseded before implementation by the Cohort Platform's precomputed `user_cohorts` membership table. See amendment section at the end of this document.

## Date

2026-05-19 — amended 2026-05-21

## Context

The NPS Cohort Definition spec (`impl-specs/2026-05-19-nps-cohort-definition.md`) introduces a `CohortEligibilityGate` that evaluates account age and transaction recency gates against a user's `UserAttributes`. The question is: **how should this gate plug into the CAS architecture?**

### Current eligibility infrastructure

CAS's existing eligibility pipeline is SpEL-based and event-driven:

1. An analytics event arrives on Kafka.
2. `SurveyEvaluatorListener` reads all active `Survey` rows (cached).
3. For each survey, `RuleParserHandler.parseRule()` evaluates `Survey.rule` — a SpEL expression — against a context object that contains `UserAttributes` and the `VerifiedAnalyticsEventDTO`.
4. If the rule passes, `RuleParserHandler` constructs a `PreprocessedSurvey` and publishes an `EventPreprocessSurveyDTO` to the `event-survey-preprocessor` Kafka topic.
5. `SurveyPreprocessorListener` consumes the DTO and persists the `PreprocessedSurvey`.

This pipeline is used today for **BRM** and will be used for **CSAT**. It works correctly for event-triggered surveys: the SpEL expression references event properties (e.g., `#event.journeyOutcome == 'SUCCESS'`) and user attributes.

### Why NPS is different

NPS is **cadence-based, not event-triggered**. The PRD (§7.1) states that NPS invitations are prepared weekly by a batch job (`NpsWeeklySamplePreparationJob`) that runs on Monday at 00:05 Africa/Lagos. There is no triggering analytics event. The sample is materialised in `nps_weekly_sample` at week start; check-in at any point during the week consults the pre-materialised sample.

This creates a structural mismatch with the SpEL pipeline:

- `RuleParserHandler.parseRule()` requires a `VerifiedAnalyticsEventDTO` as input. There is no such DTO in a batch job context — there is no triggering event.
- `Survey.rule` SpEL expressions are evaluated on the event context (e.g., `#event.platform`, `#event.type`). NPS eligibility gates (`minAccountAgeDays`, `transactionWindowDays`) are user-attribute predicates with no event dimension.
- The SpEL pipeline is invoked once per analytics event, per survey rule. Calling it for the ~24M-user NPS sampling pass would require fabricating a synthetic `VerifiedAnalyticsEventDTO` for every user — a semantic abuse of the model.

---

## Options Considered

### Option A: Update Survey.rule SpEL to add the NPS eligibility gates

Add SpEL conditions to the NPS `Survey.rule` field that express the account age and transaction recency requirements. Example:

```
#user.onboardingDate != null
  && T(java.time.LocalDate).now().minusDays(60).isAfter(#user.onboardingDate.toLocalDate())
  && #user.lastTxnDate != null
  && #user.lastTxnDate.isAfter(T(java.time.LocalDate).now().minusDays(30))
```

When `SurveyEvaluatorListener` processes an event for a user who happens to match the NPS survey's `category = NPS` and passes the SpEL rule, a `PreprocessedSurvey` is created.

**Pros:**
- Zero new Java code — only a `Survey.rule` value change in the DB
- Reuses the entire existing event-driven pipeline end-to-end

**Cons:**
- NPS is **not event-triggered**. SpEL evaluation happens on the event path — it fires when the user generates an analytics event, not on a Monday morning schedule. The sampling job's weekly cap (3,200 Personal / 2,134 Business) cannot be enforced here: the pipeline fires for every eligible user who generates any event, producing an unbounded number of NPS `PreprocessedSurvey` rows.
- The weekly cap is a hard PRD requirement (§7.2). Option A structurally cannot satisfy it without adding capping logic into `RuleParserHandler`, which would pollute a generic component with NPS-specific semantics.
- There is no "sampling" — the pipeline creates a NPS instance for every eligible event, not for a random weekly sample. The statistical validity of the NPS score (designed for 1,067 respondents at 95% confidence, ±3%) is destroyed.
- Cohort definition is invisible in the SpEL string — no `Cohort` entity exists, no `cohort_id` FK, no named segment concept. The eligibility logic is embedded in an opaque text field.
- The SpEL rule would reference `#user.onboardingDate` as a `LocalDateTime` and compare it to `LocalDate.now()` — a type mismatch requiring casting in the expression string, which is fragile and untestable without running the full SpEL engine.
- `Survey.rule` is shared between BRM, CSAT, and NPS in this model. Adding NPS-specific conditions (account age, transaction recency, weekly cap awareness) creates coupling between survey categories in a field that is supposed to be category-agnostic.

**Verdict:** Rejected. Semantically incorrect for a cadence-based programme. Cannot enforce the weekly invitation cap.

---

### Option B: Dedicated CohortEligibilityGate service, called from weekly sampling job only (DECIDED)

Build a standalone `CohortEligibilityGate` Java service (interface + implementation) that:
1. Accepts a `Cohort` and a `UserAttributes` as inputs.
2. Returns `true`/`false` based on the two static gates (account age, recent transaction).
3. Is called exclusively from `NpsWeeklySamplePreparationJob`.

The sampling job queries all active `Cohort` rows, paginates over users from `UserAttributesStorage`, calls `CohortEligibilityGate.evaluate()` for each user, and inserts passing users into `nps_weekly_sample` up to the weekly cap. The SpEL pipeline is not involved at any point.

**Pros:**
- Semantically correct: the gate is evaluated in the context where it belongs — the weekly batch sampling pass, not on an arbitrary user event.
- Weekly invitation cap is naturally enforced by the sampling job's insertion logic — the job stops inserting once `COUNT(nps_weekly_sample WHERE isoWeek = currentWeek AND cohortId = ?) >= cohort.survey.weeklyInvitationCap`.
- `CohortEligibilityGate` is a pure function of `(Cohort, UserAttributes, LocalDate)` — directly unit-testable with no Kafka, no SpEL engine, no `VerifiedAnalyticsEventDTO`.
- The SpEL pipeline (`SurveyEvaluatorListener` → `RuleParserHandler`) is **not modified**. BRM and CSAT eligibility continue to work exactly as today.
- Gate logic is expressed in typed Java — null checks, date arithmetic, boolean flags — no string-based SpEL expressions or reflection trickery.
- `Cohort` entity provides a named, queryable, FK-referenced segment concept. `PreprocessedSurvey.cohort_id` provides full traceability from a delivered NPS survey instance back to the cohort it came from.
- Adding a new gate type in the future (e.g., KYC level check) requires adding a column to `Cohort` and a typed branch in `CohortEligibilityGateImpl` — a clear, reviewable, testable change.

**Cons:**
- Introduces a new code path that does not reuse the existing event-driven pipeline — engineers must understand two eligibility models.
- The sampling job is a new Quartz job that must be maintained (ShedLock lock key, cron expression, paginated batch logic).
- `UserAttributesStorage.findUser()` currently accepts `(userId, accountNumber)` — the sampling job needs to iterate over users without knowing their account numbers in advance. A new paginated query method or a different Bigtable access pattern may be needed.

**Verdict:** Accepted. See Decision section.

---

## Decision

**We chose Option B — a dedicated `CohortEligibilityGate` service called from the weekly sampling job only.**

`CohortEligibilityGate` is a `@Component` in `module/analytics/nps/service/`. It is injected into `NpsWeeklySamplePreparationJob` and nowhere else. The SpEL pipeline (`SurveyEvaluatorListener`, `RuleParserHandler`) is not modified.

---

## Rationale

Option A's core flaw is not an implementation detail — it is a semantic one. The SpEL pipeline is a **reactive** system: it fires when users generate events and checks whether those events qualify for a survey. NPS is a **proactive** system: it determines once per week which users to invite and prepares a materialised sample. These are incompatible operational models.

Forcing NPS eligibility into the SpEL pipeline would mean:
- Users who don't generate analytics events in a given week would never be sampled — systematically excluding less-active users and biasing the NPS score downward.
- Users who generate many events would receive multiple `PreprocessedSurvey` rows for the same NPS survey in the same week — requiring de-duplication logic that doesn't belong in `RuleParserHandler`.
- The 3,200 / 2,134 weekly cap becomes impossible to enforce without a stateful counter that `RuleParserHandler` has no natural home for.

Option B treats NPS sampling as the batch-oriented, statistically-designed programme it is. `CohortEligibilityGate` is typed, focused, and directly testable. The SpEL pipeline continues to serve BRM and CSAT without modification.

The cost — two eligibility models in the codebase — is real but acceptable. The two models solve genuinely different problems. Conflating them would produce a system that does neither well.

---

## Consequences

### Positive

- SpEL pipeline is fully stable for BRM and CSAT — no regression risk from this spec.
- `CohortEligibilityGate` is unit-testable in isolation: `new CohortEligibilityGateImpl().evaluate(cohort, user, today)` — no Spring context, no Kafka, no reflection.
- NPS weekly cap is correctly enforced at insertion time in the sampling job, not as an afterthought in the pipeline.
- `nps_weekly_sample` materialises the sample once per week, making re-evaluation at check-in a lightweight point-lookup rather than a full eligibility recalculation.
- Adding a new gate type for NPS (e.g., a `min_lifetime_transactions` column) requires a typed code change in `CohortEligibilityGateImpl` that is reviewable and testable — no opaque SpEL string surgery.
- CSAT can reuse `CohortEligibilityGate` if CSAT cohorts are introduced in a future spec — the interface is category-agnostic.

### Negative

- Engineers must learn that NPS eligibility does not go through `RuleParserHandler`. This must be documented in CLAUDE.md under the Survey Domain Rules section to prevent future engineers from accidentally routing NPS eligibility through SpEL.
- `NpsWeeklySamplePreparationJob` must handle Bigtable pagination correctly for the full user base (~24M users). A buggy pagination cursor could produce duplicate samples or miss eligible users. This is a correctness risk that requires integration tests.
- The sampling job and `CohortEligibilityGate` are both new components that must be monitored. If the job fails silently (e.g., ShedLock acquisition fails on every node), no sample is prepared and no NPS surveys are served that week. An alerting rule on `nps.sampling.sample_size_prepared == 0` is required.

### Risks

- **Risk:** A future engineer extends `RuleParserHandler` or `SurveyEvaluatorListener` to call `CohortEligibilityGate` for NPS, creating a duplicate evaluation path.  
  **Mitigation:** CLAUDE.md Survey Domain Rules section explicitly states: "NPS eligibility is evaluated by `CohortEligibilityGate` from the weekly sampling job only. Do not route NPS eligibility through `RuleParserHandler`." `CohortEligibilityGateImpl` includes a Javadoc statement to the same effect.

- **Risk:** `NpsWeeklySamplePreparationJob` runs but `CohortEligibilityGate` is called with stale `UserAttributes` (e.g., `lastTxnDate` is from last week's Bigtable snapshot).  
  **Mitigation:** Bigtable is the authoritative source for `UserAttributes`. CAS reads Bigtable in real time via `UserAttributesStorage.findUser()` — there is no local caching of user attributes in the sampling job. Bigtable's typical replication lag is under 60 seconds. A user whose transaction posts on Sunday night will appear as eligible on Monday morning. Documented in the sampling job's Javadoc.

- **Risk:** CSAT is introduced in a future spec and a new engineer routes CSAT eligibility through `RuleParserHandler` using SpEL, while NPS uses `CohortEligibilityGate`. Two eligibility models for two cohort-based categories creates inconsistency.  
  **Mitigation:** The CSAT spec should explicitly reference this ADR. If CSAT is also cadence-based, it reuses the Cohort Platform. If CSAT is event-triggered (journey outcome), the SpEL pipeline is appropriate. The distinction is delivery model (cadence vs. event), not category.

---

## Amendment — 2026-05-21

### What changed

The original decision specified `CohortEligibilityGate` as a Java service called at sampling time. Before any code was written, this was superseded by the Cohort Platform spec (`impl-specs/cohort/2026-05-21-cohort-platform.md`).

### What stayed the same

The core principle is unchanged: **NPS eligibility does not go through `RuleParserHandler`**. The sampling job is batch-oriented and cadence-based — the SpEL pipeline is reactive and event-driven. These are incompatible operational models.

### What is different

| Original decision | Amended decision |
|---|---|
| `CohortEligibilityGate` evaluated at sampling time (Java, per-user) | Cohort membership precomputed nightly by `CohortResolutionJob` into `user_cohorts` table |
| Bigtable RowFilter scan in `NpsWeeklySamplePreparationJob` | MySQL `JSON_CONTAINS` lookup on `user_cohorts` |
| Rules encoded as static columns on `Cohort` entity | Rules stored as JsonLogic AST in `cohort.rule_definition` column |
| No `user_cohorts` table | `user_cohorts(user_id PK, cohort_ids JSON)` with multi-valued index |

### Why the amendment

The Cohort Platform architecture allows cohort resolution to evolve independently — different query engines, real-time refreshes, additional attributes — without changing the NPS sampling job. NPS becomes a pure consumer of precomputed data rather than an owner of eligibility logic. This aligns with the goal of making cohorts reusable across NPS, CSAT, and future survey categories.
