# ADR-002: ISO-8601 Week (`YYYY-Www`) as the Atomic NPS Measurement Unit

## Status

Accepted

## Date

2026-05-19

## Context

The NPS Sampling Programme (impl-specs/2026-05-18-nps-sampling-engine.md) treats the **calendar week as the lowest granularity of measurement** (PRD §12.1: "The calendar week is the lowest granularity of NPS measurement. Weekly scores are the atomic unit from which all higher-level views are derived"). Multiple tables join on a week identifier:

- `nps_weekly_sample` — one row per `(userId, measurementId, isoWeek)`
- `nps_weekly_score` — one row per `(measurementId, isoWeek)`
- Survey response discard logic — compare `week(preprocessedSurvey.createdOn)` to current week
- BI Platform — Airflow reads weekly atomic scores and computes 4 / 7 / 12 / 28-week rolling averages downstream (resolved per impl-spec C-02)

Three properties were required of the week identifier:

1. **Deterministic** — given a `LocalDate`, the week ID must be unambiguous and reproducible across services (CAS, BI Platform, manual SQL queries)
2. **Sortable** — comparing two week identifiers without parsing or computing dates must yield correct chronological order (so `BETWEEN '2026-W01' AND '2026-W52'` works in plain SQL)
3. **Timezone-stable** — week boundaries must be defined relative to a single canonical zone (the platform operates primarily in Africa/Lagos)

CAS runs in Africa/Lagos (UTC+1, no DST). The PRD does not specify a week-numbering scheme; the team had to choose one.

## Options Considered

### Option A: Two `DATE` columns (`week_start_date`, `week_end_date`)

Store the start and end dates of the week as two `DATE` columns on every table that needs week granularity.

**Pros:**
- Self-describing for someone reading the DB without context
- No ambiguity about which week-numbering scheme is in use

**Cons:**
- Doubles the column count for every week-aware table
- Range queries (`WHERE week_start_date >= ? AND week_end_date <= ?`) are more verbose than `WHERE iso_week BETWEEN ? AND ?`
- Two columns must be kept in sync — a place to drift if the application accidentally writes a 6-day or 8-day week
- Sorting by week requires sorting by `week_start_date` — fine but requires an extra index column or composite index
- Joins across week-aware tables require two-column matches

### Option B: Epoch-week integer (weeks since 1970-01-05)

Store the week as a single integer representing the number of complete weeks since the Unix epoch's first Monday.

**Pros:**
- Tiny storage footprint (4 bytes)
- Trivially sortable
- Single column

**Cons:**
- Not human-readable in DB output, log lines, or PM dashboards — every consumer needs a conversion function
- Debugging requires running arithmetic in one's head or reaching for a converter
- No globally-agreed definition — the epoch-week scheme is invented for this codebase, so onboarding any external consumer (BI Platform, future Java/non-Java service) requires documenting it

### Option C: ISO-8601 week date string (`"YYYY-Www"` as `CHAR(8)`)

Store the ISO-8601 week-based date format (e.g., `"2026-W20"`) as an 8-character fixed-length string.

**Pros:**
- ISO-8601 weeks have a single global definition — RFC 3339 / ISO 8601-2004 specifies week 1 as the week containing the year's first Thursday; weeks run Monday–Sunday
- `java.time.WeekFields.ISO` produces this format deterministically from any `LocalDate`
- Lexicographically sortable (`"2026-W01" < "2026-W02" < ... < "2026-W52" < "2027-W01"`) — `BETWEEN` and `ORDER BY` work directly
- Human-readable in DB output, log lines, dashboards, and PM/data-team conversations
- Single column, single value, no drift risk
- BigQuery / ClickHouse / Snowflake all support ISO-8601 week extraction natively — no special handling on the BI side
- CHAR(8) is a fixed and minimal storage cost

**Cons:**
- Slightly more verbose than the integer representation (8 bytes vs 4)
- The few "53-week years" in the ISO calendar (e.g. 2026 has 53 weeks if it starts on a Thursday) catch some engineers off guard; needs to be in onboarding docs
- The Java helper `WeekFields.ISO.weekBasedYear()` returns a different value from `LocalDate.getYear()` at year boundaries — must use the week-based year, not the calendar year, when formatting

## Decision

We chose **Option C — ISO-8601 week date string `"YYYY-Www"` stored as `CHAR(8)`**.

A shared `IsoWeekHelper` utility produces the week ID for any `LocalDate` using `java.time.WeekFields.ISO`:

```java
public static String format(LocalDate date) {
  int weekYear = date.get(WeekFields.ISO.weekBasedYear());
  int weekNum  = date.get(WeekFields.ISO.weekOfWeekBasedYear());
  return String.format("%d-W%02d", weekYear, weekNum);
}
```

All week boundary computations use `ZoneId.of("Africa/Lagos")`.

## Rationale

ISO-8601 weeks are the only standard with universal tool support across the JVM, MySQL, ClickHouse (BI Platform), Airflow (data-team ETL), and human-readable dashboards. The "everything works without translation" property is decisive: an engineer querying MySQL, a PM reading a Grafana panel, and an Airflow DAG all see the same `"2026-W20"` string and mean the same thing.

The lexicographic-sort property eliminates an entire class of bugs around date range queries — a `WHERE iso_week BETWEEN ? AND ?` is correct without any temporal reasoning. The fixed `CHAR(8)` column type is index-friendly and small.

The risks (53-week years, week-based vs calendar year confusion) are well-known and addressable with a single shared helper. Centralising the formatting in `IsoWeekHelper` ensures every component computes the same week for the same date.

## Consequences

### Positive

- All week-aware queries become trivially correct: `BETWEEN`, `ORDER BY`, equality joins all work without date parsing
- BI Platform integration is free — Airflow reads `iso_week` from the Kafka event without translation
- Human-readable in every consumer (logs, dashboards, ad-hoc SQL)
- One canonical helper enforces consistency

### Negative

- Engineers unfamiliar with ISO-8601 may initially confuse `WeekFields.ISO.weekBasedYear()` with `LocalDate.getYear()` at year boundaries — fixed by centralising in `IsoWeekHelper`
- 53-week years (when the calendar year has 53 ISO weeks) require an awareness; documented in `IsoWeekHelper` Javadoc and CLAUDE.md

### Risks

- **Risk:** A developer formats a week incorrectly outside `IsoWeekHelper` (e.g., using `LocalDate.getYear()` instead of `weekBasedYear()`), producing a wrong week label at year boundary.  
  **Mitigation:** All week formatting must go through `IsoWeekHelper`. A unit test covers the boundary cases (2025-12-29 → "2026-W01", 2027-01-02 → "2026-W53") and would catch regressions. Code review checks for direct uses of `WeekFields` outside the helper.

- **Risk:** Africa/Lagos timezone choice becomes inconsistent if the platform later expands to a region with different week semantics.  
  **Mitigation:** Week boundary timezone is configurable via a single property. Multi-region rollout (if it ever happens) revisits this ADR explicitly.

- **Risk:** A change in PM expectations (e.g., "we want fiscal weeks, not calendar weeks") would invalidate the choice.  
  **Mitigation:** Fiscal weeks would be a different cohort dimension, layered on top — the underlying calendar-week storage stays. ADR revision would only be needed if calendar weeks are completely abandoned, which the PRD does not suggest.
