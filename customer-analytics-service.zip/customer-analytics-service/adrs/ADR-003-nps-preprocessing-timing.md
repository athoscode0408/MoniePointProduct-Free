# ADR-003: NPS Preprocessing Timing — At Sample Time vs. At Check-In Time

## Status

Accepted

## Date

2026-05-19

## Context

The NPS Sampling Programme introduces a weekly cadence-based survey flow. Unlike BRM and CSAT surveys — which are event-triggered and preprocessed in real time as analytics events arrive — NPS surveys are scheduled in advance via a weekly batch job (`NpsWeeklySamplePreparationJob`). There is no triggering analytics event for NPS.

CAS's survey preprocessing step (`SurveyPreprocessorListener`) fills in user-specific template variable values (e.g., `${user.FirstName}`, `${user.AccountName}`) from the user's `UserAttributes` and builds the final `PreprocessedSurvey` entity that is served to the client at check-in. This step must happen at *some* point before the survey is served.

**The question:** At what point in the NPS flow should preprocessing occur — at the time the user is drawn into the weekly sample, or at the time the user actually checks in and is about to be served?

### Current preprocessing architecture

The existing path:

```
[BRM/CSAT event arrives]
  → RuleParserHandler evaluates SpEL rule
  → publishes EventPreprocessSurveyDTO to event-survey-preprocessor Kafka topic
  → SurveyPreprocessorListener consumes DTO
  → SurveyPreprocessorListener.populateContextValuesMap() fills template vars
    from event.* fields and user.* fields
  → PreprocessedSurvey saved to MySQL with rendered content
  → Client calls GET /check-in → PreprocessedSurvey is returned
```

`SurveyPreprocessorListener.populateContextValuesMap()` reads `event.*` fields from the `VerifiedAnalyticsEventDTO` carried in the `EventPreprocessSurveyDTO`. For NPS, there is no triggering event — `verifiedAnalyticsEventDTO` is `null` in the NPS context. Any attempt to call `event.getType()` or `event.getPlatform()` without a null guard will produce a `NullPointerException`.

### The two options

---

## Options Considered

### Option A: Preprocessing at check-in time (inline, at serve time)

When the user checks in and the check-in service determines they have an NPS survey to serve, invoke the preprocessing pipeline inline before returning the payload. This means:

1. Check-in service detects `nps_weekly_sample.status = PENDING` for the user
2. Check-in service fetches fresh `UserAttributes` from Bigtable
3. Check-in service calls the preprocessor logic directly (or publishes to a synchronous preprocessing endpoint) to fill template variables
4. Returns the rendered `PreprocessedSurvey` to the client

**Pros:**
- User attributes are maximally fresh at the moment of delivery — if a user's account name changed since Monday, they see the updated name
- Preprocessing occurs only for users who actually check in (no wasted preprocessing for PENDING users who never check in)

**Cons:**
- **Requires changes to the check-in API path** — the check-in endpoint currently returns a `PreprocessedSurvey` that was already materialized at evaluation time. Inline preprocessing introduces a new Bigtable read and template-rendering step on the hot check-in path
- **Violates the existing check-in contract** — today the check-in endpoint is a fast, read-only operation (`GET /api/v3/survey/dashboard-info`). Adding a Bigtable fetch and template rendering makes it a mixed read-compute operation with significantly higher latency variance
- **Cannot reuse `SurveyPreprocessorListener`** — the listener is a Kafka consumer operating asynchronously. Inline preprocessing would require extracting and duplicating the preprocessing logic into a synchronous service, or introducing a synchronous preprocessing endpoint that the check-in service calls
- **No NPS `PreprocessedSurvey` rows are pre-created** — the intelligence view and audit trail (which query `PreprocessedSurvey` for NPS survey distribution history) would require check-in to also write the `PreprocessedSurvey` row, adding a write operation to the check-in path
- **Survey content freshness is not a PRD requirement** — the NPS survey template for Phase 1 uses only stable user attributes (`${user.FirstName}`). First names do not change week to week. The freshness benefit is theoretical, not practical

**Verdict:** Rejected. Changes too much of the existing check-in path for marginal benefit.

---

### Option B: Preprocessing at sample time (Monday job, before check-in) — DECIDED

When the sampling job draws a user into the weekly sample on Monday morning, it immediately publishes an `EventPreprocessSurveyDTO` to the `event-survey-preprocessor` Kafka topic. `SurveyPreprocessorListener` processes this message and creates the `PreprocessedSurvey` row before any check-in occurs.

The only required change to an existing production class:

```java
// SurveyPreprocessorListener.populateContextValuesMap() — 1-line null guard:
if (event != null) {
    contextValuesMap.put("event.type",     event.getType());
    contextValuesMap.put("event.platform", event.getPlatform());
    // ... other event.* fields
}
```

When `verifiedAnalyticsEventDTO` is `null` (NPS path), the `event.*` section of the context map is simply not populated. NPS survey templates must not use `${event.*}` variables — this is a content constraint, not a code constraint.

**Pros:**
- **Zero change to the check-in path** — the check-in endpoint continues to be a fast read-only operation returning a pre-materialized `PreprocessedSurvey`
- **Reuses `SurveyPreprocessorListener` without modification** (beyond the null guard) — no duplication of preprocessing logic
- **Lowest blast radius** — only one class in the existing codebase is touched, and the change is a single null guard
- **`PreprocessedSurvey` rows exist for audit** — the intelligence view can query `PreprocessedSurvey` by cohort and ISO week immediately after job execution, without waiting for check-ins
- **Consistent with BRM/CSAT architecture** — the check-in endpoint always serves a pre-materialized row, never an on-the-fly rendered one
- **Full pipeline reuse** — existing Kafka topic, existing listener, existing persistence logic, existing TTL expiry job — all unchanged

**Cons:**
- User attributes are captured at Monday 00:05 Africa/Lagos, not at the moment of check-in. A user whose first name changed during the week would receive the stale name in the survey. In practice, user first names are stable over a 7-day window — this is not a real concern
- Preprocessing occurs for all sampled users, including those who never check in. For a typical 3,200-user weekly sample, this is 3,200 Kafka messages and 3,200 `PreprocessedSurvey` rows — negligible overhead

**Verdict:** Accepted. See Decision section.

---

## Decision

**We chose Option B — preprocessing at sample time.**

The weekly sampling job (`NpsWeeklySamplePreparationJob`) publishes `EventPreprocessSurveyDTO` messages to the existing `event-survey-preprocessor` Kafka topic immediately after drawing each user into the sample. `SurveyPreprocessorListener` processes these messages and creates `PreprocessedSurvey` rows with NPS content.

The single required change to an existing production class is a one-line null guard in `SurveyPreprocessorListener.populateContextValuesMap()` to handle the case where `verifiedAnalyticsEventDTO` is `null`.

---

## Rationale

The core engineering value of this decision is **lowest blast radius**.

The existing check-in path is the most critical user-facing flow in CAS. It is called at every user session start and drives survey delivery for all survey categories (NPS, CSAT, BRM). Modifying this path carries the highest regression risk of any change in the service. Option A requires changes here; Option B does not.

The existing `SurveyPreprocessorListener` is a tested, production-hardened class that has been running correctly for BRM surveys. Option B reuses it with a minimal, isolated change (one null guard). Option A requires extracting or duplicating its logic into a new synchronous code path.

The freshness argument for Option A is not compelling for Phase 1 NPS. The NPS template uses `${user.FirstName}` — a value that does not change week to week for the overwhelming majority of users. If a future NPS question template requires real-time data, that is a new requirement that warrants a new architectural decision at that time.

---

## Consequences

### Positive

- Check-in API path is unchanged — no regression risk to existing survey delivery
- `SurveyPreprocessorListener` is reused with one null guard — no duplication of preprocessing logic
- `PreprocessedSurvey` rows exist before any check-in — audit trail and intelligence queries work from Monday morning
- NPS survey content is consistent for all users in a given week's sample (same Monday snapshot)
- Zero new infrastructure dependencies — existing Kafka topic, existing listener, existing MySQL schema

### Negative

- NPS survey templates are constrained to user-attribute variables only — `${event.*}` variables are not populated for NPS. This is documented as a survey content rule and must be enforced at survey creation time
- User attribute values in the survey are captured at sample time, not at check-in time. Staleness window is at most 7 days — acceptable for Phase 1 NPS use cases

### Implementation notes

- The `EventPreprocessSurveyDTO` carries `verifiedAnalyticsEventDTO = null` for NPS payloads. The null guard in `SurveyPreprocessorListener.populateContextValuesMap()` must be implemented as part of chunk 04 (NPS Sampling spec)
- The `PreprocessedSurvey` row created for NPS must have `cohort_id` populated (from `EventPreprocessSurveyDTO.cohortId`) — this is already handled by the `SurveyPreprocessorListener` cohort propagation added in the NPS Cohort Definition spec (chunk C-02)
- NPS `PreprocessedSurvey` TTL: 7 days (10,080 minutes), managed by the existing `PreprocessedSurveyExpirationTriggerJob`
