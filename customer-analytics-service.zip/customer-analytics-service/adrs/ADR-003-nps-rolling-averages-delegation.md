# ADR-003: Rolling Average NPS Aggregations Delegated to Data Team Airflow, Not Computed in CAS

## Status

Accepted

## Date

2026-05-19

## Context

The NPS PRD (PO1/3295740048) lists rolling-average aggregations as a feature of the PM-facing Intelligence View. Two locations in the PRD reference rolling averages, and they are not identical:

- **PRD §12.2** ("Aggregations") lists `4-week rolling average` and `12-week rolling average` as the primary smoothed views
- **AC-13.2** of US-13 (NPS Intelligence View) requires `4-week, 7-week, 12-week, and 28-week rolling averages` to be displayed alongside the weekly scores

CAS's data flow is event-driven: the Background Worker computes the **atomic weekly NPS score** at week close (Monday 06:00 Africa/Lagos), persists it to `nps_weekly_score`, and publishes `NpsWeeklyScoreComputedEvent` on Kafka topic `event-nps-weekly-close`. Downstream of that Kafka topic is the BI Platform [VERIFIED: `architecture/c4model/02-container.mmd:51`], which is described as "ClickHouse Cloud (data warehouse), Airflow (ETL), and Grafana (dashboards)". The BI Platform's Airflow ETL already reads CAS Kafka topics into ClickHouse, and Grafana already serves PM dashboards.

The decision faced by the team during spec engineering (resolved per impl-spec C-02 in conversation with Mohammed Kamil, 2026-05-18) was: **does CAS compute these rolling averages in MySQL and expose them through the Intelligence View API, or does CAS produce only the atomic weekly score and delegate rolling aggregation to the data team's Airflow pipeline?**

Several forces apply:

1. **Single source of truth.** PMs viewing Grafana dashboards and engineers using the Intelligence View API must see the same numbers — divergence between two implementations of "12-week rolling NPS" would erode trust quickly.
2. **Re-computation cost.** Rolling averages over multiple windows (4/7/12/28-week) computed on 24M+ user-base data are slow if done naively in MySQL — index design becomes critical, JOINs over weeks are needed, and the API needs to respond in < 200 ms.
3. **Skill domains.** Airflow + ClickHouse is the data team's domain — they have established patterns, dashboards, and instrumentation for time-series rolling aggregations. CAS engineers have established patterns for transactional state and event-driven service work, not for analytics queries.
4. **Specification ambiguity.** The PRD body and the AC disagree on the set of rolling windows. The PM is more likely to want to change the set later (a new "8-week" cohort comparison, a "26-week" half-year view), and changing the set is much cheaper in a SQL query against ClickHouse than in a versioned API contract in CAS.

## Options Considered

### Option A: CAS computes rolling averages and exposes them via Intelligence View API

CAS's `NpsIntelligenceController` exposes `GET /api/v3/nps/measurements/{id}/rolling-averages?windows=4,7,12,28` returning rolling-average values computed on demand (or pre-aggregated and stored in another table).

**Pros:**
- Single API surface for PMs hitting the Intelligence View — atomic scores and rolling averages from the same endpoint
- No external dependency on the BI Platform — CAS owns the full delivery
- Cache-friendly: a `nps_weekly_rolling_average` table pre-computed at week close serves reads in < 50 ms

**Cons:**
- Duplicates work the BI Platform already does for every other analytics feed
- API contract becomes a coupling point — adding a 26-week window requires a CAS deploy
- Engineers who don't normally write time-series queries are now responsible for one (window-function SQL + correct boundary semantics for partial windows)
- Risk of divergence: Grafana / ClickHouse dashboards continue showing rolling averages independently, and there is no automated check that the two implementations agree
- Schema bloat: a `nps_weekly_rolling_average` table per window means 4 windows × N measurements × 52 weeks/year of rows just for the cache
- Performance vector — if measurement count grows (e.g. 20 measurements active), naive on-read computation requires JOINs over `nps_weekly_score` for each window, increasing latency

### Option B: CAS publishes only atomic weekly scores; data team Airflow computes rolling averages downstream

CAS computes and persists only the atomic weekly score in `nps_weekly_score`, publishes `NpsWeeklyScoreComputedEvent`. The BI Platform Airflow DAG reads the event, lands it in ClickHouse, and a separate Airflow DAG runs window functions to produce rolling-average views consumed by Grafana. The PM-facing Intelligence View API in CAS exposes only atomic weekly scores; rolling-average dashboards live in Grafana.

**Pros:**
- Single source of truth for time-series analytics: ClickHouse via the data team's pipeline. Grafana, ad-hoc analysts, and any future API consumer all read from the same place.
- Plays to each team's strengths: CAS owns transactional and event-driven work; data team owns analytics aggregations
- Adding a new rolling window is a 5-minute SQL change in the data team's repo, not a CAS deploy
- CAS's API surface stays minimal — fewer endpoints to version, document, and observe
- Eliminates the schema-bloat / cache-management work for rolling-average storage in MySQL

**Cons:**
- PMs hitting the CAS Intelligence View API see atomic scores only; rolling-average values come from Grafana — two consumption surfaces for one feature
- Dependency on the BI Platform pipeline timeliness — if Airflow lags, the rolling-average dashboard lags. CAS atomic scores are still real-time correct.
- A new contract (the `NpsWeeklyScoreComputedEvent` event schema) is consumed by the data team; schema changes need cross-team coordination per CLAUDE.md Kafka rules

## Decision

We chose **Option B — CAS publishes atomic weekly scores; data team Airflow computes rolling averages**.

The Intelligence View API exposes only `nps_weekly_score` (atomic per ISO week). Rolling averages, comparative dashboards, and any cross-measurement analytics live on Grafana, sourced from ClickHouse, populated by Airflow consuming `NpsWeeklyScoreComputedEvent` from Kafka topic `event-nps-weekly-close`.

The set of rolling windows (the 4/7/12/28 vs 4/12 discrepancy in the PRD) becomes a Grafana dashboard configuration decision, not a CAS API contract decision.

## Rationale

The platform already has an established analytics pipeline through the BI Platform. Routing NPS through it is the consistent move — it would be strange to have NPS rolling averages computed in CAS while every other analytics rollup (event-based engagement, retention, churn) flows through Airflow.

The PRD ambiguity (4/12 vs 4/7/12/28) is itself evidence that the rolling-window set is a presentation-layer concern that is likely to change. Putting it in the data team's pipeline gives PMs a fast iteration loop (change a Grafana panel) without coupling to a versioned CAS API.

CAS engineering capacity is also a factor — implementing four parallel window aggregations, with edge cases for partial windows at the start of a measurement, requires SQL idiom expertise that is more naturally found on the data team. Each team plays to its strength.

The "two consumption surfaces" downside is real but tolerable: PMs go to Grafana for trends and CAS Intelligence View for current-week ground truth. This is the same split that already exists for every other analytics feed in the platform.

## Consequences

### Positive

- CAS's Phase 1 chunk count drops; chunk 07 (weekly aggregation engine) trims from ~650 to ~450 lines because rolling-average logic is removed (~200 LOC saved)
- Future PM requests like "add a 26-week trend" are fast (Grafana change), not slow (CAS deploy)
- Single source of truth for time-series analytics — Grafana is canonical
- BI Platform pipeline expertise is leveraged; CAS team focuses on transactional correctness

### Negative

- PMs see split consumption: Grafana for trends, CAS API for current scores. Onboarding docs must explain the split clearly.
- The `NpsWeeklyScoreComputedEvent` Kafka schema becomes a cross-team contract — additive evolution rules apply (per CLAUDE.md Kafka rules)
- If the BI Platform pipeline lags, rolling-average dashboards lag — atomic weekly scores in CAS Intelligence View remain real-time. PMs may see brief inconsistency at week close until Airflow catches up (typically minutes, not hours).

### Risks

- **Risk:** Rolling-average computation in Airflow uses a different week-boundary semantics from CAS, producing subtly different numbers.  
  **Mitigation:** The atomic score event carries an explicit `isoWeek` string (per ADR-002) — Airflow uses the same string as the join key. No date-parsing on the consumer side. Contract test on the event schema asserts the `isoWeek` field is the canonical `YYYY-Www` format.

- **Risk:** The BI Platform team's Airflow pipeline is overloaded and lags significantly (hours), making the PM dashboard unreliable.  
  **Mitigation:** Atomic weekly scores remain available in real-time via the CAS Intelligence View API. PM dashboards include a "data freshness" indicator showing the lag between CAS week-close and Grafana panel update. A P3 alert fires if the lag exceeds 2 hours.

- **Risk:** The Kafka event schema for `NpsWeeklyScoreComputedEvent` evolves in a breaking way (e.g. renaming a field), breaking the Airflow consumer.  
  **Mitigation:** Per CLAUDE.md Kafka rules, schema changes are additive only (new optional fields). Removal or rename of an existing field requires coordination with all consumers — captured in the MR template Default.md checklist. The `event-nps-weekly-close` topic is owned by CAS but consumed by the data team; both teams are listed in CODEOWNERS for the relevant paths.

- **Risk:** A future Intelligence View feature requires showing rolling averages inside CAS (e.g. for an internal alerting use case) — re-opening this ADR.  
  **Mitigation:** Acceptable. This ADR's decision is correct for Phase 1. If a future requirement genuinely forces CAS to compute rolling averages, we revisit and supersede this ADR rather than working around it.
