# ADR-004: NPS Sampling Strategy — Quota Gate vs. Materialized Weekly Sample

## Status

Accepted

## Date

2026-05-19

## Context

The NPS PRD (§7.2–§7.3) specifies that the NPS programme invites a statistically representative sample of eligible users each calendar week:

- **Personal Banking NPS:** 3,200 users per ISO week
- **Business Banking NPS:** 2,134 users per ISO week

PRD §7.3 states explicitly: _"The system shall randomly select eligible users at the start of the week to form the weekly sample. Selection must draw from the full eligible pool to ensure representativeness."_

The team had to decide: **how should the weekly cap be enforced and the sample selected?**

This is not a minor implementation detail. The choice directly determines:
1. Whether the PRD's randomness and representativeness requirements are satisfied
2. Whether the check-in path is affected
3. Whether the sample can be audited after the fact
4. Whether the implementation is robust to re-runs and partial failures

### Background: what "eligible" means

A user is eligible for NPS sampling if they pass all of the following gates:

1. **Cohort gate** (account age + recent transaction — `CohortEligibilityGate`)
2. **Cool-off gate** (90-day window since last trigger + annual cap ≤ 2 — `NpsUserStateService.isInCoolOff()`)
3. **Not already in the current week's sample** (idempotency — UNIQUE INDEX on `nps_weekly_sample`)

Gate 1 and Gate 2 are evaluated against Bigtable user attribute data (account age, last transaction date) and MySQL NPS state data (trigger history). The eligible pool for Personal Banking NPS is estimated at 2–5M users at any given time (from a total population of ~20M personal account holders).

---

## Options Considered

### Option A: Quota Gate — Redis counter at check-in time

At check-in, the service checks whether the weekly quota for the user's cohort has been reached. If not, the user is served the NPS survey and the counter is decremented.

**Mechanism:**

```
Redis key: nps:quota:{cohort_id}:{iso_week}
Initial value: weeklyInvitationCap (e.g. 3200)
On check-in:
  1. Evaluate cohort gates (CohortEligibilityGate + isInCoolOff)
  2. DECR Redis key atomically
  3. If result >= 0: serve the survey; write nps_user_state
  4. If result < 0 (quota exhausted): do not serve
```

**Apparent advantages:**
- No batch job required — no Monday-morning job to maintain
- Lazy evaluation — only processes users who actually check in (no wasted work for non-checking-in users)
- Redis DECR is atomic — no race condition on the counter itself

**Critical failure: violates PRD §7.3 representativeness requirement**

The quota gate does not select from the eligible pool. It selects the **first users to check in**:

- A user who checks in at 06:00 Monday morning is selected simply because they checked in first
- A user who checks in at 14:00 Friday is excluded not because they are ineligible, but because the quota was consumed by earlier check-ins
- The sample is disproportionately composed of users with early-week, early-morning check-in habits — a systematically non-random selection

**The PRD (§7.3)** requires random selection from the full eligible pool. The quota gate delivers the opposite: deterministic selection of early checkers. This violates the randomness requirement and produces a biased sample that will systematically over-represent certain user behaviours in the NPS score.

**Additional problems:**

| Problem | Impact |
|---|---|
| No audit trail of who was selected | Post-hoc analysis cannot determine which users were in the weekly sample — the counter is ephemeral |
| Redis is a new infrastructure dependency for NPS | NPS currently has zero Redis dependency; adding one introduces a new failure mode (Redis unavailability blocks NPS delivery) |
| Counter expiry must be managed | Redis TTL must be set correctly for each week; incorrect TTL allows quota carry-over between weeks |
| Re-run safety is undefined | If the check-in service restarts mid-week, the counter state in Redis is the only record; a Redis flush would reset the quota and allow over-selection |
| Cap is at check-in, not at sample preparation | Users can pass gate evaluation (cool-off check) and then find the quota exhausted at the moment of serve — wasted gate evaluation work |
| Bigtable scan is still required | Even with a quota gate, the cool-off gate requires reading `UserAttributes` (account age, last transaction date) from Bigtable for every user who checks in — the scan is not eliminated, just deferred to check-in time and per-user rather than batched |

**Verdict:** Rejected. Structurally cannot satisfy PRD §7.3's representativeness requirement.

---

### Option B: Materialized Weekly Sample — Monday batch job — DECIDED

A Quartz job (`NpsWeeklySamplePreparationJob`) runs at Monday 00:05 Africa/Lagos. It:

1. Scans the full eligible user population from Bigtable (server-side filtered by account age and transaction recency)
2. Applies the cool-off gate for each candidate (MySQL point-reads)
3. Draws a random sample of up to `weeklyInvitationCap` users from the filtered pool (`Collections.shuffle()` + `subList()`)
4. Inserts one `NpsWeeklySample` row per sampled user (status = PENDING)
5. Publishes preprocessing messages for each sampled user to the existing Kafka topic

The check-in path then performs a simple lookup: does the user have a `nps_weekly_sample` row with `status = PENDING` for the current ISO week? If yes, serve the survey and transition to SERVED. No gate evaluation happens at check-in time for NPS.

**Why this satisfies PRD §7.3:**

The sample is drawn at week start by explicitly shuffling the full eligible pool and selecting the first N users after shuffling. This is a textbook random sample with uniform probability for every eligible user. No user has a structural advantage based on their check-in time.

**Why the check-in path benefits:**

Check-in becomes a simple lookup (`SELECT ... WHERE user_id = ? AND iso_week = ? AND status = 'PENDING'`) — a single indexed point-read. It does not require Bigtable access, SpEL evaluation, or gate logic. This is faster and less error-prone than inline gate evaluation.

**Additional advantages:**

| Property | Materialized sample behaviour |
|---|---|
| Randomness | Explicit shuffle of full eligible pool — truly random |
| Representativeness | Full eligible pool considered; no selection bias from check-in timing |
| Audit trail | One `nps_weekly_sample` row per sampled user; permanent record |
| Re-run safety | UNIQUE INDEX on `(user_id, cohort_id, iso_week)` — idempotent upsert |
| Cap enforcement | Enforced at sample preparation time — cap cannot be exceeded |
| Check-in complexity | Single indexed lookup — no gate logic |
| Week-close cleanup | Expiry job transitions PENDING → EXPIRED |
| Infrastructure | MySQL only — no new dependencies |

**Cons:**

| Property | Concern | Mitigated by |
|---|---|---|
| Preprocessing for non-checkers | 3,200 Kafka messages + `PreprocessedSurvey` rows created for users who never check in that week | Negligible overhead; existing TTL expiry job handles cleanup |
| Monday job latency | If the job fails or is delayed, no sample exists for that week | ShedLock prevents double-run; AlertManager alert on job failure; 4-hour lock timeout provides retry window |
| Memory for shuffle | 2–5M eligible userIds in-memory for shuffle step | ~250 MB at 50 bytes/userId — within Worker `-Xmx`; reservoir sampling available as fallback |

**Verdict:** Accepted. See Decision section.

---

## Decision

**We chose Option B — materialized weekly sample.**

`NpsWeeklySamplePreparationJob` runs Monday 00:05 Africa/Lagos, scans Bigtable for eligible users, applies cool-off exclusion, draws a random sample up to the weekly cap, creates `NpsWeeklySample` rows (status = PENDING), and publishes preprocessing messages. The check-in path performs a single point-read to determine whether the user has a pending sample.

---

## Rationale

Option A's failure is fundamental, not incidental. The PRD requires random selection from the full eligible pool. A quota gate selects first-to-check-in users. These are incompatible requirements. No amount of Redis engineering can make a quota gate produce an unbiased random sample — the selection mechanism itself is biased by definition.

Option B satisfies the PRD requirement by design: an explicit random shuffle of the eligible pool at week start is the standard implementation of random sampling in a batch context.

The operational concern with Option B (Monday job failure) is manageable. The job runs in a 4-hour window before business hours. ShedLock prevents concurrent runs. A monitoring alert on job completion fires before the first users check in on Monday morning, giving the engineering team time to intervene. The existing `PreprocessedSurveyExpirationTriggerJob` pattern provides a proven blueprint.

The memory concern for in-memory shuffle (2–5M userIds) is bounded and within the Worker's heap budget. If it becomes a concern at scale, reservoir sampling (`k = weeklyInvitationCap`) processes the stream in one pass without materialising the full list, reducing peak memory to O(k) regardless of eligible pool size.

---

## Consequences

### Positive

- PRD §7.3 randomness and representativeness requirements are satisfied by construction
- Check-in path is a simple indexed lookup — no gate logic, no Bigtable access at check-in time
- Permanent audit trail: `nps_weekly_sample` records which users were selected, when, and what happened
- Cap enforcement at preparation time — the weekly cap is a hard ceiling, not a race condition
- Job re-runs are idempotent — UNIQUE INDEX prevents duplicate rows; re-running after a partial failure is safe
- No new infrastructure dependencies — MySQL only

### Negative

- A batch job that must be maintained and monitored — this is an operational overhead compared to a stateless quota gate
- Preprocessing occurs for all sampled users, including those who never check in that week (offset by the cleanup value of the audit trail)
- Memory pressure during the shuffle step for very large eligible pools — mitigated by configurable batch size and reservoir sampling fallback

### Monitoring requirement

An AlertManager alert must fire if `nps_weekly_sample` contains zero `PENDING` rows for the current ISO week after 01:00 Africa/Lagos on Monday (i.e., the job should have completed within 1 hour of its 00:05 start). This alert is specified as an acceptance criterion in the sampling spec observability bundle.
