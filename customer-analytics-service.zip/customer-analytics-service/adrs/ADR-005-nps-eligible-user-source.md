# ADR-005: NPS Eligible User Source — Bigtable Scan vs. External Snapshot

## Status

Accepted

## Date

2026-05-19

## Context

`NpsWeeklySamplePreparationJob` must enumerate all users who are eligible for NPS sampling — approximately 24 million users across personal and business banking segments. Eligibility requires checking two user attributes:

1. **Account age** (`onboardingDate`) — must be at least `cohort.minAccountAgeDays` days old (60 days for Phase 1 cohorts)
2. **Recent transaction** (`lastTxnDate`) — must have a transaction within the last `cohort.transactionWindowDays` days (30 days for Phase 1 cohorts)

Both attributes are stored in CAS's **Bigtable user attribute store** (`UserAttributes`), accessed via `BigtableDataClient`. They are also replicated to downstream data stores (ClickHouse, data team snapshots), but CAS does not currently query those stores — it reads user attributes exclusively from Bigtable.

The only existing read method on the user attribute store is:

```java
UserAttributesStorage.findUser(String userId, String businessAccountNumber)
```

This is a **point lookup** — it reads a single row by row key. It cannot enumerate users matching a predicate. A new method is needed to support the sampling job.

The team had to decide: **where should the sampling job source the list of eligible users?**

---

## Options Considered

### Option A: Bigtable full-table scan with server-side column filters — DECIDED

Use `BigtableDataClient.readRows(Query)` — the standard Bigtable Java client API — to issue a server-side filtered scan of the `UserAttributes` table. The query applies `RowFilter` conditions on the `onboardingDate` and `lastTxnDate` column values, returning only rows that pass both filters.

A new method is added to `UserAttributesRepositoryService`:

```java
Stream<String> scanEligibleUsers(
    int     minAccountAgeDays,
    int     transactionWindowDays,
    boolean requireRecentTransaction,
    int     batchSize
);
```

This method issues paginated `readRows(Query)` calls, each with server-side `RowFilter` logic limiting the response to rows where:

- `onboardingDate ≤ (today - minAccountAgeDays)` (account is old enough)
- `lastTxnDate ≥ (today - transactionWindowDays)` (transaction is recent enough, when `requireRecentTransaction = true`)

Pagination uses a row-key bookmark (the last row key of each batch becomes the exclusive start key for the next batch), so the full table is scanned in `batchSize`-row segments.

**Pros:**
- **No new external dependencies** — `BigtableDataClient` is already in the CAS dependency tree; `readRows(Query)` is the standard API for filtered scans
- **Server-side filtering** — rows that fail eligibility predicates are filtered by Bigtable before being sent to the CAS JVM; network transfer is proportional to eligible rows only, not total rows
- **Authoritative source** — Bigtable is the system of record for user attributes in CAS; no synchronisation lag or data freshness concerns
- **Batch size is configurable** (`nps.sampling.batch-size`, default 1,000) — controls memory pressure and throughput independently
- **Pagination is safe** — row-key bookmark pagination is the idiomatic Bigtable pattern for full-table scans
- **No data team coordination** — the sampling job is entirely self-contained; adding a new cohort does not require a data team schema change

**Cons:**
- **Read quota consumption** — a full-table scan of 24M rows consumes significant Bigtable read quota; must be accounted for in the Bigtable capacity plan
- **Scan duration** — at typical filtered scan throughput (~3M rows/minute), a 24M-row table takes 5–10 minutes; this must fit within the ShedLock window and before business hours
- **New scan method** — `UserAttributesRepositoryService.scanEligibleUsers()` is a new code path that must be carefully tested and rate-limited; a misconfigured filter could return the full 24M user set with no filtering

**Encoding requirement:** `onboardingDate` and `lastTxnDate` must be stored as `YYYY-MM-DD` ISO-8601 strings in Bigtable for lexicographic byte-range filters to be semantically correct (ISO-8601 date sort order equals chronological order). This is the current encoding — must be verified before implementation.

**Verdict:** Accepted. See Decision section.

---

### Option B: Data-team provides weekly eligible-user snapshot in MySQL

The data team runs a weekly query against their data warehouse, produces a list of eligible users (passing account age + transaction recency criteria), and loads it into a CAS-accessible MySQL table. The sampling job reads from this snapshot table instead of scanning Bigtable.

**Apparent advantages:**
- Offloads the scan computation to the data team's infrastructure
- The snapshot table would also be available for reporting and analysis

**Critical problems:**

**Synchronisation risk:** The data team snapshot must be ready before 00:05 Monday Africa/Lagos when the sampling job runs. Any delay in the data team's pipeline — ETL job failure, warehouse maintenance, holiday — causes the sampling job to find a stale or empty snapshot. The NPS sample for that week would be incorrect or absent. The NPS programme's reliability becomes coupled to the data team's pipeline reliability.

**Asynchrony and freshness lag:** The data team's snapshot reflects data as of its last extraction time — typically midnight UTC (01:00 Africa/Lagos). A user who made their qualifying transaction at 23:30 Sunday Africa/Lagos might not appear in the snapshot if extraction ran before that transaction was indexed. The sampling job would miss them.

**Coordination overhead:** Every new cohort or change to eligibility criteria (e.g., changing `minAccountAgeDays` from 60 to 90 for a new segment) requires a coordinated change between the CAS team and the data team. This creates a deployment dependency and slows iteration on cohort parameters.

**New infrastructure dependency:** CAS does not currently consume data from the data team's MySQL export table. Establishing this data pipeline introduces a new data contract, new monitoring requirements, and a new failure mode.

**Verdict:** Rejected. Introduces synchronisation risk, deployment coupling, and a new external dependency that is not justified when Bigtable can serve the use case directly.

---

### Option C: ClickHouse query

Query CAS's ClickHouse analytics store for users passing the eligibility criteria. ClickHouse supports fast analytical queries over large datasets.

**Problems:**

**CAS does not currently query ClickHouse.** The service reads user attributes exclusively from Bigtable. Adding a ClickHouse dependency requires:
- New ClickHouse client library in the Maven POM
- Connection configuration for CAS Worker → ClickHouse
- New query pattern in the service layer
- Monitoring and circuit-breaker configuration for the new dependency

**ClickHouse is an analytics replica, not the source of truth.** User attribute data flows into ClickHouse from Bigtable asynchronously. Replication lag could cause the sampling job to miss recently-onboarded users or include users whose `lastTxnDate` was updated after the last ClickHouse sync.

**Overkill for a batch query:** ClickHouse's advantage is sub-second interactive analytical queries. The sampling job runs once per week and can tolerate a 5–10 minute scan. Bigtable's streaming scan API is more appropriate for this pattern than a ClickHouse SQL query.

**Verdict:** Rejected. New dependency for no benefit over Option A; replication lag introduces correctness risk.

---

## Decision

**We chose Option A — Bigtable full-table scan with server-side column-value filters via `BigtableDataClient.readRows(Query)`.**

A new method `UserAttributesRepositoryService.scanEligibleUsers()` is added to encapsulate the scan logic. The method uses `RowFilter` to apply `onboardingDate` and `lastTxnDate` predicates server-side, returning a paginated `Stream<String>` of eligible userIds to the sampling job.

---

## Rationale

Bigtable is the authoritative source of user attributes in CAS. `BigtableDataClient.readRows(Query)` is the standard API for server-side filtered scans — it is the correct tool for this use case, not a workaround. The filter pushdown means CAS only receives rows for users who pass the eligibility predicates, minimising network transfer and JVM memory pressure.

Options B and C both introduce external dependencies and synchronisation risks that are not present with Option A. The data team dependency (Option B) is particularly dangerous for a weekly job: if the snapshot is unavailable when the job fires at 00:05 Monday, there is no fallback and the week's sample is lost. Option A is entirely self-contained — the sampling job controls its own data access with no external process dependencies.

The scan duration concern (5–10 minutes for 24M rows) is acceptable given the job's scheduling context. The job runs at 00:05 Monday in a 4-hour ShedLock window. Even a 12-minute worst-case scan completes before business hours with significant margin.

---

## Consequences

### Positive

- Sampling job is self-contained — no external process dependencies, no synchronisation risk
- Bigtable is the authoritative source of user attributes — no freshness lag, no replication concerns
- Server-side filtering minimises network transfer and JVM memory pressure
- No new CAS infrastructure dependencies
- Cohort eligibility parameters (`minAccountAgeDays`, `transactionWindowDays`) are passed as scan parameters — changing them requires no data team coordination

### Negative

- New scan method `UserAttributesRepositoryService.scanEligibleUsers()` introduces a new code path that must be tested with Bigtable integration tests
- Bigtable read quota consumption increases once per week by ~24M filtered row reads — must be tracked in the Bigtable capacity plan and reviewed with the infrastructure team before production activation
- A misconfigured or missing RowFilter would cause the scan to return the full 24M-user table — this must be guarded by integration tests that verify filter correctness before deployment

### Implementation constraints

- `onboardingDate` and `lastTxnDate` must be encoded as `YYYY-MM-DD` UTF-8 strings in Bigtable for lexicographic byte-range comparisons to be semantically correct. Verify encoding against the live Bigtable schema before writing production RowFilter logic.
- The scan method must be paginated via row-key bookmark to avoid holding a single long-lived gRPC stream. `batchSize` (default 1,000) controls the pagination window.
- Integration tests for `scanEligibleUsers()` must run against a Bigtable emulator or a dedicated test table to avoid scan load on the production table during CI.
- Bigtable read quota monitoring must be in place before enabling `nps.programme.enabled` in production — add a Grafana panel showing `bigtable.read_rows_count` for the CAS Worker service identity, scoped to the user attributes table.
