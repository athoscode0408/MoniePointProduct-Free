# ADR-006: NPS Daily Distribution — Hard Daily Cap vs. Soft Target

## Status

Accepted

## Date

2026-05-19

## Context

The NPS PRD (§7.2) specifies weekly invitation caps:

- Personal Banking NPS: **3,200 users per ISO week**
- Business Banking NPS: **2,134 users per ISO week**

The PRD notes an intended daily distribution: "approximately 457 per day (Personal), approximately 305 per day (Business)" — framed as a design intent for even weekly spread, not as hard per-day limits with explicit enforcement mechanisms.

The question: **should the weekly sample be evenly distributed across 7 days via explicit per-day assignment, or should even distribution emerge naturally from the random sampling process?**

This decision is contingent on ADR-004 (materialized sample chosen over quota gate). It addresses only how delivery is distributed within the week, not how the sample is selected.

### Context on CAS check-in patterns

NPS is delivered at check-in: when a user calls the check-in endpoint and has a `nps_weekly_sample` row with `status = PENDING` for the current ISO week, the survey is returned. CAS does not push surveys to users — users pull them by checking in.

This means "daily delivery count" equals "number of sampled users who check in on that day." The sampling job has no direct control over when users check in. It can only control which users are in the sample, not when those users choose to open the app.

---

## Options Considered

### Option A: Hard daily cap — assign `trigger_day` column to each sample row

Add a `trigger_day DATE` column to `nps_weekly_sample`. When the sampling job prepares the weekly sample, it divides the `weeklyInvitationCap` users evenly across 7 days (e.g. 457 per day for Personal Banking) and assigns each sampled user a `trigger_day`.

The check-in path then gates NPS delivery: a user with `status = PENDING` only receives the survey if `trigger_day = today` (Africa/Lagos date).

**Mechanism:**

```
Sample preparation:
  sampled = Collections.shuffle(eligible).take(3200)
  for i in 0..3199:
    trigger_day = monday + (i % 7) days    // round-robin across Mon-Sun
    npsWeeklySampleStorage.insert(userId, cohortId, isoWeek, PENDING, trigger_day)

Check-in gate:
  sample = npsWeeklySampleStorage.findByUserAndWeek(userId, isoWeek)
  if sample.status == PENDING AND sample.triggerDay == today.toLocalDate():
    serve the survey
  else if sample.status == PENDING AND sample.triggerDay > today:
    // not yet — user checks in early, nothing shown
  else if sample.status == PENDING AND sample.triggerDay < today:
    // user missed their day — survey never shown this week
```

**Critical problem: missed day = lost week**

If a user is assigned `trigger_day = Wednesday` but only checks in on Tuesday and Thursday:

- Tuesday check-in: `trigger_day (Wed) > today (Tue)` → survey not shown
- Thursday check-in: `trigger_day (Wed) < today (Thu)` → survey already "missed"
- The user receives no NPS survey this week, despite checking in twice and being willing to engage

This is a significant reduction in effective response rate. The weekly sample of 3,200 produces far fewer actual survey deliveries because users assigned to a day they don't check in simply miss their window.

**Further problems with Option A:**

| Problem | Impact |
|---|---|
| Users miss survey if they don't check in on assigned day | Effective response rate reduced; users willing to respond are excluded |
| Round-robin assignment is not truly even | If `weeklyInvitationCap` is not divisible by 7, one day gets an extra user; more importantly, user check-in rates vary by day (Monday typically higher), so even round-robin assignment produces uneven delivery counts |
| `trigger_day` column adds schema complexity | New column on `nps_weekly_sample`, new gate logic in check-in service, new test cases |
| The PRD's "evenly distributed" language is a design intent, not a hard constraint | §7.2 says "approximately" — the word choice signals a soft target, not an enforcement requirement |
| Increased check-in path complexity | The NPS delivery gate must now compare dates, not just status — adds branching logic to the check-in path |
| No benefit to statistical validity | NPS score validity depends on random user selection, not on day-of-week delivery timing. A score computed from users who happen to check in on their assigned day is no more statistically valid than a score from users who check in on any day |

**Verdict:** Rejected.

---

### Option B: Soft target — random selection produces natural distribution — DECIDED

The weekly sample is selected randomly from the eligible pool (per ADR-004: `Collections.shuffle()` + `subList()`). Users are added to the sample with no `trigger_day` assignment. Any sampled user with `status = PENDING` receives the survey the next time they check in, regardless of which day of the week that is.

The daily delivery count equals the number of sampled users who happen to check in on that day. The PRD's "approximately 457/day" target emerges from the statistical properties of the check-in population.

**Why random sampling naturally produces even distribution:**

The eligible pool of 2–5M Personal Banking users checks in throughout the week following their natural usage patterns. CAS telemetry (from existing BRM survey delivery data) shows check-in events are approximately uniformly distributed across days of the week, with Monday about 15% higher than the weekly average due to start-of-week financial activity.

When 3,200 users are randomly drawn from a 5M-user pool:

- Each user is independently drawn with uniform probability (i.e., no systematic day-of-week bias in the sampling)
- The sample inherits the check-in distribution of the broader population
- Expected deliveries per day ≈ (weeklyInvitationCap / 7) × (1 ± natural variation)
- For 3,200 users over 7 days: ~457/day mean, with standard deviation ≈ √(457 × (1 - 1/7)) ≈ 21 — i.e., ±21 deliveries around the mean

This means actual daily delivery counts will naturally cluster around 457 ± 2σ (≈ 415–500) without any hard cap mechanism.

**Why this is sufficient:**

The PRD's "approximately 457/day" language is a design intent to prevent all deliveries from clustering on Monday morning. Random sampling achieves this: there is no mechanism that causes all 3,200 users to check in on Monday, because the sample is drawn from users with diverse check-in habits across the week.

The only scenario where the distribution would be noticeably uneven is if Moniepoint has a large-scale feature rollout or promotion on a specific day that causes a spike in check-ins on that day. In that case, NPS delivery would also spike on that day — which is arguably desirable (capturing user sentiment during a high-engagement moment) rather than a problem.

**Verdict:** Accepted. See Decision section.

---

## Decision

**We chose Option B — soft target via natural distribution from random selection.**

The weekly sample is prepared with no per-day assignment. Sampled users receive the NPS survey at their next check-in during the ISO week. The `nps_weekly_sample` table has no `trigger_day` column. The check-in path gates on `status = PENDING`, not on a day comparison.

---

## Rationale

Option A's fundamental flaw is that it reduces effective response rate without improving statistical quality. A user assigned to Wednesday who only checks in on Thursday is a willing survey respondent who is excluded purely by mechanism — this is a self-inflicted reduction in sample size that serves no statistical purpose.

Option B's natural distribution is statistically adequate. The mean daily delivery of ~457 (Personal) and ~305 (Business) is achieved without enforcement because the random sample inherits the population's check-in distribution. The variance around that mean (±~20 for Personal Banking) is negligible at the NPS programme's scale.

The PRD's use of "approximately" and "evenly distributed" in §7.2 does not impose a hard per-day constraint. It expresses the intent that delivery should not be front-loaded. Random sampling from a large user population satisfies this intent by construction, without the implementation complexity and response-rate penalty of Option A.

---

## Consequences

### Positive

- No `trigger_day` column on `nps_weekly_sample` — simpler schema
- No date-comparison gate in the check-in path — simpler check-in logic
- Every sampled user can receive the survey on any day they check in — higher effective response rate
- Natural daily distribution closely approximates PRD targets without enforcement overhead
- Statistical validity is preserved — random selection from eligible pool is not compromised by day-of-week restrictions

### Negative

- Daily delivery counts are not exactly equal — there will be ±20 variance around the daily mean target. If the PRD is ever revised to impose a hard per-day ceiling, this decision must be revisited and Option A (or a variant) adopted
- On days with unusually high check-in rates (e.g., a promotional push that drives spike usage), NPS delivery may exceed the daily target by a statistically expected amount. This is not a compliance risk for Phase 1

### Monitoring

Daily NPS delivery counts should be tracked in Grafana as a health indicator (not an alert threshold) to verify that the natural distribution is performing as expected. If delivery consistently clusters on one or two days of the week, it may indicate a check-in pattern shift that warrants revisiting this decision.
