# ADR-007: NPS Reminder State Storage — Extend `NpsWeeklySample` vs. Separate Table vs. JSON

## Status

Accepted

## Date

2026-05-19

## Author

Mohammed Kamil (`mohammed.kamil@moniepoint.com`)

---

## Context

The NPS Reminder feature (PRD §9.1, §9.2) requires CAS to track two new pieces of state per `(user_id, cohort_id, iso_week)` tuple:

1. **When the user dismissed the survey** (`dismissed_at TIMESTAMP`). Required to evaluate the minimum interval condition: `NOW() - dismissed_at >= reminderMinIntervalHours * 60 minutes`.
2. **Whether the reminder has already been served** (`reminder_served_at TIMESTAMP`). Required to enforce the single-reminder-per-week invariant: no further reminders after the first reminder is served.

The question is: **where should this state live?**

### Constraints

- Both fields are per `(user_id, cohort_id, iso_week)` — the exact composite key that `NpsWeeklySample` already owns. There is a natural one-to-one relationship between a reminder state record and a sample record.
- The `dismissed_at` timestamp must be written atomically with the `NpsWeeklySample.status = DISMISSED` transition. The `reminder_served_at` timestamp must be written atomically with the `NpsWeeklySample.status = REMINDER_SERVED` transition.
- The reminder eligibility check is evaluated at every check-in call for users with a DISMISSED sample. Latency matters — the check must not introduce additional database round trips on the check-in hot path beyond what is already required.
- The week-close expiry job (`NpsWeeklyExpiredSampleJob`) already operates on `NpsWeeklySample` rows. It does not need to interact with reminder state separately.
- All CAS-owned writable state lives in MySQL (see ADR-009 for the canonical statement of this constraint).

---

## Options Considered

### Option A: Extend `NpsWeeklySample` with two nullable TIMESTAMP columns — DECIDED

Add `dismissed_at TIMESTAMP NULL` and `reminder_served_at TIMESTAMP NULL` directly to the `nps_weekly_sample` table.

**Mechanism:**

```sql
ALTER TABLE nps_weekly_sample
    ADD COLUMN dismissed_at        TIMESTAMP NULL AFTER served_at,
    ADD COLUMN reminder_served_at  TIMESTAMP NULL AFTER dismissed_at;
```

The `NpsWeeklySample` entity gains two new nullable fields:

```java
@Column(name = "dismissed_at")
private Instant dismissedAt;

@Column(name = "reminder_served_at")
private Instant reminderServedAt;
```

`dismissed_at` is set in the same transaction as `status = DISMISSED`. `reminder_served_at` is set in the same transaction as `status = REMINDER_SERVED`.

**Eligibility evaluation:** The `NpsReminderEligibilityChecker` evaluates all four reminder conditions on the already-fetched `NpsWeeklySample` object. No additional database queries are required.

**Verdict:** Accepted.

---

### Option B: Separate `nps_reminder_state` table

Create a new table `nps_reminder_state` with columns `(id, user_id, cohort_id, iso_week, dismissed_at, reminder_served_at, version)` and a UNIQUE INDEX on `(user_id, cohort_id, iso_week)`.

**Mechanism:**

```sql
CREATE TABLE nps_reminder_state (
    id                 BIGINT    NOT NULL AUTO_INCREMENT,
    user_id            VARCHAR(50) NOT NULL,
    cohort_id          BIGINT    NOT NULL,
    iso_week           CHAR(8)   NOT NULL,
    dismissed_at       TIMESTAMP NULL,
    reminder_served_at TIMESTAMP NULL,
    version            INT       NOT NULL DEFAULT 0,
    ...
    UNIQUE INDEX uq_nrs_user_cohort_week (user_id, cohort_id, iso_week)
);
```

**Problems:**

1. **Duplicated composite key.** The `(user_id, cohort_id, iso_week)` key is already owned by `nps_weekly_sample`. Creating a second table with the identical composite key produces a one-to-one relationship where neither side has a clear reason to be split from the other.
2. **Additional JOIN or second query at check-in.** Evaluating reminder eligibility now requires fetching both the `NpsWeeklySample` row and the `NpsReminderState` row. This is either a JOIN (complicates the repository) or a second point-read (adds one MySQL round trip to the check-in hot path).
3. **Synchronisation burden.** Two tables must be kept consistent: a DISMISSED transition writes to `nps_weekly_sample` AND creates/updates a `nps_reminder_state` row. If either write fails, the system is in an inconsistent state. Wrapping both in the same transaction mitigates this but adds overhead for what is essentially a column addition.
4. **Expiry complexity.** The `NpsWeeklyExpiredSampleJob` transitions `NpsWeeklySample` rows at week close. With a separate table, the job would also need to clean up `nps_reminder_state` rows, or accept that they accumulate indefinitely.
5. **No benefit.** The only argument for a separate table is if the reminder state is expected to grow much faster than the sample state, or if it needs to be queried independently at significant scale. Neither is true here: reminder state has a one-to-one relationship with sample rows and is only ever queried alongside the sample row.

**Verdict:** Rejected.

---

### Option C: Store reminder state in `PreprocessedSurvey.additionalData` JSON

`PreprocessedSurvey.additionalData` is a `VARCHAR` / `TEXT` column that stores a JSON blob of supplemental data for the survey. Reminder fields could be stored as JSON keys:

```json
{
  "dismissed_at": "2026-05-19T14:30:00Z",
  "reminder_served_at": null
}
```

**Problems:**

1. **Not indexed.** JSON values in `additionalData` cannot be used in a WHERE clause without a full-text scan or an expression index. Querying "all dismissed NPS surveys where the interval has elapsed" is not possible efficiently.
2. **Not typed.** JSON parsing introduces a deserialization step at read time. Timestamp comparisons require parsing the string first. Option A evaluates all four conditions on in-memory Java fields.
3. **Wrong ownership.** `PreprocessedSurvey` models the per-survey delivery lifecycle (one row per user per survey cohort per week). `NpsWeeklySample` models the sampling programme's tracking of the same `(user, cohort, week)` unit. The reminder state belongs with the sampling programme's record, not with the survey delivery record.
4. **Coupling.** Adding reminder logic to `PreprocessedSurvey.additionalData` would make the survey delivery entity aware of NPS-specific programme state. `PreprocessedSurvey` is a general entity shared by BRM, CSAT, and NPS. Polluting it with NPS reminder fields violates the separation of concerns.
5. **Version incompatibility.** If `additionalData` is already used for other fields, schema migration of the JSON blob requires care to avoid breaking existing JSON readers.

**Verdict:** Rejected.

---

## Decision

**We chose Option A — extend `NpsWeeklySample` with two nullable TIMESTAMP columns (`dismissed_at`, `reminder_served_at`).**

The DDL change is:

```sql
ALTER TABLE nps_weekly_sample
    ADD COLUMN dismissed_at        TIMESTAMP NULL AFTER served_at,
    ADD COLUMN reminder_served_at  TIMESTAMP NULL AFTER dismissed_at;
```

Both columns are nullable. Existing rows in any status (`PENDING`, `SERVED`, `RESPONDED`, `EXPIRED`, `ABANDONED`) have both columns as `NULL`. No data migration is required.

---

## Rationale

Option A co-locates all per-`(user_id, cohort_id, iso_week)` state in a single row. The composite key already exists; the two timestamp columns are an additive extension with zero duplication and zero additional query complexity.

Option B introduces a second table that duplicates the composite key without adding any structural benefit. It adds operational complexity (synchronisation, expiry, JOIN) for a use case that is a natural extension of the sample row's existing responsibility.

Option C stores state in a column that was not designed for structured programmatic queries. It is slower to evaluate (JSON parsing), harder to index, and semantically wrong (survey delivery entity should not own programme tracking state).

The timing symmetry is also compelling: `dismissed_at` is set at the same moment `status = DISMISSED` is written; `reminder_served_at` is set at the same moment `status = REMINDER_SERVED` is written. Both writes are naturally in the same row update.

---

## Consequences

### Positive

- No new table, no JOIN, no second query on the check-in path.
- Reminder eligibility check is fully in-memory once the `NpsWeeklySample` row is fetched.
- `dismissed_at` and `reminder_served_at` are atomically consistent with `status` — they are written in the same row update, within the same `@Transactional` boundary.
- `NpsWeeklyExpiredSampleJob` requires no changes — it already operates on `NpsWeeklySample` rows by status; the new columns are transparent to the expiry logic.
- DDL migration is additive (two nullable columns) — backward compatible, no downtime required.
- The full reminder lifecycle is visible in a single row: `served_at`, `dismissed_at`, `reminder_served_at`, `responded_at` — giving a complete time-series audit trail of a user's NPS interaction for the week.

### Negative

- `nps_weekly_sample` gains two columns that are `NULL` for the majority of rows (only DISMISSED and REMINDER_SERVED rows ever have non-null values). At the expected scale of ~5,300 rows per week, this is negligible.
- Engineers unfamiliar with this decision may question why reminder state is on the sample table and not a separate entity. This ADR serves as the canonical explanation.

### Risks

| Risk | Mitigation |
|---|---|
| `dismissed_at` set to a stale value if status transitions are not applied atomically | Service layer enforces: `dismissed_at = NOW()` is always written in the same `@Transactional` as `status = DISMISSED`. No code path sets status without setting the corresponding timestamp. |
| `reminder_served_at` overwritten on a double-reminder bug | `NpsReminderEligibilityChecker` condition C-4 (`reminder_served_at IS NULL`) prevents a second reminder. `@Version` optimistic lock prevents concurrent double-write. |
| Future reminder feature with cross-week semantics requires this decision to be revisited | Documented here. If PRD ever adds cross-week reminders or multiple-reminder-per-week capability, a separate table (Option B) becomes appropriate. This is not a Phase 1 requirement. |
