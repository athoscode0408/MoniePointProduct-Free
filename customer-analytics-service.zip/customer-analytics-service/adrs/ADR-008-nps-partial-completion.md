# ADR-008: NPS Partial Completion Handling — ABANDONED vs. DISMISSED Distinction

## Status

Accepted

## Date

2026-05-19

## Author

Mohammed Kamil (`mohammed.kamil@moniepoint.com`)

---

## Context

The NPS survey has two questions:

- **Q1:** The NPS rating scale (0–10). Submitting Q1 captures the user's numeric score.
- **Q2:** An open-text follow-up ("What's the main reason for your score?"). Submitting Q2 is optional but provides qualitative context.

When a user starts the NPS survey but does not complete both questions, two distinct outcomes are possible:

1. **Explicit dismissal.** The user taps "Ask Me Later" or the X button before answering Q1. The user has not submitted any response. This is a deliberate deferral signal.
2. **Partial completion.** The user answers Q1 (submits the numeric score) but exits without answering Q2. The user has contributed a score but skipped the qualitative follow-up.

CAS already uses an `ABANDONED` state in the `PreprocessedSurveyState` enum to represent "survey was served but not fully completed." The NPS Sampling spec (`2026-05-19-nps-sampling.md`) introduced `NpsWeeklySample.status = DISMISSED` for the explicit dismissal case.

**The question this ADR resolves:** Should partial completion (Q1 answered, Q2 not) be treated the same as explicit dismissal for the purposes of reminder eligibility? Specifically: should ABANDONED flow through the same `DISMISSED` status path and therefore be eligible for a reminder?

### Why this decision matters

PRD §9.1 explicitly states:

> "The reminder is triggered only when the user has explicitly dismissed the survey. Partial completion — where the user has submitted a rating but not the follow-up text — is treated as a completed interaction for the purposes of reminder eligibility. A reminder must not be sent after a partial completion."

If CAS were to treat ABANDONED the same as DISMISSED (Option A below), the reminder would fire for users who have already provided their NPS score. This would violate the PRD and expose those users to potential anchoring bias on their follow-up text (they already know their numerical score when the reminder appears).

---

## Options Considered

### Option A: Treat ABANDONED and DISMISSED identically — set `NpsWeeklySample.status = DISMISSED` for both

Map both "explicit dismiss before Q1" and "Q1 submitted, Q2 skipped" to `NpsWeeklySample.status = DISMISSED`. Both user behaviours would be reminder-eligible. The ABANDONED state would not be used in `NpsWeeklySample`.

**Benefits:**
- Simpler state machine — only one "left-without-completing" status on `NpsWeeklySample`.
- No need for the client to distinguish between dismiss events and Q1 submission events.

**Problems:**

1. **Violates PRD §9.1.** The PRD is explicit that partial completion does not qualify for a reminder. Treating ABANDONED as DISMISSED re-prompts users who have already submitted their NPS score, which the PRD prohibits.
2. **Anchoring bias on Q2.** A user who submitted a score of 4 and then receives a reminder knows their score. Their Q2 follow-up text may be anchored to having already committed to a 4 rating. This compromises the qualitative independence of Q2.
3. **Double-counting the trigger.** The NPS score from Q1 is a valid data point. If CAS re-prompts the user, any subsequent Q2 response is not a fresh qualitative answer — it is a continuation of a partially completed survey. Downstream analytics systems would need to handle this ambiguity.
4. **Loss of ABANDONED analytics signal.** ABANDONED in `PreprocessedSurvey.state` is an existing analytics marker for "survey was served and partially completed." If we map Q1-only submissions to DISMISSED on `NpsWeeklySample`, the relationship between the two tables becomes inconsistent: `NpsWeeklySample.status = DISMISSED` (no answer) while `PreprocessedSurvey.state = ABANDONED` (partial answer). This inconsistency would confuse analytics queries.
5. **No simplification in practice.** The client still needs to send distinct events for "user submitted Q1" versus "user tapped dismiss" — because the backend needs to know whether to set `responded_at` on `NpsWeeklySample` (Q1 submit) or `dismissed_at` (dismiss). The client distinction exists regardless of this ADR's outcome.

**Verdict:** Rejected.

---

### Option B: Preserve ABANDONED ≠ DISMISSED distinction — DECIDED

Maintain separate handling for the two outcomes:

- **Explicit dismiss (before Q1):** `NpsWeeklySample.status = DISMISSED`, `dismissed_at = NOW()`. Reminder eligible.
- **Q1 submitted, Q2 not submitted:** `NpsWeeklySample.status = RESPONDED`, `responded_at = NOW()`. `PreprocessedSurvey.state = ABANDONED` preserved. NOT reminder eligible.

**Mechanism:**

The client emits distinct event types for the two actions:

| User action | Client event | Backend outcome |
|---|---|---|
| User taps dismiss / X / "Ask Me Later" (before answering Q1) | `NPS_SURVEY_DISMISSED` | `NpsWeeklySample.status = DISMISSED`, `dismissed_at = NOW()`. `PreprocessedSurvey.state = DISMISSED`. Reminder eligible after interval. |
| User submits Q1 rating (confirms numeric score) | `NPS_SURVEY_Q1_SUBMITTED` | `NpsWeeklySample.status = RESPONDED`, `responded_at = NOW()`. `PreprocessedSurvey.state = ABANDONED`. Not reminder eligible. Cool-off applies. |

The `NpsReminderEligibilityChecker` condition C-1 (`sample.status == DISMISSED`) ensures that only explicitly dismissed samples are evaluated for reminder eligibility. Q1-only submissions result in `status = RESPONDED`, which fails C-1.

**Verdict:** Accepted.

---

## Decision

**We chose Option B — preserve the ABANDONED ≠ DISMISSED distinction.**

The state mapping is:

| User behaviour | `NpsWeeklySample.status` | `PreprocessedSurvey.state` | Reminder eligible | Cool-off applies |
|---|---|---|---|---|
| Dismissed before Q1 | `DISMISSED` | `DISMISSED` | **Yes** | Yes (triggered at SERVED) |
| Q1 submitted, Q2 not | `RESPONDED` | `ABANDONED` | **No** | Yes (triggered at SERVED) |
| Q1 + Q2 submitted | `RESPONDED` | `COMPLETED` | No (terminal) | Yes (triggered at SERVED) |
| No action, week closes | `ABANDONED` | `ABANDONED` | No (terminal) | Yes (triggered at SERVED) |

**Client contract (acceptance criterion):**

The mobile client team MUST ensure that the following two user actions emit distinct server-side events:

1. User taps "Ask Me Later", X, or any dismiss affordance before submitting a rating → emit `NPS_SURVEY_DISMISSED` (or the platform-canonical equivalent dismiss event type)
2. User confirms/submits their NPS numeric score (Q1 input is committed) → emit `NPS_SURVEY_Q1_SUBMITTED` (or the platform-canonical equivalent scoring event type)

If both actions emit the same event, CAS cannot distinguish them and the reminder logic will either fire for ABANDONED users (if both map to DISMISSED) or never fire (if both map to RESPONDED). This is a hard requirement, not a preference.

---

## Rationale

Option A's core flaw is that it conflates two semantically distinct user behaviours. "I want to answer this later" and "I answered the rating but don't want to give a reason" are different signals. The PRD recognises this distinction and explicitly prohibits reminder on partial completion.

Beyond PRD compliance, there are two practical data quality arguments for Option B:

1. **ClickHouse analytics.** The `PreprocessedSurvey.state = ABANDONED` value is published downstream to ClickHouse as part of the NPS programme's response-rate funnel. It represents the "Q1-answered, Q2-skipped" step in the funnel. Losing this signal by mapping Q1-only submissions to DISMISSED would collapse the distinction between "zero engagement" (dismissed) and "partial engagement" (Q1 answered) in all downstream reporting.

2. **Cool-off correctness.** Whether the user dismisses or answers Q1 only, the cool-off trigger was written at SERVED time. Both behaviours consume the user's cool-off and annual trigger budget slots equivalently. The ABANDONED signal on `PreprocessedSurvey` does not affect eligibility calculations; it is purely an analytics marker.

The client event taxonomy distinction is a necessary consequence of Option B. However, as noted above, the client already needs to distinguish these events to correctly call different API paths (dismiss vs. score submission). The requirement is not new work for the client team — it is an existing product requirement that becomes an acceptance criterion for the reminder feature.

---

## Consequences

### Positive

- PRD §9.1 compliance: reminder fires only on genuine dismissal, not on partial completion.
- No anchoring bias introduced on Q2 responses: users re-prompted after a reminder have not previously committed to a numeric score.
- `PreprocessedSurvey.state = ABANDONED` analytics signal preserved in ClickHouse — response-rate funnel retains "Q1-only" as a distinct funnel step.
- `NpsReminderEligibilityChecker` condition C-1 is a clean status equality check (`status == DISMISSED`) — no compound conditions, no "not RESPONDED" logic.
- `NpsWeeklySample.status = RESPONDED` for Q1-only submissions correctly prevents any reminder for those users without requiring a special exclusion rule.

### Negative

- Mobile client team must implement and validate the distinguish-dismiss-from-Q1-submit event taxonomy before the reminder feature is enabled. This is a cross-team dependency.
- The counter-intuitive `NpsWeeklySample.status = RESPONDED` for a "partial completion" requires documentation — engineers may expect ABANDONED to be used on the sample table as well. This ADR serves as the canonical explanation.
- `PreprocessedSurvey.state = ABANDONED` and `NpsWeeklySample.status = RESPONDED` exist in apparent tension for the Q1-only case. Engineers querying both tables must understand that "RESPONDED" on the sample table does not imply "COMPLETED" on the survey — it implies "engaged enough to consume the trigger." The design doc (`docs/design/nps-reminder-design.md §4`) documents the comparison table.

### Risks

| Risk | Mitigation |
|---|---|
| Client emits the same event for dismiss and Q1 submit | Acceptance criterion is written into the reminder impl spec. QA test plan must include a specific test case for dismiss-vs-Q1 event differentiation. CAS backend logs a `WARN` if it receives a Q1-submit event on a sample that is not in `SERVED` or `REMINDER_SERVED` status. |
| Future spec re-introduces a "re-trigger on ABANDONED" requirement | This ADR would need to be revisited and a new option evaluated. The status mapping would need to change, along with the client event contract. Any such change requires a PRD update — the current PRD explicitly prohibits it. |
| Downstream analytics queries that use `NpsWeeklySample.status = RESPONDED` to mean "fully responded" produce incorrect funnel counts | Analytics queries MUST filter by `PreprocessedSurvey.state` (COMPLETED vs. ABANDONED) for funnel accuracy. The sampling spec and this ADR document this. Grafana dashboards for NPS funnel must join to `PreprocessedSurvey.state`, not rely on `NpsWeeklySample.status` alone. |
