# ADR-009: NPS Cool-Off State Storage — Re-Affirm CAS-Owned MySQL Table

## Status

Accepted

## Date

2026-05-19

## Author

Mohammed Kamil (`mohammed.kamil@moniepoint.com`)

---

## Context

The NPS Sampling Programme requires a **90-day global cool-off** per user across all NPS measurements, plus an **annual trigger cap of 2 per calendar year** (PRD §10, AC-05.1 through AC-05.6, AC-12.1 through AC-12.5). The cool-off state must be:

1. **Written at trigger time** — atomically with the `nps_weekly_sample.status = SERVED` update (PRD §10 bullet 3: "must be recorded at the point of trigger, not at the point of response").
2. **Globally consistent** — one `user_id` maps to exactly one cool-off record, shared across all active NPS measurements.
3. **Writable by CAS** — the Customer Analytics Service owns the trigger decision and must be able to write the state in the same transaction.

The full options analysis — including detailed pros/cons of Bigtable, `PreprocessedSurvey` reuse, and CAS-owned MySQL — was conducted and documented in the original decision:

> **Archived:** `adrs/archive/ADR-001-nps-cool-off-storage.md`

This ADR (ADR-009) re-affirms the decision from ADR-001 in the context of the cool-off spec (separate from the broader sampling engine spec), records the per-category state table pattern as an established platform convention, and closes out any remaining ambiguity about Bigtable write capability.

### Constraints that remain true at the time of this spec

- **Bigtable is read-only from CAS.** The architecture diagram [VERIFIED: `architecture/c4model/02-container.mmd:43`] declares the CAS–Bigtable relationship as `"Reads user attributes for eligibility"`. No write path has been opened since ADR-001. Opening a write path is an external-dependency workstream of unknown timeline and is not being pursued for this spec.
- **All CAS-owned writable state lives in MySQL.** Every existing CAS entity (`Survey`, `PreprocessedSurvey`, `SurveyAlert`, etc.) is persisted in MySQL. CAS has no current capability to write to any other persistent store.
- **NPS cool-off must be independent of CSAT cool-off.** The two programmes have different cool-off periods, different classification schemes, and different annual caps. Sharing state would couple their configurations.

---

## Options Considered

### Option A: Store cool-off in Bigtable on the user record

Write `last_nps_triggered_date` and `trigger_count_year` to the user's Bigtable row alongside `onboardingDate` and `lastTxnDate`.

**Status: Blocked — read-only access.**

Bigtable is read-only from CAS. Opening a write path would require data-team approval, IAM role changes, and coordination with the batch-ingestion pipeline that populates `UserAttributes`. The timeline is unknown and the NPS Phase 1 delivery cannot block on it.

Full analysis in `adrs/archive/ADR-001-nps-cool-off-storage.md` §Options Considered, Option A.

---

### Option B: Derive cool-off from `PreprocessedSurvey` rows

Query the most recent `PreprocessedSurvey` row with `category=NPS` for the user and use its `created_on` timestamp as the trigger date.

**Status: Rejected — semantic conflict and scaling issues.**

`PreprocessedSurvey` is keyed on `(user_id, survey_id)` and models per-survey lifecycle state. Cool-off is a cross-survey, per-user programme concept. Querying "most recent NPS row across all measurements" requires a scan-style query over a table that grows as O(users × measurements × weeks). No clean place to store `trigger_count_year`. The approach conflates per-survey lifecycle with cross-survey programme state.

Full analysis in `adrs/archive/ADR-001-nps-cool-off-storage.md` §Options Considered, Option B.

---

### Option C: CAS-owned `nps_user_state` MySQL table (DECIDED)

Create a dedicated MySQL table `nps_user_state` owned by CAS. One row per user who has ever been triggered for NPS. The table holds all NPS cool-off state: `last_nps_triggered_date`, `trigger_year`, `trigger_count_year`, and `last_nps_response_classification`.

**Status: Accepted.**

---

## Decision

We use **Option C — a CAS-owned `nps_user_state` table in MySQL**, as first decided in `adrs/archive/ADR-001-nps-cool-off-storage.md`.

The schema is:

```sql
CREATE TABLE nps_user_state (
    id                              BIGINT       NOT NULL AUTO_INCREMENT,
    user_id                         VARCHAR(50)  NOT NULL,
    last_nps_triggered_date         DATE         NULL,
    last_nps_response_classification ENUM('PROMOTER','PASSIVE','DETRACTOR') NULL,
    trigger_year                    SMALLINT     NULL,
    trigger_count_year              SMALLINT     NOT NULL DEFAULT 0,
    version                         INTEGER      NOT NULL DEFAULT 0,
    created_by                      VARCHAR(100) NULL,
    created_on                      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by                VARCHAR(100) NULL,
    last_modified_on                TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                 ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT uq_nps_user_state_user_id UNIQUE (user_id)
);
```

The DDL is to be raised in the DB migrations repository. CAS code depends on the table existing before the service with NPS sampling enabled is deployed.

---

## Rationale

Option A is blocked by an external dependency on an unknown timeline. Option B conflates two semantically distinct concepts and produces a query pattern that does not scale to 24M+ users. Option C aligns with how CAS already manages all writable state — in MySQL — and provides a clean, dedicated home for NPS programme state with natural support for:

- **Optimistic concurrency** via `BaseEntity.@Version` — prevents double-trigger on concurrent check-in calls without any custom locking logic
- **Atomic trigger write** — MySQL transaction semantics ensure `nps_user_state` and `nps_weekly_sample.status=SERVED` are written atomically in the same transaction (both commit or both roll back)
- **Annual cap storage** — `trigger_year` and `trigger_count_year` columns live in the same row and are updated atomically with the trigger date
- **Per-category independence** — CSAT gets its own `csat_user_state` table (see below) with independently configurable cool-off and cap settings

### Per-category state table pattern

This ADR establishes the following platform convention:

> **Every survey category that has a cool-off mechanism owns a dedicated `{category}_user_state` table.**

| Category | Table | Status |
|---|---|---|
| NPS | `nps_user_state` | Accepted (this ADR) |
| CSAT | `csat_user_state` | Future — CSAT cool-off spec |
| BRM | (no cool-off; event-triggered with no recurrence limit) | N/A |

The per-category pattern avoids coupling between programmes that have fundamentally different cool-off semantics. A single shared `survey_user_state` table (with a `category` discriminator column) would be appropriate only if a fifth or sixth category appears with the same schema shape — the team should revisit that trade-off at that point.

This convention is also documented in `CLAUDE.md` under Survey Domain Rules.

---

## Consequences

### Positive

- NPS spec is fully unblocked — no dependency on the data team or Bigtable write infrastructure.
- Bigtable schema is unchanged; no coordination cost with the data team for NPS Phase 1.
- Concurrent double-trigger is prevented at the database level via `@Version` — zero custom locking code required.
- The CSAT cool-off spec can copy this pattern directly (`csat_user_state`) without renegotiation.
- Table is compact — one row per user who has ever been triggered, not one per survey instance. Expected steady-state size: O(triggered users) ≪ O(total users).

### Negative

- Adds an additional MySQL table to operate, monitor, and back up.
- Per-category state means engineers implementing future survey categories must know to create their own `{category}_user_state` table. Mitigated by documenting the convention in `CLAUDE.md`.

### Risks

| Risk | Mitigation |
|---|---|
| Two state tables (NPS + CSAT) become hard to reason about as the platform grows | Document the pattern in `CLAUDE.md`. If a fifth or sixth category appears, consider a unified table with a `category` discriminator column |
| MySQL row-level locking contention if one user generates many concurrent check-in attempts | `@Version` produces an immediate `OptimisticLockException` (no lock-wait), caught and resolved to already-served state. No retry loop |
| A future team opens a Bigtable write path and duplicates the cool-off state | Document in the Bigtable user attributes schema (external to this repo) that CAS is the authoritative source of NPS cool-off state. Do not dual-write |
