# ADR-010: NPS Annual Trigger Cap Enforcement Strategy

## Status

Accepted

## Date

2026-05-19

## Author

Mohammed Kamil (`mohammed.kamil@moniepoint.com`)

---

## Context

PRD AC-12.5 states: "A user must not be triggered for NPS more than twice in any calendar year." This is a hard ceiling that applies independently of the 90-day cool-off. A user who has been triggered twice already in the current year must be excluded from NPS sampling even if 90 or more days have elapsed since their last trigger.

The `nps_user_state` table (established in ADR-009) stores two columns to support this cap:

- `trigger_year SMALLINT NULL` — the calendar year in which the user was last triggered
- `trigger_count_year SMALLINT NOT NULL DEFAULT 0` — the count of triggers in `trigger_year`

At the start of each new calendar year, a user's `trigger_count_year` must effectively reset to zero so they become eligible again. The question this ADR resolves is: **how is the year rollover enforced, and where does the reset logic live?**

---

## Options Considered

### Option A: DB CHECK constraint

Add a `CHECK (trigger_count_year <= 2)` constraint to the `nps_user_state` table.

**Status: Rejected.**

A static `CHECK` constraint cannot express year-based logic because it has no access to the current date. The constraint would block any increment of `trigger_count_year` beyond 2, but it could not reset the count at year boundary. The constraint would also be the wrong abstraction — it would prevent the increment from ever going above 2 for any year, meaning a user triggered once in 2025 and once in 2026 would be blocked from their second 2026 trigger (because `trigger_count_year` would be at 2 from the prior-year accumulation if the reset logic failed). This option only works in combination with a reset mechanism, and that mechanism must live somewhere — making the constraint redundant once the reset logic is correct.

Additionally, `CHECK` constraints in MySQL 8.0 are evaluated but do not provide the same transactional isolation guarantees as application-layer validation under concurrent writes. The `@Version` optimistic lock in the application layer is the correct concurrent-write guard.

---

### Option B: Application-code year rollover in `NpsUserStateService.writeTriggered()` (DECIDED)

In the `writeTriggered()` method, compare `trigger_year` against `LocalDate.now().getYear()` at write time. If they differ, reset `trigger_count_year = 1` and update `trigger_year` to the current year. If they match, increment `trigger_count_year`.

**Status: Accepted.**

Year rollover is evaluated lazily — exactly at the moment of a new trigger write. No scheduled job or background process is needed. The logic is simple, testable, and co-located with the write that changes the state.

---

### Option C: Scheduled yearly reset job

A Quartz job running on January 1 at 00:05 resets `trigger_count_year = 0` and `trigger_year = NULL` for all rows in `nps_user_state`.

**Status: Rejected.**

This approach introduces operational risk:

- If the job fails to run (ShedLock contention, pod restart, maintenance window, clock skew), no users get their cap reset. The first week of January produces zero eligible users, which is a silent correctness failure.
- The job runs once per year — a single failure point with no retry window.
- Resetting every row in `nps_user_state` is a table-wide write that is operationally expensive and risky near a high-traffic period (new year app usage spike).
- The application-code approach (Option B) produces the same correct outcome with zero operational overhead.

---

## Decision

We use **Option B — application-code year rollover in `NpsUserStateService.writeTriggered()`**.

### Algorithm

```
function writeTriggered(userId) → NpsUserState:

    state ← NpsUserStateStorage.findByUserId(userId)  // or null
    today ← LocalDate.now()
    currentYear ← today.getYear()

    if state is null:
        state ← new NpsUserState(userId = userId)

    state.lastNpsTriggeredDate ← today

    if state.triggerYear is null OR state.triggerYear != currentYear:
        // Year has changed (or first-ever trigger) — reset
        state.triggerYear ← currentYear
        state.triggerCountYear ← 1
    else:
        // Same year — increment
        state.triggerCountYear ← state.triggerCountYear + 1

    return NpsUserStateStorage.save(state)  // @Version guard
```

The cool-off gate reads the cap in `isInCoolOff()`:

```
if state.triggerYear == currentYear AND state.triggerCountYear >= yearlyTriggerCap:
    return true   // excluded — annual cap hit
```

Note: the gate does NOT need to evaluate the rollover case. If `trigger_year != currentYear`, the count does not apply to the current year — the user has zero triggers so far this year and passes the annual cap check.

---

## Rationale

Year rollover requires comparing `trigger_year` to the current calendar year at runtime. This is a runtime value (`LocalDate.now().getYear()`) that cannot be expressed in a static DB constraint. Application code is the only correct place for this comparison.

The lazy evaluation approach (rollover happens at the next trigger write) means no background job is needed. A user who was last triggered in 2025 and is triggered again in 2027 will have their count reset at the moment of the 2027 trigger write — no batch reset required in 2026 (a year in which they were never triggered anyway).

This approach has been used successfully for similar per-year counters in high-volume transaction systems where scheduled resets are operationally fragile.

---

## Consequences

### Positive

- Zero operational overhead — no scheduled job, no annual maintenance window, no ShedLock competition.
- Logic is testable with a single unit test: set `trigger_year = 2025`, call `writeTriggered()` in "2026" (mock `LocalDate.now()`), assert `trigger_year = 2026` and `trigger_count_year = 1`.
- Rollover is atomic with the trigger write — there is no window in which `trigger_count_year` is reset but `lastNpsTriggeredDate` has not yet been updated.
- Works correctly across arbitrary multi-year gaps (e.g. a user last triggered in 2024, not triggered in 2025, triggered in 2026 — count correctly starts at 1 for 2026).

### Negative

- The `nps_user_state` table accumulates stale `trigger_year` values for users who are never triggered in the current year. These stale rows do not cause incorrect behaviour (the gate evaluates `trigger_year == currentYear`, so a 2025 row does not affect 2026 eligibility), but they occupy space. Mitigated by: table is compact (one row per ever-triggered user), and the stale year value is resolved lazily on the user's next trigger.

### Edge Cases Documented

| Scenario | Behaviour | Correct? |
|---|---|---|
| First trigger ever (no row) | New row created; `triggerYear = currentYear`; `triggerCountYear = 1` | Yes |
| Second trigger same year | `triggerCountYear` increments to 2 | Yes |
| Third trigger same year attempted | Blocked by `isInCoolOff()` annual cap gate before `writeTriggered()` is called | Yes |
| Triggered Dec 31 2026, sampled Jan 1 2027 | At Jan 1 write: `trigger_year` flips to 2027; `trigger_count_year` resets to 1 | Yes |
| User triggered twice in 2026, not triggered in 2027, sampled in 2028 | At 2028 write: `trigger_year=2026 != 2028`; reset to `triggerYear=2028`, `count=1` | Yes |
| Server JVM restarts at year boundary between two concurrent writes | `@Version` ensures one write wins; both see `LocalDate.now()` from their own thread — both would reset if they see new year | Correct — both trigger the same reset branch; `@Version` ensures exactly one commits |
| `trigger_year` column is null (existing row from before column was added) | `null != currentYear` evaluates to true; reset branch taken; correct | Yes |

### Constraints Not Used

A `CHECK (trigger_count_year <= 2)` constraint is intentionally NOT added to the table. Reasons:

1. The constraint is enforced at the application layer by `isInCoolOff()` before `writeTriggered()` is ever called on a capped user.
2. A DB constraint would mask bugs in the application layer rather than testing them — bugs should surface as assertion failures in tests, not as DB exceptions in production.
3. `yearlyTriggerCap` is configurable at runtime via `SurveyBody.yearlyTriggerCap`. A hardcoded DB constraint cannot track a runtime-configurable cap value.
