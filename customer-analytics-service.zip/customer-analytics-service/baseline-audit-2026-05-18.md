# Baseline Codebase Audit Report

**Repo:** `customer-analytics-service`
**Domain:** CX Analytics — survey delivery (NPS, CSAT, BRM), analytics event routing (Braze, Mixpanel, CustomerIO, GA, Singular), check-in pre-commitment eligibility engine
**Date:** 2026-05-18
**Auditor:** Claude Code (claude-sonnet-4-6)

---

## Summary

| Dimension | Value |
|---|---|
| Modules | 1 (single-module Maven) |
| Java version | 22 |
| Spring Boot version | 3.3.3 |
| Java classes (main) | 253 total; ~151 non-excluded (excl. DTOs, entities, exceptions, config, security, enums) |
| Test files | 92 |
| Test coverage estimate (class level) | ~44% of non-excluded classes have a matching test file — **ESTIMATE** |
| Endpoint test ratio | 21 controller endpoints; MockMvc used in 75+ assertion calls across 7 controller test files — **ESTIMATE** |
| CRITICAL findings | 4 |
| WARNING findings | 7 |
| INFO findings | 5 |

> Run `./mvnw jacoco:report` for accurate line/branch coverage. Target: 80% instruction, 60% branch. Current JaCoCo gate: 50% line / 50% branch.

---

## CRITICAL (fix before adopting new-code rules)

**[SECURITY] RSA private key committed to repository**
- `rsa-private-pkcs8.pem` contains a live RSA private key and was committed in git history (commit `77eaacc — "Implement Braze Auth for Web and Mobile Client"`). The key is not gitignored.
- The public key `rsa-public.pem` is also committed.
- **Remediation:** Rotate the key pair immediately. Add `*.pem` to `.gitignore`. Remove the files from git history using `git filter-branch` or BFG Repo Cleaner. Store keys in a secrets manager (Vault/K8s secrets) and inject at runtime via environment variables or mounted volumes.

**[PII] Account number logged at INFO level in production code paths**
- Three separate service classes log `accountNumber` at `INFO` level using SLF4J structured args:
  - `PreprocessedSurveyRepositoryService.java:174` — `log.info("User data returned for user {} and account {} from bigtable is {}", userId, accountNumber, user)`
  - `SurveyEventCompletionService.java:219` — same pattern
  - `SurveyEvaluatorListener.java:63` — same pattern
- Account numbers are PII / financial identifiers. Logging them at INFO in a production service will write them to log aggregators (New Relic, Splunk, etc.).
- **Remediation:** Mask or hash account numbers before logging. Use a `PiiMasker` utility (e.g., hash first 4 + last 4 visible). Downgrade to DEBUG if the full value is operationally necessary.

**[SECURITY] `BadRequestException` imported from Tomcat internal API (`org.apache.coyote`) rather than the domain hierarchy**
- `SurveyController.java`, `AdminSurveyController.java`, `AdminBrazeConfigController.java` import `org.apache.coyote.BadRequestException` (a Tomcat internal) and throw it from controller methods.
- The domain has `BaseRuntimeException → NotFoundException / ServerException` but no `BadRequestException` — so controllers are forced to use the Tomcat class.
- The `GenericControllerAdvice` handles `org.apache.coyote.BadRequestException`, which means the handler itself is coupled to a server-internal API.
- **Remediation:** Add `BadRequestException extends BaseRuntimeException` to `common/exception/`. Replace all `org.apache.coyote.BadRequestException` imports. Update `GenericControllerAdvice` to handle the domain exception.

**[PII] `AuthenticatedUser` has `@ToString` with PII-sensitive fields**
- `AuthenticatedUser.java` is annotated `@ToString` (Lombok) and includes fields: `email`, `phone`, `resetPassword`.
- Any `log.info("... {}", user)` call (including the implicit ones in test output, error messages, or debug traces) will render all these fields.
- **Remediation:** Replace `@ToString` with `@ToString(exclude = {"email", "phone", "resetPassword"})` or a hand-written `toString()` that masks those fields.

---

## WARNING (fix incrementally, opportunistically)

**[PATTERN] Kafka publishing via direct `KafkaTemplate.send()` — no outbox pattern**
- All Kafka publishing goes through `AbstractKafkaEventPublisher.publishEvent/publishEvents` which calls `kafkaTemplate.send()` directly.
- There is no transactional outbox table: DB writes and Kafka publishes are not atomic. If the DB write succeeds and Kafka publish fails (before the fallback retry lands in `EventRetry`), the event may be silently dropped or partially retried.
- The fallback retry (`EventRetry` / `EventDeadLetter`) only covers downstream provider failures (Braze, CIO, etc.) — not the upstream Kafka publish step.
- **Remediation:** Evaluate adopting the outbox pattern for at-least-once guarantee on the Kafka publish path. At minimum, document the known gap in CLAUDE.md and ensure the `EventRetry` mechanism explicitly covers Kafka publish failures.

**[RESILIENCE] No Resilience4j circuit-breakers or retry decorators on external HTTP calls**
- All external HTTP calls use OpenFeign with `FallbackFactory` (Braze, CustomerIO, Mixpanel, GA, Singular) for graceful degradation on failure.
- However, no Resilience4j `CircuitBreaker`, `Retry`, or `Bulkhead` decorators are configured on any Feign client or outbound call. `@EnableRetry` is present in `CustomerIOConfig` but no `@Retryable` annotations were found anywhere.
- The Feign fallback factories log the failure and enqueue for retry, but there is no circuit-opening to prevent cascading failures under sustained provider outages.
- **Remediation:** Add Resilience4j `CircuitBreakerConfig` for at least the Braze and CustomerIO integrations (highest traffic). Use the `Decorators` API pattern as per `claude-engineering/patterns/circuit-breaker-fallback.md`.

**[PATTERN] No HTTP logging filter / request-response audit trail**
- No `HttpLoggingFilter`, `CommonsRequestLoggingFilter`, or custom `OncePerRequestFilter` was found that logs inbound HTTP requests and responses.
- Correlation IDs are correctly propagated via `CorrelationIdFilter`, but there is no structured request-level audit log (method, path, status, duration).
- **Remediation:** Add a lightweight `OncePerRequestFilter` that logs request method, path, correlation ID, response status, and duration at INFO. Ensure the body is NOT logged (PII risk) or is masked before logging.

**[PATTERN] `@ToString(callSuper = true)` on entities — potential PII in logs**
- Eleven JPA entities use `@ToString(callSuper = true)`: `Survey`, `SurveyAlert`, `PreprocessedSurvey`, `EventRetry`, `EventDeadLetter`, `UnsupportedEvent`, `SupportedEvent`, `AnalyticsEventProvider`, `BrazeApiKey`, `MixpanelApiKey`.
- `PreprocessedSurvey` stores `user` (userId/account number), `survey` (full JSON payload), and `additionalData`. Logging an entity instance will dump all these fields.
- `SurveyAlert` similarly stores user references.
- **Remediation:** Add `@ToString(exclude = {"user", "survey", "additionalData"})` on `PreprocessedSurvey` and `SurveyAlert`. Review all entities with `callSuper = true` for sensitive fields.

**[PATTERN] Exception message propagated directly to error response bodies**
- `BannerService.java:71`, `BrazeAuthHandler.java:33`, `BrazeCampaignsHandler.java:45,52`, `WebhookService.java:63,97` construct `ResponseEntity` bodies using `exception.getMessage()` directly.
- If an exception message contains stack trace fragments, database error details, or internal path information, these will be exposed to API callers.
- `GenericControllerAdvice` also forwards `exception.getMessage()` for most exception types.
- **Remediation:** Sanitize or genericize exception messages before placing them in API responses. Provide safe user-facing messages; log the full exception internally.

**[RULES] `@Autowired` field injection in `ObjectMapperHelper`**
- `ObjectMapperHelper.java:28` uses `@Autowired` constructor injection (which is acceptable for a constructor), but it's explicitly annotated — per CLAUDE.md rules, `@Autowired` should not be used; rely on Spring's implicit constructor injection with `@RequiredArgsConstructor` instead.
- **Remediation:** Remove the `@Autowired` annotation from the constructor; the single-constructor rule means Spring will inject it automatically.

**[RULES] Missing `@Trace(dispatcher = true)` on several public controller methods**
- CLAUDE.md mandates `@Trace(dispatcher = true)` on all public controller methods for New Relic instrumentation.
- Missing on: `AnalyticsController.pushEvent`, `AnalyticsControllerV2.pushEvent`, `UserInfoController.userInfo`, all methods in `AdminSurveyController`, `AdminBrazeConfigController`, `AdminEventConfigController`, `BrazeController`, `WebhookController`, `JobController`.
- `SurveyController` fully complies; `AnalyticsControllerV3` fully complies.
- **Remediation:** Add `@Trace(dispatcher = true)` to all public controller methods that lack it.

---

## INFO (noted, low priority)

**[MIGRATION] No Flyway migrations present**
- `db/migration/` exists but contains only `.gitkeep`. The actual DDL schema is in `dockers/db_seed/0000_init_schema.sql` (a Docker seed file, not a migration).
- Schema drift risk: if the DB schema changes are applied manually or via seed files, there is no migration history and no automated schema validation at startup.
- **Remediation:** Migrate the seed SQL into Flyway-format versioned scripts (`V1__init_schema.sql`, etc.) in `db/migration/`. This is the convention already established in CLAUDE.md.

**[DEPENDENCY] Spring Boot 3.3.3 — one minor version behind current 3.4.x**
- Spring Boot 3.3.x is in OSS support. Spring Boot 3.4.x is the current stable release as of early 2026. Two minor versions behind is approaching the warning threshold.
- **Remediation:** Plan an upgrade to 3.4.x in the next sprint cycle. Review Spring Cloud compatibility matrix before upgrading.

**[DEPENDENCY] `commons-codec:1.15` — old version**
- `commons-codec:1.15` (released 2021) is bundled explicitly. Current version is 1.17. Spring Boot manages this transitively; the explicit pinning may prevent BOM-managed upgrades.
- **Remediation:** Remove the explicit version pin and allow Spring Boot BOM to manage it, or update to `1.17`.

**[PATTERN] No idempotency key handling on mutation endpoints**
- Mutation endpoints (`POST /api/v1/push-event`, `POST /api/v2/push-event`, `POST /api/v3/event`, `POST /api/v3/events`) do not accept or enforce an idempotency key header.
- The `id` field on `BaseAnalyticsEventRequestDTO` serves as a de-duplication key in downstream processing, but it is not enforced at the HTTP layer with a standard `Idempotency-Key` header pattern.
- **Remediation:** This is informational for an analytics event pipeline — event de-duplication by `id` downstream may be sufficient. Evaluate whether HTTP-layer idempotency is required for the check-in / survey trigger endpoints.

**[TESTING] `AnalyticsController` (v1), `AnalyticsControllerV2`, `BrazeController`, `WebhookController` — tests exist but `@Trace` and `@PreAuthorize` annotation coverage not verified**
- Tests exist for all four controllers. However, the `@PreAuthorize` check on `BrazeController.getBrazeAuth` is absent — the endpoint has no `@PreAuthorize`, meaning any authenticated user can call it without a specific authority. This may be intentional but should be confirmed.
- **Remediation:** Confirm intent on `getBrazeAuth`. If it should be role-restricted, add `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_CAMPAIGN)")` or equivalent.

---

## Pattern Divergence Summary

| Pattern | Status | Notes |
|---|---|---|
| HTTP client | OpenFeign (acceptable) | All external integrations use `@FeignClient`. No `RestTemplate` or `WebClient` found. OpenFeign is the current team standard — not divergent. |
| Error model | Single `@RestControllerAdvice` — COMPLIANT | One `GenericControllerAdvice`. Exception hierarchy (`BaseRuntimeException → NotFoundException, ServerException`) is clean. **Missing:** `BadRequestException` in domain hierarchy forces use of `org.apache.coyote.BadRequestException` — see CRITICAL finding. |
| Idempotency | Partial — downstream de-duplication only | No HTTP-layer `Idempotency-Key` header; de-duplication relies on event `id` field downstream. See INFO finding. |
| Outbox | Absent — direct `KafkaTemplate.send()` | No transactional outbox table. All publishing via `AbstractKafkaEventPublisher`. See WARNING finding. |
| Resilience | Feign fallbacks present; Resilience4j circuit-breakers ABSENT | `FallbackFactory` on Braze, CIO, Mixpanel, GA. No Resilience4j `CircuitBreaker` or `Retry` config. |
| PII masking | Absent — no centralized `PiiMasker` | Account numbers logged at INFO. `AuthenticatedUser` has `@ToString` with email/phone. No HTTP logging filter with masking. |
| Scheduled jobs | `clustered-job-manager` (custom) — acceptable | 4 scheduled jobs use `ClusteredJob` interface via `teamapt/clustered-job-manager`. Not ShedLock, but provides distributed locking semantics. |
| Status mapping | N/A | No provider status→domain status translation needed in this service (event routing, not payment processing). |
| Strategy dispatch | `support(provider)` pattern — COMPLIANT | All `EventProviderHandler` impls use `boolean support(EventProvider)` — clean strategy dispatch, no `instanceof` chains. |

---

## Recommended First Actions (Top 5)

1. **[CRITICAL — SECURITY] Rotate and remove the committed RSA private key.**
   Run `git filter-repo --path rsa-private-pkcs8.pem --invert-paths` (or BFG). Add `*.pem` to `.gitignore`. Provision new keys via Vault or Kubernetes secrets. This must happen before any future push — the key is already in the remote's object store.

2. **[CRITICAL — SECURITY] Add `BadRequestException` to the domain exception hierarchy.**
   Create `src/main/java/com/moniepoint/loans/cas/common/exception/BadRequestException.java` extending `BaseRuntimeException`. Update `GenericControllerAdvice` to handle the domain class. Replace all `org.apache.coyote.BadRequestException` imports across 3 controllers. This removes the Tomcat internal API coupling and closes a CLAUDE.md violation.

3. **[CRITICAL — PII] Mask `accountNumber` in log statements.**
   In `PreprocessedSurveyRepositoryService`, `SurveyEventCompletionService`, and `SurveyEvaluatorListener`: replace `accountNumber` in `log.info(...)` with a masked version (e.g., `HashUtil.sha256(accountNumber).substring(0, 8) + "..."` or a dedicated `PiiMasker.maskAccount()` utility). Also add `@ToString(exclude = {"email", "phone", "resetPassword"})` on `AuthenticatedUser`.

4. **[WARNING — RESILIENCE] Add Resilience4j circuit-breakers to the two highest-traffic integrations (Braze, CustomerIO).**
   Configure `CircuitBreakerConfig` beans for Braze and CustomerIO Feign clients. Use the `Decorators` API. Set sliding-window of 10, failure threshold 50%, wait duration 30s. This prevents a single provider outage from cascading into thread exhaustion across the whole service.

5. **[INFO — MIGRATION] Migrate the Docker seed SQL into Flyway versioned migrations.**
   Move `dockers/db_seed/0000_init_schema.sql` → `db/migration/V1__init_schema.sql` and `0001_init_providers.sql` → `db/migration/V2__init_providers.sql`. Add `spring.flyway.enabled=true` to application config. This establishes schema version tracking and prevents drift between environments.
