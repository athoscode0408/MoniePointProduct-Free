# Overview

This folder is used to support running the project locally.
The docker-compose.yml file defines containers for dependencies (Kafka, Redis, MySQL, the Bigtable
emulator).

The MySQL container starts with an empty schema. The service creates and populates it itself via
Liquibase on startup (see `src/main/resources/db/changelog/`) — the same mechanism used in every real
environment — so no separate seed step is needed before running the app locally.

This is not run in production.
For environment variables, secrets and database scripts location see the root README.md file.