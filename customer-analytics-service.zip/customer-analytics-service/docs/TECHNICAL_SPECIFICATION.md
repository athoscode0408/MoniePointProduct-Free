# Customer Analytics Service – Technical Specification

## Table of Contents
- [1. Overview](#1-overview)
- [2. System Architecture](#2-system-architecture)
- [3. Core Components](#3-core-components)
- [4. Data Flow](#4-data-flow)
- [5. Integration Points](#5-integration-points)
- [6. Data Models](#6-data-models)
- [7. Configuration](#7-configuration)
- [8. Security](#8-security)
- [9. Performance & Scalability](#9-performance--scalability)
- [10. Monitoring & Observability](#10-monitoring--observability)
- [11. Error Handling & Resilience](#11-error-handling--resilience)
- [12. Development Guide](#12-development-guide)

---

## 1. Overview

### 1.1 Purpose
The Customer Analytics Service (CAS) is a centralized analytics event management platform. It receives customer interaction events from Moniepoint's mobile apps, web applications, and backend services, validates and enriches them, and distributes them to multiple third-party analytics providers. It also runs an embedded, rule-driven survey system that evaluates events in real time and delivers targeted surveys to users.

### 1.2 Key Objectives
- **Single Integration Point**: Eliminate per-team analytics SDK integrations across Moniepoint products.
- **Multi-Provider Routing**: Fan out validated events to Braze, Mixpanel, Customer.io, Google Analytics, and Singular simultaneously.
- **Survey Engine**: Rule-based survey system with TTL-managed delivery, push notification triggers, alert promotion, and banner lifecycle.
- **Event Resilience**: Dead-letter and retry infrastructure that ensures no events are silently lost.
- **Centralized Observability**: Consistent correlation ID propagation, structured logging, and New Relic APM tracing across all event flows.

### 1.3 Technology Stack

| Concern | Choice |
|---------|--------|
| Framework | Spring Boot 3.3.3 |
| Language | Java 22 (virtual threads enabled) |
| Build Tool | Maven |
| Message Queue | Apache Kafka |
| Distributed Cache | Redis (Spring Data Redis) |
| Local Cache | Caffeine (Spring Cache) |
| Primary Database | MySQL (JPA / HikariCP) |
| User Attributes Store | Google Bigtable |
| HTTP Client | OpenFeign |
| Authentication | OAuth2 Resource Server with RSA-signed JWTs |
| Job Scheduling | Quartz (clustered, MySQL-backed) |
| APM | New Relic |

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
                       ┌──────────────────────────────────────────┐
  Mobile / Web /       │           Customer Analytics Service      │
  Backend Clients ────▶│                                          │
                       │  REST API → Kafka → Event Processors     │
                       │                ↓                         │
                       │       Survey Engine (Rule Eval →         │
                       │       Preprocess → Notify → Alert)       │
                       └───────────────────┬──────────────────────┘
                                           │
          ┌──────────────────┬─────────────┼─────────────┬────────────────┐
          ▼                  ▼             ▼             ▼                ▼
        Braze           Mixpanel      Customer.io   Google Analytics  Singular
```

### 2.2 Architecture Diagram
See [architecture.puml](./architecture.puml) for the full component interaction diagram.

### 2.3 Key Architectural Patterns

| Pattern | Application |
|---------|-------------|
| Event-Driven Architecture | All event processing goes through Kafka topics |
| Publisher-Subscriber | Each analytics provider has its own consumer group on the verified-event topic |
| CQRS | Write path (event ingestion) is fully decoupled from read path (survey fetch, user info) |
| Repository Pattern | JPA repositories wrapped in `*RepositoryService` beans for caching and business logic |
| Provider Handler | `EventProviderHandler` interface abstracts per-provider processing; each listener delegates to its handler |
| Retry / Dead Letter | Failed provider calls are persisted to `event_retries`; exceeded retries move to `event_dead_letter` |
| Circuit Breaker | Feign fallback factories on each provider client |

---

## 3. Core Components

### 3.1 REST API Layer

#### 3.1.1 AnalyticsControllerV3
**Base path:** `/api/v3`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/event` | Optional (`CAN_PUSH_ANALYTICS_EVENT` or unauthenticated) | Submit a single v3 analytics event. IP is enriched from the `X-Forwarded-For` header. |
| `POST` | `/events` | Optional | Submit a batch of v3 analytics events. Payload is split into chunks when it exceeds the configured size limit. Survey completion events are routed to a separate topic. |

#### 3.1.2 AnalyticsControllerV2
**Base path:** `/api/v2`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/push-event` | `CAN_PUSH_ANALYTICS_EVENT` | Legacy v2 event ingestion endpoint. |

#### 3.1.3 AnalyticsController (v1)
**Base path:** `/api/v1`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/push-event` | `CAN_PUSH_ANALYTICS_EVENT` | Legacy v1 event ingestion endpoint. |

#### 3.1.4 SurveyController
**Base path:** `/api/surveys`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/user` | `CAN_FETCH_SURVEY` | Retrieve all active preprocessed surveys for the authenticated user. |
| `GET` | `/{id}` | `CAN_FETCH_SURVEY` | Retrieve a single preprocessed survey by its ID. |
| `GET` | `/{surveyId}/history` | `CAN_FETCH_SURVEY` | Fetch survey submission history for a user within a date range (`startDate`, `endDate` query params). |
| `GET` | `/schema/{surveyId}` | `CAN_FETCH_SURVEY` | Retrieve the survey schema enriched with user attribute values. |
| `GET` | `/dashboard-info` | `CAN_FETCH_SURVEY` | Retrieve survey alerts for a dashboard agent. Accepts `moniepointAgentId` as a header or query param, and `username` as a query param. |

#### 3.1.5 BrazeController
**Base path:** `/api`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/campaign` | `CAN_FETCH_CAMPAIGN` | Fetch Braze Canvas details by `id` query param. |
| `GET` | `/braze/auth` | Authenticated | Return Braze auth token for the authenticated user. |

#### 3.1.6 WebhookController
**Base path:** `/api/webhook`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/braze/assign-campaign` | `X-Secret-Key` header | Webhook: assign a Braze campaign/reward to a user. |
| `POST` | `/braze/stop-campaign` | `X-Secret-Key` header | Webhook: stop a Braze campaign/reward for a user. |

#### 3.1.7 UserInfoController
**Base path:** `/api/v3`

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/user-info` | Optional | Generate or return a session ID for a device. Accepts `AnalyticsEventV3DeviceInfoDTO`. |

#### 3.1.8 Admin Controllers
**Base path:** `/internal/admin`

| Controller | Path | Operations |
|------------|------|-----------|
| `AdminSurveyController` | `/surveys` | `POST /` – create survey; `PUT /` – update survey |
| `AdminEventConfigController` | `/event` | `POST /` – bulk create event configurations |
| `AdminBrazeConfigController` | `/braze-api-key-config` | `POST /` – create Braze API key entries; `PUT /` – update an entry |

#### 3.1.9 JobController
**Base path:** `/api/v1/job`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/` | List all scheduled Quartz jobs. |
| `GET` | `/{keyGroup}/get` | Get a specific job by group and name. |
| `POST` | `/{keyGroup}/pause` | Pause a scheduled job. |
| `POST` | `/{keyGroup}/resume` | Resume a paused scheduled job. |

---

### 3.2 Event Processing Pipeline

#### 3.2.1 Kafka Topics

| Topic Name                       | Config Key | Purpose |
|----------------------------------|-----------|---------|
| `RAW_ANALYTICS_EVENT`            | `kafka.topic.raw-analytics-event` | Raw events from legacy v1 clients |
| `CUSTOMER_ANALYTICS_EVENT`       | `kafka.topic.customer-analytics-event` | Validated events from v2/v3 clients (note: topic name has a typo preserved from initial setup) |
| `VERIFIED_ANALYTICS_EVENT`       | `kafka.topic.verified-analytics-event` | Events verified and enriched, ready for provider fan-out |
| `SURVEY_PREPROCESSOR_EVENT`      | `kafka.topic.event-survey-preprocessor` | Survey preprocessing requests |
| `VALIDATED_SURVEY_EVENT`         | `kafka.topic.event-validated-survey` | Events that have passed survey rule evaluation |
| `SURVEY_COMPLETED_EVENT`         | `kafka.topic.event-completed-survey` | Survey completion / dismissal / abandonment events |
| `SURVEY_PUSH_NOTIFICATION_EVENT` | `kafka.topic.event-survey-push-notification` | Triggers NOS push notification for a survey |
| `EVENT_RETRY_ID`                 | `kafka.topic.event-retry-id` | Retry a single event by its DB ID |
| `EVENT_RETRY_ID_RANGE`           | `kafka.topic.event-retry-id-range` | Retry a batch of events by ID range |
| `EVENT_RETRY_DTO`                | `kafka.topic.event-retry-dto` | Retry events carried as full DTO payloads |
| `CUSTOMER_PROFILE_UPDATES_TP`    | `kafka.topic.customer-profile-updates-event` | Customer profile update events for Customer.io |

#### 3.2.2 Kafka Consumer Groups

| Group ID | Handles |
|----------|---------|
| `customer-analytics-service` | Raw events, customer analytics events, retry topics |
| `braze-consumer` | Verified analytics events → Braze |
| `mixpanel-consumer` | Verified analytics events → Mixpanel |
| `customerio-consumer` | Verified analytics events → Customer.io, customer profile updates |
| `googleanalytics-consumer` | Verified analytics events → Google Analytics |
| `singular-consumer` | Verified analytics events → Singular |
| `survey-evaluator-consumer` | Survey evaluation, preprocessing, completion, push notifications |

#### 3.2.3 Kafka Listeners

| Listener | Topic | Consumer Group | Behaviour |
|----------|-------|----------------|-----------|
| `RawAnalyticsEventListener` | `RAW_ANALYTICS_EVENT` | Default | Deserializes `AnalyticsEventV1RequestDTO`, maps to internal DTO, calls `AnalyticsService.handleRawAnalyticsEvent()` |
| `CustomerAnalyticsEventListener` | `VALIDATED_SURVEY_EVENTTE` | Default | Validates and forwards events for provider processing |
| `BrazeEventListener` | `VERIFIED_ANALYTICS_EVENT` | `braze-consumer` | Delegates to `BrazeEventProviderHandler` |
| `MixpanelEventListener` | `VERIFIED_ANALYTICS_EVENT` | `mixpanel-consumer` | Delegates to `MixpanelEventProviderHandler` |
| `CustomerIOEventListener` | `VERIFIED_ANALYTICS_EVENT` | `customerio-consumer` | Delegates to `CustomerIOEventProviderHandler` |
| `GoogleAnalyticsEventListener` | `VERIFIED_ANALYTICS_EVENT` | `googleanalytics-consumer` | Delegates to `GoogleAnalyticsEventProviderHandler` |
| `SingularEventListener` | `VERIFIED_ANALYTICS_EVENT` | `singular-consumer` | Delegates to `SingularEventProviderHandler` |
| `SurveyEventListener` | `VERIFIED_ANALYTICS_EVENT` | `survey-evaluator-consumer` | Triggers survey rule evaluation via `SurveyEvaluatorListener` |
| `SurveyEvaluatorListener` | `VALIDATED_SURVEY_EVENT` | `survey-evaluator-consumer` | Evaluates survey rules against user attributes; publishes to `SURVEY_PREPROCESSOR_EVENT` if matched |
| `SurveyPreprocessorListener` | `SURVEY_PREPROCESSOR_EVENT` | `survey-evaluator-consumer` | Generates `PreprocessedSurvey` record with TTL; caches it; publishes to `SURVEY_PUSH_NOTIFICATION_EVENT` |
| `CompletedSurveyListener` | `SURVEY_COMPLETED_EVENT` | `survey-evaluator-consumer` | Delegates to `SurveyEventCompletionService` for state transitions and side effects |
| `SurveyPushNotificationListener` | `SURVEY_PUSH_NOTIFICATION_EVENT` | `survey-evaluator-consumer` | Calls `NOSClient` to deliver push notification |
| `CustomerProfileUpdateEventListener` | `CUSTOMER_PROFILE_UPDATES_TP` | `customerio-consumer` | Sends profile update to Customer.io |
| `EventRetryIDListener` | `EVENT_RETRY_ID` | Default | Retries a single failed event by its `event_retries` row ID |
| `EventRetryIDRangeListener` | `EVENT_RETRY_ID_RANGE` | Default | Retries a range of failed events |

#### 3.2.4 Kafka Producers

| Publisher | Topic | Payload |
|-----------|-------|---------|
| `RawAnalyticsEventKafkaEventPublisher` | `RAW_ANALYTICS_EVENT` | `AnalyticsEventV1RequestDTO` |
| `CustomerAnalyticsKafkaEventPublisher` | `VALIDATED_SURVEY_EVENTTE` | `BaseAnalyticsEventRequestDTO<?>` |
| `VerifiedAnalyticsEventKafkaEventPublisher` | `VERIFIED_ANALYTICS_EVENT` | `VerifiedAnalyticsEventDTO` |
| `SurveyEvaluatorKafkaEventPublisher` | `VALIDATED_SURVEY_EVENT` | Validated survey payload |
| `SurveyPreprocessorKafkaEventPublisher` | `SURVEY_PREPROCESSOR_EVENT` | Survey preprocessing request |
| `SurveyPushNotificationKafkaEventPublisher` | `SURVEY_PUSH_NOTIFICATION_EVENT` | Push notification payload |
| `SurveyCompletedEventPublisher` | `SURVEY_COMPLETED_EVENT` / `COMPLETED_SURVEY` | Survey completion event |
| `EventRetryIdKafkaEventPublisher` | `EVENT_RETRY_ID` | `Long` (retry row ID) |
| `EventRetryIdRangeKafkaEventPublisher` | `EVENT_RETRY_ID_RANGE` | ID range boundaries |

Kafka producer settings:
- **Compression:** zstd
- **Linger:** 20 ms
- **Batch size:** 128 KB

#### 3.2.5 Validation

Before events reach the `VERIFIED_ANALYTICS_EVENT` topic, they pass through:

- **EventValidator** – verifies required fields (`id`, `eventType`, `appEnv`, `platform`) and ensures values are in the allowed sets (`prod, dev, staging, beta` for environments; `BACKEND, WEB, IOS, ANDROID` for platforms).
- **ProviderConfigValidator** – queries `analytics_event_providers` to determine which providers are enabled for the event type; removes disabled providers from the routing set. Events with no valid providers are saved to `unsupported_events` and dropped.

---

### 3.3 Analytics Provider Handlers

All handlers implement `EventProviderHandler` and are invoked by their corresponding Kafka listener. The interface provides default `processEvents(List<VerifiedAnalyticsEventDTO>)` which iterates and calls `processEvent(VerifiedAnalyticsEventDTO)` on each item asynchronously via `@Async("appExecutor")`.

| Handler | `EventProvider` Key | External Client | Key Behaviour                                                                                                                                                                                                     |
|---------|--------------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `BrazeEventProviderHandler` | `BRAZE` | `BrazeClient` | Builds `BrazeTrackRequest` + `BrazeIdentifyRequest`. Supports multi-workspace targeting (per `applicationID/appDomain`) and attribute filtering. On failure, persists to `event_retries` via `EventRetryService`. |
| `MixpanelEventProviderHandler` | `MIX` | `MixpanelClient` | Builds Mixpanel event and profile update requests. Routes through `MixpanelIntegrationService`. Supports per-application workspace targeting via the `mixpanel_api_keys` table (see §3.3.1). On failure, persists to `event_retries` via `EventRetryService`. |
| `CustomerIOEventProviderHandler` | `CIO` | `CustomerIOClient` | Builds customer event or anonymous event request depending on whether a customer identifier is present.                                                                                                           |
| `GoogleAnalyticsEventProviderHandler` | `GA` | `GoogleAnalyticsClient` | Uses GA4 Measurement Protocol. Optionally validates events via the debug endpoint before sending.                                                                                                                 |
| `SingularEventProviderHandler` | `SIN` | `SingularClient` | Server-to-server event via GET. Requires at least one device identifier (`idfv` for iOS, `aifa` for Android, `sdid` for Web); drops the event if all are blank.                                                   |

#### 3.3.1 Mixpanel Workspace Targeting

Mixpanel supports multiple projects across different client applications. Rather than a single global project token, CAS selects credentials at runtime based on the `applicationID` carried on each event.

**`mixpanel_api_keys` table** (`MixpanelApiKey` entity, `MixpanelApiKeyStorage` repository):

| Column | Type | Notes |
|--------|------|-------|
| `api_secret` | `VARCHAR(100)` | Project API secret, used for Query API authentication |
| `project_id` | `VARCHAR(50)` | Mixpanel project ID, used for user profile queries |
| `project_token` | `VARCHAR(50)` | Project token, used to authenticate event import requests |
| `application_id` | `VARCHAR` | Matches `applicationID` on the inbound event |

**Lookup flow (`MixpanelIntegrationServiceImpl.getClientProjectData`):**

1. If `enable-workspace-targeting` is `false` (config: `integrations.mixpanel.enable-workspace-targeting`), workspace lookup is skipped and the global token/secret from application config is used for all events.
2. When workspace targeting is enabled, `getClientProjectData(applicationId)` is called with the event's `applicationID`.
3. The full `mixpanel_api_keys` table is loaded from cache key `mixpanel_api_keys` (Redis, default TTL). On a cache miss the table is fetched from the database and cached.
4. The list is filtered client-side for a case-insensitive match on `application_id`. If a match is found, its `projectToken` is used for the event import request and its `projectID`/`apiSecret` for any user-identity Query API calls. If no match is found, the global config values are used as fallback.

**Retry path:** When an event is retried from `event_retries`, `application_id` is read from the serialised `MixpanelEventRequest.properties.customProperties`. The same `getClientProjectData` lookup applies, so retried events are routed to the correct project even after the original event context is gone.

---

### 3.4 Survey System

#### 3.4.1 Survey Lifecycle

```
Analytics Event
      │
      ▼
SurveyEvaluatorListener
  → Fetch user attributes (Redis → Bigtable)
  → Evaluate survey rules (SpEL expressions)
  → Check response-window limits
      │ (rule matched)
      ▼
SurveyPreprocessorListener
  → Create PreprocessedSurvey (state: NOT_COMPLETED)
  → Set TTL = event.timestamp + survey.preprocessedSurveyTTL (default 7 days)
  → Optionally assign banner (BannerService)
  → Cache in Redis
  → Publish to SURVEY_PUSH_NOTIFICATION_EVENT
      │
      ▼
SurveyPushNotificationListener
  → Call NOSClient to send push notification
      │
      ▼
User opens app
  → GET /api/surveys/user  (cache → DB)
  → Survey displayed
      │
      ├── COMPLETED → finalise, remove from cache, unassign banner, delete SurveyAlert if alert type
      ├── DISMISSED → finalise, optionally promote to SurveyAlert if alertingAfterDismissal enabled
      └── ABANDONED → finalise, remove from cache, delete SurveyAlert if alert type
```

#### 3.4.2 Survey States

| State | Meaning                                                       |
|-------|---------------------------------------------------------------|
| `NOT_READY` | Survey is being preprocessed                                  |
| `NOT_COMPLETED` | Ready or delivered to user but not yet answered               |
| `COMPLETED` | User submitted a response                                     |
| `DISMISSED` | User actively dismissed the survey                            |
| `ABANDONED` | User partially responded to survey                            |
| `EXPIRED` | TTL elapsed before the user responded (set by the expiry job) |

#### 3.4.3 Survey Categories

| Value | Description |
|-------|-------------|
| `BRM` | Branch Relationship Manager rating survey |
| `CSAT` | Customer Satisfaction survey |
| `NPS` | Net Promoter Score survey |

#### 3.4.4 Survey Response Window Enforcement

| Config Property | Default | Meaning |
|----------------|---------|---------|
| `survey.response-window-days` | 7 | Global response window (days) |
| `survey.max-response-in-window` | 2 | Max surveys a user can be assigned in the global window |
| `survey.response-window-days-individual-survey` | 30 | Per-survey response window (days) |
| `survey.max-response-in-window-individual-survey` | 1 | Max responses per survey within its window |

`SurveyBody.responseWindowUniqueSurveyMins` and `maxCountUniqueSurveyInResponseWindow` can override these defaults per survey definition.

#### 3.4.5 Alert Promotion (Alerting After Dismissal)

When a survey with `enableAlertingAfterDismissal = true` is dismissed:

1. `SurveyEventCompletionService.handleAlertingOnDismissal()` evaluates a SpEL `alertingCondition` against the user's attributes.
2. If the condition is met, the survey's `displayModalType` is changed to `alert` and a delay is applied (`displayDelayPeriodInSecs`).
3. A `SurveyAlert` record is created, linking the survey to the agent's `moniepointAgentId`.
4. The updated survey is re-cached in Redis.
5. The alert is accessible via `GET /api/surveys/dashboard-info`.

#### 3.4.6 Voluntary Surveys

When a survey completion event arrives without a matching `PreprocessedSurvey` in the database (i.e. `surveyId = 0` in the meta), the service creates a new `PreprocessedSurvey` record directly in the terminal state, capturing the user's response without a prior preprocessing step.

#### 3.4.7 BRM (Branch Relationship Manager) Survey

BRM surveys use `generateUniqueSurveyPerBRM = true` in the survey body. Each preprocessed record stores a `brmId` in `additionalData`. During voluntary survey completion matching, `brmIdMatchesAdditionalData()` is used to find the correct record:
- The request's `brmId` is taken from `dto.getUserAttributes().getBrmId()`.
- If absent, user attributes are fetched from Redis → Bigtable using the account number from the request to resolve the `brmId` before matching.

#### 3.4.8 Survey Services

| Service | Responsibility |
|---------|---------------|
| `SurveyService` | Create and update `Survey` entities; invalidates the survey rules cache |
| `RuleParserHandler` | Parses survey rule JSON and evaluates SpEL conditions against user attributes |
| `SurveyEventCompletionService` | Processes COMPLETED / DISMISSED / ABANDONED events; handles side effects (banner unassign, alert promotion, cache eviction) |
| `PreprocessedSurveyExpiryServiceImpl` | Batch-marks expired surveys (`ttl < NOW()`) as `EXPIRED`; runs via Quartz job |
| `PreprocessedSurveyRepositoryService` | Cache-aware reads: Redis first, then DB; builds full survey response with associated alerts |

---

### 3.5 Banner Service Integration

`BannerService` manages promotional banner assignment as a side effect of survey delivery and completion.

| Method | Behaviour |
|--------|-----------|
| `assignBannerToUser(ownerIdentifier, bannerId)` | Calls `BannerClient.assignBanner()` with `expiryDate = now + preprocessedSurveyTtl mins`. |
| `unAssignBannerToUser(ownerIdentifier, bannerId)` | Calls `BannerClient.unAssignBanner()`. Invoked on survey COMPLETED. |

The banner expiry mirrors the survey TTL so the banner is removed as soon as the survey window closes.

---

### 3.6 Scheduled Jobs

All jobs are Quartz clustered jobs backed by MySQL, ensuring only one node executes each job at a time. The job manager runs a 20-thread pool.

| Job | Code | Default Schedule | Action |
|-----|------|-----------------|--------|
| `AnalyticsEventRetryTriggerJob` | `ANALYTICS_EVENT_RETRY_TRIGGER_JOB` | Every minute | Calls `EventRetryService.retryFailedEvents()`. Fetches `event_retries` records and re-attempts provider delivery. Moves to `event_dead_letter` after `integrations.retry.max-attempts` (default 3). |
| `EventDeadLetterCleanupTriggerJob` | `EVENT_DEAD_LETTER_CLEANUP_TRIGGER_JOB` | Every minute | Deletes all rows from `event_dead_letter`. |
| `PreprocessedSurveyExpirationTriggerJob` | `PREPROCESSED_SURVEY_EXPIRY_TRIGGER_JOB` | Every minute | Batch-marks `NOT_COMPLETED` / `NOT_READY` surveys where `ttl < NOW()` as `EXPIRED`. Batch size controlled by `survey.expiry-fetch-limit` (default 100). |
| `UnsupportedEventsCleanupTriggerJob` | `UNSUPPORTED_EVENTS_CLEANUP_TRIGGER_JOB` | Every minute | Deletes all rows from `unsupported_events`. |

Job cron frequencies are configurable via `clustered.cron.job.*` and `survey.preprocessed-survey-expiry-frequency`. All jobs can be paused/resumed at runtime via `JobController`.

---

### 3.7 Caching Strategy

CAS uses two cache layers:

#### Caffeine (Local In-Memory)
- **Max entries:** 20,000 (configurable: `cache.max-size`)
- **Expiry:** 180 minutes (configurable: `cache.expiry-in-mins`)
- **Used for:** Survey rules (`CAS_SURVEY_RULES_KEY`); supported event → provider mappings.
- **Invalidation:** Explicit eviction on survey create/update.

#### Redis (Distributed)
- **Connection:** `localhost:6379`, database index `10`, timeout `500ms`
- **Default TTL:** 300 seconds (5 minutes)

| Cached Item | Key Pattern | TTL |
|-------------|-------------|-----|
| User attributes | `pps-user-attributes:{userId}` | `survey.preprocessed-survey-cache-by-id-mins` (default 1440 min = 1 day) |
| Preprocessed surveys by user | `{userId}` (namespace managed by `RedisCacheServiceImpl`) | `survey.preprocessed-survey-cache-by-user-ttl-mins` (default 10080 min = 7 days) |
| Preprocessed survey by ID | `{surveyId}` (namespace managed by `RedisCacheServiceImpl`) | `survey.preprocessed-survey-cache-by-id-mins` (default 10080 min = 7 days) |
| Survey alerts | Keyed by `user` + `moniepointAgentId` | Inherits default or survey TTL |
| Supported events → providers | Spring Cache (`CAS_SURVEY_RULES_KEY`) | 86400 seconds (1 day) |
| Cosmos access token | Internal key | Token expiry – configurable buffer |

---

### 3.8 Event Retry & Dead Letter System

#### Flow

```
Provider call fails
        │
        ▼
EventRetryService.processFailedEventData()
  → Upsert row in event_retries (eventId + eventProvider is unique)
        │
        ▼ (AnalyticsEventRetryTriggerJob, every minute)
EventRetryService.retryFailedEvents()
  → Fetch paginated event_retries rows
  → Re-attempt provider call
  → On success: delete from event_retries
  → On failure (attemptCount >= max-attempts): move to event_dead_letter
        │
        ▼ (EventDeadLetterCleanupTriggerJob, every minute)
event_dead_letter rows deleted
```

#### Configuration

| Property | Default | Meaning |
|----------|---------|---------|
| `integrations.retry.max-attempts` | 3 | Maximum delivery attempts before dead-lettering |
| `integrations.retry.next-interval-in-seconds` | 60 | Minimum interval between retry attempts |
| `event-retry.page-size` | 2 | Rows fetched per retry job page |
| `event-retry.partition-size` | 5 | Partitions used for range-based retry |

---

## 4. Data Flow

### 4.1 Standard Event Ingestion

```
1.  Client → POST /api/v3/event (AnalyticsEventRequestDTO)
2.  AnalyticsControllerV3 enriches IP from X-Forwarded-For header
3.  Publish to VALIDATED_SURVEY_EVENTTE (CustomerAnalyticsKafkaEventPublisher)
4.  CustomerAnalyticsEventListener receives event
5.  EventValidator: validate fields + allowed environments/platforms
6.  ProviderConfigValidator: resolve enabled providers for this event type
7.  Build VerifiedAnalyticsEventDTO (includes resolved Set<EventProvider>)
8.  Publish to VERIFIED_ANALYTICS_EVENT (VerifiedAnalyticsEventKafkaEventPublisher)
9.  Provider listeners consume in parallel (one consumer group each):
      BrazeEventListener        → BrazeEventProviderHandler   → BrazeClient
      MixpanelEventListener     → MixpanelEventProviderHandler → MixpanelClient
      CustomerIOEventListener   → CustomerIOEventProviderHandler → CustomerIOClient
      GoogleAnalyticsEventListener → GAEventProviderHandler   → GoogleAnalyticsClient
      SingularEventListener     → SingularEventProviderHandler → SingularClient
      SurveyEventListener       → publishes to VALIDATED_SURVEY_EVENT
```

### 4.2 Survey Evaluation & Delivery

```
1.  SurveyEvaluatorListener receives from VALIDATED_SURVEY_EVENT
2.  Fetch user attributes: Redis → Bigtable
3.  RuleParserHandler evaluates SpEL conditions for all active surveys
4.  Check response-window limits (global + per-survey)
5.  For each matched survey: publish to SURVEY_PREPROCESSOR_EVENT
6.  SurveyPreprocessorListener:
      - Create PreprocessedSurvey (state: NOT_COMPLETED, TTL = event.timestamp + ttl_mins)
      - Optionally assign banner (BannerService.assignBannerToUser)
      - Cache survey in Redis
      - Publish to SURVEY_PUSH_NOTIFICATION_EVENT
7.  SurveyPushNotificationListener → NOSClient.notify()
8.  User: GET /api/surveys/user
      → RedisCacheServiceImpl (cache hit) or PreprocessedSurveyStorage (DB)
      → Filters: state IN (NOT_COMPLETED, DISMISSED) AND ttl > NOW()
9.  Survey completion event arrives: POST from mobile/web
      → Published to SURVEY_COMPLETED_EVENT
10. CompletedSurveyListener → SurveyEventCompletionService.processCompletedSurveyEvent()
      - Resolve survey record
      - Append source to additionalData
      - Handle side effects (banner unassign, alert deletion, alert promotion)
      - Set terminal state (COMPLETED / DISMISSED / ABANDONED)
      - Persist and evict cache
```

### 4.3 Alert Promotion Flow (Dismissal → Dashboard Alert)

```
1.  Survey dismissed (CompletedSurveyListener)
2.  SurveyEventCompletionService.handleAlertingOnDismissal():
      - Fetch user attributes (userStorage.findUser)
      - Evaluate SpEL alertingCondition
3.  Condition met:
      - Change displayModalType → "alert"
      - Set alertStartTime = now + displayDelayPeriodInSecs
      - Save SurveyAlert record
      - Re-cache updated PreprocessedSurvey
4.  Agent dashboard: GET /api/surveys/dashboard-info?moniepointAgentId=...
      → PreprocessedSurveyRepositoryService.fetchSurveyAlerts()
      → Returns SurveyAlert entries where ttl > NOW()
```

### 4.4 Banner Assignment Flow

```
1.  SurveyPreprocessorListener: survey matched → assignBannerToUser(userId, bannerId)
2.  BannerService calculates expiryDate = now + preprocessedSurveyTtl
3.  BannerClient.assignBanner(AssignBannerDTO) via Feign
4.  Survey COMPLETED → SurveyEventCompletionService calls unAssignBannerToUser(userId, bannerId)
5.  BannerClient.unAssignBanner() via Feign
```

---

## 5. Integration Points

### 5.1 Inbound Integrations

| Source | Protocol | Notes |
|--------|----------|-------|
| Android App | REST (v3) | Events include device identifiers (`appDomain`, `applicationID`) |
| iOS App | REST (v3) | Events include `idfv` for Singular attribution |
| Web App | REST (v3) | Events include `sdid` (Singular device ID) |
| Backend Services | Kafka direct or REST v1/v2 | Used for system-generated events |

### 5.2 Outbound Integrations

| Service | Client Interface | Protocol | Base URL Config Key | Purpose |
|---------|-----------------|----------|--------------------|-|
| Braze | `BrazeClient` | REST | `integrations.braze.base-url` | User tracking, event submission, identity resolution, canvas details |
| Mixpanel | `MixpanelClient` | REST | `integrations.mixpanel.base-url` | Event import, profile property updates |
| Mixpanel Query API | `MixpanelQueryAPIClient` | REST | `integrations.mixpanel.query-api-url` | User profile queries |
| Customer.io | `CustomerIOClient` | REST | `integrations.customerio.base-url` | Customer and anonymous event tracking, profile updates |
| Google Analytics | `GoogleAnalyticsClient` | REST | `integrations.googleanalytics.base-url` | GA4 Measurement Protocol events |
| Singular | `SingularClient` | REST (GET) | `integrations.singular.base-url` | Server-to-server mobile attribution |
| Banner Service | `BannerClient` | REST | `integrations.banner.base-url` | Assign/unassign promotional banners |
| NOS | `NOSClient` | REST | `integrations.nos.base-url` | Push notification delivery |
| Cosmos | `CosmosClient` | REST | `integrations.cosmos.base-url` | OAuth2 token issuance for service-to-service auth |
| Rewards Service | `RewardsClient` | REST | `integrations.rewards.base-url` | Campaign assignment/stop via webhook |
| Google Bigtable | `BigtableDataClient` | gRPC | `bigtable.*` | User attribute reads/writes |

### 5.3 Infrastructure Dependencies

| Dependency | Purpose | Criticality |
|------------|---------|-------------|
| Kafka | All event streaming | Critical |
| MySQL | Primary entities, Quartz state | Critical |
| Redis | Distributed cache, survey state | High |
| Bigtable | User attributes for survey rule evaluation | High |
| Spring Cloud Config Server | Externalised configuration per environment | High |

---

## 6. Data Models

### 6.1 BaseEntity (abstract)

All entities extend `BaseEntity`:

| Field | Type | Notes |
|-------|------|-------|
| `id` | `Long` | Primary key, auto-increment |
| `createdBy` | `String(100)` | Populated by Spring Data Auditing, immutable |
| `createdOn` | `Timestamp` | Populated on insert, immutable |
| `lastModifiedBy` | `String(100)` | Updated on every save |
| `lastModifiedOn` | `Timestamp` | Updated on every save |
| `version` | `Integer` | Optimistic locking |

### 6.2 PreprocessedSurvey (`preprocessed_survey`)

| Column | Type | Nullable | Notes |
|--------|------|----------|-------|
| `user` | `VARCHAR(50)` | No | User identifier |
| `event` | `VARCHAR` | No | Triggering event name |
| `priority` | `INT` | No | Default 10 |
| `survey_id` | `BIGINT` | No | FK → `survey.id` |
| `survey` | `TEXT` | No | Full survey JSON (SurveyBody) |
| `ttl` | `TIMESTAMP` | No | Expiry timestamp |
| `location` | `VARCHAR` | No | Survey display location key |
| `state` | `VARCHAR(50)` | Yes | `PreprocessedSurveyState` enum |
| `completed_on` | `TIMESTAMP` | Yes | Set on COMPLETED / ABANDONED |
| `additional_data` | `TEXT` | Yes | JSON: `brmId`, `source`, `accountNumber` |

### 6.3 SurveyAlert (`survey_alert`)

| Column | Type | Nullable | Notes |
|--------|------|----------|-------|
| `user` | `VARCHAR(50)` | No | User identifier |
| `preprocessed_survey_id` | `BIGINT` | No | FK → `preprocessed_survey.id` |
| `survey_id` | `BIGINT` | Yes | Survey schema ID |
| `account_number` | `VARCHAR(50)` | No | User account number |
| `moniepoint_agent_id` | `VARCHAR(50)` | No | Agent to whom the alert is shown |
| `ttl` | `TIMESTAMP` | No | Alert expiry |
| `event` | `VARCHAR` | No | Triggering event |
| `alert_type` | `VARCHAR` | Yes | |
| `alert_icon` | `VARCHAR` | Yes | |
| `alert_priority` | `INT` | No | |
| `alert_title` | `VARCHAR` | Yes | Default: `survey.alert.title` |
| `alert_message` | `VARCHAR` | Yes | Default: `survey.alert.message` |
| `alert_action_label` | `VARCHAR` | Yes | Default: `survey.alert.action-label` |
| `alert_dismissible` | `BOOLEAN` | No | |
| `alert_start_time` | `TIMESTAMP` | Yes | When the alert becomes visible |

### 6.4 Survey (`survey`)

| Column | Type | Notes |
|--------|------|-------|
| `rule` | `TEXT` | JSON rule definition for SpEL evaluation |
| `priority` | `INT` | Default 10; higher priority surveys evaluated first |
| `survey` | `TEXT` | Full survey schema JSON |
| `web_location` | `VARCHAR` | Location key for web |
| `mobile_location` | `VARCHAR` | Location key for mobile |
| `category` | `VARCHAR` | `SurveyCategory` enum: `BRM`, `CSAT`, `NPS` |
| `start` | `TIMESTAMP` | Survey active-from date |
| `duration_in_days` | `INT` | Active duration |

### 6.5 EventRetry (`event_retries`)

| Column | Type | Notes |
|--------|------|-------|
| `event_id` | `VARCHAR(50)` | Original event ID |
| `event_data` | `TEXT` | Serialised event payload |
| `event_provider` | `VARCHAR` | `EventProvider` enum value |
| `attempt_count` | `INT` | Number of delivery attempts made |
| `last_retry_time` | `TIMESTAMP` | Last attempt timestamp |
| `next_retry_time` | `TIMESTAMP` | Earliest time for next attempt |
| `last_failure_reason` | `TEXT` | Exception message from last attempt |

### 6.6 EventDeadLetter (`event_dead_letter`)

| Column | Type | Notes |
|--------|------|-------|
| `event_id` | `VARCHAR(50)` | Unique; same as originating event ID |
| `event_data` | `TEXT` | Serialised event payload |
| `event_provider` | `VARCHAR` | `EventProvider` enum value |
| `last_retry_time` | `TIMESTAMP` | |
| `last_failure_reason` | `TEXT` | |

### 6.7 SupportedEvent (`supported_events`)

Defines which event types are routed to which analytics providers.

| Column | Type | Notes |
|--------|------|-------|
| `event_type` | `VARCHAR(100)` | Unique event name |

Joined to `AnalyticsEventProvider` via `providers_event_types` and to `SupportedUserAttributes` via `event_supported_user_attributes`.

### 6.8 AnalyticsEventProvider (`analytics_event_providers`)

| Column | Type | Notes |
|--------|------|-------|
| `provider_name` | `VARCHAR(50)` | Human-readable name |
| `provider_key` | `VARCHAR` | `EventProvider` enum: `BRAZE`, `MIX`, `CIO`, `GA`, `SIN` |

### 6.9 BrazeApiKey (`braze_api_keys`)

Supports multi-workspace Braze targeting.

| Column | Type | Notes |
|--------|------|-------|
| `api_key` | `VARCHAR(50)` | Workspace API key |
| `application_id` | `VARCHAR` | Braze app ID for workspace matching |
| `app_domain` | `VARCHAR` | App domain for workspace matching |

### 6.10 MixpanelApiKey (`mixpanel_api_keys`)

Stores per-application Mixpanel project credentials for workspace targeting. See §3.3.1 for the lookup and caching behaviour.

| Column | Type | Notes |
|--------|------|-------|
| `api_secret` | `VARCHAR(100)` | Project API secret |
| `project_id` | `VARCHAR(50)` | Mixpanel project ID |
| `project_token` | `VARCHAR(50)` | Project token for event import |
| `application_id` | `VARCHAR` | Matched case-insensitively against the event's `applicationID` |

### 6.11 Key DTOs

#### AnalyticsEventRequestDTO / BaseAnalyticsEventRequestDTO

The inbound event contract used by all v2/v3 ingestion paths:

| Field | Type | Notes |
|-------|------|-------|
| `id` | `String` | Required; unique event ID |
| `eventType` | `String` | Required |
| `appEnv` | `String` | Must be one of: `prod, dev, staging, beta` |
| `platform` | `String` | Must be one of: `BACKEND, WEB, IOS, ANDROID` |
| `timestamp` | `Timestamp` | Epoch ms deserialized to Timestamp |
| `data` | `JsonNode` | Event payload |
| `customerIdentifier` | `String` | Optional user identity |
| `userIdentifiers` | `UserEventIdentifier` | Contains `userID`, email, phone |
| `userAttributes` | `UserAttributes` | User profile at time of event |
| `ip` | `String` | Override IP; otherwise taken from `X-Forwarded-For` |
| `longitude`, `latitude` | `Double` | Optional geo coordinates |
| `applicationID` | `String` | App/workspace identifier for Braze routing |
| `appDomain` | `String` | App domain for workspace targeting |
| `excludeProviders` | `List<EventProvider>` | Providers to skip for this event |

#### UserAttributes

Carries the user profile alongside the event. Supports `@JsonAnySetter` / `@JsonAnyGetter` for arbitrary custom attributes.

Key standard fields: `email`, `phone`, `name`, `firstName`, `lastName`, `dateOfBirth`, `kycLevel`, `userName`, `city`, `state`, `nubanAccountNumber`, `businessNubanAccountNumber`, `businessName`, `businessClassification`, `businessType`, `businessCategory`, `brmId`, `brmName`, `brmPhoneNumber`, `terminalId`, `moniepointAgentId`, `onboardingDate`, `lastTxnDate`, `deviceId`, `deviceType`, `appVersion`, `platform`, `appDomain`.

The `update(UserAttributes other)` method merges a second `UserAttributes` into this one, filling blank fields from the source without overwriting non-blank values.

#### SurveyBody

Embedded JSON stored in `preprocessed_survey.survey`. Key fields:

| Field | Notes |
|-------|-------|
| `assignBanner` | If true, a banner is assigned to the user when the survey is preprocessed |
| `bannerId` | Banner ID to assign |
| `displayModalType` | `"alert"` causes the survey to behave as a dashboard alert |
| `generateUniqueSurveyPerBRM` | One preprocessed record per BRM |
| `enableAlertingAfterDismissal` | If true, a dismissed survey is promoted to a SurveyAlert |
| `alertingCondition` | SpEL expression evaluated against `UserAttributes`; gates alert promotion |
| `displayDelayPeriodInSecs` | Delay before the alert becomes visible |
| `alertType`, `alertIcon`, `alertTitle`, `alertMessage`, `alertActionLabel`, `alertPriority`, `alertDismissible` | Alert presentation fields |
| `preprocessedSurveyTTL` | Per-survey TTL override (minutes); overrides global config when present |
| `responseWindowUniqueSurveyMins`, `maxCountUniqueSurveyInResponseWindow` | Per-survey response window overrides |

---

## 7. Configuration

### 7.1 Server

```yaml
server:
  port: 9003
  max-http-request-header-size: 64KB
```

### 7.2 Datasources

Two separate HikariCP pools are configured:

| Pool | Purpose | Max Connections |
|------|---------|----------------|
| `primary-pool` | All application JPA entities | 10 |
| `retry-pool` | EventRetry and EventDeadLetter entities | 5 |

Both point to the same MySQL database (`customer_analytics`) by default. Keeping them separate prevents retry traffic from starving the primary pool.

### 7.3 Kafka

```yaml
spring.kafka:
  producer:
    compression.type: zstd
    linger.ms: 20
    batch.size: 131072
  consumer:
    group-id: customer-analytics-service
```

See §3.2.2 for all consumer group IDs and §3.2.1 for topic names.

### 7.4 Survey Configuration

```yaml
survey:
  preprocessed-survey-ttl-mins: 10080          # 7 days
  preprocessed-survey-expiry-frequency: "0 0/1 * ? * * *"
  expiry-fetch-limit: 100
  response-window-days: 7
  max-response-in-window: 2
  response-window-days-individual-survey: 30
  max-response-in-window-individual-survey: 1
  image-location-url: <dashboard-service-url>/api/v1/files/
  alert:
    title: "How's your BRM?"
    message: "Your feedback helps us make Moniepoint better for you"
    priority: 1
    action-label: "Rate Them"
```

### 7.5 Event Retry Configuration

```yaml
integrations.retry:
  max-attempts: 3
  next-interval-in-seconds: 60

event-retry:
  page-size: 2
  partition-size: 5
```

### 7.6 Cluster Job Configuration

```yaml
clustered:
  job.manager:
    enabled: true
    threadPoolCount: 20
    scheduler.name: customer-analytics-service
  cron.job:
    analytics-event-retry.frequency: "0 0/1 * ? * * *"
    event-dead-letter-clean-up.frequency: "0 0/1 * ? * * *"
    unsupported-events-clean-up.frequency: "0 0/1 * ? * * *"
```

### 7.7 Integration Toggle Flags

Each provider can be independently enabled/disabled:

```yaml
integrations:
  braze.enable: false
  mixpanel.enable: true
  customerio.enable: false
  googleanalytics.enable: false
  singular.enable: false
```

### 7.8 Cache Configuration

```yaml
redis.default.expiry: 300         # seconds (5 minutes)
cache:
  max-size: 20000
  expiry-in-mins: 180
  supported-event.expiry: 86400  # seconds (1 day)
```

### 7.9 Bigtable Configuration

```yaml
bigtable:
  project-id: <project>
  instance-id: <instance>
  emulator-host: localhost:8086   # local dev only
  users-attributes-table: users
  users-business-attributes-column-family: business
```

### 7.10 Environment-Specific Configuration

All environment-specific values (database URLs, API keys, Kafka brokers) are managed via Spring Cloud Config Server. The local `application.yml` contains only development defaults.

---

## 8. Security

### 8.1 Authentication & Authorization

CAS uses OAuth2 Resource Server with RSA-signed JWTs. Three public keys are registered for validation:

| Issuer | Key Config |
|--------|-----------|
| Cosmos (internal) | `web-security.cosmos.public-key` |
| Moniebook | `web-security.moniebook.public-key` |
| Monnify | `web-security.monnify.public-key` |

**Permission authorities:**

| Authority | Endpoints |
|-----------|----------|
| `CAN_PUSH_ANALYTICS_EVENT` | Event ingestion (v1, v2, v3) |
| `CAN_FETCH_SURVEY` | All `/api/surveys/*` endpoints |
| `CAN_FETCH_CAMPAIGN` | `GET /api/campaign` |

Some v3 endpoints allow unauthenticated access (`!isAuthenticated() || hasAuthority(...)`).

### 8.2 Webhook Security

Webhook endpoints (`/api/webhook/braze/*`) are protected by an HMAC secret key (`hmac-secret-key`), passed as an `X-Secret-Key` header. This is validated server-side before processing the request.

### 8.3 Braze JWT Signing

`GET /api/braze/auth` returns a short-lived JWT signed with `braze.auth-private-key` (RSA), used by mobile clients to authenticate directly with Braze SDK.

### 8.4 CORS

```yaml
web-security.cors:
  allowed-headers: '*'
  allowed-origins: '*'
```

Configured for development; restrict in production.

### 8.5 Data Security
- Credentials are externalised via Config Server; not committed to source.
- PII fields (email, phone, account number) are not logged at INFO level.
- TLS enforced for all outbound Feign calls to external providers.

---

## 9. Performance & Scalability

### 9.1 Async Processing
- All provider handler `processEvents()` calls run via `@Async("appExecutor")`.
- Java 22 virtual threads are enabled, reducing thread overhead for I/O-bound Feign calls.

### 9.2 Kafka Partitioning
- Each provider has its own consumer group on `VERIFIED_ANALYTICS_EVENT`, so providers scale independently.
- Kafka producer uses zstd compression and 128 KB batches to maximise throughput.

### 9.3 Caching
- **User attributes** are cached for 24 hours in Redis, avoiding repeated Bigtable reads for the same user within a day.
- **Supported event → provider mappings** are cached for 24 hours in Caffeine; this lookup happens on every event validation.
- **Preprocessed surveys** are cached in Redis with the same TTL as their DB record, so the read path rarely hits MySQL.

### 9.4 Database
- Two HikariCP pools prevent retry workload from impacting primary event storage.
- The Quartz cluster table (backed by MySQL) ensures no duplicate job execution across instances.
- Batch sizes and page sizes for retry processing are configurable to tune throughput vs. lock contention.

### 9.5 Kafka Producer Tuning

| Setting | Value | Effect |
|---------|-------|--------|
| `compression.type` | `zstd` | Reduces broker storage and network usage |
| `linger.ms` | 20 | Accumulates records for up to 20ms to fill batches |
| `batch.size` | 131072 (128 KB) | Maximum batch size before flushing |

---

## 10. Monitoring & Observability

### 10.1 New Relic APM
- `@Trace` annotations on controller methods and key service methods create named New Relic transactions.
- `@Trace` segments are opened around Bigtable reads (`BigTableRead`) for granular external-call timing.
- Feign client calls are automatically traced via the New Relic Java agent.

### 10.2 Structured Logging

Log pattern includes correlation ID and New Relic trace/span IDs:

```
%d{HH:mm:ss.SSS} [%thread] %-5level [%X{correlationId}] %logger - %msg
trace.id=%X{trace.id} span.id=%X{span.id}
```

Log levels by concern:

| Level | Used for |
|-------|---------|
| `ERROR` | Unrecoverable failures (provider errors, DB failures, uncaught exceptions) |
| `WARN` | Validation failures, missing optional data, retry attempts, skipped operations |
| `INFO` | Successful state changes, event receipt |
| `DEBUG` | Detailed Feign payloads, cache hit/miss, Bigtable reads (non-production) |

### 10.3 Health & Actuator

| Endpoint | Purpose |
|----------|---------|
| `/actuator/health` | Composite health including DB, Redis, Kafka |
| `/actuator/health/liveness` | Liveness probe for Kubernetes |
| `/actuator/health/readiness` | Readiness probe for Kubernetes |
| `/actuator/metrics` | Prometheus-compatible metrics |

### 10.4 Key Metrics to Monitor

- Kafka consumer lag per consumer group (provider-specific lag indicates a provider bottleneck)
- `event_retries` table row count (high count = sustained provider failures)
- `event_dead_letter` table row count (events permanently lost to provider)
- `unsupported_events` table row count (unknown event types arriving)
- Redis cache hit rate for user attributes and preprocessed surveys
- Bigtable read latency (via New Relic `BigTableRead` segment)
- Survey preprocessing rate vs. completion rate

---

## 11. Error Handling & Resilience

### 11.1 Provider Failure Handling

| Failure Type | Behaviour |
|--------------|-----------|
| Feign exception on provider call | Caught by handler; event persisted to `event_retries` |
| Max retries exceeded | Row moved from `event_retries` to `event_dead_letter` |
| Feign fallback factory triggered | Logs error; returns empty/null to prevent cascade |
| Unknown event type | Saved to `unsupported_events`; cleaned up hourly |

### 11.2 Survey Processing Errors

| Failure Type | Behaviour |
|--------------|-----------|
| Survey rule evaluation exception | Logged as WARN; survey skipped |
| Alert condition evaluation exception | Logged as WARN; alert promotion skipped |
| `additionalData` JSON parse failure | Logged as WARN; `brmIdMatchesAdditionalData` returns `false` |
| SurveyAlert persist failure | Caught and logged as ERROR; does not roll back state transition |
| Missing `moniepointAgentId` on dismissal | WARN logged; alert promotion skipped |

### 11.3 Kafka Consumer Errors

- Malformed or undeserializable messages are logged and dropped.
- Consumer listeners do not rethrow unhandled exceptions (prevents infinite Kafka requeue loops).

### 11.4 Bigtable Errors

`UserAttributesRepositoryService.findUser()` catches all exceptions and returns `null`. Callers fall back to the `UserAttributes` from the event DTO itself.

---

## 12. Development Guide

### 12.1 Local Development Setup

**Prerequisites:**
- JDK 22
- Maven 3.8+
- Docker & Docker Compose
- VPN access (for Spring Cloud Config Server)

**Steps:**

```bash
# 1. Start local infrastructure (MySQL, Redis, Kafka, Bigtable emulator)
make dockers-up

# 2. Build (requires Archiva credentials in settings.xml)
mvn clean install --settings settings.xml -DskipTests

# 3. Run
mvn spring-boot:run --settings settings.xml
```

The service starts on port **9003** by default.

### 12.2 Testing

```bash
mvn test                               # Unit tests only
mvn verify --settings settings.xml    # Unit + integration tests
```

**Test approach:**
- JUnit 5 + Mockito (`@ExtendWith(MockitoExtension.class)`)
- Objects instantiated with `new` (not Spring context) — `@Value` fields default to Java defaults; use `ReflectionTestUtils.setField` to inject values.
- `@Async` methods are **not** proxied when the object is instantiated with `new`, so they run synchronously in tests.
- Available test doubles: `FakeBrazeClient`, `FakeMixpanelClient`, `FakeCacheService`, `FakeValidator`, `FakeEventRetryRepository`, `FakeSupportedUserAttributesRepository`.
- `VerifiedAnalyticsEventFactory` (package-private in `analytics.service.impl`) builds `VerifiedAnalyticsEventDTO` instances for tests.

### 12.3 API Documentation
- OpenAPI/Swagger: [docs/api/api.swagger.yaml](./api/api.swagger.yaml)
- AsyncAPI: [docs/api/asyncapi.yaml](./api/asyncapi.yaml)

### 12.4 Database Migrations
Managed in a separate repository: [analytics-service-migration-repo](https://gitlab.com/tcosmos/moniepoint-loans/projects/common/database-migrations/analytics-service-migration-repo). Flyway is used for version-controlled migrations.

### 12.5 Code Conventions
- Google Java Style Guide
- Lombok for boilerplate reduction (`@Data`, `@Builder`, `@RequiredArgsConstructor`, `@Slf4j`)
- SLF4J for all logging
- `@Trace` on controller methods and I/O-heavy service methods for New Relic instrumentation
- No comments unless the *why* is non-obvious

### 12.6 Branching Strategy

| Branch | Purpose |
|--------|---------|
| `main` | Production-ready code |
| `develop` | Integration branch |
| `feature/*` | Feature development |
| `bugfix/*` | Bug fixes |
| `hotfix/*` | Production hotfixes |
| `refactor/*` | Refactoring work |

### 12.7 CI/CD Pipeline
- Build and test on every PR
- Automated deployment to dev/staging on merge to `develop`
- Manual approval gate for production
- Database migrations run automatically as part of deployment

---

## Appendix

### A. Related Documentation
- [API Spec (Swagger)](./api/api.swagger.yaml)
- [AsyncAPI Spec](./api/asyncapi.yaml)
- [Architecture Diagram](./architecture.puml)
- [Preprocessed Survey Archive Strategy](./preprocessed-survey-archive-strategy.md)
- [Technical Flow (Confluence)](https://teamapt.atlassian.net/wiki/spaces/BLS/pages/1660682242/Customer+Analytics+Service)

### B. Key Repositories

| Repository | Purpose |
|------------|---------|
| Current repository | Main service |
| [analytics-service-migration-repo](https://gitlab.com/tcosmos/moniepoint-loans/projects/common/database-migrations/analytics-service-migration-repo) | Database migrations |
| [wclms-dev-config](https://gitlab.com/tcosmos/moniepoint-loans/environments/dev/config-repos/wclms-dev-config) | Development configuration |

### C. Support
- **Team:** Moniepoint Loans Engineering
- **Slack:** #customer-analytics-service
- **JIRA:** BLS

### D. Glossary

| Term | Definition |
|------|-----------|
| BRM | Branch Relationship Manager |
| CAS | Customer Analytics Service |
| CSAT | Customer Satisfaction score |
| DLT | Dead Letter Topic |
| NOS | Notification Orchestration System |
| NPS | Net Promoter Score |
| SpEL | Spring Expression Language — used to evaluate survey alerting conditions |
| TTL | Time To Live |

---

**Document Version:** 2.0
**Last Updated:** 2026-05-15
**Maintained By:** Moniepoint Engineering Team
