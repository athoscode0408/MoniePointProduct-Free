# Container Diagram — CAS: Cohort Platform + NPS Programme

```mermaid
flowchart TD
    USER(["👤 Mobile / Web User"])
    ENGINEER(["👤 Engineer\nDB migrations"])

    subgraph CAS["Customer Analytics Service"]
        direction TB

        API["CAS API Handler\nSpring Boot 3.3 · Java 22\nServes check-in · survey delivery · eligibility"]

        WORKER["CAS Background Worker\nSpring Boot 3.3 · Java 22\nCohort resolution job · NPS sampling job\nKafka consumers · expiry job"]

        TOPIC[["event-survey-preprocessor\nKafka topic\nSurvey preprocessing events"]]

        DB[("CAS MySQL Database\nMySQL 8.0\ncohort · user_cohorts · nps_weekly_sample\nnps_user_state · preprocessed_survey\ncohort_resolution_checkpoint · survey")]
    end

    BT([" ☁ Cloud Bigtable\nUser feature store"])
    BQ([" ☁ BigQuery\nnative_user_features snapshot"])
    ETL([" ⚙ ETL Pipeline\nData Infrastructure"])

    USER       -->|"HTTPS · GET /check-in"| API
    ENGINEER   -->|"DDL migrations"| DB
    API        <-->|"JDBC"| DB
    WORKER     <-->|"JDBC"| DB
    WORKER     -->|"publishes"| TOPIC
    WORKER     -->|"consumes"| TOPIC
    WORKER     -->|"BigQuery API · HTTPS"| BQ
    WORKER     -->|"gRPC · point-lookups"| BT
    ETL        -->|"reads from"| BT
    ETL        -->|"writes daily snapshot to"| BQ

    classDef person    fill:#2a9d8f,stroke:#264653,color:#fff,font-weight:bold
    classDef container fill:#457b9d,stroke:#1d3557,color:#fff
    classDef db        fill:#e9c46a,stroke:#e76f51,color:#000
    classDef queue     fill:#6d597a,stroke:#3d2b56,color:#fff
    classDef external  fill:#a8dadc,stroke:#457b9d,color:#000

    class USER,ENGINEER person
    class API,WORKER container
    class DB db
    class TOPIC queue
    class BT,BQ,ETL external
```

> **Worker dual-role note**: the Background Worker both produces and consumes `event-survey-preprocessor`. The Kafka hop reuses the existing BRM/CSAT preprocessing pipeline — `SurveyPreprocessorListener` handles NPS events identically once attributes are fetched.
