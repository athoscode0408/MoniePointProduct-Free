# System Context — Customer Analytics Service

Shared context for the Cohort Platform and NPS Programme.

```mermaid
flowchart TD
    ENGINEER(["👤 Engineer\nSeeds cohort rules + surveys\nvia DB migrations"])
    USER(["👤 Mobile / Web User\nReceives NPS surveys at check-in"])

    subgraph CAS["Customer Analytics Service"]
        APP["CAS\nSurvey delivery · cohort resolution\nNPS · CSAT · BRM analytics"]
    end

    BT([" ☁ Cloud Bigtable\nUser feature store\nauthoritative attributes"])
    BQ([" ☁ BigQuery\nCohort query engine\nnative_user_features snapshot"])
    KAFKA([" ⇄ Kafka\nAsync messaging backbone"])
    MOBILE([" 📱 Moniepoint App\nMobile · Web · POS"])
    ETL([" ⚙ ETL Pipeline\nData Infrastructure\nnightly Bigtable → BigQuery"])

    ENGINEER -->|"DB migration"| CAS
    USER --> MOBILE
    MOBILE -->|"HTTPS · GET /check-in"| CAS
    CAS -->|"gRPC"| BT
    CAS -->|"BigQuery API · HTTPS"| BQ
    CAS <-->|"Kafka producer / consumer"| KAFKA
    ETL -->|"reads features from"| BT
    ETL -->|"writes daily snapshot to"| BQ

    classDef person   fill:#2a9d8f,stroke:#264653,color:#fff,font-weight:bold
    classDef internal fill:#457b9d,stroke:#1d3557,color:#fff
    classDef external fill:#a8dadc,stroke:#457b9d,color:#000

    class ENGINEER,USER person
    class APP internal
    class BT,BQ,KAFKA,MOBILE,ETL external
```
