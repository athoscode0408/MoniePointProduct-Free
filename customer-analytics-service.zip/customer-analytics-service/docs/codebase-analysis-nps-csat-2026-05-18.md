# Codebase Analysis: NPS Programme Enhancement + CSAT Product Survey

**Date:** 2026-05-18  
**Scope:** customer-analytics-service  
**PRD references:**  
- NPS: https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD  
- CSAT: https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3308421134/CSAT+PRD

---

## Module Structure

| Package | Purpose | Key Classes | Dependencies |
|---|---|---|---|
| `module/analytics` | Core domain — survey pipeline, event routing, provider orchestration | `AnalyticsServiceImpl`, `SurveyService`, `RuleParserHandler`, `RuntimeSurveyScheduler`, `SurveyEventCompletionService`, 5 provider handlers, 8 Kafka publishers | kafka, cache, integrations, outbound, common |
| `module/kafka` | Pub-sub orchestration — 15 listeners, 1 abstract publisher template | `SurveyEventListener`, `SurveyEvaluatorListener`, `SurveyPreprocessorListener`, `CompletedSurveyListener`, `SurveyPushNotificationListener`, provider listeners | analytics (via DTOs) |
| `module/job` | Clustered background jobs (Quartz + ShedLock) | `PreprocessedSurveyExpirationTriggerJob`, `AnalyticsEventRetryTriggerJob`, `EventDeadLetterCleanupTriggerJob`, `UnsupportedEventsCleanupTriggerJob` | analytics |
| `module/cache` | Redis-backed distributed cache + Caffeine L1 | `RedisCacheServiceImpl`, `CacheKeys` | Spring Data Redis, Jedis |
| `module/ratelimiter` | AOP-based Redis rate limiting | `@RateLimit`, `RedisRateLimiterService`, `RateLimiterAspect` | Redis |
| `integrations/` | 5 external analytics provider clients (Feign) | `BrazeClient`, `CustomerIOClient`, `GoogleAnalyticsClient`, `MixpanelClient`, `SingularClient` (all with fallback factories) | FeignConfig |
| `outbound/` | Internal Moniepoint service clients | `NOSClient`, `CosmosClient`, `BannerClient`, `RewardsClient` | FeignConfig |
| `common/` | Cross-cutting: security, advice, config, utilities | `WebSecurityConfiguration`, `MultiProviderAuthManager`, `GenericControllerAdvice`, `CorrelationIdFilter` | — |

---

## Public APIs

### REST Endpoints

| Method | Path | Auth | Request | Response | Notes |
|---|---|---|---|---|---|
| POST | `/api/v1/push-event` | CAN_PUSH_ANALYTICS_EVENT | AnalyticsEventV1RequestDTO | AnalyticsEventResponseDTO | v1 event ingest |
| POST | `/api/v2/push-event` | CAN_PUSH_ANALYTICS_EVENT | AnalyticsEventV2RequestDTO | AnalyticsEventResponseDTO | v2 event ingest |
| POST | `/api/v3/event` | CAN_PUSH_ANALYTICS_EVENT or none | BaseAnalyticsEventRequestDTO | AnalyticsEventResponseDTO | v3 event ingest |
| POST | `/api/v3/events` | CAN_PUSH_ANALYTICS_EVENT or none | List\<BaseAnalyticsEventRequestDTO\> | AnalyticsEventResponseDTO | v3 batch ingest |
| **GET** | **`/api/surveys/dashboard-info`** | **CAN_FETCH_SURVEY** | **AuthPrincipal + header** | **SurveyAlertsResponse** | **Check-in pre-commitment endpoint — NPS+CSAT share this** |
| GET | `/api/surveys/user` | CAN_FETCH_SURVEY | AuthPrincipal | List\<PreprocessedSurveyDTO\> | User's active surveys |
| GET | `/api/surveys/{id}` | CAN_FETCH_SURVEY | path: id | PreprocessedSurveyDTO | Single survey fetch |
| GET | `/api/surveys/{surveyId}/history` | CAN_FETCH_SURVEY | startDate, endDate | SurveyHistoryResponse | Survey history |
| GET | `/api/surveys/schema/{surveyId}` | CAN_FETCH_SURVEY | UserAttributes | SurveySchemaDTO | Survey schema |
| POST | `/internal/admin/surveys` | None (internal) | SurveyCreateRequest | Long | Create survey |
| PUT | `/internal/admin/surveys` | None (internal) | SurveyCreateRequest | 202 | Update survey |
| POST | `/api/v3/user-info` | CAN_PUSH_ANALYTICS_EVENT or none | AnalyticsEventV3DeviceInfoDTO | UserInfoResponseDTO | Device/user info |
| GET/POST | `/api/v1/job/**` | None | — | JobResponse | Job management |

### Kafka Topics

| Topic (property key) | Consumers | Message Type | Notes |
|---|---|---|---|
| `customer-analytics-event` | CustomerAnalyticsEventListener | BaseAnalyticsEventRequestDTO | Inbound v2/v3 events |
| `raw-analytics-event` | RawAnalyticsEventListener | AnalyticsEventV1RequestDTO | Inbound v1 events |
| `verified-analytics-event` | BrazeEventListener, CustomerIOEventListener, GAEventListener, MixpanelEventListener, SingularEventListener, **SurveyEventListener** | VerifiedAnalyticsEventDTO | Fan-out to 6 consumers |
| `event-validated-survey` | SurveyEvaluatorListener | VerifiedAnalyticsEventDTO | Survey rule evaluation |
| `event-survey-preprocessor` | SurveyPreprocessorListener | EventPreprocessSurveyDTO | Survey personalisation + storage |
| `event-survey-push-notification` | SurveyPushNotificationListener | NotificationRequest | Push notification dispatch |
| `event-completed-survey` | CompletedSurveyListener | AnalyticsEventRequestDTO | Completion / dismissal / abandonment |
| `event-retry-id` | EventRetryIDListener | EventRetryDTO | Single-event retry |
| `event-retry-id-range` | EventRetryIDRangeListener | EventRetryIDRangeDTO | Batch retry |
| `customer-profile-updates-event` | CustomerProfileUpdateEventListener | CustomerProfileUpdatesEventDTO | Customer.io profile sync |

### Scheduled Jobs

| Job | Config property | Functionality |
|---|---|---|
| `PreprocessedSurveyExpirationTriggerJob` | `survey.preprocessed-survey-expiry-frequency` | Bulk-expires preprocessed surveys past TTL |
| `AnalyticsEventRetryTriggerJob` | `clustered.cron.job.analytics-event-retry.frequency` | Retries failed events from EventRetry table |
| `EventDeadLetterCleanupTriggerJob` | `clustered.cron.job.event-dead-letter-clean-up.frequency` | Purges permanently failed events |
| `UnsupportedEventsCleanupTriggerJob` | `clustered.cron.job.unsupported-events-clean-up.frequency` | Purges unknown event type rows |

---

## Data Model

### Survey Domain Entities

| Table | Key Columns | Gaps for NPS/CSAT |
|---|---|---|
| `survey` | id, rule, priority, survey (JSON), location_web, location_mobile, category (BRM/CSAT/NPS), start, duration_days | Missing: reminder_interval, max_reminder_count, backoff_policy, weekly_cap (NPS), cohort_dimensions |
| `preprocessed_survey` | id, user, event, priority, survey_id, survey (JSON), ttl, location, state (NOT_READY/NOT_COMPLETED/COMPLETED/EXPIRED/ABANDONED/DISMISSED), completed_on, additional_data | Missing: **last_nps_triggered_date**, outcome_state (CSAT), channel, journey_type, week_number (NPS), nps_score, csat_rating |
| `survey_alert` | id, user, preprocessed_survey_id, survey_id, account_number, moniepoint_agent_id, ttl, event, alert_type, alert_icon, alert_priority, alert_title, alert_message, alert_action_label, alert_dismissible, alert_start_time | Missing: outcome_state, channel, journey_type |

### Analytics Infrastructure Entities

| Table | Key Columns | Notes |
|---|---|---|
| `analytics_event_providers` | id, provider_name, provider_key (MIX/CIO/GA/BRAZE/SIN) | Provider registry |
| `supported_events` | id, event_type | Event whitelist |
| `event_retries` | id, event_id, event_data, provider_key, attempt_count, last/next_retry_time, last_failure_reason | Retry tracking (separate DB) |
| `event_dead_letter` | id, event_id, event_data, provider_key, last_retry_time, last_failure_reason | Permanent failures (separate DB) |
| `braze_api_keys` / `mixpanel_api_keys` | id, api_key, application_id, app_domain | Provider credentials |

### Repositories (Survey Domain)

| Repository | Custom queries of note |
|---|---|
| `PreprocessedSurveyStorage` | `findByUserAndStateInAndTtlAfter`, `findFirstByUserAndSurveyIdAndStateInAndTtlAfter`, `expirePreprocessedSurveys(limit)` (native bulk update) |
| `SurveyAlertStorage` | `findByUserAndMoniepointAgentIdAndTtlAfter`, `deleteByPreprocessedSurveyId` |
| `SurveyStorage` | JpaRepository only — no custom queries |

---

## Dependency Graph

| Source | Target | Type | Protocol / Client | Notes |
|---|---|---|---|---|
| analytics | Braze | External | Feign (FallbackFactory) | Track events, identify users, fetch canvas. Failed track events → EventRetryService |
| analytics | Customer.io | External | Feign (FallbackFactory) | Customer events, anonymous events, profile updates |
| analytics | Google Analytics | External | Feign (FallbackFactory) | Event validation + send. Multi-platform secrets (Android/iOS/Web × Personal/Business) |
| analytics | Mixpanel | External | Feign (FallbackFactory) | Event import, profile properties, query API (rate-limited 55/hr) |
| analytics | Singular | External | Feign | S2S events |
| analytics | NOS | Internal | Feign | Push notification orchestration (`/v2/notification`) |
| analytics | Cosmos | Internal | Feign | OAuth token (client credentials, cached 300s before expiry) |
| analytics | Banner Service | Internal | Feign | Banner assignment/unassignment |
| analytics | Rewards Service | Internal | Feign | Campaign assignment/stop (webhook secret auth) |
| analytics | MySQL (primary) | DB | Spring Data JPA | Survey, PreprocessedSurvey, SurveyAlert, EventProviders, SupportedEvents |
| analytics | MySQL (retry) | DB | Spring Data JPA | EventRetry, EventDeadLetter (separate datasource) |
| analytics | Google BigTable | DB | Bigtable SDK v2 | UserAttributes (high-throughput user attribute reads) |
| analytics | Redis | Cache | Jedis / Spring Data Redis | Preprocessed surveys (10080 min TTL), survey alerts (720 min TTL), Cosmos tokens |
| analytics | Kafka | Events | Spring Kafka | 10 published topics, 10 consumed topics |

**Feign defaults:** connect timeout 2000ms, read timeout 10000ms. No Resilience4j circuit breakers — resilience via FallbackFactory only.

---

## Resilience Patterns

| Service | Pattern | Config | Fallback |
|---|---|---|---|
| BrazeClient | FallbackFactory | — | track → EventRetryService; identify → log warn; canvas → error response |
| CustomerIOClient | FallbackFactory | — | All methods → failureHandler + empty response |
| GoogleAnalyticsClient | FallbackFactory | — | All methods → failureHandler + empty response |
| MixpanelClient | FallbackFactory | — | Batch → per-item failureHandler; profile → log error |
| Mixpanel Query API | Manual rate limit | `integrations.mixpanel.rate-limit-per-hour: 55` | Skip + log warning |
| All outbound clients (NOS, Cosmos, Banner, Rewards) | **None** | — | Default Feign error propagation |
| Resilience4j | **ABSENT** | — | No @CircuitBreaker, @Retry, @Bulkhead anywhere |

---

## Feature Flags

| Property | Gated Behaviour | Default |
|---|---|---|
| `integrations.braze.enable` | Braze event routing active | required |
| `integrations.braze.enable-workspace-targeting` | Multi-tenant workspace routing | true |
| `integrations.braze.enable-attributes-filtering` | User attribute filtering | true |
| `integrations.customerio.enable` | Customer.io routing active | required |
| `integrations.customerio.update-customer-profile` | Profile update calls | false |
| `integrations.googleanalytics.enable` | GA routing active | required |
| `integrations.mixpanel.enable` | Mixpanel routing active | required |
| `integrations.mixpanel.enable-workspace-targeting` | Workspace routing | true |
| `integrations.singular.enable` | Singular routing active | false |
| `events.disable-downstream-processing` | Kill-switch for all downstream | false |

_No `@ConditionalOnProperty` found — all flags injected via `@Value`._

---

## Domain Type Hierarchies

| Parent Type | Kind | Values | Used in Exhaustive Switch |
|---|---|---|---|
| `SurveyCategory` | Enum | BRM, CSAT, NPS | Partially — rule parsing logic branches on category |
| `PreprocessedSurveyState` | Enum | NOT_READY, NOT_COMPLETED, COMPLETED, EXPIRED, ABANDONED, DISMISSED | Yes — CompletedSurveyListener, ExpiryService |
| `EventProvider` | Enum | MIX, CIO, GA, BRAZE, SIN | Yes — provider handler dispatch |
| `CustomerIOEventType` | Enum | EVENT, PAGE, SCREEN | In CustomerIO service |

_No sealed interfaces or abstract domain hierarchies._

---

## Provider Error Mapping

| Integration | Error Condition | Internal Action |
|---|---|---|
| Braze | HTTP failure on trackEvent | Persist to EventRetry for async retry |
| Braze | HTTP failure on identify | Log warn, no retry |
| CustomerIO | HTTP failure | `failureHandler(statusCode)` — empty response returned |
| CustomerIO | Exception | `failureHandler(exception.getMessage())` |
| Google Analytics | HTTP failure | `failureHandler(statusCode + body)` |
| Mixpanel | Batch partial failure | Per-item `batchFailureHandler` → `failureHandler` per failed item |
| All outbound (NOS, Cosmos, Banner, Rewards) | Any error | Default Feign exception propagation — **no fallback** |

---

## Gap & Impact Assessment

### NPS Programme Enhancement

| Requirement Element | Classification | Affected Components | Notes |
|---|---|---|---|
| `SurveyCategory.NPS` enum value | **REUSE** | `SurveyCategory` | Already defined |
| Check-in pre-commitment endpoint | **REUSE** | `GET /api/surveys/dashboard-info` | This IS the check-in endpoint; returns `SurveyAlertsResponse` |
| Survey state machine (COMPLETED, ABANDONED, DISMISSED, EXPIRED) | **REUSE** | `PreprocessedSurveyState`, `CompletedSurveyListener` | All required terminal states exist |
| Survey expiry job pattern | **REUSE** | `PreprocessedSurveyExpirationTriggerJob` | Adapt for NPS weekly window expiry |
| Survey preprocessing pipeline | **REUSE** | `SurveyPreprocessorListener` + `SurveyEvaluatorListener` | NPS flows through the same pipeline; eligibility gates added here |
| Survey JSON schema (Q1/Q2 structure, conditional follow-up) | **REUSE** | `Survey.survey` (JSON), `SurveyBody` | Follow-up question mapping by score band stored in JSON schema |
| NPS cool-off reminder logic (1 per week on dismissal) | **REUSE** | `PreprocessedSurveyState.DISMISSED`, `SurveyEvaluatorListener` | DISMISSED state exists; re-eligibility check on next check-in already supported |
| Admin survey CRUD (create/update NPS survey config) | **REUSE** | `AdminSurveyController`, `SurveyService` | Works as-is for creating NPS surveys |
| Redis cache for preprocessed surveys | **REUSE** | `RedisCacheServiceImpl` | Already caches by user+surveyId |
| `Survey` entity — add NPS config fields | **MODIFY** | `Survey`, `SurveyCreateRequest`, `SurveyBody`, DB migrations repo | Add: `weekly_invitation_cap`, `reminder_min_interval_hours`, `max_reminders_per_week` (currently 1 — enforced in logic) |
| `PreprocessedSurvey` entity — add NPS tracking fields | **MODIFY** | `PreprocessedSurvey`, `PreprocessedSurveyStorage`, `PreprocessedSurveyRepositoryService`, DB migrations repo | Add: `week_number` (ISO week), `nps_score` (Integer, nullable), `nps_classification` (PROMOTER/PASSIVE/DETRACTOR), `qualitative_response` (TEXT) |
| `dashboard-info` response — include NPS pre-commitment alongside CSAT | **MODIFY** | `SurveyController`, `SurveyAlertsResponse` | NPS and CSAT resolved in one pass; combined payload must stay <1KB |
| `SurveyEvaluatorListener` — add NPS eligibility gates | **MODIFY** | `SurveyEvaluatorListener`, `RuleParserHandler` | Add gates: account_age ≥ 60d, ≥2 transactions in 30d, last_nps_triggered_date > 90d. Route NPS events through existing pipeline |
| `CompletedSurveyListener` — capture NPS Q1 score + Q2 text | **MODIFY** | `CompletedSurveyListener`, `SurveyEventCompletionService` | Extract score from event payload, persist to `nps_score` + `qualitative_response` columns |
| `last_nps_triggered_date` field on user profile | **NET-NEW** | New column (DB migrations repo), `PreprocessedSurvey` or dedicated NPS user state table | Must be written at trigger point, not response. Cross-measurement global cool-off needs a user-scoped record, not a survey-scoped record. Consider a new `NpsUserState` table (user_id, last_triggered_date) |
| NPS weekly sample preparation job | **NET-NEW** | `module/job/jobs/NpsWeeklySampleJob`, Quartz config | New `ClusteredJob`. Runs at week start. Randomly selects eligible users up to weekly cap per app type. Writes to a `nps_weekly_sample` table (user_id, week_number, app_type, triggered) |
| NPS weekly sample tracking table | **NET-NEW** | New entity `NpsWeeklySample`, `NpsWeeklySampleStorage`, DB migrations repo | Fields: user_id, week_number (ISO), app_type (PERSONAL/BUSINESS), sampled_at, triggered (boolean) |
| Transaction count lookup (≥2 in 30 days gate) | **NET-NEW** | New outbound Feign client or BigTable query | Requires access to transaction count per user for last 30 days. Likely BigTable query on existing user_attributes or new outbound service call. Clarify data source with data team |
| Account age lookup (≥60 days gate) | **NET-NEW** | BigTable query on `onboarding_date` from `UserAttributes` | `onboardingDate` field exists on `UserAttributes` DTO — BigTable already stores this |
| NPS respondent classifier | **NET-NEW** | `module/analytics/service/NpsClassificationService` | Classifies 9-10 as PROMOTER, 7-8 as PASSIVE, 0-6 as DETRACTOR |
| NPS score calculation engine | **NET-NEW** | `module/analytics/service/NpsScoreService` or scheduled job | Weekly: % Promoters − % Detractors. Requires querying completed NPS responses by week_number |
| NPS rolling average computation (4/7/12/28-week) | **NET-NEW** | `NpsScoreService` or query layer | Derived from weekly scores stored in `NpsWeeklyScore` table |
| NPS weekly score storage | **NET-NEW** | New entity `NpsWeeklyScore`, `NpsWeeklyScoreStorage`, DB migrations repo | Fields: survey_id, week_number, nps_score, promoter_pct, passive_pct, detractor_pct, population_size, sample_size, respondent_size, response_rate |
| NPS intelligence view REST API | **NET-NEW** | New controller `NpsIntelligenceController` or extension of `SurveyController` | Endpoints: GET weekly scores, GET rolling averages, GET raw responses by classification, GET AI summary by week |
| Weekly AI summary (promoter drivers + detractor drivers) | **NET-NEW** | `module/analytics/service/NpsAiSummaryService`, Claude API client (`anthropic-java-sdk` or REST) | Calls Claude API with free-text responses batched by week. Stores result in `NpsWeeklyAiSummary` table |
| Impression / reminder / discard event logging | **NET-NEW** | Extend `CompletedSurveyListener` or new `NpsEventLogService` | Log impression_at, reminder_served_at, response_discarded_at per `PreprocessedSurvey` row. Or new `NpsEventLog` table |
| Weekly summary report generation (post-week close) | **NET-NEW** | `NpsWeeklyReportJob` (new ClusteredJob) | Runs at week close. Computes + persists `NpsWeeklyScore`. Triggers AI summary generation |

---

### CSAT Product Survey

| Requirement Element | Classification | Affected Components | Notes |
|---|---|---|---|
| `SurveyCategory.CSAT` enum value | **REUSE** | `SurveyCategory` | Already defined |
| Check-in pre-commitment endpoint | **REUSE** | `GET /api/surveys/dashboard-info` | Shared with NPS — single pass |
| Survey state machine | **REUSE** | `PreprocessedSurveyState` | COMPLETED, ABANDONED, DISMISSED, EXPIRED all present |
| Survey preprocessing pipeline | **REUSE** | `SurveyPreprocessorListener`, `SurveyEvaluatorListener` | CSAT flows through same pipeline; outcome_state added at eligibility resolution |
| Admin survey CRUD | **REUSE** | `AdminSurveyController`, `SurveyService` | Create/update CSAT survey configs |
| Redis cache | **REUSE** | `RedisCacheServiceImpl` | Caches pre-committed CSAT surveys by user |
| Survey JSON schema (5-star rating, contextual open-text) | **REUSE** | `Survey.survey` (JSON) | 5-star vs BRM star difference encoded in schema; display format is client-driven |
| POS heartbeat delivery path | **REUSE** | `GET /api/surveys/dashboard-info` (heartbeat variant) | Dashboard-info already supports `moniepointAgentId` parameter — used for POS heartbeat |
| BRM CSAT co-existence / stacking prevention | **REUSE** | `SurveyEvaluatorListener`, `RuleParserHandler` | Existing rule evaluation already prioritises by `priority` field on `PreprocessedSurvey`. Stacking prevention = only one active survey per session in check-in response |
| `Survey` entity — add CSAT config fields | **MODIFY** | `Survey`, `SurveyCreateRequest`, DB migrations repo | Add: `reminder_interval_hours`, `max_reminder_count`, `backoff_policy` (enum: LINEAR/EXPONENTIAL), `cool_off_days` (configurable per measurement) |
| `PreprocessedSurvey` entity — add CSAT fields | **MODIFY** | `PreprocessedSurvey`, `PreprocessedSurveyStorage`, DB migrations repo | Add: `outcome_state` (SUCCESS/FAILURE/ERROR), `channel` (MOBILE/WEB/POS), `journey_type` (String), `csat_rating` (Integer 1-5, nullable), `qualitative_response` (TEXT, nullable), `calendar_day` (Date) |
| `SurveyAlert` entity — add CSAT context tags | **MODIFY** | `SurveyAlert`, `SurveyAlertStorage`, DB migrations repo | Add: `outcome_state`, `channel`, `journey_type` — required for north star formula |
| `SurveyEvaluatorListener` — add CSAT eligibility (global cool-off across journeys, per-day cap) | **MODIFY** | `SurveyEvaluatorListener`, `RuleParserHandler` | Cross-journey cool-off: check last contact date across all CSAT measurements for user, not just current journey. Per-day cap: max 1 CSAT per user per calendar day regardless of journey attempts |
| `CompletedSurveyListener` — capture CSAT rating + outcome_state tagging | **MODIFY** | `CompletedSurveyListener`, `SurveyEventCompletionService` | Extract csat_rating from event payload; persist outcome_state (must be set at trigger, not retrospectively) |
| `SurveyPreprocessorListener` — tag outcome_state + channel at trigger | **MODIFY** | `SurveyPreprocessorListener` | outcome_state and channel must be written to `PreprocessedSurvey` when the pre-committed survey fires — i.e., at journey outcome, before the survey is shown |
| 30-minute window sampling distribution | **MODIFY** | `RuntimeSurveyScheduler` or `SurveyEvaluatorListener` | `SurveyBody.randomizeSurveyAssignment` exists — extend to enforce even 30-minute window distribution |
| `outcome_state` enum (SUCCESS, FAILURE, ERROR) | **NET-NEW** | `module/analytics/enums/OutcomeState` | New enum. Distinct from `PreprocessedSurveyState` (lifecycle state) — this is the journey outcome state |
| Journey outcome event tagging in event taxonomy | **NET-NEW** | Upstream clients (Mobile, Web, POS) publish outcome-tagged events | CAS receives these events; outcome_state extracted from event payload in `SurveyPreprocessorListener`. Requires upstream instrumentation (out of scope for CAS — dependency on client teams) |
| CSAT_north formula computation | **NET-NEW** | `module/analytics/service/CsatScoreService` | `CSAT_north = (s × CSAT_success) + (f × CSAT_failure) + (e × CSAT_error)`. Outcome rates (s, f, e) derived from tagged event counts per journey per day |
| CSAT daily score storage | **NET-NEW** | New entity `CsatDailyScore`, `CsatDailyScoreStorage`, DB migrations repo | Fields: survey_id, journey_type, channel, calendar_day, csat_north, csat_success, csat_failure, csat_error, success_rate, failure_rate, error_rate, sample_size, respondent_size, response_rate |
| CSAT rolling aggregations (7-day, 28-day) | **NET-NEW** | `CsatScoreService` | Computed from `CsatDailyScore` — query over last 7/28 calendar days |
| CSAT daily score computation job | **NET-NEW** | `CsatDailyScoreJob` (new ClusteredJob) | Runs daily. Aggregates completed CSAT responses by journey/channel/outcome. Computes CSAT_north. Stores in `CsatDailyScore` |
| Journey Intelligence View — quantitative section API | **NET-NEW** | `CsatIntelligenceController` | Endpoints: GET CSAT trends by journey (daily, 7d/28d rolling), GET CSAT breakdown by channel and outcome state |
| Daily AI summary of CSAT free-text responses | **NET-NEW** | `module/analytics/service/CsatAiSummaryService`, Claude API client | Generates structured summary (areas of satisfaction + areas for improvement) from daily free-text. Stored in `CsatDailyAiSummary` table |
| Raw free-text response access API | **NET-NEW** | `CsatIntelligenceController` | GET free-text responses by journey/day, separated by satisfaction vs improvement sentiment |
| Kano research backlog entity | **NET-NEW** | New entity `KanoFinding`, `KanoFindingStorage`, admin CRUD controller, DB migrations repo | Fields: id, journey_type, finding_type (BASIC/PERFORMANCE/DELIGHTER), description, resolution_status, competitor_flag, aging_days. Admin endpoints to log/update findings |
| CSAT intelligence view — Kano backlog section | **NET-NEW** | `CsatIntelligenceController` | GET Kano findings by journey, ordered by type + aging + competitor_flag |
| Measurement configuration enhancements (reminder_interval, max_reminder_count, backoff_policy) | **NET-NEW** (config model) | `SurveyCreateRequest`, `Survey` entity, admin UI | PM-configurable per measurement |

---

## Platform Guardrails

- **Detected platform:** Backend API (Spring Boot service, no web/mobile frontend code)
- Standard rules apply. No WCAG, bundle size, or offline guardrails required.
- **Kafka contract guardrail:** Any new event type or new field on `VerifiedAnalyticsEventDTO` must be coordinated with all 6 downstream consumers (Braze, CustomerIO, GA, Mixpanel, Singular, Survey listeners) — they all fan-out from the same topic.
- **Payload size guardrail:** Combined NPS + CSAT pre-commitment payload returned by `dashboard-info` must remain <1KB after both sets of survey configs are included.

---

## Flags

| # | Flag | Severity | Detail |
|---|---|---|---|
| F1 | `last_nps_triggered_date` is user-scoped, not survey-scoped | Architecture | Current `PreprocessedSurvey` is keyed by (user, surveyId). Global NPS cool-off across all measurements requires a user-level record. A new `NpsUserState` table is needed rather than adding a column to `PreprocessedSurvey` |
| F2 | Transaction count gate requires external data | Dependency | The NPS eligibility gate "≥2 transactions in last 30 days" requires a transaction count API. `UserAttributes` in BigTable has `lastTxnDate` but not a count. Clarify data source with data/platform team before spec |
| F3 | Outcome_state must be tagged at trigger, not at response | Contract | CSAT PRD is explicit that `outcome_state` cannot be applied retrospectively. The tag must be written to `PreprocessedSurvey` at the moment the journey outcome event fires — in `SurveyPreprocessorListener`. Cannot be inferred later from the response |
| F4 | Upstream instrumentation is a hard dependency for CSAT | Dependency | CSAT measurement is meaningless without journey outcome events (`success`/`failure`/`error`) from Mobile, Web, and POS clients. These teams must instrument before CSAT scoring is valid |
| F5 | No Resilience4j on NOS, Cosmos, Banner, Rewards outbound clients | Risk | These 4 outbound clients have no fallback factory and no circuit breaker. NPS reminder delivery (via NOS) and CSAT pre-commitment (via Cosmos for auth) are in the critical path. Consider adding FallbackFactory at minimum |
| F6 | AI summary scope: single API call per summary may exceed 1-hour timeout for large weekly batches | Risk | NPS weekly AI summary processes all detractor + promoter free-text for a week. At 1000+ responses, a single synchronous Claude API call will time out. The AI summary job must process in batches and aggregate summaries |
| F7 | CSAT cooloff is global across journeys but NPS cooloff is global across measurements | Scope boundary | Two different global cooloff semantics. Ensure the eligibility logic in `SurveyEvaluatorListener` handles them independently — NPS cooloff checks `NpsUserState`, CSAT cooloff checks last contact across all CSAT `PreprocessedSurvey` records for the user |

---

## Recommendations

1. **Implement NPS before CSAT.** NPS touches the check-in endpoint, adds the weekly sample job, and establishes the `NpsUserState` pattern. CSAT's cross-journey cooloff depends on a similar pattern. NPS is the simpler of the two.

2. **`NpsUserState` table over a column on `PreprocessedSurvey`.** The global cool-off must be checked at eligibility time, before any `PreprocessedSurvey` row exists for the user. A dedicated table keyed by `(user_id)` with `last_nps_triggered_date` and `yearly_trigger_count` is cleaner than querying `PreprocessedSurvey`.

3. **Extend `SurveyBody` for NPS/CSAT-specific config.** Rather than separate entities, encode NPS (`weekly_invitation_cap`, `reminder_min_interval_hours`) and CSAT (`reminder_interval`, `max_reminder_count`, `backoff_policy`, `cool_off_days`) config into `SurveyBody` JSON. The `Survey.survey` column already stores `SurveyBody` as JSON — add typed fields to `SurveyBody` and document them. This avoids a DB schema change for config fields.

4. **Reuse the existing Kafka survey pipeline for both NPS and CSAT.** The `SurveyEventListener → SurveyEvaluatorListener → SurveyPreprocessorListener → CompletedSurveyListener` chain already handles multi-category surveys. Add NPS/CSAT-specific branches inside the existing listeners — do not create parallel listener chains.

5. **New Kafka topic for NPS weekly metrics.** Introduce `event-nps-weekly-close` published by the `NpsWeeklyReportJob` at week close. This decouples score computation, AI summary generation, and any future downstream consumers (reporting dashboards, alerting) from the job itself.

6. **Introduce `anthropic-java-sdk` dependency** for AI summaries (NPS weekly + CSAT daily). Use streaming responses for large batches. Add `integrations.ai.enable` feature flag following the existing provider flag pattern.

7. **Add FallbackFactory to NOS client** before NPS reminder delivery goes live. NOS is in the critical path for survey push notifications; a timeout or outage will silently drop reminders.

8. **Place all new entities in `module/analytics/entity/`.** New entities: `NpsUserState`, `NpsWeeklySample`, `NpsWeeklyScore`, `NpsWeeklyAiSummary`, `CsatDailyScore`, `CsatDailyAiSummary`, `KanoFinding`. Each follows the existing `BaseEntity` + `*Storage` naming pattern.

9. **Place all new controllers in a versioned package.** New reporting/intelligence endpoints: `module/analytics/controller/v4/NpsIntelligenceController`, `module/analytics/controller/v4/CsatIntelligenceController`. Admin Kano endpoints: `AdminKanoFindingController` under `/internal/admin/`.

10. **Confirm transaction count data source before NPS spec.** This is the single most uncertain external dependency. If BigTable does not store 30-day transaction counts, an outbound Feign client to a transaction service is needed — and that service must be identified and SLA-agreed before committing to the NPS eligibility implementation.
