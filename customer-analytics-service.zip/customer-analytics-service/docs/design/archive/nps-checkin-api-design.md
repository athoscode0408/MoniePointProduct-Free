# Check-in API Design — Side-by-Side Comparison

> **Status:** Draft — 2026-05-19  
> **Owner:** Mohammed Kamil  
> **Method:** `claude-engineering:design-an-interface` skill (3 parallel sub-agents, one stance each)  
> **Decision required:** Engineer picks one option (or requests a fourth stance)  
> **Downstream:** chosen design becomes input to chunk 05 of `impl-specs/2026-05-18-nps-sampling-engine.md`

---

## Stances Considered

| Option | Stance | Core Trade-off |
|---|---|---|
| **A** | Inline schema | Embed full survey content in every check-in response. Zero follow-up calls. Largest payload. |
| **B** | Reference only | Return only `surveyId` + routing metadata. Smallest payload. Client fetches schema via existing `/api/surveys/schema/{surveyId}`. Two round trips on first show. |
| **C** | ETag-conditional schema | Embed schema only when client's `If-None-Match` ETag doesn't match server's. Single round trip + small steady-state payload + opportunistic schema refresh. Server owns cache-coherence semantics. |

---

## Side-by-Side Comparison

| Dimension | Option A — Inline | Option B — Reference | Option C — ETag-conditional |
|---|---|---|---|
| **HTTP path** | `POST /api/v3/surveys/check-in` | `POST /api/v3/analytics/check-in` | `POST /api/v3/surveys/check-in` |
| **Response body shape** | Always carries full `SurveyBody` per eligible survey | Only `surveyId`, `category`, `triggerCondition`, `classification`, `sampleRef` per eligible survey | `eligible`, `surveyId`, `etag`, `schema` (null on hit, full on miss), `triggerToken` |
| **Payload — single NPS eligible** | ~620 B gzip ✓ under 1KB | ~180 B gzip ✓ | ~190 B gzip on hit / ~3–6KB on miss |
| **Payload — combined NPS+CSAT** | **~1.3–1.5 KB gzip — exceeds 1KB target by 30–50%** ✗ | ~340 B gzip ✓ | ~250 B on hit / ~6–12 KB on miss |
| **Round trips — first show** | **1** (full content inline) | **2** (check-in + schema) | **1** (schema in body on miss) |
| **Round trips — subsequent shows (cached schema)** | 1 | 2 (schema served from existing endpoint cache) | **1** (schema omitted on hit) |
| **Cache coherence model** | None — server always sends content; client always sees latest | CDN cache at `/api/surveys/schema/{surveyId}` with `private, max-age=300` + ETag | Server-driven via `If-None-Match` round trip; client cache invalidates on ETag mismatch |
| **How client knows survey copy changed** | Never stale — every response is fresh | ETag on schema endpoint + 300s max-age | Fresh ETag in response triggers cache replace |
| **Idempotency mechanism** | Deterministic `checkInId = UUIDv5(userId, isoWeek)` + `@Version` on `nps_user_state` + unique key on `nps_weekly_sample` | Unique key on `nps_weekly_sample` + `@Version` + idempotency advisor catches `OptimisticLockingFailureException` | `INSERT … ON DUPLICATE KEY UPDATE` detects replay before state write + `triggerToken` Redis SETNX |
| **Server complexity** | Low — single response shape, no conditional logic | Medium — two endpoints, but `/schema` already exists; new check-in is simple | **High** — ETag derivation, multi-value `If-None-Match` parsing, cache-coherence across API pods |
| **Backward compat with existing `/api/surveys/schema/{surveyId}`** | Makes it redundant for v3 clients (but kept for legacy) | **Reuses it as canonical content source** | Keeps it as fallback; v3 clients normally don't call it |
| **Testability — unit** | Easy (thin controller, fakeable services) | Easy (same shape; fewer response fields to assert) | Medium — ETag derivation needs property-based tests; multi-value header parsing |
| **Testability — concurrency** | Standard — concurrent POST integration test on Testcontainers MySQL | Standard | Hard — cross-pod cache-coherence requires multi-pod integration test |
| **Testability — schema size** | Test that asserts gzip(response) < 1024 B per active survey (build-time guard); combined case fails today | N/A — schema is separate concern | Test the cache-miss branch payload independently from hit branch |
| **POS compatibility (when heartbeat exists)** | POS heartbeat would carry the full schema — at ~1 KB+, possibly OK if heartbeat is generously sized; but heartbeat fires repeatedly so cache benefit is lost | POS heartbeat carries only surveyId reference; client fetches schema once and caches | POS heartbeat steady-state is sub-200 B (cache-hit path) — ideal for repeated heartbeats |
| **Lock-in / reversal cost** | High — every schema field is in the public contract; renaming breaks all clients on next deploy. Mitigation: `version` field for client gating | Medium — `/schema/{surveyId}` endpoint becomes load-bearing forever; clients always do 2 calls | High — 12-char SHA-256 truncation, `If-None-Match` semantics, `triggerToken` lifecycle all in public contract |
| **Observability gain** | Inline-schema-rendered metric must come from client (no server-side render confirmation) | Free server-side "abandoned-before-render" signal via the schema fetch metric | Cache hit/miss rate per client; "stuck cache" detection from miss-rate per `clientId` |
| **Localisation strategy** | Server returns localised strings keyed off `Accept-Language` | Same — but isolated to the schema endpoint, which is naturally cacheable per-locale | Same — but ETag must include locale to avoid serving wrong-language schema on a hit |

---

## Convergences (signal that the design is over-constrained)

All three agents independently reached the same conclusions on:

1. **The endpoint is a POST.** GET is incompatible with the atomic state write of `last_nps_triggered_date`. None of the three proposed any variation of GET.
2. **`@Version` on `nps_user_state` + unique key on `nps_weekly_sample` is the right concurrency model.** All three handle the concurrent-duplicate scenario by combining DB unique-key idempotency for the sample claim and optimistic locking for the cool-off write.
3. **Cool-off / sample-cap / eligibility computation is identical** across stances — they differ only on response-body composition, not on the eligibility resolver logic.
4. **PII masking via `patterns/pii-masking.md`** applies to all logs uniformly; no stance has more PII surface than another because none ship free-text in the check-in response.
5. **`@PreAuthorize` + `@Trace(dispatcher = true)` + `ResponseEntity<T>`** structure per CLAUDE.md is uncontested.

## Irreconcilable Differences

These force the engineer's choice:

| Dimension | The trade-off |
|---|---|
| **Payload budget** | Option A breaks the 1KB target on combined NPS+CSAT (admits this honestly, recommends renegotiating PRD §16). Options B and C stay well under 1KB. |
| **Round trips on first render** | Option A and C are single round-trip; Option B is two. |
| **Server complexity** | Option B is the simplest server-side; Option C is the most complex (ETag derivation, cache coherence across pods); Option A is moderate. |
| **Cache coherence semantics** | Option A has none (always fresh from server). Option B leverages existing HTTP caching on the schema endpoint. Option C invents a content-aware ETag flow inside a POST. |
| **POS heartbeat suitability** | Option A — payload size is a concern for repeated heartbeats. Option B — clean reference model fits heartbeat well. Option C — cache-hit path is ideal for repeated heartbeats. |

---

## Orchestrator Notes

**On the PRD §16 payload budget:** All three agents took the budget seriously. Option A's agent flagged honestly that combined NPS+CSAT breaks the budget and asked for PRD revision; Options B and C both achieve <1KB comfortably. If the budget is non-negotiable, Option A is disqualified unless the team accepts payload negotiation (drop Q2 alternate-band copy, drop `displayConfig` fields).

**On the `triggerToken` concept (Option C introduces it, Option A and B do not explicitly):** A single-use server-issued token that the client echoes back on response submit defends against client-side forgery (a malicious client cannot fake "I was triggered" without an authentic token). This is worth lifting into whichever option is chosen — it's a defense-in-depth measure for the survey-submit endpoint, orthogonal to the response shape.

**On observability:** Each stance reveals a different "natural" signal:
- Option A — must rely on client analytics to confirm render
- Option B — server-side `schema.fetch.surveyId` minus `checkin.surveyId.issued` gives a free abandonment metric
- Option C — cache hit-rate per `clientId` surfaces stuck-cache clients automatically

**On the cross-pod inconsistency window in Option C:** The scenario where a copy edit lands between two concurrent calls on different API pods can produce a transient stale-render. Option C's agent admits this honestly and characterizes it as a sub-second tuning concern (Redis pub-sub invalidation latency). If the team needs strict consistency across pods, Option C requires extra plumbing.

---

## Open Questions for the Engineer

1. **Is the PRD §16 1KB-per-request budget hard or soft?** If hard, Option A is disqualified. If soft (renegotiable for combined NPS+CSAT case), all three remain viable.
2. **Is the existing `GET /api/surveys/schema/{surveyId}` endpoint authoritative, or are we open to deprecating it?** Option B doubles down on it; Option A makes it redundant; Option C uses it as a fallback.
3. **POS heartbeat — is repeated polling expected to fire the schema body each heartbeat (Option A) or only on cache miss (B/C)?** When POS heartbeat infrastructure is built, this choice matters a lot.
4. **Cache coherence requirement on copy edits — is sub-second propagation required (Option C's cross-pod window is too loose), or is "next session" acceptable (Option A and B are fine)?**
5. **Do we want the `triggerToken` server-issued anti-forgery token regardless of stance?** Recommendation: yes — it's defense in depth.

---

# Full Designs (verbatim from sub-agents)

## DESIGN A — Inline Schema

### Stance

The check-in endpoint returns the full, render-ready survey content embedded inline in the response — question text, scale labels, per-band Q2 follow-up copy, dismiss button label, theming hints, and display config — so the client renders immediately with zero follow-up HTTP calls. The trade-off accepted: response bodies grow to ~1.5–2.5 KB pre-gzip (~700–1100 B post-gzip for a typical NPS schema, ~1.3–1.8 KB post-gzip when both NPS and CSAT fire in the same response), which **breaks the 1,024 B post-gzip target** when both surveys are eligible in the same call.

### Interface signature

**Path:** `POST /api/v3/surveys/check-in`

**Request body:**
```json
{ "platform": "MOBILE", "appType": "PERSONAL", "clientId": "ios-7f3c-2026w20", "appVersion": "8.14.2" }
```

**Response body (NPS eligible, CSAT not eligible):**
```json
{
  "checkInId": "8b1e2c4a-9f1d-4a3b-9d6e-2c8a1b5d4e0f",
  "isoWeek": "2026-W20",
  "evaluatedAt": "2026-05-18T09:14:22Z",
  "surveys": [
    {
      "measurementId": "nps.personal.weekly",
      "category": "NPS",
      "surveyId": "srv-nps-personal-v7",
      "version": 7,
      "triggerId": "1f9a3b2c-4d5e-6f70-8190-a1b2c3d4e5f6",
      "outcomeTag": null,
      "expiresAt": "2026-05-25T09:14:22Z",
      "schema": {
        "q1": {
          "text": "How likely are you to recommend Moniepoint to a friend?",
          "scale": { "min": 0, "max": 10, "minLabel": "Not at all", "maxLabel": "Extremely" }
        },
        "q2ByBand": {
          "PROMOTER":  { "prompt": "What did we get right?",      "placeholder": "Tell us more", "maxChars": 500 },
          "PASSIVE":   { "prompt": "What would make this a 10?",  "placeholder": "Tell us more", "maxChars": 500 },
          "DETRACTOR": { "prompt": "What let you down?",          "placeholder": "Tell us more", "maxChars": 500 }
        },
        "dismissLabel": "Not now",
        "submitLabel": "Send"
      },
      "display": { "presentation": "BOTTOM_SHEET", "theme": "AUTO", "delayMs": 800, "dismissible": true }
    }
  ]
}
```

**Spring controller signature:**
```java
@RestController
@RequestMapping("/api/v3/surveys")
@RequiredArgsConstructor
public class CheckInController {

    private final CheckInService checkInService;

    @PostMapping("/check-in")
    @PreAuthorize("hasAuthority('" + CosmosAuthorities.SURVEY_CHECKIN + "')")
    @Trace(dispatcher = true)
    public ResponseEntity<CheckInResponse> checkIn(
            @AuthenticationPrincipal AuthenticatedUser user,
            @Valid @RequestBody CheckInRequest request) {

        if (user == null || isBlank(user.getUserId())) {
            throw new BadRequestException("userId missing from principal");
        }
        CheckInResponse body = checkInService.resolve(user.getUserId(), request);
        return ResponseEntity.ok()
                .header("X-Idempotency-Key", body.checkInId().toString())
                .cacheControl(CacheControl.noStore())
                .body(body);
    }
}
```

**Response DTO records:**
```java
public record CheckInResponse(UUID checkInId, String isoWeek, Instant evaluatedAt, List<InlineSurvey> surveys) {}

public record InlineSurvey(
        String measurementId, SurveyCategory category, String surveyId, int version,
        UUID triggerId, OutcomeTag outcomeTag, Instant expiresAt,
        SurveyBody schema, DisplayConfig display) {}
```

### Trade-offs

- **Gains:** True single round trip; server-client schema-version consistency guaranteed by construction (same bytes evaluated and rendered); `/api/surveys/schema/{surveyId}` becomes redundant for v3 clients; atomicity co-located with read of content the client sees.
- **Costs:** Combined NPS+CSAT response is **~1.3–1.5 KB gzip — exceeds 1KB target by 30–50%**. Author honestly recommends renegotiating PRD §16 to ~1.5KB for the combined case. Daily 50KB budget remains comfortable (~33 check-ins/day at worst-case payload). Schema field renames are instant breaking changes; mitigated by `version` field on `InlineSurvey`.
- **Lock-in:** Every client release is tied to the inline schema shape. Cannot CDN-cache (per-user, write-bearing). Future categories compound the payload budget problem linearly.

### Observability

Inline-schema stance loses one signal: **no server-side proof that the client rendered**. Must rely on a client-emitted `cas.client.survey.rendered{triggerId}` analytics event to detect abandoned triggers. This is the one observability hole the stance creates.

---

## DESIGN B — Reference Only

### Stance

The check-in endpoint is a pure eligibility resolver: it returns only opaque identifiers and routing metadata (`surveyId`, `triggerCondition`, `classification`), never question text, copy, scale labels, or display config. Clients that receive a non-empty eligibility list make a second, independent call to the pre-existing `GET /api/surveys/schema/{surveyId}` to fetch renderable content — trading one extra HTTP round-trip (only when a survey is actually eligible) for a guaranteed sub-256-byte check-in payload, perfect cacheability of schemas at the CDN edge, and a clean architectural seam between eligibility (stateful, write-side) and content (stateless, read-side).

### Interface signature

**Path:** `POST /api/v3/analytics/check-in`

**Request body:**
```json
{ "platform": "MOBILE", "appType": "PERSONAL", "clientId": "ios-7d3c9f2a" }
```

**Response body — both surveys eligible:**
```json
{
  "eligibilities": [
    {
      "surveyId": "7c1f2a90-3d4e-4b1c-9a8e-1b2c3d4e5f60",
      "category": "NPS",
      "triggerCondition": "NPS_WEEKLY_SAMPLE",
      "classification": "PRIMARY",
      "sampleRef": "nps:2026-W20:01H..."
    },
    {
      "surveyId": "a2b4c6d8-1111-2222-3333-444455556666",
      "category": "CSAT",
      "triggerCondition": "CSAT_JOURNEY_SUCCESS",
      "classification": "SECONDARY",
      "sampleRef": null
    }
  ],
  "resolvedAt": "2026-05-18T09:14:22Z"
}
```

Byte count: ~340 B uncompressed; ~180 B gzipped.

**Empty-eligibility response (~50 B):** `{ "eligibilities": [], "resolvedAt": "..." }`

**Schema endpoint contract (unchanged):**
```
GET /api/surveys/schema/{surveyId}
Cache-Control: private, max-age=300
ETag: "<hash>"
```

**Spring controller signature:**
```java
@RestController
@RequestMapping("/api/v3/analytics")
@RequiredArgsConstructor @Slf4j
public class CheckInController {

    private final CheckInService checkInService;

    @PostMapping("/check-in")
    @PreAuthorize("hasAuthority('" + COSMOS_ROLE_PREFIX + "CHECK_IN_RESOLVE')")
    @Trace(dispatcher = true)
    public ResponseEntity<CheckInResponse> resolveCheckIn(
            @AuthenticationPrincipal AuthenticatedUser principal,
            @Valid @RequestBody CheckInRequest request) {

        if (principal == null || isBlank(principal.userId())) {
            throw new BadRequestException("userId not resolvable from principal");
        }
        CheckInResponse body = checkInService.resolve(principal.userId(), request);
        return ResponseEntity.ok()
                .cacheControl(CacheControl.noStore())
                .body(body);
    }
}
```

**Response DTOs:**
```java
public record CheckInResponse(List<SurveyEligibility> eligibilities, Instant resolvedAt) {}

public record SurveyEligibility(
        UUID surveyId, SurveyCategory category, TriggerCondition triggerCondition,
        Classification classification, String sampleRef) {}
```

### Trade-offs

- **Gains:** 3× safer than 1KB ceiling with both surveys eligible; daily 50KB envelope absorbs ~150 check-ins/day worst case; schema endpoint independently cacheable at CDN edge; schema-version evolution is a non-event (bump ETag → clients refetch); minimal PII surface (UUIDs only).
- **Costs:** +1 round-trip on first render (~30–80ms extra mobile latency before render). Two failure modes for client (check-in failure vs schema-fetch failure). Cold cache miss eats real origin RTT. No way to A/B-test "render the banner" purely server-side.
- **Lock-in:** `/api/surveys/schema/{surveyId}` is now load-bearing forever; clients always do 1 or 2 calls. `sampleRef` is part of public contract.

### Observability

Most explicit "abandoned-before-render" signal among the three: `cas.survey.abandoned_before_render = checkin.surveyId.issued − schema.surveyId.fetched`. Distributed-trace cohesion is the cost — two independent traces joined post-hoc via `X-Correlation-Id`.

---

## DESIGN C — ETag-Conditional Schema

### Stance

The check-in endpoint is a state-changing POST whose response body is content-aware: the survey schema is inlined only when the client's `If-None-Match` header does not match the server's currently-computed ETag for `(surveyId, lastModifiedOn)`. On a match, the response is a sub-200-byte eligibility verdict; on a miss, the response embeds the full schema plus a fresh `ETag` response header — single round-trip, schema-renderable, regardless of cache state.

### Interface signature

**Path:** `POST /api/v3/surveys/check-in`

**ETag derivation:**
```
etag = HEX( SHA-256( surveyId + ":" + lastModifiedOn.toEpochMilli() ) ).substring(0, 12)
```

**Request:**
```http
POST /api/v3/surveys/check-in
If-None-Match: "a3f1c2d4e5b6", "b7e8c9d1a2f4"
X-Correlation-Id: 01H...

{ "platform": "MOBILE", "appType": "PERSONAL", "clientId": "ios-app-3.42.1", "isoWeek": "2026-W20" }
```

**Cache-hit response (~190 B):**
```json
{
  "correlationId": "01HX9...",
  "decisions": [
    {
      "category": "NPS",
      "eligible": true,
      "surveyId": "nps-personal-2026q2",
      "etag": "a3f1c2d4e5b6",
      "schema": null,
      "triggerToken": "tok_8f2a91"
    }
  ],
  "schemaPolicy": "CONDITIONAL"
}
```

**Cache-miss response (~3–6 KB):** same shape, `schema: { ... full SurveyBody ... }`.

**Spring controller signature:**
```java
@RestController
@RequestMapping("/api/v3/surveys")
@RequiredArgsConstructor @Slf4j
public class SurveyCheckInV3Controller {

    private final SurveyCheckInService checkInService;

    @PostMapping("/check-in")
    @PreAuthorize("hasAuthority('" + COSMOS_ROLE_PREFIX + "USER')")
    @Trace(dispatcher = true)
    public ResponseEntity<CheckInResponse> checkIn(
            @AuthenticationPrincipal AuthenticatedUser user,
            @RequestHeader(value = HttpHeaders.IF_NONE_MATCH, required = false) String ifNoneMatch,
            @RequestHeader(value = "X-Correlation-Id", required = false) String correlationId,
            @Valid @RequestBody CheckInRequest request) {

        if (user.userId() == null || user.userId().isBlank()) {
            throw new BadRequestException("userId missing from principal");
        }

        var clientEtags = IfNoneMatchParser.parse(ifNoneMatch);
        var result = checkInService.resolve(user.userId(), request, clientEtags, correlationId);

        return ResponseEntity.ok()
                .header(HttpHeaders.ETAG, IfNoneMatchParser.join(result.authoritativeEtags()))
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .body(result.body());
    }
}
```

**Response DTO:**
```java
public record CheckInResponse(String correlationId, List<Decision> decisions, SchemaPolicy schemaPolicy) {
    public record Decision(
            SurveyCategory category, boolean eligible, String reason,
            String surveyId, String etag, SurveyBody schema, String triggerToken) {}
}
public enum SchemaPolicy { CONDITIONAL }
```

### Trade-offs

- **Gains:** Steady-state response ~190 B (well under 1KB); single round-trip on both cache-hit and cache-miss paths; opportunistic schema refresh whenever copy changes; `ETag` response header lets clients self-audit cache integrity. PRD §16 becomes trivial.
- **Costs:** Server must compute ETag on every call (cheap SHA-256). Multi-value `If-None-Match` parsing must be RFC 7232-correct. Cache-coherence across API pods is now correctness-adjacent (Scenario 3 in the agent output shows it's bounded but real). Error path more complex.
- **Lock-in:** 12-char SHA-256 truncation is now a public contract. `schemaPolicy: CONDITIONAL` is a forward-compat hook but `CONDITIONAL` becomes the default forever. `triggerToken` semantics enter the contract.

### Why POST, not 304

The check-in is always a state mutation — it writes `last_nps_triggered_date` and increments `nps_weekly_sample` counters. HTTP 304 means "your cached representation is still valid" — that conflates two orthogonal concerns: (a) is the survey schema still current, and (b) is today's eligibility the same as yesterday's. (b) is never cacheable. So we always return 200 with a body containing freshly-computed eligibility, and use `If-None-Match` / `ETag` as a payload-shaping signal within that body.

### Observability

Naturally produces a cache hit-rate signal per `clientId`. Stuck-cache detection: any `clientId` with sustained 100% miss rate while peers see >90% hit rate is shipping a release that fails to persist ETags. Schema-version-currency distribution across the user base is observable end-to-end without extra instrumentation.

---

## Recommendation Framework

The skill protocol forbids the orchestrator from picking a winner. Use these prompts:

| If the team prioritises... | Choose |
|---|---|
| Smallest payload, simplest server, leveraging existing endpoint, future POS heartbeat | **B (Reference only)** |
| Single round trip on both hit and miss paths, smart caching, opportunistic schema refresh | **C (ETag-conditional)** |
| Zero conditional logic, guaranteed schema-version consistency, simplest client | **A (Inline)** — **but accept renegotiating PRD §16 to ~1.5KB** |

If the engineer wants a fourth stance explored (e.g., "small content + ETag" hybrid, or "always inline but with hard schema-size budget enforcement"), the orchestrator can dispatch another sub-agent.

---

## Next Steps After Decision

1. Engineer picks one of A / B / C (or requests a fourth stance).
2. If Tier-3 paths are touched (they are — check-in writes `nps_user_state`, `nps_weekly_sample`), run `/grill-me` to stress-test the chosen design before locking it in.
3. The chosen design becomes input to **chunk 05** of `impl-specs/2026-05-18-nps-sampling-engine.md`.
4. An ADR documents the choice and the rejected alternatives (consider `adrs/ADR-004-checkin-api-shape.md`).
