# NPS Sampling Programme — Domain Design

> **Status:** Draft — 2026-05-19  
> **Relates to:** `impl-specs/2026-05-18-nps-sampling-engine.md` (all 12 challenge questions resolved)  
> **PRD:** [NPS PRD v1.0 — teamapt PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD)  
> **ADRs:** `adrs/ADR-001`, `adrs/ADR-002`, `adrs/ADR-003`

---

## 1. Overview

This document describes *how* the NPS Sampling Programme works inside the Customer Analytics Service (CAS). The impl spec says *what* to build; this document says *how the domain model, invariants, algorithms, and flows are designed* so that implementation can proceed with confidence.

### 1.1 What this document covers (Phase 1)

- Domain model: entities, aggregates, value objects, invariants, enforcement mechanisms
- Database schema design: tables, column types, indexes, constraints
- Component design: services, repositories, jobs, controllers, Kafka events, Redis state
- Sequence diagrams for all five core flows
- Eligibility engine design and gate-evaluation order
- Sampling algorithm
- Calendar-week invariants
- NPS score calculation (formula and edge cases)
- Payload budget enforcement
- Observability (metrics, log masking, alerts)

### 1.2 What this document does NOT cover

- POS heartbeat delivery (POS heartbeat infrastructure does not exist — deferred per ADR-004 equivalent; see impl-spec C-04)
- Weekly AI summary (Phase 1.5 — deferred per impl-spec C-08)
- CSAT domain model (separate spec; CSAT will mirror the pattern established here)
- Survey UI rendering (web modal / mobile bottom sheet — owned by client teams)

### 1.3 Relationship to existing CAS components

CAS already has a working survey pipeline for BRM surveys:

```
SurveyEventListener → SurveyEvaluatorListener → SurveyPreprocessorListener → CompletedSurveyListener
```

NPS reuses this pipeline and extends it with NPS-specific branches. The `Survey` and `PreprocessedSurvey` entities are reused. New NPS-specific entities (`NpsCohort`, `NpsMeasurement`, `NpsUserState`, `NpsWeeklySample`, `NpsWeeklyScore`) are introduced in a distinct sub-package.

---

## 2. Domain Model

### 2.1 Aggregate Map

The NPS domain has five aggregate roots. Each aggregate root owns its data. Cross-aggregate references use foreign-key IDs only — no JPA `@ManyToOne` or `@OneToMany` across root boundaries.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         NPS Domain                                       │
│                                                                          │
│  ┌──────────────┐     ┌──────────────────┐     ┌──────────────────┐    │
│  │  NpsCohort   │◄────│  NpsMeasurement  │     │  NpsUserState    │    │
│  │ (aggregate   │     │  (aggregate root)│     │  (aggregate root)│    │
│  │  root)       │     │                  │     │  1 row per user  │    │
│  └──────────────┘     └──────────────────┘     └──────────────────┘    │
│                               │  1:N                    ▲               │
│                               │                         │               │
│                               ▼                         │               │
│                    ┌─────────────────────┐              │               │
│                    │  NpsWeeklySample    │──────────────┘               │
│                    │  (aggregate root)   │   cool-off check             │
│                    │  1 row per          │                              │
│                    │  (user,meas,week)   │                              │
│                    └─────────────────────┘                              │
│                               │                                         │
│                               │  aggregated into                        │
│                               ▼                                         │
│                    ┌─────────────────────┐                              │
│                    │  NpsWeeklyScore     │                              │
│                    │  (aggregate root)   │                              │
│                    │  1 row per          │                              │
│                    │  (meas, week)       │                              │
│                    └─────────────────────┘                              │
│                                                                          │
│  Reused (by reference only):                                            │
│    Survey [VERIFIED] — survey definition + SurveyBody JSON              │
│    PreprocessedSurvey [VERIFIED] — per-user survey instance + TTL       │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Entity Schemas

All entities extend `BaseEntity` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/common/entity/BaseEntity.java`], which contributes:

| Field | Type | Annotation | Purpose |
|---|---|---|---|
| `id` | `Long` | `@Id @GeneratedValue(IDENTITY)` | Surrogate primary key |
| `createdBy` | `String` | `@CreatedBy @Column(updatable=false)` | Spring Auditing |
| `createdOn` | `Timestamp` | `@CreatedDate @Column(updatable=false)` | Spring Auditing |
| `lastModifiedBy` | `String` | `@LastModifiedBy` | Spring Auditing |
| `lastModifiedOn` | `Timestamp` | `@LastModifiedDate` | Spring Auditing |
| `version` | `Integer` | `@Version` | **Optimistic concurrency — prevents double-write** |

---

#### 2.2.1 `NpsCohort`

Represents a configured user segment that a PM can target with an NPS measurement.

```
@Entity @Table(name = "nps_cohort")
class NpsCohort extends BaseEntity {

  @Column(name = "name", nullable = false, length = 100)
  String name;

  @Column(name = "description", length = 500)
  String description;                              // nullable

  @Enumerated(EnumType.STRING)
  @Column(name = "segment", nullable = false, length = 30)
  CohortSegment segment;                           // PERSONAL_BANKING | BUSINESS_BANKING | AGENTS

  @Enumerated(EnumType.STRING)
  @Column(name = "customer_age_band", nullable = false, length = 30)
  CustomerAgeBand customerAgeBand;                 // see enum definition §2.3

  @Column(name = "entity_scope", length = 50)
  String entityScope;                              // nullable = all entities

  @Column(name = "weekly_invitation_cap", nullable = false)
  int weeklyInvitationCap;                         // > 0; Personal default 3200, Business 2134
}
```

**DB table:** `nps_cohort`  
**Unique index:** `(segment, customer_age_band, entity_scope)` — prevents duplicate cohort definitions  
**Cascade:** none (cohort is referenced by NpsMeasurement; it is not deleted while measurements exist)

---

#### 2.2.2 `NpsMeasurement`

A PM-configured measurement linking a cohort to a platform scope. Multiple measurements can run simultaneously and be compared side-by-side.

```
@Entity @Table(name = "nps_measurement")
class NpsMeasurement extends BaseEntity {

  @Column(name = "cohort_id", nullable = false)
  Long cohortId;                                   // FK → nps_cohort.id (no JPA association)

  @Enumerated(EnumType.STRING)
  @Column(name = "platform_scope", nullable = false, length = 30)
  PlatformScope platformScope;                     // PERSONAL_MOBILE | PERSONAL_WEB | BUSINESS_MOBILE | BUSINESS_WEB

  @Enumerated(EnumType.STRING)
  @Column(name = "app_type", nullable = false, length = 20)
  AppType appType;                                 // PERSONAL | BUSINESS (derived from platformScope, stored for query efficiency)

  @Enumerated(EnumType.STRING)
  @Column(name = "status", nullable = false, length = 20)
  MeasurementStatus status;                        // ACTIVE | PAUSED | ENDED; default ACTIVE

  @Column(name = "start_date", nullable = false)
  LocalDate startDate;

  @Column(name = "end_date")
  LocalDate endDate;                               // nullable = open-ended
}
```

**DB table:** `nps_measurement`  
**Unique index (partial):** `(cohort_id, platform_scope) WHERE status = 'ACTIVE'` — only one active measurement per cohort+platform at a time (partial index on MySQL via application-layer guard, since MySQL partial indexes require expression indexes in 8.0+; enforced in service layer with a pre-insert check + `@Version`)

---

#### 2.2.3 `NpsUserState`

Per-user NPS cool-off state. **Global across all NPS measurements for the user** — one row per user, regardless of how many measurements are active. Cool-off is NPS-specific (not shared with CSAT or BRM).

```
@Entity @Table(name = "nps_user_state")
class NpsUserState extends BaseEntity {

  @Column(name = "user_id", nullable = false, length = 50, unique = true)
  String userId;                                   // UNIQUE INDEX — one row per user

  @Column(name = "last_nps_triggered_date")
  LocalDate lastNpsTriggeredDate;                  // nullable; set at trigger, NOT at response

  @Enumerated(EnumType.STRING)
  @Column(name = "last_nps_response_classification", length = 20)
  NpsRespondentClassification lastNpsResponseClassification; // nullable; PROMOTER | PASSIVE | DETRACTOR

  @Column(name = "trigger_year")
  Short triggerYear;                               // nullable; year of last trigger for annual-cap reset

  @Column(name = "trigger_count_year", nullable = false)
  short triggerCountYear = 0;                      // count of triggers in triggerYear; hard cap ≤ 2
}
```

**DB table:** `nps_user_state`  
**Unique index:** `(user_id)`  
**Index:** `(last_nps_triggered_date)` — optimises cool-off batch exclusion in sampling job  
**Concurrency note:** `@Version` (inherited) is the primary guard against concurrent double-trigger. Concurrent login attempts on the same user will result in one succeeding and one receiving `OptimisticLockException`.

---

#### 2.2.4 `NpsWeeklySample`

One row per user per measurement per ISO week. Written by `NpsWeeklySamplePreparationJob` at week start; updated to SERVED atomically at check-in trigger.

```
@Entity @Table(name = "nps_weekly_sample")
class NpsWeeklySample extends BaseEntity {

  @Column(name = "user_id", nullable = false, length = 50)
  String userId;

  @Column(name = "measurement_id", nullable = false)
  Long measurementId;                              // FK → nps_measurement.id

  @Column(name = "iso_week", nullable = false, length = 8)
  String isoWeek;                                  // "YYYY-Www", e.g. "2026-W20"

  @Enumerated(EnumType.STRING)
  @Column(name = "status", nullable = false, length = 20)
  NpsWeeklySampleStatus status = NpsWeeklySampleStatus.PENDING;

  @Column(name = "sampled_at", nullable = false)
  Timestamp sampledAt;

  @Column(name = "served_at")
  Timestamp servedAt;                              // nullable; set atomically when status → SERVED

  // Domain method — sets both fields atomically, preventing partial state
  public void markServed(Timestamp at) {
    if (!NpsWeeklySampleStatus.PENDING.canTransitionTo(NpsWeeklySampleStatus.SERVED)) {
      throw new BadRequestException("sample already served or terminal");
    }
    this.status = NpsWeeklySampleStatus.SERVED;
    this.servedAt = at;
  }
}
```

**DB table:** `nps_weekly_sample`  
**Unique index:** `(user_id, measurement_id, iso_week)` — prevents duplicate sampling of the same user into the same measurement in the same week  
**Index:** `(iso_week, status)` — used by sampling job and score aggregation job  
**Index:** `(measurement_id, iso_week, status)` — used by score aggregation job

---

#### 2.2.5 `NpsWeeklyScore`

Read-side projection: one row per measurement per ISO week. Written by `NpsWeeklyScoreAggregationJob` at week close + 6 hours. **Immutable after write.**

```
@Entity @Table(name = "nps_weekly_score")
class NpsWeeklyScore extends BaseEntity {

  @Column(name = "measurement_id", nullable = false)
  Long measurementId;                              // FK → nps_measurement.id

  @Column(name = "iso_week", nullable = false, length = 8)
  String isoWeek;                                  // "YYYY-Www"

  @Column(name = "nps_score", nullable = false)
  int npsScore;                                    // range -100 to +100

  @Column(name = "promoter_pct", nullable = false, precision = 5, scale = 2)
  BigDecimal promoterPct;                          // e.g. 50.00

  @Column(name = "passive_pct", nullable = false, precision = 5, scale = 2)
  BigDecimal passivePct;

  @Column(name = "detractor_pct", nullable = false, precision = 5, scale = 2)
  BigDecimal detractorPct;                         // promoterPct + passivePct + detractorPct = 100.00

  @Column(name = "promoter_count", nullable = false)
  long promoterCount;

  @Column(name = "passive_count", nullable = false)
  long passiveCount;

  @Column(name = "detractor_count", nullable = false)
  long detractorCount;

  @Column(name = "population_size", nullable = false)
  long populationSize;                             // total eligible users that week

  @Column(name = "sample_size", nullable = false)
  long sampleSize;                                 // users selected in nps_weekly_sample

  @Column(name = "respondent_size", nullable = false)
  long respondentSize;                             // users with status=RESPONDED

  @Column(name = "response_rate", nullable = false, precision = 6, scale = 4)
  BigDecimal responseRate;                         // respondentSize / sampleSize

  @Column(name = "computed_at", nullable = false)
  Timestamp computedAt;
}
```

**DB table:** `nps_weekly_score`  
**Unique index:** `(measurement_id, iso_week)` — one score row per measurement per week  
**Immutability:** No `update` method on `NpsWeeklyScoreStorage`. Once written, the row is never updated (the job is idempotent via `INSERT IGNORE` / upsert-if-absent semantics on the unique index).

---

### 2.3 Enum Definitions

#### `CohortSegment`
| Value | DB String | Meaning |
|---|---|---|
| `PERSONAL_BANKING` | `"PERSONAL_BANKING"` | Personal app users |
| `BUSINESS_BANKING` | `"BUSINESS_BANKING"` | Business app users |
| `AGENTS` | `"AGENTS"` | Moniepoint agents |

#### `CustomerAgeBand`
| Value | DB String | Meaning |
|---|---|---|
| `LESS_THAN_30_DAYS` | `"LESS_THAN_30_DAYS"` | Account age < 30 days |
| `GE_30_DAYS_LT_60` | `"GE_30_DAYS_LT_60"` | 30 ≤ age < 60 days |
| `GE_60_DAYS` | `"GE_60_DAYS"` | Age ≥ 60 days (NPS eligible band) |
| `GE_60_DAYS_LT_90` | `"GE_60_DAYS_LT_90"` | 60 ≤ age < 90 days |
| `GE_90_DAYS_LT_180` | `"GE_90_DAYS_LT_180"` | 90 ≤ age < 180 days |
| `GE_180_DAYS_LT_360` | `"GE_180_DAYS_LT_360"` | 180 ≤ age < 360 days |
| `GE_360_DAYS` | `"GE_360_DAYS"` | Age ≥ 360 days |

#### `PlatformScope`
| Value | DB String | Meaning |
|---|---|---|
| `PERSONAL_MOBILE` | `"PERSONAL_MOBILE"` | Personal App, mobile client |
| `PERSONAL_WEB` | `"PERSONAL_WEB"` | Personal App, web client |
| `BUSINESS_MOBILE` | `"BUSINESS_MOBILE"` | Business App, mobile client |
| `BUSINESS_WEB` | `"BUSINESS_WEB"` | Business App, web client |

#### `AppType`
| Value | DB String | Meaning |
|---|---|---|
| `PERSONAL` | `"PERSONAL"` | Personal App |
| `BUSINESS` | `"BUSINESS"` | Business App |

#### `MeasurementStatus`
| Value | DB String | Transitions | Terminal? |
|---|---|---|---|
| `ACTIVE` | `"ACTIVE"` | → PAUSED, → ENDED | No |
| `PAUSED` | `"PAUSED"` | → ACTIVE | No |
| `ENDED` | `"ENDED"` | (none) | **Yes** |

#### `NpsRespondentClassification`
| Value | DB String | Score Range |
|---|---|---|
| `PROMOTER` | `"PROMOTER"` | 9 – 10 |
| `PASSIVE` | `"PASSIVE"` | 7 – 8 |
| `DETRACTOR` | `"DETRACTOR"` | 0 – 6 |

#### `NpsWeeklySampleStatus`
| Value | DB String | Meaning | Valid next states |
|---|---|---|---|
| `PENDING` | `"PENDING"` | Sampled, not yet served | → SERVED, → EXPIRED |
| `SERVED` | `"SERVED"` | Survey delivered at check-in | → RESPONDED, → DISMISSED, → EXPIRED |
| `RESPONDED` | `"RESPONDED"` | User submitted a response | (terminal) |
| `DISMISSED` | `"DISMISSED"` | User dismissed (reminder eligible) | → SERVED (on reminder), → EXPIRED |
| `EXPIRED` | `"EXPIRED"` | Week closed without response | (terminal) |

---

### 2.4 Invariant Catalogue

Every business rule and its enforcement mechanism. Rules are grouped by entity.

#### NpsCohort Invariants

| Invariant | How Enforced |
|---|---|
| `(segment, customerAgeBand, entityScope)` must be unique | DB unique index. `DataIntegrityViolationException` caught at service layer → `BadRequestException` with 409 |
| `weeklyInvitationCap > 0` | `@Min(1) @NotNull` on `NpsCohortCreateRequest` DTO; service-layer precondition check before save |
| Cannot delete cohort while active measurements reference it | `NpsCohortService.delete()` queries for active `NpsMeasurement` rows referencing this cohort; throws `BadRequestException` if any exist |

#### NpsMeasurement Invariants

| Invariant | How Enforced |
|---|---|
| One ACTIVE measurement per `(cohortId, platformScope)` at a time | `NpsMeasurementService.activate()` queries for existing ACTIVE before save; `@Version` prevents TOCTOU on concurrent activation |
| `endDate > startDate` when endDate is set | `@AssertTrue` validation on DTO |
| Status transition is one-directional (ENDED is terminal) | `MeasurementStatus.canTransitionTo(next)` returns `false` for illegal transitions; service throws `BadRequestException`; `ENDED → *` always returns false |
| `startDate` must not be in the past by more than 1 week | Warning logged; not rejected (allows retroactive measurement creation) |

#### NpsUserState Invariants

| Invariant | How Enforced |
|---|---|
| One row per `userId` | DB UNIQUE INDEX on `user_id`. Upsert on conflict (`INSERT ... ON DUPLICATE KEY UPDATE`) |
| `triggerCountYear ≤ 2` | `NpsEligibilityResolver` checks before triggering; `NpsUserState.recordTrigger()` throws `IllegalStateException` if `triggerCountYear >= 2` for the current year |
| `lastNpsTriggeredDate` written **at trigger**, not at response | `CheckInPrecommitService` writes `NpsUserState` and `NpsWeeklySample.status=SERVED` atomically in `@Transactional` before returning the check-in response — before the survey is displayed to the user |
| `@Version` prevents concurrent double-write | `OptimisticLockException` on second concurrent trigger write; `CheckInPrecommitService` catches and returns already-served state |
| `triggerYear` is reset when current year > `triggerYear` | `NpsUserState.recordTrigger(LocalDate)` checks `triggerYear != currentYear` and resets `triggerCountYear = 0, triggerYear = currentYear` before incrementing |

#### NpsWeeklySample Invariants

| Invariant | How Enforced |
|---|---|
| `(userId, measurementId, isoWeek)` unique | DB UNIQUE INDEX. Batch insert in sampling job uses `INSERT IGNORE` semantics (idempotent re-run) |
| Status transitions are one-way | `NpsWeeklySampleStatus.canTransitionTo(next)` guard; `NpsWeeklySample.markServed()` validates before state change |
| `servedAt` non-null iff `status ≥ SERVED` | `markServed()` sets both atomically; no public setter for `servedAt` alone |
| `servedAt ≥ sampledAt` | Asserted in `markServed()` — `servedAt.before(sampledAt)` throws `IllegalArgumentException` |

#### NpsWeeklyScore Invariants

| Invariant | How Enforced |
|---|---|
| `(measurementId, isoWeek)` unique | DB UNIQUE INDEX. Job uses `INSERT IGNORE` (idempotent re-run) |
| `promoterPct + passivePct + detractorPct = 100.00 (± 0.01)` | `NpsScoreCalculator.calculate()` computes `passivePct = 100 - promoterPct - detractorPct` to eliminate floating-point drift; constructor assertion |
| `npsScore = round(promoterPct − detractorPct)` | `NpsScoreCalculator.calculate()` enforces; unit test covers formula with worked examples |
| `respondentSize ≤ sampleSize ≤ populationSize` | `NpsScoreCalculator.validate()` asserts before persisting |
| `responseRate = respondentSize / sampleSize` at scale 4 | Computed by `NpsScoreCalculator`; `respondentSize = 0` → `responseRate = 0` (no division by zero) |
| Immutable after write | No `update()` on `NpsWeeklyScoreStorage`; service layer never calls `save()` on existing row |

---

### 2.5 `SurveyBody` NPS Extension Fields

`SurveyBody` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/dto/v3/SurveyBody.java`] uses `@JsonAnyGetter`/`@JsonAnySetter` for unknown properties and `@JsonIgnoreProperties(ignoreUnknown = true)`. Adding typed `@JsonProperty` fields is **backward-compatible**: Jackson deserializes known fields into their typed members; the `@JsonAnySetter` handler only receives properties with no matching field.

New fields added in chunk 01 (grouped in a nested `NpsConfig` section for readability):

```java
// Added to SurveyBody.java — backward-compatible (unknown fields ignored by existing clients)

private int weeklyInvitationCap;          // default 3200 (Personal) or 2134 (Business) per cohort
private int reminderMinIntervalHours;     // min hours before a reminder fires (default 24)
private int coolOffDays;                  // NPS-specific cool-off period in days (default 90)
private int yearlyTriggerCap;             // max NPS triggers per calendar year (default 2)
private String q2CopyDetractor;           // Q2 follow-up for scores 0–6
private String q2CopyPassive;             // Q2 follow-up for scores 7–8
private String q2CopyPromoter;            // Q2 follow-up for scores 9–10
```

These fields are populated by the NPS `Survey` row (admin-managed). They are **not serialized into the check-in response** — `CheckInSurveyItem` DTO maps only client-visible fields.

---

## 3. Database Schema Design

All DDL scripts are produced by the DB migrations team in the dedicated migrations repo. This section describes the schema for coordination purposes only.

### 3.1 Table Summary

| Table | Owner | Row count estimate | Notes |
|---|---|---|---|
| `nps_cohort` | CAS | < 100 | Rarely changes; cached aggressively |
| `nps_measurement` | CAS | < 50 | Rarely changes; cached |
| `nps_user_state` | CAS | Up to 24M+ | Critical hot path; unique index on user_id |
| `nps_weekly_sample` | CAS | ~16,640/week (sum of all caps) | Grows ~860K/year; partition by year recommended |
| `nps_weekly_score` | CAS | ~52 × active measurements / year | Small; no partitioning needed |

### 3.2 Index Design

#### `nps_cohort`
```sql
UNIQUE KEY uq_nps_cohort_definition (segment, customer_age_band, entity_scope)
```

#### `nps_measurement`
```sql
-- Partial-unique enforced in application layer (MySQL 8+ expression index alternative):
INDEX idx_nps_measurement_active (cohort_id, platform_scope, status)
-- Application ensures only one ACTIVE per (cohort_id, platform_scope)
```

#### `nps_user_state`
```sql
UNIQUE KEY uq_nps_user_state_user (user_id)
INDEX idx_nps_user_state_triggered (last_nps_triggered_date)    -- sampling cool-off batch scan
```

#### `nps_weekly_sample`
```sql
UNIQUE KEY uq_nps_weekly_sample (user_id, measurement_id, iso_week)
INDEX idx_nps_weekly_sample_week_status (iso_week, status)       -- score aggregation job
INDEX idx_nps_weekly_sample_meas_week (measurement_id, iso_week, status)  -- per-measurement queries
```

#### `nps_weekly_score`
```sql
UNIQUE KEY uq_nps_weekly_score (measurement_id, iso_week)
```

### 3.3 Key Design Choices

**ISO week as `CHAR(8)`:** `"2026-W20"` is lexicographically sortable without date parsing, cheaper than two `DATE` columns, and unambiguous. All week-range queries use `BETWEEN '2026-W01' AND '2026-W52'`.

**BigDecimal scale:** Percentages at `DECIMAL(5,2)` (e.g. `99.99`). Response rate at `DECIMAL(6,4)` (e.g. `0.9999`). Score counts as `BIGINT` not `INT` — population can exceed 24M.

**No Bigtable foreign keys:** `nps_user_state.user_id` is the same user identifier used across the platform but is stored as a `VARCHAR(50)` in MySQL — no FK reference to Bigtable. CAS owns its own state tables.

---

## 4. Component Design

### 4.1 Service Layer

#### `NpsEligibilityResolver` [PROPOSED — chunk 03]

Resolves whether a user should be served an NPS survey at check-in. Gates are evaluated in fast-fail order (cheapest first):

```
Gate 1: sample membership   [Redis]     — is userId in nps_weekly_sample for currentWeek?
Gate 2: cool-off            [MySQL]     — lastNpsTriggeredDate > today − 90 days?
Gate 3: year cap            [MySQL]     — triggerCountYear >= 2 in current year?
Gate 4: account age         [BigTable]  — onboardingDate > today − 60 days?
Gate 5: transaction recency [BigTable]  — lastTxnDate < today − 30 days?
```

**Key insight:** BigTable is accessed once via `UserAttributesStorage.findUser()` [VERIFIED] for gates 4+5 — a single round trip. Gates 2+3 share the same MySQL row read from `NpsUserStateStorage`.

If all gates pass → `EligibilityResult.SERVE(sampleId)`.  
If any gate fails → `EligibilityResult.SKIP(reason)` where reason is one of `NOT_SAMPLED | COOL_OFF | YEAR_CAP | ACCOUNT_AGE | TX_RECENCY`.

**The resolver does NOT write state.** Writing (marking SERVED, updating NpsUserState) is done by `CheckInPrecommitService` after the full NPS+CSAT resolution completes.

#### `CheckInPrecommitService` [PROPOSED — chunk 05]

Orchestrates the check-in pre-commitment call:

1. Call `NpsEligibilityResolver.resolve(userId, platform, appType)`
2. If `SERVE`: build `CheckInSurveyItem` from the `Survey` row; validate payload size < 1024B via `CheckInPayloadBudgetGuard`
3. Atomically in `@Transactional`:
   - `NpsWeeklySample.markServed(now)`
   - `NpsUserState.recordTrigger(today)` (upsert)
4. Emit `nps.check_in.eligibility_resolved` metric
5. Return `CheckInResponse` (NPS item + CSAT item combined)

**Idempotency:** If `NpsWeeklySample.status == SERVED` at step 3, the `@Version` check raises `OptimisticLockException`. `CheckInPrecommitService` catches this and returns the **already-served state** — same survey reference — without re-writing `NpsUserState`.

#### `NpsResponseClassifier` [PROPOSED — chunk 06]

Pure function. Classifies a submitted NPS score:

```java
static NpsRespondentClassification classify(int score) {
  if (score >= 9) return PROMOTER;
  if (score >= 7) return PASSIVE;
  return DETRACTOR;
}
```

Called by the extended `CompletedSurveyListener` when `SurveyCategory.NPS` is detected on the completed `PreprocessedSurvey`.

#### `NpsScoreCalculator` [PROPOSED — chunk 07]

Pure function — no I/O. Computes `NpsWeeklyScore` from a list of classified responses.

```java
NpsWeeklyScore calculate(long measurementId, String isoWeek,
                          long promoterCount, long passiveCount, long detractorCount,
                          long populationSize, long sampleSize) {

  long respondentSize = promoterCount + passiveCount + detractorCount;
  if (respondentSize == 0) return zeroScore(measurementId, isoWeek, populationSize, sampleSize);

  BigDecimal total = BigDecimal.valueOf(respondentSize);
  BigDecimal promoterPct = BigDecimal.valueOf(promoterCount).divide(total, 2, HALF_UP).multiply(HUNDRED);
  BigDecimal detractorPct = BigDecimal.valueOf(detractorCount).divide(total, 2, HALF_UP).multiply(HUNDRED);
  BigDecimal passivePct = HUNDRED.subtract(promoterPct).subtract(detractorPct); // ensures sum = 100

  int npsScore = promoterPct.subtract(detractorPct).setScale(0, HALF_UP).intValue();

  assert promoterPct.add(passivePct).add(detractorPct).compareTo(HUNDRED) == 0;

  return NpsWeeklyScore.builder()
      .measurementId(measurementId).isoWeek(isoWeek)
      .npsScore(npsScore)
      .promoterPct(promoterPct).passivePct(passivePct).detractorPct(detractorPct)
      .promoterCount(promoterCount).passiveCount(passiveCount).detractorCount(detractorCount)
      .populationSize(populationSize).sampleSize(sampleSize).respondentSize(respondentSize)
      .responseRate(BigDecimal.valueOf(respondentSize).divide(BigDecimal.valueOf(sampleSize), 4, HALF_UP))
      .computedAt(Timestamp.from(Instant.now()))
      .build();
}
```

### 4.2 Job Layer

Both jobs follow the `ClusteredJob` pattern [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/job/jobs/PreprocessedSurveyExpirationTriggerJob.java`] with Quartz + ShedLock.

#### `NpsWeeklySamplePreparationJob` [PROPOSED — chunk 04]

**Fires:** Monday 00:05 Africa/Lagos (cron: `0 5 0 ? * MON *`)  
**Lock key:** `NPS_WEEKLY_SAMPLE_PREPARATION_JOB`

```
For each ACTIVE NpsMeasurement M:
  currentWeek = IsoWeekHelper.currentWeek(ZoneId("Africa/Lagos"))
  if nps_weekly_sample already has rows for (M.id, currentWeek): skip (idempotent)
  
  eligiblePool = UserAttributesStorage batch scan:
    - segment matching M.cohort.segment
    - onboardingDate ≤ today − 60 days
    - lastTxnDate ≥ today − 30 days
    - EXCLUDE users where NpsUserState.lastNpsTriggeredDate > today − 90 days
    - EXCLUDE users where NpsUserState.triggerCountYear >= 2 AND triggerYear == currentYear
  
  selectedUsers = SecureRandom sample of min(eligiblePool.size(), M.cohort.weeklyInvitationCap) users
  
  nps_weekly_sample bulk INSERT IGNORE rows for (userId, M.id, currentWeek, PENDING, now())
  
  publish NpsWeeklySamplePreparedEvent(week=currentWeek, measurementId=M.id, sampleSize=selectedUsers.size())
  
  log.info "Prepared sample for measurement {} week {}: {} users selected from pool of {}",
           M.id, currentWeek, selectedUsers.size(), eligiblePool.size()
```

**Batch size:** `nps.sampling.batch-size` (default 1,000). BigTable scan is page-iterated with cursor.

#### `NpsWeeklyScoreAggregationJob` [PROPOSED — chunk 07]

**Fires:** Monday 06:00 Africa/Lagos (cron: `0 0 6 ? * MON *`)  
**Lock key:** `NPS_WEEKLY_SCORE_AGGREGATION_JOB`

```
priorWeek = IsoWeekHelper.priorWeek(ZoneId("Africa/Lagos"))

For each ACTIVE NpsMeasurement M:
  if nps_weekly_score already has a row for (M.id, priorWeek): skip (idempotent)
  
  responses = query PreprocessedSurvey where:
    surveyId in (Survey rows with category=NPS and measurement linkage)
    AND state = COMPLETED
    AND iso_week (from additional_data JSON) = priorWeek
  
  populationSize = count of eligible users for M in priorWeek (from nps_weekly_sample population_hint or fresh BigTable count)
  sampleSize = count nps_weekly_sample WHERE measurement_id=M.id AND iso_week=priorWeek
  
  classified = responses.stream().map(r → classify(r.npsScore))
  
  score = NpsScoreCalculator.calculate(M.id, priorWeek,
    classified.promoterCount, classified.passiveCount, classified.detractorCount,
    populationSize, sampleSize)
  
  nps_weekly_score INSERT IGNORE (row for M.id, priorWeek, computed score fields)
  
  publish NpsWeeklyScoreComputedEvent(week=priorWeek, measurementId=M.id, npsScore=score.npsScore,
    promoterPct=score.promoterPct, passivePct=score.passivePct, detractorPct=score.detractorPct,
    respondentSize=score.respondentSize, sampleSize=score.sampleSize, responseRate=score.responseRate)
```

### 4.3 Repository Layer

Five new storage interfaces following the `*Storage` naming convention [VERIFIED: CLAUDE.md]:

| Interface | Extends | Key custom methods |
|---|---|---|
| `NpsCohortStorage` | `JpaRepository<NpsCohort, Long>` | `findBySegmentAndCustomerAgeBandAndEntityScope(...)` |
| `NpsMeasurementStorage` | `JpaRepository<NpsMeasurement, Long>` | `findAllByStatus(MeasurementStatus)`, `findByAppTypeAndStatus(AppType, MeasurementStatus)` |
| `NpsUserStateStorage` | `JpaRepository<NpsUserState, Long>` | `findByUserId(String)`, `findByLastNpsTriggeredDateAfter(LocalDate)` |
| `NpsWeeklySampleStorage` | `JpaRepository<NpsWeeklySample, Long>` | `findByUserIdAndIsoWeekAndStatus(...)`, `countByMeasurementIdAndIsoWeek(...)`, `@Modifying expireByIsoWeekBefore(String)` |
| `NpsWeeklyScoreStorage` | `JpaRepository<NpsWeeklyScore, Long>` | `findByMeasurementIdAndIsoWeekBetween(...)`, `findByMeasurementIdOrderByIsoWeekDesc(...)` |

### 4.4 Controller Layer

#### `AdminNpsCohortController` [PROPOSED — chunk 01]
Path: `/internal/admin/nps/cohorts` and `/internal/admin/nps/measurements`  
Methods: POST create, PUT update, GET list, GET by id  
No `@PreAuthorize` — secured by k8s network policy per CLAUDE.md internal-endpoint convention.

#### `CheckInController` [PROPOSED — chunk 05]
Path: TBD — output of `/design-an-interface` workstream (see `docs/design/nps-checkin-api-design.md`)  
Resolves NPS + CSAT pre-commitment in a single call; writes trigger state atomically.

#### `NpsIntelligenceController` [PROPOSED — chunk 08]
Paths:
- `GET /api/v3/nps/measurements/{id}/weekly-scores?from={isoWeek}&to={isoWeek}` — atomic weekly scores
- `GET /api/v3/nps/measurements/{id}/responses?week={isoWeek}&classification={class}&page={n}&size={n}` — paginated raw free-text responses
- `GET /api/v3/nps/measurements` — list all measurements with latest score snapshot

`@PreAuthorize("hasAuthority(@Authorities.NPS_INTELLIGENCE_READ)")` on all endpoints.  
`@Trace(dispatcher = true)` per CLAUDE.md controller rules.

### 4.5 Kafka Events

| Event | Topic | Producer | Consumer | Schema |
|---|---|---|---|---|
| `NpsWeeklySamplePreparedEvent` | `event-nps-sampling` (new) | `NpsWeeklySamplePreparationJob` | BI Platform (Airflow ETL) | `{week, measurementId, sampleSize, appType}` |
| `NpsResponseClassifiedEvent` | existing `event-completed-survey` | Extended `CompletedSurveyListener` | BI Platform, score aggregation | Adds `{npsScore, classification, isoWeek}` to existing event |
| `NpsWeeklyScoreComputedEvent` | `event-nps-weekly-close` (new) | `NpsWeeklyScoreAggregationJob` | BI Platform (Airflow rolling avgs) | `{week, measurementId, npsScore, promoterPct, passivePct, detractorPct, respondentSize, sampleSize, responseRate}` |

**Note on `NpsResponseClassifiedEvent`:** This extends the existing `event-completed-survey` topic, not a new one. Per CLAUDE.md Kafka rules: new fields added to an existing event must be **additive only** — existing consumers continue working without modification. The BI Platform Airflow ETL picks up the new `npsScore`, `classification`, and `isoWeek` fields for rolling-average computation.

### 4.6 Redis State Design

```
# Daily per-client byte budget counter
Key:    nps:budget:{clientId}:{YYYY-MM-DD}
Value:  integer (cumulative byte count for the day)
TTL:    86400s (auto-expires at midnight + some drift; daily key is self-cleaning)
Op:     INCRBY on each check-in; GET to compare against 51200 (50KB)

# Sample membership cache (avoids MySQL lookup for users not in current week's sample)
Key:    nps:sample:{userId}:{isoWeek}
Value:  NpsWeeklySampleId (string) | "NONE"
TTL:    3600s (1h)
Op:     GET on check-in; SET after MySQL lookup; INVALIDATE on trigger write

# Eligibility result cache (short-lived; avoids BigTable round trip for repeat check-ins)
Key:    nps:eligible:{userId}:{isoWeek}
Value:  "SERVE:{sampleId}" | "SKIP:{reason}"
TTL:    600s (10 min) — short enough to reflect mid-week cool-off changes
Op:     GET before gates; SET after full gate evaluation; DELETE on trigger write (ensures next check-in re-evaluates)
```

---

## 5. Sequence Diagrams

### 5.1 Weekly Sample Preparation (Monday 00:05)

```mermaid
sequenceDiagram
    participant Job as NpsWeeklySamplePreparationJob
    participant MeasStorage as NpsMeasurementStorage
    participant UserAttr as UserAttributesStorage (BigTable)
    participant UserState as NpsUserStateStorage (MySQL)
    participant SampleStorage as NpsWeeklySampleStorage
    participant Kafka as Kafka: event-nps-sampling

    Job->>Job: currentWeek = IsoWeekHelper.currentWeek(Africa/Lagos)
    Job->>MeasStorage: findAllByStatus(ACTIVE)
    loop For each active NpsMeasurement M
        Job->>SampleStorage: countByMeasurementIdAndIsoWeek(M.id, currentWeek)
        alt Already prepared (idempotent re-run)
            Job->>Job: skip measurement M
        else Not yet prepared
            Job->>UserAttr: batchScan(segment=M.cohort.segment, paginated)
            loop Each page of eligible users
                Job->>UserAttr: apply account-age filter (onboardingDate ≤ today−60d)
                Job->>UserAttr: apply tx-recency filter (lastTxnDate ≥ today−30d)
                Job->>UserState: excludeUsersInCoolOff(lastNpsTriggeredDate > today−90d)
                Job->>UserState: excludeUsersAtYearCap(triggerCountYear ≥ 2, triggerYear=currentYear)
            end
            Job->>Job: SecureRandom.sample(eligiblePool, cap=M.cohort.weeklyInvitationCap)
            Job->>SampleStorage: bulkInsertIgnore(selectedUsers, M.id, currentWeek, PENDING)
            Job->>Kafka: publish NpsWeeklySamplePreparedEvent
        end
    end
```

### 5.2 Check-in — User in Sample (Happy Path)

```mermaid
sequenceDiagram
    participant Client as Mobile/Web Client
    participant Controller as CheckInController
    participant Service as CheckInPrecommitService
    participant Resolver as NpsEligibilityResolver
    participant Redis as Redis
    participant UserState as NpsUserStateStorage
    participant UserAttr as UserAttributesStorage (BigTable)
    participant SampleStorage as NpsWeeklySampleStorage
    participant DB as MySQL @Transactional

    Client->>Controller: POST /check-in {platform, appType, clientId}
    Controller->>Service: resolvePrecommitment(userId, platform, appType, clientId)
    Service->>Resolver: resolve(userId, currentWeek)

    Resolver->>Redis: GET nps:eligible:{userId}:{week}
    alt Cache miss
        Resolver->>Redis: GET nps:sample:{userId}:{week}
        alt Cache miss
            Resolver->>SampleStorage: findByUserIdAndIsoWeekAndStatus(userId, week, PENDING)
            Resolver->>Redis: SET nps:sample:{userId}:{week} = sampleId | "NONE" TTL=3600
        end
        alt Not in sample
            Resolver-->>Service: EligibilityResult.SKIP(NOT_SAMPLED)
        else In sample
            Resolver->>UserState: findByUserId(userId)
            Resolver->>Resolver: check cool-off (lastTriggeredDate > today−90d?)
            Resolver->>Resolver: check year cap (triggerCountYear ≥ 2?)
            Resolver->>UserAttr: findUser(userId)
            Resolver->>Resolver: check account age (onboardingDate > today−60d?)
            Resolver->>Resolver: check tx recency (lastTxnDate < today−30d?)
            Resolver->>Redis: SET nps:eligible:{userId}:{week} = "SERVE:{sampleId}" TTL=600
            Resolver-->>Service: EligibilityResult.SERVE(sampleId)
        end
    else Cache hit
        Resolver-->>Service: EligibilityResult from cache
    end

    alt SERVE
        Service->>Service: build CheckInSurveyItem from Survey row (no config fields)
        Service->>Service: CheckInPayloadBudgetGuard.assertUnder1KB(response)
        Service->>Service: SurveyQuotaService.assertDailyBudget(clientId)
        Service->>DB: NpsWeeklySample.markServed(now) [optimistic lock via @Version]
        Service->>DB: NpsUserState.recordTrigger(today) [upsert]
        Service->>Redis: DEL nps:eligible:{userId}:{week}
        Service-->>Controller: CheckInResponse{nps: CheckInSurveyItem, csat: null}
    else SKIP
        Service-->>Controller: CheckInResponse{nps: null, csat: null}
    end

    Controller-->>Client: HTTP 200 CheckInResponse
```

### 5.3 Check-in — User in Cool-off (Short-circuit)

```mermaid
sequenceDiagram
    participant Client as Mobile/Web Client
    participant Controller as CheckInController
    participant Service as CheckInPrecommitService
    participant Resolver as NpsEligibilityResolver
    participant Redis as Redis
    participant UserState as NpsUserStateStorage

    Client->>Controller: POST /check-in {platform, appType, clientId}
    Controller->>Service: resolvePrecommitment(userId, ...)
    Service->>Resolver: resolve(userId, currentWeek)

    Resolver->>Redis: GET nps:eligible:{userId}:{week}
    alt Cache miss
        Resolver->>Redis: GET nps:sample:{userId}:{week}
        Resolver->>Resolver: sample lookup → PENDING row found
        Resolver->>UserState: findByUserId(userId)
        Note over Resolver: lastNpsTriggeredDate = 2026-05-01<br/>today = 2026-05-19<br/>diff = 18 days < 90 → COOL_OFF
        Resolver->>Redis: SET nps:eligible:{userId}:{week} = "SKIP:COOL_OFF" TTL=600
        Resolver-->>Service: EligibilityResult.SKIP(COOL_OFF)
    end

    Service->>Service: emit metric nps.check_in.eligibility_resolved{result=SKIP_COOLOFF}
    Service-->>Controller: CheckInResponse{nps: null}
    Controller-->>Client: HTTP 200 CheckInResponse (empty)
    Note over Client: No survey shown
```

### 5.4 Survey Completion and Classification

```mermaid
sequenceDiagram
    participant Client as Mobile/Web Client
    participant SurveyCtrl as SurveyController (existing)
    participant Kafka as Kafka: event-completed-survey
    participant Listener as CompletedSurveyListener (extended)
    participant Classifier as NpsResponseClassifier
    participant SampleStorage as NpsWeeklySampleStorage
    participant UserState as NpsUserStateStorage

    Client->>SurveyCtrl: POST /api/surveys/{id}/complete {score, qualitativeResponse}
    SurveyCtrl->>Kafka: publish CompletedSurveyEvent{preprocessedSurveyId, data}
    Kafka->>Listener: CompletedSurveyEvent

    Listener->>Listener: load PreprocessedSurvey by id
    alt SurveyCategory == NPS
        Listener->>Listener: extract npsScore from event data
        Listener->>Listener: isoWeek = IsoWeekHelper.ofDate(preprocessedSurvey.createdOn)

        alt isoWeek != currentWeek (response after week close)
            Listener->>Listener: log NpsResponseDiscardedEvent{userId, isoWeek, reason=WEEK_EXPIRED}
            Listener->>Listener: metric nps.response.discarded++
            Note over Listener: Response discarded; no state written
        else within valid week
            Listener->>Classifier: classify(npsScore)
            Listener->>SampleStorage: findByUserIdAndIsoWeek(userId, isoWeek)
            Listener->>SampleStorage: updateStatus(sampleId, RESPONDED)
            Listener->>UserState: updateClassification(userId, classification)
            Listener->>Kafka: publish NpsResponseClassifiedEvent{npsScore, classification, isoWeek, ...}
        end
    else Not NPS
        Listener->>Listener: delegate to existing BRM/CSAT completion logic
    end
```

### 5.5 Weekly Score Aggregation (Monday 06:00)

```mermaid
sequenceDiagram
    participant Job as NpsWeeklyScoreAggregationJob
    participant MeasStorage as NpsMeasurementStorage
    participant SampleStorage as NpsWeeklySampleStorage
    participant SurveyStorage as PreprocessedSurveyStorage (existing)
    participant Calculator as NpsScoreCalculator
    participant ScoreStorage as NpsWeeklyScoreStorage
    participant Kafka as Kafka: event-nps-weekly-close

    Job->>Job: priorWeek = IsoWeekHelper.priorWeek(Africa/Lagos)
    Job->>MeasStorage: findAllByStatus(ACTIVE)

    loop For each active NpsMeasurement M
        Job->>ScoreStorage: findByMeasurementIdAndIsoWeek(M.id, priorWeek)
        alt Score already computed (idempotent)
            Job->>Job: skip
        else
            Job->>SampleStorage: countByMeasurementIdAndIsoWeek(M.id, priorWeek)
            Note over Job: sampleSize known

            Job->>SurveyStorage: findCompletedNpsByMeasurementAndWeek(M.id, priorWeek)
            Job->>Job: classify each response (PROMOTER/PASSIVE/DETRACTOR)
            Job->>Job: count promoters, passives, detractors

            Job->>Calculator: calculate(M.id, priorWeek, counts, populationSize, sampleSize)
            Job->>ScoreStorage: insertIgnore(NpsWeeklyScore)
            Job->>Kafka: publish NpsWeeklyScoreComputedEvent
        end
    end
```

---

## 6. Eligibility Engine Design

### 6.1 Gate Evaluation Order

Gates are ordered cheapest-first to minimise latency and external calls:

| Order | Gate | Data source | Fail reason | Notes |
|---|---|---|---|---|
| 1 | Sample membership | Redis → MySQL | `NOT_SAMPLED` | Most users are not in the week's sample (cap << user base) — fail fast |
| 2 | Cool-off (90 days) | MySQL `nps_user_state` | `COOL_OFF` | One MySQL read (shares row with gate 3) |
| 3 | Year cap (2 per year) | MySQL `nps_user_state` | `YEAR_CAP` | Same row as gate 2 — no extra I/O |
| 4 | Account age (≥ 60 days) | BigTable `UserAttributes.onboardingDate` | `ACCOUNT_AGE` | BigTable call batched with gate 5 |
| 5 | Transaction recency (lastTxnDate ≥ today−30d) | BigTable `UserAttributes.lastTxnDate` | `TX_RECENCY` | Same BigTable response as gate 4 |

**Total I/O per eligible check-in:** 1 Redis GET + 1 MySQL read + 1 BigTable read = 3 round trips.

**Transaction recency note:** `UserAttributes.lastTxnDate` [VERIFIED: `UserAttributes.java:40`] is a `LocalDate` representing the date of the user's most recent transaction. Gate 5 checks `lastTxnDate.isBefore(today.minusDays(30))`. If true → user has not transacted in the last 30 days → excluded. No separate transaction-count API is required.

### 6.2 Re-check at Trigger Time vs Pre-computed in Sampling Job

The sampling job pre-computes eligibility at week start (snapshot of user pool). However, user state can change mid-week (e.g. a user in a different measurement gets triggered, consuming their annual cap). The check-in resolver re-checks gates 2+3 (cool-off and year cap) at trigger time to defend against this staleness.

Gates 4+5 (account age and tx recency) are NOT re-checked at trigger time for performance reasons — these attributes change slowly (account age only increases, tx recency changes but a user active enough to be in the sample is unlikely to have transacted more than 30 days ago in the same week).

---

## 7. Sampling Algorithm

### 7.1 Cohort Resolution

The sampling job resolves which users belong to a cohort by applying the cohort's `segment`, `customerAgeBand`, and `entityScope` filters against the BigTable `UserAttributes` data for the active user base.

Because BigTable does not support complex WHERE clauses, the job iterates the user base in pages and applies filters in memory:

```java
boolean matchesCohort(UserAttributes user, NpsCohort cohort) {
  // account age gate
  if (!accountAgeMatchesBand(user.getOnboardingDate(), cohort.getCustomerAgeBand())) return false;
  // entity scope
  if (cohort.getEntityScope() != null && !cohort.getEntityScope().equals(user.getAppDomain())) return false;
  // segment (PERSONAL_BANKING vs BUSINESS_BANKING vs AGENTS)
  return segmentMatches(user, cohort.getSegment());
}
```

### 7.2 Cap Enforcement

After the eligible pool is built, the sampling job selects `min(pool.size(), cohort.weeklyInvitationCap)` users randomly. The cap is enforced at **insert time** as well: the `UNIQUE KEY (userId, measurementId, isoWeek)` prevents the same user from appearing twice in the sample, making bulk-insert idempotent.

### 7.3 Random Selection

```java
List<String> randomSample(List<String> eligiblePool, int cap) {
  if (eligiblePool.size() <= cap) return eligiblePool; // whole pool fits
  Collections.shuffle(eligiblePool, new SecureRandom());
  return eligiblePool.subList(0, cap);
}
```

No weighting by activity level, tenure, or segment — as specified in PRD §6.4 ("random sampling with no weighting").

---

## 8. Calendar Week Invariants

### 8.1 ISO-8601 Week Definition

The NPS programme uses **ISO-8601 weeks**: Monday (day 1) through Sunday (day 7). Week `"2026-W20"` starts Monday 2026-05-11 and ends Sunday 2026-05-17.

```java
// Helper utility — used across jobs, services, and listeners
public final class IsoWeekHelper {
  public static String currentWeek(ZoneId zone) {
    return format(LocalDate.now(zone));
  }
  public static String priorWeek(ZoneId zone) {
    return format(LocalDate.now(zone).minusWeeks(1));
  }
  public static String ofDate(Timestamp ts) {
    return format(ts.toLocalDateTime().toLocalDate());
  }
  private static String format(LocalDate date) {
    int weekYear = date.get(WeekFields.ISO.weekBasedYear());
    int weekNum  = date.get(WeekFields.ISO.weekOfWeekBasedYear());
    return String.format("%d-W%02d", weekYear, weekNum);
  }
}
```

**Timezone:** `ZoneId.of("Africa/Lagos")` (UTC+1, no DST). Week boundaries are computed in Lagos time so that midnight Monday Lagos time opens a new week for all CAS jobs.

### 8.2 Week Open and Close

| Event | Time (Lagos) | Action |
|---|---|---|
| Week open | Monday 00:05 | `NpsWeeklySamplePreparationJob` fires, inserts `nps_weekly_sample` rows for current week |
| Week close | Monday 06:00 | `NpsWeeklyScoreAggregationJob` fires, aggregates prior week's responses |
| Rollover buffer | 5 min — 6 hours | Allows for clock skew and late Kafka delivery; responses arriving in this window for the prior week are still within the 6h buffer |

### 8.3 Late-Response Discard

`CompletedSurveyListener` computes `responseWeek = IsoWeekHelper.ofDate(preprocessedSurvey.createdOn)` and compares it to `currentWeek`. If they differ, the response is discarded:

```java
if (!responseWeek.equals(currentWeek)) {
  log.warn("NPS response discarded: user={}, week={}, currentWeek={}", userId, responseWeek, currentWeek);
  meterRegistry.counter("nps.response.discarded", "reason", "WEEK_EXPIRED").increment();
  return; // do not classify, do not update sample status
}
```

---

## 9. NPS Score Calculation

### 9.1 Formula

```
NPS = % Promoters − % Detractors

% Promoters  = (promoterCount  / respondentCount) × 100   [BigDecimal HALF_UP, scale 2]
% Detractors = (detractorCount / respondentCount) × 100   [BigDecimal HALF_UP, scale 2]
% Passives   = 100 − % Promoters − % Detractors           [ensures sum = 100.00]

NPS (integer) = round(% Promoters − % Detractors)         [BigDecimal HALF_UP, scale 0]
```

**Passives are excluded from the NPS calculation.** They are tracked separately as a diagnostic signal (PRD §4.2 and CLAUDE.md invariant).

### 9.2 Worked Example

| Classification | Count |
|---|---|
| Promoters (9–10) | 500 |
| Passives (7–8) | 200 |
| Detractors (0–6) | 300 |
| **Total respondents** | **1000** |

```
% Promoters  = 500/1000 × 100 = 50.00
% Detractors = 300/1000 × 100 = 30.00
% Passives   = 100 − 50.00 − 30.00 = 20.00

NPS = round(50.00 − 30.00) = 20
```

### 9.3 Edge Cases

| Condition | Handling |
|---|---|
| `respondentSize == 0` | NPS = 0, all %s = 0.00, responseRate = 0.0000. Valid (no responses ≠ broken). |
| All respondents are passives | NPS = 0 (% Promoters = 0, % Detractors = 0), passivePct = 100.00. Valid. |
| Single respondent, score 10 | NPS = 100, promoterPct = 100.00, passivePct = 0.00, detractorPct = 0.00. Valid but statistically unreliable — surfaced via small `respondentSize`. |
| Rounding artefact in sum | `passivePct` is computed as `100 − promoterPct − detractorPct` to guarantee the sum is exactly 100.00 regardless of HALF_UP rounding. |

---

## 10. Payload Budget Enforcement

### 10.1 Per-Request Budget (<1024 bytes)

`CheckInPayloadBudgetGuard` [PROPOSED — chunk 05] measures the serialised byte length of the `CheckInResponse` after construction, before return:

```java
@Component
class CheckInPayloadBudgetGuard {
  void assertUnder1KB(CheckInResponse response, ObjectMapper mapper) {
    int bytes = mapper.writeValueAsBytes(response).length;
    if (bytes > 1024) {
      meterRegistry.counter("nps.check_in.payload_budget_exceeded").increment();
      log.warn("CheckInResponse exceeds 1KB budget: {} bytes", bytes);
      // attempt to strip optional schema and re-measure
      response.stripOptionalFields();
      bytes = mapper.writeValueAsBytes(response).length;
      if (bytes > 1024) throw new ServerException("Check-in payload exceeds 1KB budget after stripping");
    }
  }
}
```

### 10.2 Daily Per-Client Budget (<50KB)

`SurveyQuotaService` [PROPOSED — chunk 05] maintains a Redis counter:

```java
void assertDailyBudget(String clientId, int responseBytes) {
  String key = "nps:budget:" + clientId + ":" + LocalDate.now(ZoneId.of("Africa/Lagos"));
  Long newTotal = redisTemplate.opsForValue().increment(key, responseBytes);
  if (newTotal == responseBytes) {
    redisTemplate.expire(key, Duration.ofDays(1)); // set TTL on first write
  }
  if (newTotal > 51_200) { // 50KB
    meterRegistry.counter("nps.daily_budget.exceeded", "clientId", clientId).increment();
    throw new TooManyRequestsException("Daily survey data budget exceeded for client " + clientId);
  }
}
```

The 50KB budget is shared across NPS and CSAT activity per the PRD §16 constraint.

---

## 11. Observability Design

### 11.1 Metrics Catalogue

| Metric name | Type | Labels | Description |
|---|---|---|---|
| `nps.weekly_sample.prepared` | Counter | `measurementId`, `week`, `appType` | Users added to weekly sample |
| `nps.weekly_sample.eligible_pool_size` | Gauge | `measurementId`, `week` | Eligible pool before random selection |
| `nps.check_in.eligibility_resolved` | Timer | `result` (SERVE \| SKIP_NOT_SAMPLED \| SKIP_COOL_OFF \| SKIP_YEAR_CAP \| SKIP_AGE \| SKIP_TXN) | Latency + outcome distribution of eligibility check |
| `nps.check_in.payload_budget_exceeded` | Counter | — | Per-request 1KB budget exceeded |
| `nps.daily_budget.exceeded` | Counter | `clientId` | 50KB/day budget exceeded |
| `nps.response.classified` | Counter | `classification` (PROMOTER \| PASSIVE \| DETRACTOR), `isoWeek` | Responses received and classified |
| `nps.response.discarded` | Counter | `reason` (WEEK_EXPIRED) | Responses discarded after week close |
| `nps.score.computed` | Gauge | `measurementId`, `isoWeek` | NPS score value at aggregation time |
| `nps.score.response_rate` | Gauge | `measurementId`, `isoWeek` | Response rate (0–1) at aggregation time |
| `nps.sample_prep_job.duration` | Timer | — | Wall-clock time for sample prep job |
| `nps.aggregation_job.duration` | Timer | — | Wall-clock time for score aggregation job |

### 11.2 Log Masking Rules

| Field | Log level | Treatment |
|---|---|---|
| `qualitativeResponse` (free-text) | Any | `[redacted-N-chars]` where N is the character count |
| `userId` | DEBUG only | Full value at DEBUG; masked as `usr-****` at INFO and above |
| `npsScore` (the rating itself) | INFO | Full value (not PII — it's a 0–10 integer) |
| `NpsRespondentClassification` | INFO | Full value |

Reference: `patterns/pii-masking.md` in the claude-engineering pattern library.

### 11.3 Alert Candidates

| Alert | Condition | Severity | Action |
|---|---|---|---|
| Sample prep job failure | Job does not complete within 30 min of firing | P2 | Check ShedLock, BigTable connectivity |
| Score aggregation job failure | Job does not complete by Mon 08:00 Lagos | P2 | Check MySQL connectivity; re-run job manually |
| Payload budget breach rate | `nps.check_in.payload_budget_exceeded` > 1% of check-ins over 15 min | P3 | Investigate survey JSON size; may indicate admin misconfiguration |
| Response discard rate | `nps.response.discarded` > 5% of responses over 1 hour | P3 | Investigate Kafka lag; responses arriving after week close |
| Daily budget exceeded | `nps.daily_budget.exceeded` > 100 events in 1 hour | P3 | Investigate client behaviour; may indicate a retry loop |

---

## 12. Design Decisions Traceability

Cross-reference to `impl-specs/2026-05-18-nps-sampling-engine.md` design decisions:

| Spec Decision | Section(s) in this doc | ADR |
|---|---|---|
| D1 — `module/analytics/nps/` sub-package | §4 Component Design | — |
| D2 — CAS-owned `nps_user_state` (not Bigtable) | §2.2.3, §3.2, §6 | `ADR-001` |
| D3 — ISO-8601 CHAR(8) week | §2.2.4, §3.3, §8 | `ADR-002` |
| D4 — Materialised `nps_weekly_sample` | §2.2.4, §4.2, §7 | — |
| D5 — Reuse `Survey` + `PreprocessedSurvey` | §1.3, §2.1, §4.4 | — |
| D6 — Dedicated check-in API (shape via /design-an-interface) | §4.4 CheckInController | `docs/design/nps-checkin-api-design.md` |
| D7 — AI summary deferred to Phase 1.5 | §1.2 Non-goals | — |
| D8 — `nps_weekly_score` read-side projection | §2.2.5, §4.2, §9 | — |
| D9 — `CheckInPayloadBudgetGuard` + `SurveyQuotaService` | §10 | — |
| D10 — Feature flag `nps.programme.enabled` | §4.2 (sampling job) | — |
| C-01 — Transaction gate ≥ 1 | §6.1 Gate 5, §6.2 | — |
| C-02 — Rolling averages by Airflow | §4.5 Kafka Events | `ADR-003` |
| C-03 — Check-in API via /design-an-interface | §4.4 CheckInController | `docs/design/nps-checkin-api-design.md` |
| C-05 — NPS-specific cool-off | §2.2.3, §6.1 Gate 2 | `ADR-001` |
| C-11 — Hard year cap (max 2) | §2.2.3, §2.4, §6.1 Gate 3 | — |
| C-12 — Admin-managed Survey rows + SurveyBody extension | §2.5 | — |
