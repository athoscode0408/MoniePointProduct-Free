# Design: ClickHouse + Airflow NPS Sampling Pipeline — CAS Interface Contract

**Status:** Current  
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)  
**Date:** 2026-05-25  
**Supersedes:** [`cohort-bq-materialized-view-design.md`](cohort-bq-materialized-view-design.md) (archived), the BigQuery execution path in [`cohort-extensible-pipeline-design.md`](cohort-extensible-pipeline-design.md)

---

## 1. Overview

The NPS sampling pipeline resolves cohort membership, applies eligibility exclusions, and draws the weekly sample entirely outside of CAS — in an Airflow DAG that reads user attributes from ClickHouse. CAS's role shifts from running the pipeline to:

1. **Owning the configuration** — cohort rules, eligibility rules, and sampling parameters stored in MySQL
2. **Receiving the output** — Airflow writes the pre-computed sample to `nps_weekly_sample`
3. **Publishing to the delivery path** — `NpsWeeklySamplePreparationJob` reads the pre-populated sample and publishes Kafka events to create `PreprocessedSurvey` rows

```mermaid
flowchart LR
    subgraph CAS_MYSQL["CAS MySQL (owned by CAS)"]
        direction TB
        C[(cohort\nrule_definition · sampling_config)]
        ER[(eligibility_rule)]
        NUS[(nps_user_state\neligibility state)]
        NWS[(nps_weekly_sample\nPENDING rows written by Airflow)]
        PA[(survey_pipeline_audit\nfunnel metrics)]
    end

    subgraph CH["ClickHouse (cx_analytics)"]
        UAH[(user_attributes_historical\n_data_final)]
    end

    subgraph AIRFLOW["Airflow (owned by data platform team)"]
        direction TB
        T1["read_cohort_configs"]
        T2["query_cohort_members\n(ClickHouse)"]
        T3["filter_eligible_users\n(MySQL nps_user_state)"]
        T4["apply_sampling"]
        T5["write_to_nps_weekly_sample"]
        T6["write_audit"]
        T1 --> T2 --> T3 --> T4 --> T5
        T4 --> T6
    end

    subgraph CAS_WORKER["CAS Worker"]
        JOB["NpsWeeklySamplePreparationJob\nMon 01:00 Africa/Lagos\nreads PENDING rows → publishes Kafka"]
    end

    C  -->|"read: rule_definition\nsampling_config\nactive cohorts"| T1
    ER -->|"read: eligibility rules\nper cohort"| T3
    UAH -->|"query cohort members"| T2
    NUS -->|"read: cool-off + annual cap"| T3
    T5 -->|"INSERT nps_weekly_sample\nstatus=PENDING"| NWS
    T6 -->|"INSERT survey_pipeline_audit"| PA
    NWS -->|"SELECT PENDING rows\nfor current ISO week"| JOB

    classDef cas   fill:#f4a261,stroke:#e76f51,color:#000
    classDef ch    fill:#457b9d,stroke:#1d3557,color:#fff
    classDef af    fill:#2a9d8f,stroke:#264653,color:#fff
    classDef db    fill:#e9c46a,stroke:#e76f51,color:#000

    class JOB cas
    class UAH ch
    class T1,T2,T3,T4,T5,T6 af
    class C,ER,NUS,NWS,PA db
```

---

## 2. Scheduling

| Component | Schedule | Owner |
|---|---|---|
| Airflow DAG `cas_nps_weekly_pipeline` | Sunday 22:00 Africa/Lagos | Data platform team |
| `NpsWeeklySamplePreparationJob` (CAS) | Monday 01:00 Africa/Lagos | CAS |

The 3-hour gap guarantees Airflow has completed and `nps_weekly_sample` is populated before the CAS Kafka publishing job fires.

---

## 3. MySQL Tables That Airflow Reads

### 3.1 `cohort` — cohort definitions

Airflow reads all rows where `active = true AND survey_category = 'NPS'`.

| Column | Airflow usage |
|---|---|
| `id` | Used as `cohort_id` in writes to `nps_weekly_sample` |
| `name` | Logging / audit only |
| `survey_category` | Filter: `NPS` only |
| `rule_definition` | JsonLogic AST → compiled to ClickHouse SQL `WHERE` clause (see §4) |
| `sampling_config` | JSON → determines sampling algorithm and cap (see §5) |
| `active` | Filter: `true` only |

### 3.2 `eligibility_rule` — per-cohort eligibility exclusion rules

Airflow reads all rows where `active = true` for each cohort it is processing.

| Column | Airflow usage |
|---|---|
| `cohort_id` | Join key: rules for this cohort |
| `rule_order` | Evaluation sequence; lower = applied first |
| `rule_type` | Discriminator: `COOL_OFF`, `ANNUAL_CAP`, `CROSS_PROGRAMME_CAP` |
| `rule_config` | JSON config for the rule type (see §6) |
| `active` | Filter: `true` only |

### 3.3 `nps_user_state` — user-level NPS eligibility state

Airflow joins this against the cohort member list to apply cool-off and annual cap exclusions.

| Column | Airflow usage |
|---|---|
| `user_id` | Join key |
| `last_nps_triggered_date` | `COOL_OFF` rule: exclude if `>= CURDATE() - coolOffDays` |
| `annual_trigger_count` | `ANNUAL_CAP` rule: exclude if `>= maxCount AND trigger_year = YEAR(CURDATE())` |
| `trigger_year` | `ANNUAL_CAP` rule: check against current calendar year |

---

## 4. MySQL Tables That Airflow Writes

### 4.1 `nps_weekly_sample` — the sampled audience

Airflow inserts one row per sampled user per cohort for the current ISO week. **Insert is idempotent** — the `UNIQUE INDEX(user_id, cohort_id, iso_week)` prevents duplicates on re-run.

```sql
INSERT INTO nps_weekly_sample
    (user_id, cohort_id, iso_week, status, created_by, created_on,
     last_modified_by, last_modified_on, version)
VALUES
    (?, ?, ?, 'PENDING', 'airflow', NOW(), 'airflow', NOW(), 0)
ON DUPLICATE KEY UPDATE last_modified_on = last_modified_on;  -- no-op on duplicate
```

**ISO week format**: `YYYY-Www` in Africa/Lagos timezone, e.g. `2026-W22`. Computed using `isoweek()` equivalent in Python: `f"{date.isocalendar().year}-W{date.isocalendar().week:02d}"`.

**Fields Airflow must not set**: `served_at`, `dismissed_at`, `reminder_served_at`, `responded_at` — these are managed by the CAS serve path only.

### 4.2 `survey_pipeline_audit` — funnel metrics

Airflow writes one row per cohort per ISO week with the full sampling funnel.

```sql
INSERT INTO survey_pipeline_audit
    (cohort_id, context_key, run_date,
     population_size, eligible_size, sample_size, status)
VALUES
    (?, ?, CURDATE(), ?, ?, ?, 'COMPLETE')
ON DUPLICATE KEY UPDATE
    population_size = VALUES(population_size),
    eligible_size   = VALUES(eligible_size),
    sample_size     = VALUES(sample_size),
    status          = 'COMPLETE';
```

`context_key` = ISO week string, e.g. `"2026-W22"`.

---

## 5. Cohort Rule Format (`cohort.rule_definition`)

Rules are stored as a **JsonLogic AST** in the `rule_definition` JSON column. Airflow compiles this to a ClickHouse `WHERE` clause against `cx_analytics.user_attributes_historical_data_final`.

### 5.1 Supported operators

| JsonLogic | ClickHouse equivalent |
|---|---|
| `{ "and": [...] }` | `(... AND ...)` |
| `{ "or": [...] }` | `(... OR ...)` |
| `{ "==": [A, B] }` | `A = B` |
| `{ "!=": [A, B] }` | `A != B` |
| `{ "<": [A, B] }` | `A < B` |
| `{ "<=": [A, B] }` | `A <= B` |
| `{ ">": [A, B] }` | `A > B` |
| `{ ">=": [A, B] }` | `A >= B` |
| `{ "var": "field_name" }` | Resolved via field registry (see §5.2) |
| `{ "days_ago": N }` | `today() - N` in ClickHouse |

### 5.2 Field registry — allowed `var` paths

The Airflow compiler must reject any `var` path not in this registry to prevent arbitrary column injection.

| JsonLogic `var` path | ClickHouse column | Type |
|---|---|---|
| `customer_type` | TBD from `user_attributes_historical_data_final` schema | STRING |
| `joining_date` | TBD from `user_attributes_historical_data_final` schema | DATE |
| `last_txn_date` | TBD from `user_attributes_historical_data_final` schema | DATE |
| `country` | TBD from `user_attributes_historical_data_final` schema | STRING |

**Action required**: Airflow team to confirm exact ClickHouse column names and update this registry.

### 5.3 Compilation example — Personal Banking NPS

Stored `rule_definition`:
```json
{
  "and": [
    { "==": [{ "var": "customer_type" }, "PERSONAL"] },
    { "<=": [{ "var": "joining_date" }, { "days_ago": 60 }] },
    { ">=": [{ "var": "last_txn_date" }, { "days_ago": 30 }] }
  ]
}
```

Expected ClickHouse `WHERE` clause:
```sql
(customer_type = 'PERSONAL'
 AND toDate(joining_date) <= today() - 60
 AND toDate(last_txn_date) >= today() - 30)
```

Full ClickHouse query:
```sql
SELECT DISTINCT user_id
FROM cx_analytics.user_attributes_historical_data_final
WHERE <compiled_where_clause>
```

---

## 6. Eligibility Rule Config Format (`eligibility_rule.rule_config`)

### 6.1 `COOL_OFF`

Excludes users triggered within the last N days. A NULL record (never surveyed) always passes.

```json
{
  "type": "COOL_OFF",
  "sourceTable": "nps_user_state",
  "dateField": "last_nps_triggered_date",
  "days": 90
}
```

Exclusion logic (applied in Python after MySQL read):
```
exclude if: nps_user_state.last_nps_triggered_date >= (today - 90 days)
pass if: no row in nps_user_state (never triggered)
```

### 6.2 `ANNUAL_CAP`

Excludes users who have reached the annual trigger cap. Resets at calendar year boundary.

```json
{
  "type": "ANNUAL_CAP",
  "sourceTable": "nps_user_state",
  "countField": "annual_trigger_count",
  "yearField": "trigger_year",
  "maxCount": 2
}
```

Exclusion logic:
```
exclude if: trigger_year = YEAR(today) AND annual_trigger_count >= 2
pass if: no row in nps_user_state OR trigger_year < YEAR(today)
```

### 6.3 `CROSS_PROGRAMME_CAP`

Excludes users who have received N or more surveys of any category this quarter.

```json
{
  "type": "CROSS_PROGRAMME_CAP",
  "sourceTable": "survey_trigger_history_quarterly",
  "countField": "surveys_this_quarter",
  "maxPerQuarter": 2
}
```

---

## 7. Sampling Config Format (`cohort.sampling_config`)

### 7.1 `SIMPLE_RANDOM`

Uniform random selection up to a hard cap. Default when `sampling_config` is NULL.

```json
{ "type": "SIMPLE_RANDOM", "cap": 3200 }
```

Implementation: `random.shuffle(eligible_ids); sampled = eligible_ids[:cap]`

### 7.2 `HASH_BASED`

Deterministic hash-based sampling. Same users selected on each run until `salt` is rotated. Useful for A/B testing or stable holdout groups.

```json
{
  "type": "HASH_BASED",
  "bucketNumerator": 13,
  "bucketDenominator": 100,
  "salt": "nps_q3_2026",
  "cap": 3200
}
```

ClickHouse expression:
```sql
cityHash64(concat(user_id, 'nps_q3_2026')) % 100 < 13
```

### 7.3 `STRATIFIED`

Proportional or equal allocation across a categorical dimension.

```json
{
  "type": "STRATIFIED",
  "strataField": "customer_segment",
  "allocation": "PROPORTIONAL",
  "cap": 3200
}
```

---

## 8. CAS Components Supporting the Pipeline

### 8.1 `AirflowDagTriggerService`

Provides a way to manually trigger the Airflow DAG from CAS (e.g., from the admin API for re-runs or testing). Not used in normal weekly operation — the DAG runs on its own schedule.

```
POST /api/v1/dags/cas_nps_weekly_pipeline/dagRuns
Body: { "conf": { "triggered_by": "cas_admin", "iso_week": "2026-W22" } }
```

### 8.2 Simplified `NpsWeeklySamplePreparationJob`

Runs Monday 01:00 Africa/Lagos. Reads PENDING rows from `nps_weekly_sample` for the current ISO week and publishes Kafka events to create `PreprocessedSurvey` rows.

This job no longer performs cohort lookup, cool-off filtering, or sampling. Its only responsibility is the Kafka publish step that bridges the pre-computed sample into the CAS survey delivery path.

**Idempotency**: re-running the job re-publishes Kafka events, but `SurveyPreprocessorListener` uses `INSERT ON DUPLICATE KEY` when saving `PreprocessedSurvey`, so re-processing is safe.

---

## 9. Boundary Conditions

| Scenario | Behaviour |
|---|---|
| Airflow pipeline did not run (Sunday outage) | `NpsWeeklySamplePreparationJob` reads zero PENDING rows; logs warning; no surveys delivered this week |
| Airflow inserts partial sample (pipeline failed mid-run) | CAS job publishes only the rows that were written; Airflow re-run fills remaining rows before next CAS run |
| Airflow re-runs for the same ISO week | `ON DUPLICATE KEY` insert is a no-op; sample size unchanged |
| Cohort deactivated mid-week | Active PENDING rows continue to be served; no new sample inserted on next run |
| User is in cool-off (MySQL state) | Airflow applies exclusion at pipeline time; CAS serve path does not re-check cool-off |
