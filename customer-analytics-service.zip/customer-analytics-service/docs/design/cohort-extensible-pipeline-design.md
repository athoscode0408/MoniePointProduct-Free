# Design: Extensible Survey Pipeline — Eligibility and Sampling Rule Registry

**Status:** Future phase — not part of current implementation  
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)  
**Date:** 2026-05-22  
**Context:** Extension of the Cohort Platform design to make eligibility rules and sampling algorithms configuration-driven rather than hardcoded in the Airflow DAG.

> **Note — 2026-05-25**: Phase 1 of the eligibility rule registry is now live in the current design.
> The `eligibility_rule` MySQL table (§3.1 data model) and the `cohort.sampling_config` JSON column (§4.1) are both specified and seeded in [`impl-specs/cohort/2026-05-21-cohort-platform.md`](../../impl-specs/cohort/2026-05-21-cohort-platform.md).
> The query engine referenced in this document uses BigQuery + `EXTERNAL_QUERY`. The current implementation uses **ClickHouse** for user attribute queries, with eligibility state read from MySQL directly by the Airflow pipeline.
> See [`clickhouse-airflow-pipeline-design.md`](clickhouse-airflow-pipeline-design.md) for the current interface contract.
> The Java compilers (`EligibilityRuleCompiler`, `SamplingRuleCompiler`, `AirflowPipelineCompiler`) described in this document are Phase 2 scope — they will be built if the rule registry needs to generate ClickHouse SQL from CAS rather than from Airflow.

---

## 1. Problem Statement

In the current Cohort Platform design, eligibility rules and sampling logic are compiled directly into the BigQuery SQL that the Airflow DAG executes. The rules are correct for today's requirements (90-day cool-off, annual cap of 2, simple random sampling to a fixed cap) but adding or changing any rule requires:

1. Editing the `AirflowPipelineCompiler` in CAS
2. Editing the BQ SQL template
3. Potentially changing the Airflow DAG

As survey programmes grow — CSAT with per-journey eligibility, cross-programme caps, complaint-history exclusions, stratified sampling for better failure-state coverage — this becomes a maintenance problem. Each new requirement touches the pipeline itself rather than just its configuration.

**Goal:** Make CAS the owner of all survey pipeline intelligence. The Airflow DAG becomes a generic executor that never changes when business rules change.

---

## 2. Architecture Overview

```mermaid
flowchart TD
    subgraph CAS["CAS — Rule Owner + Compiler"]
        direction TB
        CR["Cohort Rule\nJsonLogic AST"]
        ER["Eligibility Rules\nTyped Registry"]
        SR["Sampling Rule\nTyped Registry"]

        subgraph COMPILERS["Compilers"]
            direction LR
            JC["JsonLogicToSqlCompiler"]
            EC["EligibilityRuleCompiler"]
            SC["SamplingRuleCompiler"]
        end

        PC["AirflowPipelineCompiler\nAssembles full BQ SQL"]
        TRG["AirflowDagTriggerService\nPOST /dagRuns with compiled payload"]
    end

    subgraph AIRFLOW["Airflow — Generic Executor"]
        direction TB
        RCV["receive_pipeline_config\n(DAG run conf)"]
        BQ["execute_bq_query\n(generic — runs any SQL)"]
        MY["load_to_mysql\n(generic — writes any rows)"]
        RCV --> BQ --> MY
    end

    subgraph DB["MySQL — Rule Storage"]
        direction TB
        RT["eligibility_rule\ntable"]
        SM["cohort.sampling_config\nJSON column"]
        CD["cohort.rule_definition\nJsonLogic column"]
    end

    CD --> JC
    RT --> EC
    SM --> SC
    JC --> PC
    EC --> PC
    SC --> PC
    PC --> TRG --> RCV

    classDef compiler fill:#457b9d,stroke:#1d3557,color:#fff
    classDef storage  fill:#e9c46a,stroke:#e76f51,color:#000
    classDef airflow  fill:#2a9d8f,stroke:#264653,color:#fff

    class JC,EC,SC,PC compiler
    class RT,SM,CD storage
    class RCV,BQ,MY airflow
```

**The invariant:** When a new eligibility rule or sampling algorithm is added, only CAS code and configuration change. The Airflow DAG structure never changes.

---

## 3. Eligibility Rule Registry

### 3.1 Data model

Eligibility rules are stored per measurement (or cohort) as an ordered list. Each rule has a type discriminator and a typed JSON config.

```sql
CREATE TABLE eligibility_rule (
    id              BIGINT       NOT NULL AUTO_INCREMENT,
    measurement_id  BIGINT       NOT NULL,   -- FK to the CSAT measurement, or NULL for NPS cohort-level
    cohort_id       BIGINT       NULL,        -- FK to cohort if rule applies at cohort level
    rule_order      INT          NOT NULL,    -- evaluation sequence; lower runs first
    rule_type       VARCHAR(50)  NOT NULL,    -- discriminator: COOL_OFF | ANNUAL_CAP | CROSS_PROGRAMME_CAP | ...
    rule_config     JSON         NOT NULL,    -- typed parameters (see §3.3)
    active          BOOLEAN      NOT NULL DEFAULT true,
    created_on      TIMESTAMP    NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_measurement (measurement_id, rule_order),
    INDEX idx_cohort      (cohort_id, rule_order)
);
```

### 3.2 Java type hierarchy

Sealed interfaces ensure every rule type is handled at compile time — adding a new rule type without updating the compiler produces a compile error.

```java
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
    @JsonSubTypes.Type(value = CoolOffRule.class,            name = "COOL_OFF"),
    @JsonSubTypes.Type(value = AnnualCapRule.class,          name = "ANNUAL_CAP"),
    @JsonSubTypes.Type(value = CrossProgrammeCapRule.class,  name = "CROSS_PROGRAMME_CAP"),
    // Future:
    // @JsonSubTypes.Type(value = ComplaintHistoryRule.class, name = "COMPLAINT_HISTORY"),
    // @JsonSubTypes.Type(value = AccountStatusRule.class,   name = "ACCOUNT_STATUS"),
})
public sealed interface EligibilityRule
    permits CoolOffRule, AnnualCapRule, CrossProgrammeCapRule {}

/**
 * Excludes users triggered within the last N days.
 * A NULL record (never surveyed) always passes — null_passes = true is the invariant.
 */
public record CoolOffRule(
    String sourceTable,        // Cloud SQL table: "nps_user_state"
    String joinKey,            // "user_id"
    String dateField,          // "last_nps_triggered_date"
    int    days                // 90
) implements EligibilityRule {}

/**
 * Excludes users who have reached the annual trigger cap.
 * Resets at calendar year boundary.
 */
public record AnnualCapRule(
    String sourceTable,        // "nps_user_state"
    String joinKey,            // "user_id"
    String countField,         // "annual_trigger_count"
    String yearField,          // "trigger_year"
    int    maxCount            // 2
) implements EligibilityRule {}

/**
 * Excludes users who have received N or more surveys of any type this quarter.
 * Cross-programme: applies across NPS + CSAT + BRM.
 * Requires a survey_trigger_history view in Cloud SQL.
 */
public record CrossProgrammeCapRule(
    String sourceTable,        // "survey_trigger_history_quarterly"
    String joinKey,            // "user_id"
    String countField,         // "surveys_this_quarter"
    int    maxPerQuarter       // 2
) implements EligibilityRule {}
```

### 3.3 Stored JSON examples

```json
// COOL_OFF
{
  "type": "COOL_OFF",
  "sourceTable": "nps_user_state",
  "joinKey": "user_id",
  "dateField": "last_nps_triggered_date",
  "days": 90
}

// ANNUAL_CAP
{
  "type": "ANNUAL_CAP",
  "sourceTable": "nps_user_state",
  "joinKey": "user_id",
  "countField": "annual_trigger_count",
  "yearField": "trigger_year",
  "maxCount": 2
}

// CROSS_PROGRAMME_CAP
{
  "type": "CROSS_PROGRAMME_CAP",
  "sourceTable": "survey_trigger_history_quarterly",
  "joinKey": "user_id",
  "countField": "surveys_this_quarter",
  "maxPerQuarter": 2
}
```

### 3.4 `EligibilityRuleCompiler`

The compiler produces two outputs for each rule list: the LEFT JOIN clauses (which bring eligibility state into the BQ query via `EXTERNAL_QUERY`) and the WHERE predicates (which apply the exclusion logic).

```java
@Component
@RequiredArgsConstructor
public class EligibilityRuleCompiler {

    private static final String CONNECTION_ID =
        "projects/%s/locations/%s/connections/cas-cloudsql";

    @Value("${cohort.bigquery.project-id}")   private String project;
    @Value("${cohort.bigquery.location}")     private String location;

    /**
     * Generates LEFT JOIN EXTERNAL_QUERY clauses for each unique source table.
     * A table is aliased as _{tableName} to avoid collisions with BQ column names.
     */
    public List<String> compileJoins(List<EligibilityRule> rules) {
        return rules.stream()
            .map(this::sourceTable)
            .distinct()
            .map(table -> """
                LEFT JOIN EXTERNAL_QUERY(
                    '%s',
                    'SELECT * FROM %s'
                ) AS _%s ON nuf.user_id = _%s.user_id
                """.formatted(connectionId(), table, table, table))
            .toList();
    }

    /**
     * Generates AND-joined WHERE conditions for all active rules.
     * Each condition has null-safe semantics: a missing record = user is eligible.
     */
    public String compileWhere(List<EligibilityRule> rules) {
        return rules.stream()
            .map(this::compileRule)
            .collect(Collectors.joining("\n  AND "));
    }

    private String compileRule(EligibilityRule rule) {
        return switch (rule) {

            case CoolOffRule r -> """
                (_%s.%s IS NULL
                 OR _%s.%s IS NULL
                 OR _%s.%s < DATE_SUB(CURRENT_DATE(), INTERVAL %d DAY))
                """.formatted(
                    r.sourceTable(), r.joinKey(),
                    r.sourceTable(), r.dateField(),
                    r.sourceTable(), r.dateField(), r.days());

            case AnnualCapRule r -> """
                (_%s.%s IS NULL
                 OR _%s.%s IS NULL
                 OR _%s.%s < EXTRACT(YEAR FROM CURRENT_DATE())
                 OR _%s.%s < %d)
                """.formatted(
                    r.sourceTable(), r.joinKey(),
                    r.sourceTable(), r.countField(),
                    r.sourceTable(), r.yearField(),
                    r.sourceTable(), r.countField(), r.maxCount());

            case CrossProgrammeCapRule r -> """
                (_%s.%s IS NULL
                 OR _%s.%s < %d)
                """.formatted(
                    r.sourceTable(), r.joinKey(),
                    r.sourceTable(), r.countField(), r.maxPerQuarter());
        };
    }

    private String sourceTable(EligibilityRule rule) {
        return switch (rule) {
            case CoolOffRule           r -> r.sourceTable();
            case AnnualCapRule         r -> r.sourceTable();
            case CrossProgrammeCapRule r -> r.sourceTable();
        };
    }

    private String connectionId() {
        return CONNECTION_ID.formatted(project, location);
    }
}
```

### 3.5 Compiled output — Personal Banking NPS eligibility

Input rules (from `measurement_eligibility_rules`):
1. `CoolOffRule(nps_user_state, user_id, last_nps_triggered_date, 90)`
2. `AnnualCapRule(nps_user_state, user_id, annual_trigger_count, trigger_year, 2)`
3. `CrossProgrammeCapRule(survey_trigger_history_quarterly, user_id, surveys_this_quarter, 2)`

Compiled JOIN:
```sql
LEFT JOIN EXTERNAL_QUERY(
    'projects/moniepoint/locations/europe-west1/connections/cas-cloudsql',
    'SELECT * FROM nps_user_state'
) AS _nps_user_state ON nuf.user_id = _nps_user_state.user_id
LEFT JOIN EXTERNAL_QUERY(
    'projects/moniepoint/locations/europe-west1/connections/cas-cloudsql',
    'SELECT * FROM survey_trigger_history_quarterly'
) AS _survey_trigger_history_quarterly ON nuf.user_id = _survey_trigger_history_quarterly.user_id
```

Compiled WHERE:
```sql
(_nps_user_state.user_id IS NULL
 OR _nps_user_state.last_nps_triggered_date IS NULL
 OR _nps_user_state.last_nps_triggered_date < DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY))
AND (_nps_user_state.user_id IS NULL
     OR _nps_user_state.annual_trigger_count IS NULL
     OR _nps_user_state.trigger_year < EXTRACT(YEAR FROM CURRENT_DATE())
     OR _nps_user_state.annual_trigger_count < 2)
AND (_survey_trigger_history_quarterly.user_id IS NULL
     OR _survey_trigger_history_quarterly.surveys_this_quarter < 2)
```

---

## 4. Sampling Rule Registry

### 4.1 Data model

Sampling config is stored as a JSON column on the `cohort` table (already proposed) or on the `measurement` table for CSAT where measurements can have different sampling modes.

```sql
ALTER TABLE cohort ADD COLUMN sampling_config JSON NULL;
-- Default when NULL: {"type":"SIMPLE_RANDOM","cap":3200}
```

### 4.2 Java type hierarchy

```java
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
    @JsonSubTypes.Type(value = SimpleRandomRule.class,  name = "SIMPLE_RANDOM"),
    @JsonSubTypes.Type(value = StatisticalRule.class,   name = "STATISTICAL"),
    @JsonSubTypes.Type(value = HashBasedRule.class,     name = "HASH_BASED"),
    @JsonSubTypes.Type(value = StratifiedRule.class,    name = "STRATIFIED"),
    // Future:
    // @JsonSubTypes.Type(value = WeightedRule.class,   name = "WEIGHTED"),
    // @JsonSubTypes.Type(value = TimeWindowedRule.class, name = "TIME_WINDOWED"),
})
public sealed interface SamplingRule
    permits SimpleRandomRule, StatisticalRule, HashBasedRule, StratifiedRule {}

/**
 * Uniformly random, exact N. Default for NPS and CSAT.
 * Compiled to: ROW_NUMBER() OVER (ORDER BY RAND()) with LIMIT cap.
 */
public record SimpleRandomRule(int cap) implements SamplingRule {}

/**
 * Cochran formula — sample size computed from statistical parameters.
 * Compiled to: Bernoulli filter (RAND() < p) or row-number with computed cap.
 * Useful when the cohort is large and statistical confidence matters more than exact count.
 */
public record StatisticalRule(
    double confidence,             // 0.95
    double marginOfError,          // 0.05
    double expectedResponseRate    // 0.30 — used to inflate sample size for non-response
) implements SamplingRule {}

/**
 * Deterministic hash-based sampling — same users selected on every run.
 * Salt rotation changes the selected population (e.g., per quarter for A/B testing).
 * Compiled to: FARM_FINGERPRINT bucket filter.
 */
public record HashBasedRule(
    int    bucketNumerator,        // 13
    int    bucketDenominator,      // 100  → selects ~13% of eligible users
    String salt                    // appended to user_id before hashing; rotate for new cohort
) implements SamplingRule {}

/**
 * Proportional or equal allocation across a categorical dimension.
 * Ensures representation from each sub-group (e.g., segment, platform, entity).
 * Compiled to: ROW_NUMBER() OVER (PARTITION BY strata_field ORDER BY RAND()).
 */
public record StratifiedRule(
    String strataField,            // "customer_segment"
    String allocation,             // "PROPORTIONAL" | "EQUAL"
    int    totalCap                // 3200
) implements SamplingRule {}
```

### 4.3 Stored JSON examples

```json
// SIMPLE_RANDOM — default NPS
{"type": "SIMPLE_RANDOM", "cap": 3200}

// STATISTICAL — for measurements where exact N matters less than confidence
{"type": "STATISTICAL", "confidence": 0.95, "marginOfError": 0.05, "expectedResponseRate": 0.30}

// HASH_BASED — A/B test: select stable 15% of eligible users, rotate salt per quarter
{"type": "HASH_BASED", "bucketNumerator": 15, "bucketDenominator": 100, "salt": "nps_q3_2026"}

// STRATIFIED — ensure proportional representation across customer segments
{"type": "STRATIFIED", "strataField": "customer_segment", "allocation": "PROPORTIONAL", "totalCap": 3200}
```

### 4.4 `SamplingRuleCompiler`

```java
@Component
public class SamplingRuleCompiler {

    /**
     * Returns the SQL expression to inject into the SELECT list.
     * For row-number algorithms: the window function.
     * For hash-based: the bucket expression.
     */
    public String compileSelectExpression(SamplingRule rule) {
        return switch (rule) {

            case SimpleRandomRule  ignored ->
                "ROW_NUMBER() OVER (PARTITION BY _cohort_id ORDER BY RAND()) AS _rn";

            case StatisticalRule   r -> {
                int cap = computeStatisticalCap(r);
                // Store cap for use in WHERE — pass via context or inline
                yield "ROW_NUMBER() OVER (PARTITION BY _cohort_id ORDER BY RAND()) AS _rn";
            }

            case HashBasedRule     r ->
                "MOD(ABS(FARM_FINGERPRINT(CONCAT(nuf.user_id, '%s'))), %d) AS _hash_bucket"
                    .formatted(r.salt(), r.bucketDenominator());

            case StratifiedRule    r ->
                """
                ROW_NUMBER() OVER (
                    PARTITION BY _cohort_id, nuf.%s ORDER BY RAND()
                ) AS _rn,
                COUNT(*) OVER (PARTITION BY _cohort_id, nuf.%s) AS _stratum_size,
                COUNT(*) OVER (PARTITION BY _cohort_id)         AS _cohort_eligible
                """.formatted(r.strataField(), r.strataField());
        };
    }

    /**
     * Returns the WHERE filter that applies the sampling cut.
     */
    public String compileFilter(SamplingRule rule) {
        return switch (rule) {
            case SimpleRandomRule  r  -> "_rn <= %d".formatted(r.cap());
            case StatisticalRule   r  -> "_rn <= %d".formatted(computeStatisticalCap(r));
            case HashBasedRule     r  -> "_hash_bucket < %d".formatted(r.bucketNumerator());
            case StratifiedRule    r  ->
                "_rn <= CEIL(CAST(%d AS FLOAT64) * _stratum_size / _cohort_eligible)"
                    .formatted(r.totalCap());
        };
    }

    /**
     * Cochran formula with finite population correction and non-response inflation.
     * n_raw      = (Z² × p × q) / e²
     * n_adjusted = n_raw / (1 + (n_raw - 1) / N)   [finite population correction]
     * n_inflated = n_adjusted / expected_response_rate
     */
    private int computeStatisticalCap(StatisticalRule r) {
        double z     = zScore(r.confidence());
        double p     = 0.5;   // maximum variance — conservative
        double q     = 1 - p;
        double e     = r.marginOfError();
        double nRaw  = (z * z * p * q) / (e * e);
        // Finite population correction is omitted here — cohort size is queried at runtime
        return (int) Math.ceil(nRaw / r.expectedResponseRate());
    }

    private double zScore(double confidence) {
        return switch ((int) (confidence * 100)) {
            case 90 -> 1.645;
            case 95 -> 1.96;
            case 99 -> 2.576;
            default -> throw new IllegalArgumentException("Unsupported confidence: " + confidence);
        };
    }
}
```

### 4.5 Compiled SQL — output per algorithm

| Algorithm | Compiled SELECT expression | Compiled WHERE |
|---|---|---|
| `SimpleRandom(3200)` | `ROW_NUMBER() OVER (ORDER BY RAND()) AS _rn` | `_rn <= 3200` |
| `Statistical(0.95, 0.05, 0.30)` | `ROW_NUMBER() OVER (ORDER BY RAND()) AS _rn` | `_rn <= 1283` |
| `HashBased(15, 100, "q3_2026")` | `MOD(ABS(FARM_FINGERPRINT(CONCAT(user_id,'q3_2026'))),100) AS _hash_bucket` | `_hash_bucket < 15` |
| `Stratified("segment","PROP",3200)` | `ROW_NUMBER() OVER (PARTITION BY segment ORDER BY RAND()) AS _rn, COUNT(*) OVER (PARTITION BY segment) AS _stratum_size, COUNT(*) OVER () AS _cohort_eligible` | `_rn <= CEIL(3200.0 * _stratum_size / _cohort_eligible)` |

---

## 5. AirflowPipelineCompiler — the assembler

This is the single point where cohort rule, eligibility rules, and sampling rule are assembled into a complete BQ query ready for Airflow to execute.

```java
@Service
@RequiredArgsConstructor
public class AirflowPipelineCompiler {

    private final JsonLogicToSqlCompiler    cohortCompiler;
    private final EligibilityRuleCompiler   eligibilityCompiler;
    private final SamplingRuleCompiler      samplingCompiler;
    private final EligibilityRuleStorage    eligibilityRuleStorage;

    @Value("${cohort.bigquery.project-id}")  private String bqProject;
    @Value("${cohort.bigquery.dataset-id}")  private String bqDataset;

    public CompiledPipeline compile(Cohort cohort, PipelineContext context) {
        // 1. Compile cohort membership filter
        String cohortWhere = cohortCompiler.compile(cohort.getRuleDefinition());

        // 2. Load and compile eligibility rules
        List<EligibilityRule> eligibilityRules = eligibilityRuleStorage
            .findActiveByCohortId(cohort.getId());
        List<String> eligibilityJoins = eligibilityCompiler.compileJoins(eligibilityRules);
        String eligibilityWhere       = eligibilityCompiler.compileWhere(eligibilityRules);

        // 3. Compile sampling
        SamplingRule samplingRule    = cohort.getSamplingRule();
        String samplingSelect        = samplingCompiler.compileSelectExpression(samplingRule);
        String samplingFilter        = samplingCompiler.compileFilter(samplingRule);

        // 4. Assemble full BQ query
        String sql = buildQuery(
            bqProject, bqDataset,
            cohortWhere, eligibilityJoins, eligibilityWhere,
            samplingSelect, samplingFilter,
            cohort.getId(), context
        );

        return new CompiledPipeline(cohort.getId(), cohort.getName(), sql, context);
    }

    private String buildQuery(
        String project, String dataset,
        String cohortWhere,
        List<String> eligibilityJoins,
        String eligibilityWhere,
        String samplingSelect,
        String samplingFilter,
        Long cohortId,
        PipelineContext ctx
    ) {
        return """
            SELECT user_id, %d AS cohort_id, '%s' AS context_key
            FROM (
                SELECT
                    nuf.user_id,
                    %s,                                      -- sampling expression
                    COUNT(*) OVER () AS _population_size,    -- funnel: total cohort members
                    COUNT(*) OVER () AS _eligible_size       -- funnel: after eligibility (same level)
                FROM `%s.%s.native_user_features` nuf
                %s                                           -- eligibility LEFT JOINs
                WHERE (%s)                                   -- cohort rule
                  AND (%s)                                   -- eligibility rules
            )
            WHERE %s                                         -- sampling filter
            """.formatted(
                cohortId, ctx.contextKey(),
                samplingSelect,
                project, dataset,
                String.join("\n", eligibilityJoins),
                cohortWhere,
                eligibilityWhere,
                samplingFilter
        );
    }
}
```

---

## 6. Airflow DAG — generic executor

The DAG receives compiled SQL and executes it. It has no knowledge of rule types, algorithms, or survey business logic.

```python
from airflow.decorators import dag, task
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.mysql.hooks.mysql import MySqlHook
from pendulum import datetime

@dag(schedule=None, start_date=datetime(2026, 1, 1), catchup=False)
def survey_pipeline():
    """
    Generic survey pipeline executor.
    Receives fully compiled BQ SQL from CAS via dag_run.conf.
    Never changes when eligibility or sampling rules change.
    """

    @task
    def get_pipelines(**context) -> list[dict]:
        return context["dag_run"].conf["pipelines"]

    @task
    def execute_bq_query(pipeline: dict) -> dict:
        """Runs the compiled SQL. Returns rows + funnel counts."""
        rows = BigQueryHook().get_records(pipeline["compiled_sql"])

        # The compiled SQL selects _population_size and _eligible_size in the inner query.
        # These are available as the last two columns on the first row.
        population_size = rows[0][-2] if rows else 0
        eligible_size   = rows[0][-1] if rows else 0

        return {
            "pipeline":       pipeline,
            "rows":           [(r[0], r[1], r[2]) for r in rows],   # user_id, cohort_id, context_key
            "population_size": population_size,
            "eligible_size":   eligible_size,
            "sample_size":     len(rows)
        }

    @task
    def load_to_mysql(result: dict):
        """Writes sampled rows + audit record. Generic — works for NPS and CSAT."""
        pipeline = result["pipeline"]
        hook     = MySqlHook(mysql_conn_id="cas_cloudsql")

        hook.insert_rows(
            table=pipeline["target_table"],
            rows=result["rows"],
            target_fields=pipeline["target_fields"],
            replace=False
        )

        hook.run("""
            INSERT INTO survey_pipeline_audit
                (cohort_id, context_key, run_date, population_size, eligible_size, sample_size, status)
            VALUES (%s, %s, CURRENT_DATE(), %s, %s, %s, 'COMPLETE')
            ON DUPLICATE KEY UPDATE
                population_size=%s, eligible_size=%s, sample_size=%s, status='COMPLETE'
        """, parameters=[
            pipeline["cohort_id"], pipeline["context_key"],
            result["population_size"], result["eligible_size"], result["sample_size"],
            result["population_size"], result["eligible_size"], result["sample_size"]
        ])

    pipelines = get_pipelines()
    results   = execute_bq_query.expand(pipeline=pipelines)
    load_to_mysql.expand(result=results)

survey_pipeline()
```

This DAG has been stable since it was created. It does not know what `COOL_OFF` or `HASH_BASED` mean.

---

## 7. Extension walkthrough

### 7.1 Adding a new eligibility rule: `ComplaintHistoryRule`

> Requirement: exclude users who have an open complaint in the last 60 days.

**Step 1 — Define the rule record (CAS):**

```java
public record ComplaintHistoryRule(
    String sourceTable,      // "complaint_history"
    String joinKey,          // "user_id"
    String dateField,        // "last_complaint_date"
    String statusField,      // "complaint_status"
    int    exclusionDays     // 60
) implements EligibilityRule {}
```

**Step 2 — Add `@JsonSubTypes` entry:**

```java
@JsonSubTypes.Type(value = ComplaintHistoryRule.class, name = "COMPLAINT_HISTORY")
```

**Step 3 — Add compiler case:**

```java
case ComplaintHistoryRule r -> """
    (_%s.%s IS NULL
     OR _%s.%s NOT IN ('OPEN', 'PENDING')
     OR _%s.%s < DATE_SUB(CURRENT_DATE(), INTERVAL %d DAY))
    """.formatted(
        r.sourceTable(), r.joinKey(),
        r.sourceTable(), r.statusField(),
        r.sourceTable(), r.dateField(), r.exclusionDays());
```

**Step 4 — Seed the rule in MySQL:**

```sql
INSERT INTO eligibility_rule
    (measurement_id, rule_order, rule_type, rule_config, active, created_on)
VALUES
    (1, 4, 'COMPLAINT_HISTORY',
     '{"type":"COMPLAINT_HISTORY","sourceTable":"complaint_history","joinKey":"user_id","dateField":"last_complaint_date","statusField":"complaint_status","exclusionDays":60}',
     true, NOW());
```

**No Airflow DAG changes. No BQ SQL template changes.**

---

### 7.2 Adding a new sampling algorithm: `TimeWindowedRule`

> Requirement: CSAT daily sample distributed across 48 × 30-minute windows (PRD AC-02.5).

**Step 1 — Define the rule record:**

```java
public record TimeWindowedRule(
    int   totalDailyCap,           // 4000
    int   windowsPerDay,           // 48 (30-min windows in 24h)
    String distributionMode        // "EVEN" | "PEAK_WEIGHTED"
) implements SamplingRule {}
```

**Step 2 — Add `@JsonSubTypes` entry and compiler cases:**

```java
// compileSelectExpression:
case TimeWindowedRule r -> {
    int perWindow = r.totalDailyCap() / r.windowsPerDay();
    yield """
        ROW_NUMBER() OVER (
            PARTITION BY _cohort_id,
            FLOOR(MOD(ABS(FARM_FINGERPRINT(nuf.user_id)), %d))
            ORDER BY RAND()
        ) AS _rn
        """.formatted(r.windowsPerDay());
}

// compileFilter:
case TimeWindowedRule r -> "_rn <= %d".formatted(r.totalDailyCap() / r.windowsPerDay());
```

**Step 3 — JSON config:**

```json
{
  "type": "TIME_WINDOWED",
  "totalDailyCap": 4000,
  "windowsPerDay": 48,
  "distributionMode": "EVEN"
}
```

**No Airflow DAG changes.**

---

## 8. Pipeline observability

Every compiled pipeline query includes funnel count expressions. These are captured automatically in `survey_pipeline_audit`:

```sql
CREATE TABLE survey_pipeline_audit (
    cohort_id        BIGINT       NOT NULL,
    context_key      VARCHAR(50)  NOT NULL,   -- "2026-W22" for NPS, "2026-05-22" for CSAT
    run_date         DATE         NOT NULL,
    population_size  INT          NOT NULL,   -- users matching cohort rule
    eligible_size    INT          NOT NULL,   -- after eligibility exclusions
    sample_size      INT          NOT NULL,   -- final sampled count
    status           VARCHAR(20)  NOT NULL,
    PRIMARY KEY (cohort_id, context_key)
);
```

The Journey Intelligence View reads this table for the funnel display (population → eligible → sampled → pre-committed → triggered → responded).

---

## 9. Migration path from current implementation

The current implementation hardcodes eligibility rules in `AirflowPipelineCompiler.compile()` and the BQ SQL template. Migration is incremental:

| Phase | What changes | Effort |
|---|---|---|
| **Phase 1 (current)** | Hardcoded rules compiled into BQ SQL | Baseline |
| **Phase 2a** | Extract `EligibilityRuleCompiler` and `SamplingRuleCompiler` as separate classes; same hardcoded rules but now in typed records | Small refactor — rules still seeded in code, not DB |
| **Phase 2b** | Move rules to `eligibility_rule` MySQL table; compiler reads from DB | DB migration + loader |
| **Phase 2c** | Add `sampling_config` JSON to `cohort` table | DB migration + JSON column |
| **Phase 3** | Full rule registry — PMs can add rule rows without engineering involvement | Complete |

Each phase is independently deployable. Phase 2a and 2b can land in separate PRs with no behaviour change.

---

## 10. Phase 2 rule candidates

Rules that are known future requirements but not in scope today:

**Eligibility:**

| Rule type | Trigger | Source table |
|---|---|---|
| `COMPLAINT_HISTORY` | Exclude users with open complaints | `complaint_history` |
| `ACCOUNT_STATUS` | Exclude suspended / restricted accounts | `account_status` |
| `JOURNEY_FREQUENCY` | Exclude users who completed the journey fewer than N times | `journey_event_log` |
| `CHANNEL_EXCLUSIVE` | Only include users who primarily use a specific channel | `user_channel_preference` |

**Sampling:**

| Algorithm | Use case |
|---|---|
| `WEIGHTED` | Weight by time since last survey — users not surveyed recently get higher probability |
| `TIME_WINDOWED` | CSAT: distribute evenly across 30-min windows within a day |
| `HOLDOUT` | Permanently exclude a stable 5% of users as an unbiased baseline |
| `STRATIFIED_WITH_MINIMUM` | Stratified but with a minimum floor per stratum (for failure/error state coverage) |
