# Design: NPS Cohort Logic Application — Three-Phase Eligibility Pipeline

**Spec:** [`impl-specs/2026-05-19-nps-sampling.md`](../../impl-specs/2026-05-19-nps-sampling.md)
**Depends on:** [NPS Sampling Design](nps-sampling-design.md) · [NPS Cohort Definition Design](nps-cohort-definition-design.md) · [NPS Cool-Off Design](nps-cool-off-design.md) · [User Attributes Storage Design](user-attributes-storage-design.md)
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)
**Date:** 2026-05-20

---

## 1. Overview

The `NpsWeeklySamplePreparationJob` selects eligible users for each NPS cohort through three sequential phases. Each phase eliminates a different class of ineligible user at a different cost tier:

| Phase | Gate | Mechanism | Cost |
|---|---|---|---|
| 1 | Cohort eligibility (account age + recent transaction) | Bigtable server-side `RowFilter` | ~1–3 min, one streaming scan |
| 2 | Cool-off (90-day window + annual cap) | MySQL bulk anti-join → `Set<String>` | < 1 second, one SQL query |
| 3 | Weekly cap enforcement | In-memory `Collections.shuffle()` + `subList()` | < 30 seconds |

The phases are ordered by cost, highest first: the most expensive gate (Bigtable scan of 24M rows) applies the broadest filter first, so downstream phases receive a much smaller input. The cool-off anti-join works on the 2–5M users who survived Phase 1, reducing the candidate pool further before the in-memory shuffle.

---

## 2. Cohort Fields → Bigtable Filter Parameter Mapping

Each `Cohort` row's eligibility fields map directly to `RowFilter` construction parameters in `UserAttributesRepositoryService.scanEligibleUsers()`:

| Cohort field | Type | RowFilter parameter | Effect |
|---|---|---|---|
| `minAccountAgeDays` | `INT` | `cutoffDate = today - minAccountAgeDays`; ageFilter uses `endOpen(cutoffDate.plusDays(1))` | Excludes users onboarded after the cutoff date |
| `requireRecentTransaction` | `BOOLEAN` | Determines filter shape: `true` → `condition(ageFilter).then(txnFilter).otherwise(block())`; `false` → `ageFilter` only | Switches between AND (both gates) and age-only mode |
| `transactionWindowDays` | `INT` | `earliestTxn = today - transactionWindowDays`; txnFilter uses `startClosed(earliestTxn)` | Excludes users with no transaction in the look-back window |

**Phase 1 filter parameters for the two seed cohorts** (as defined in the cohort seed data):

| Cohort | `minAccountAgeDays` | `requireRecentTransaction` | `transactionWindowDays` | cutoffDate (today = 2026-05-20) | earliestTxn |
|---|---|---|---|---|---|
| Personal Banking NPS | 60 | `true` | 30 | 2026-03-21 | 2026-04-20 |
| Business Banking NPS | 60 | `true` | 30 | 2026-03-21 | 2026-04-20 |

Both seed cohorts use identical gate parameters; the distinction between cohorts is the `segment` field (`PERSONAL_BANKING` vs `BUSINESS_BANKING`), which is used by upstream services to route users to the right Bigtable rows, not by the RowFilter itself.

---

## 3. Phase 1: Bigtable Server-Side Filter

### 3.1 Why server-side filtering is the first gate

The Bigtable `users` table holds approximately 24M rows at current scale. Without server-side filters, a full-table scan would transfer ~4.8 GB of data (24M rows × ~200 bytes/row) from Bigtable to the CAS Worker. With the eligibility filter applied server-side, only matching rows (estimated 2–5M for the two NPS cohorts) cross the network, and each row carries only the minimum qualifying cell (~80 bytes). Network transfer drops by approximately 10×.

Server-side filtering runs on Bigtable nodes (not in the CAS JVM), meaning CPU cost is distributed across the cluster rather than concentrated in a single Worker pod.

### 3.2 ConditionFilter for AND semantics

When `requireRecentTransaction = true`, both the age gate and the transaction gate must pass. Bigtable's `FILTERS.interleave()` must **not** be used for this — it gives OR semantics at the cell level, admitting any row where at least one cell matches either sub-filter.

Example of the OR-semantics failure:
- User with `onboardingDate = "2022-01-01 00:00:00"` (very old account) and `lastTxnDate = "2025-01-01"` (no transaction in 30 days)
- `interleave(ageFilter, txnFilter)`: ageFilter matches the `onboardingDate` cell → row returned **incorrectly**
- `condition(ageFilter).then(txnFilter)`: ageFilter matches → then txnFilter applied → `lastTxnDate` cell fails → 0 cells → **row omitted correctly**

Corrected filter construction:

```java
RowFilter ageFilter = FILTERS.chain()
    .filter(FILTERS.qualifier().exactMatch("onboardingDate"))
    .filter(FILTERS.value().range()
        .endOpen(ByteString.copyFromUtf8(cutoffDate.plusDays(1).toString())));
// endOpen(cutoffDate+1) required because onboardingDate is stored as
// "yyyy-MM-dd HH:mm:ss" — see user-attributes-storage-design.md §3.2

RowFilter txnFilter = FILTERS.chain()
    .filter(FILTERS.qualifier().exactMatch("lastTxnDate"))
    .filter(FILTERS.value().range()
        .startClosed(ByteString.copyFromUtf8(earliestTxn.toString())));
// startClosed(date) is correct because lastTxnDate is stored as "YYYY-MM-DD"

RowFilter combined = FILTERS.condition(ageFilter)
    .then(txnFilter)
    .otherwise(FILTERS.block());
```

### 3.3 Relationship to CohortEligibilityGate

`CohortEligibilityGate.evaluate(cohort, userAttributes, today)` (specified in the cohort definition spec) implements the same two-gate logic in Java code. The relationship between the Bigtable filter and the Java gate is:

- **Phase 1 (Bigtable filter)** applies the cohort gates server-side during scanning, eliminating ineligible users before they reach the CAS JVM. The filter parameters are derived directly from the same `Cohort` entity fields.
- **`CohortEligibilityGate`** is a pure Java implementation of the same logic, used as a secondary verifier and in tests. It is NOT called in the main sampling job hot-path — the Bigtable filter already performs the equivalent check.

This means the Bigtable filter and `CohortEligibilityGate` must stay in sync when `Cohort` eligibility criteria change. If a new gate is added to `CohortEligibilityGate`, the corresponding server-side filter must also be updated in `scanEligibleUsers()`.

---

## 4. Phase 2: Cool-Off Anti-Join

### 4.1 The N+1 problem it replaces

The original design filtered the eligible stream with a per-user call:
```java
candidateStream = eligibleStream.filter(uid ->
    !npsUserStateService.isInCoolOff(uid, coolOffDays, yearlyTriggerCap)
)
```

For 2–5M eligible users, this issues 2–5M individual MySQL point-reads against `nps_user_state`. The vast majority (>98%) return `null` because most users have never received an NPS survey. At 10K QPS realistic throughput, 5M queries = ~500 seconds — potentially longer than the Bigtable scan itself.

### 4.2 Anti-join: invert the query

The cool-off population at steady state is bounded and small:

```
coolOffSize ≈ weeklyInvitationCap × (coolOffDays / 7 weeks)
            = (3,200 + 2,134) × (90 / 7)
            ≈ 5,334 × 12.86
            ≈ 68,600 users in cool-off at any time
```

Heap cost: ~68,600 × 50 bytes ≈ 3.4 MB — negligible.

Instead of asking "is this user in cool-off?" N times, ask "which users are in cool-off?" once:

```java
// New method on NpsUserStateService:
Set<String> coolOffIds = npsUserStateService.findUsersInCoolOff(coolOffDays, yearlyTriggerCap);

// O(1) filter per user — no DB call per user
candidateStream = eligibleStream.filter(uid -> !coolOffIds.contains(uid));
```

### 4.3 New method: `NpsUserStateService.findUsersInCoolOff()`

**Interface addition:**

```java
/**
 * Returns the set of user IDs currently excluded from NPS sampling.
 * A user is in cool-off if they were triggered within the last {@code coolOffDays}
 * days OR have reached the annual trigger cap.
 *
 * @param coolOffDays       minimum days since last trigger (typically 90)
 * @param yearlyTriggerCap  maximum triggers per calendar year (typically 2)
 * @return set of user IDs; never null; expected size ~70K at steady state
 */
Set<String> findUsersInCoolOff(int coolOffDays, int yearlyTriggerCap);
```

**Implementation query:**

```sql
SELECT user_id
FROM   nps_user_state
WHERE  last_nps_triggered_date >= :ninetyDaysAgo
    OR annual_trigger_count    >= :yearlyTriggerCap
```

Where `:ninetyDaysAgo = LocalDate.now(ZoneId.of("Africa/Lagos")).minusDays(coolOffDays)`.

**Return type:** `Set<String>` backed by a `HashSet` for O(1) membership checks.

**Expected performance:** One indexed range scan on `nps_user_state.last_nps_triggered_date` (needs an index on this column) + OR branch for `annual_trigger_count`. For ~70K rows, response time is ~10–50 ms.

**Index requirement:** `INDEX(last_nps_triggered_date)` on `nps_user_state`. If this index does not exist, the query performs a full table scan. The `nps_user_state` table grows at `weeklyInvitationCap` rows/week and is bounded by the user population — an index is required for production correctness.

### 4.4 Per-cohort scope

`findUsersInCoolOff()` is called once per cohort per sampling run (inside the cohort loop). This is correct because `coolOffDays` and `yearlyTriggerCap` are read from `SurveyBody` and may differ between cohorts. In the current seed data both cohorts use the same values (90 days, cap 2), but the structure supports future divergence.

```java
for (Cohort cohort : activeCohorts) {
    SurveyBody surveyBody = parseSurveyBody(cohort);
    int coolOffDays      = surveyBody.getCoolOffDays();
    int yearlyTriggerCap = surveyBody.getYearlyTriggerCap();

    Stream<String> eligibleStream = userAttributesRepositoryService
        .scanEligibleUsers(...);

    Set<String> coolOffIds = npsUserStateService
        .findUsersInCoolOff(coolOffDays, yearlyTriggerCap);  // one query per cohort

    List<String> candidates = eligibleStream
        .filter(uid -> !coolOffIds.contains(uid))
        .collect(toList());
    ...
}
```

---

## 5. Phase 3: Random Selection

After cool-off exclusion, the candidate list is shuffled and truncated to `weeklyInvitationCap`. Fisher-Yates shuffle via `Collections.shuffle()` gives uniform random selection — every eligible, non-cool-off user has equal probability of selection.

The full candidate list must be materialised before shuffling (PRD §7.3 requires random selection from the full eligible pool). At 5M candidates × 50 bytes/userId, peak heap pressure is ~250 MB — within the Worker's `-Xmx` budget. If memory pressure becomes a concern, reservoir sampling (`k = weeklyInvitationCap`) processes the stream in one pass with O(k) peak memory; this is documented as a fallback in the sampling spec.

---

## 6. Complete Annotated Algorithm (one cohort)

```
execute():

  currentIsoWeek ← IsoWeekUtil.current("Africa/Lagos")
  activeCohorts  ← cohortStorage.findBySurveyCategoryAndActiveTrue(NPS)

  for each cohort in activeCohorts:

    survey            ← surveyStorage.findById(cohort.surveyId)
    surveyBody        ← objectMapper.readValue(survey.survey, SurveyBody.class)
    weeklyInvCap      ← surveyBody.weeklyInvitationCap
    coolOffDays       ← surveyBody.coolOffDays          // default 90
    yearlyTriggerCap  ← surveyBody.yearlyTriggerCap     // default 2
    batchSize         ← config.nps.sampling.batchSize   // recommended 50,000

    if weeklyInvCap <= 0: log.warn + continue

    // ── Phase 1: Bigtable server-side filter ────────────────────────────
    // Scans 24M rows; server-side ConditionFilter passes ~2–5M rows.
    // Filter uses endOpen(cutoffDate+1) for onboardingDate datetime encoding.
    // AND semantics: condition(ageFilter).then(txnFilter).otherwise(block()).
    //
    eligibleStream ← userAttributesRepositoryService.scanEligibleUsers(
      cohort.minAccountAgeDays,
      cohort.transactionWindowDays,
      cohort.requireRecentTransaction,
      batchSize
    )   // returns lazy Stream<String> of userIds

    // ── Phase 2: Cool-off anti-join ─────────────────────────────────────
    // One bulk MySQL query loads ~70K cool-off IDs into a HashSet.
    // Stream filter is O(1) per user — no per-user DB call.
    //
    coolOffIds ← npsUserStateService.findUsersInCoolOff(coolOffDays, yearlyTriggerCap)
    candidateStream ← eligibleStream.filter(uid → !coolOffIds.contains(uid))
    candidates ← candidateStream.collect(toList())      // materialise for shuffle

    // ── Phase 3: Random selection ────────────────────────────────────────
    Collections.shuffle(candidates)
    sampled ← candidates.subList(0, min(candidates.size(), weeklyInvCap))

    // ── Insert sample rows + trigger preprocessing ───────────────────────
    for each userId in sampled:
      npsWeeklySampleStorage.upsert(
        NpsWeeklySample(userId, cohort.id, currentIsoWeek, PENDING)
      )
      userAttributes ← userAttributesStorage.findUser(userId, null)
      surveyPreprocessorKafkaEventPublisher.publish(
        EventPreprocessSurveyDTO(survey, userAttributes, null,
          PreprocessedSurvey(userId, survey.id, cohort.id, currentIsoWeek))
      )

    log.info("NPS sampling: cohort={}, isoWeek={}, eligible={}, coolOff={}, sampled={}/{}",
             cohort.name, currentIsoWeek,
             candidates.size() + coolOffExcluded, coolOffExcluded,
             sampled.size(), weeklyInvCap)
```

---

## 7. Sequence Diagram

```
NpsWeeklySamplePreparationJob     UserAttributesRepositoryService    BigtableDataClient
         │                                    │                           │
         │── scanEligibleUsers(args) ─────────►│                           │
         │                                    │── readRows(Query+Filter) ─►│
         │                                    │◄── Stream<Row> ────────────│ (~2-5M rows)
         │                                    │   (paginated, ~480 batches │
         │                                    │    at batchSize=50K)       │
         │◄── Stream<String> (userIds) ────────│                           │
         │                                    │                           │
         │                                    NpsUserStateService     NpsUserStateStorage
         │                                         │                       │
         │── findUsersInCoolOff(90, 2) ────────────►│                       │
         │                                         │── SELECT user_id ─────►│
         │                                         │   WHERE cooloff_cond   │
         │                                         │◄── ~70K rows ──────────│
         │◄── Set<String> coolOffIds ─────────────│                       │
         │                                         │                       │
         │  filter(uid → !coolOffIds.contains(uid))  [O(1) per user, in-heap]
         │  collect(toList())
         │  Collections.shuffle()
         │  subList(0, weeklyInvCap)
         │
         │                           NpsWeeklySampleStorage    KafkaProducer
         │                                   │                     │
         │  for each sampled userId:         │                     │
         │── upsert(NpsWeeklySample) ────────►│                     │
         │── publish(EventPreprocessSurveyDTO)────────────────────►│
         │                                   │                     │
         │  [end loop]                        │                     │
         │
         │  log.info("cohort=..., sampled=N/cap")
```

---

## 8. Test Cases for the Two Fixes

The following test cases validate correctness of the ConditionFilter (Fix 1) and the anti-join (Fix 2). They supplement the existing test matrix in `impl-specs/2026-05-19-nps-sampling.md`.

| # | Test | Component | Type | Assertion |
|---|---|---|---|---|
| T-NEW-01 | User with old account AND no recent transaction is excluded from eligible stream | C-02 (Bigtable scan) | Unit (emulator) | User with `onboardingDate = today-65 08:30:00`, `lastTxnDate = today-60` (outside 30-day window) is NOT in `scanEligibleUsers()` output |
| T-NEW-02 | User with recent transaction AND new account is excluded | C-02 | Unit (emulator) | User with `onboardingDate = today-30 00:00:00`, `lastTxnDate = today` is NOT in output |
| T-NEW-03 | User with old account AND recent transaction IS included | C-02 | Unit (emulator) | User with `onboardingDate = today-65 08:30:00`, `lastTxnDate = today-15` IS in output |
| T-NEW-04 | User onboarded exactly on cutoffDate (datetime encoding boundary) is included | C-02 | Unit (emulator) | User with `onboardingDate = cutoffDate 08:30:00` IS returned — validates `endOpen(cutoffDate+1)` not `endClosed(cutoffDate)` |
| T-NEW-05 | Cool-off check issues exactly ONE SQL query per cohort, regardless of eligible pool size | C-03 | Unit (Mockito) | `npsUserStateStorage.findUsersInCoolOff()` called once per cohort iteration; no call to `isInCoolOff(userId)` for any userId |
| T-NEW-06 | User IDs in cool-off HashSet are excluded from sampled output | C-03 | Unit | Stub `findUsersInCoolOff()` returns `Set.of("user-A", "user-B")`; verify neither appears in `sampled` list |
| T-NEW-07 | Cool-off anti-join is correct when cool-off set is empty (first run, no prior triggers) | C-03 | Unit | `findUsersInCoolOff()` returns empty set; all eligible users pass Phase 2 filter |
| T-NEW-08 | Annual cap users (trigger_count >= 2) are excluded even if outside 90-day window | C-03 | Unit | Stub returns user whose `annual_trigger_count = 2`; user excluded from candidates |

---

## 9. `findUsersInCoolOff()` — Chunk Placement

This method is a new addition to `NpsUserStateService` (the cool-off spec's `isInCoolOff()` was the original interface). It should be delivered as an addendum to the cool-off spec's C-02 chunk, or as a standalone C-07 chunk in the sampling spec's chunk list. The change is small (~30 lines including test) but touches a Tier 3 interface.

**DDL requirement:** If `nps_user_state.last_nps_triggered_date` does not already have an index, add one before this method is deployed to production. The query's `WHERE last_nps_triggered_date >= :date` predicate requires the index for acceptable query time at scale.

```sql
-- Add to DB migrations repo (if not already present):
ALTER TABLE nps_user_state
    ADD INDEX idx_nus_last_triggered (last_nps_triggered_date);
```
