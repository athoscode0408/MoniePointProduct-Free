# Design: NPS Cohort Definition

**Spec:** [`impl-specs/2026-05-19-nps-cohort-definition.md`](../../impl-specs/2026-05-19-nps-cohort-definition.md)  
**ADRs:** [ADR-001 Cohort Design Strategy](../../adrs/ADR-001-cohort-design-strategy.md) · [ADR-002 Cohort Eligibility Integration](../../adrs/ADR-002-cohort-eligibility-integration.md)  
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)  
**Date:** 2026-05-19

---

## 1. Overview and Relationship to Existing Components

The NPS Sampling Programme (impl-spec `2026-05-18-nps-sampling-engine.md`) requires that users be drawn from **pre-defined audience segments** before a weekly invitation cap is applied. Today, CAS has no cohort concept: survey eligibility is evaluated per-event via SpEL rules in `RuleParserHandler`, and no persistent record of which users belong to which product segment exists in the service.

This design introduces the `Cohort` entity — a DB-seeded, engineering-managed record that defines a named audience segment with static eligibility gates. The entity is named `Cohort` (not `NpsCohort`) so it is reusable for CSAT and future survey categories without schema changes.

### How this design fits into the existing survey pipeline

```
Existing event-driven path (BRM / CSAT):
  Analytics Event
    → SurveyEventListener
    → SurveyEvaluatorListener   (reads all Survey rules)
    → RuleParserHandler          (SpEL eval → pass/fail)
    → [pass] publishes EventPreprocessSurveyDTO to Kafka
    → SurveyPreprocessorListener
    → PreprocessedSurvey saved to MySQL
    → Existing GET /api/surveys/dashboard-info serves it

NPS cohort evaluation path (NEW — batch only):
  NpsWeeklySamplePreparationJob  (Quartz + ShedLock, runs Mon 00:05 Africa/Lagos)
    → CohortEligibilityGate.evaluate(cohort, userAttributes)
    → [pass] user inserted into nps_weekly_sample
    → At check-in: NpsEligibilityResolver looks up nps_weekly_sample
    → EventPreprocessSurveyDTO published (with cohortId set)
    → SurveyPreprocessorListener
    → PreprocessedSurvey saved with cohort_id column populated
    → Existing delivery endpoints serve it
```

Key invariants maintained by this design:
- The SpEL pipeline (`SurveyEvaluatorListener` → `RuleParserHandler`) is **not modified**. It continues to serve BRM and CSAT.
- NPS eligibility **never goes through** `RuleParserHandler`. Cohort gates are evaluated in typed Java code only.
- `PreprocessedSurvey` delivery endpoints are **not changed**. The new `cohort_id` column is informational and does not alter client-facing payloads.

---

## 2. Domain Model

### 2.1 Cohort aggregate

`Cohort` is the root of a small aggregate. It holds the definition of an audience segment, including the eligibility gates required to belong to it and the `Survey` row it drives. There is no parent aggregate: `Cohort` rows are standalone, engineering-seeded, and referenced by FK from `nps_weekly_sample` and `PreprocessedSurvey`.

```
Cohort
  ├── id            (PK, from BaseEntity)
  ├── name          VARCHAR(100) — human label ("Personal Banking NPS", etc.)
  ├── surveyCategory ENUM(NPS, CSAT, BRM)
  ├── segment        ENUM(PERSONAL_BANKING, BUSINESS_BANKING, AGENTS)
  ├── minAccountAgeDays  INT — Gate 1 lower bound
  ├── requireRecentTransaction  BOOLEAN — Gate 2 switch
  ├── transactionWindowDays  INT — Gate 2 look-back window
  ├── platform       ENUM(PERSONAL_APP, BUSINESS_APP, POS, ALL)
  ├── surveyId       BIGINT FK → survey.id  — the Survey row this cohort drives
  ├── active         BOOLEAN DEFAULT false
  └── BaseEntity audit fields (createdBy, createdOn, lastModifiedBy, lastModifiedOn, version)
```

`Cohort.surveyId` is a direct FK to the `survey` table. This eliminates the need for a separate `NpsMeasurement` entity for Phase 1: each cohort drives exactly one survey. If a future requirement calls for one cohort to drive multiple concurrent surveys (e.g. A/B testing two NPS questionnaires), the FK becomes a join table — that is a forward-compatible schema change.

### 2.2 cohort_id on PreprocessedSurvey

`PreprocessedSurvey` gains one nullable column:

```
cohort_id  BIGINT NULLABLE  — FK to cohort.id
```

This column is populated by `SurveyPreprocessorListener` when the `EventPreprocessSurveyDTO` it consumes was published by the NPS sampling path (i.e., when `cohortId` is present on the DTO). For BRM and CSAT surveys that go through the SpEL path, `cohort_id` remains `NULL`.

The column is **explicit** — it is a declared `@Column` on the entity, not a key in `additionalData` JSON. This makes it queryable, indexable, and schema-verifiable.

---

## 3. Entity Schemas

### 3.1 Cohort entity

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT | From `BaseEntity` |
| `name` | `VARCHAR(100)` | NOT NULL | Human label. Unique enforced by application, not DB. |
| `survey_category` | `ENUM('NPS','CSAT','BRM')` | NOT NULL | `@Enumerated(EnumType.STRING)` |
| `segment` | `ENUM('PERSONAL_BANKING','BUSINESS_BANKING','AGENTS')` | NOT NULL | `@Enumerated(EnumType.STRING)` |
| `min_account_age_days` | `INT` | NOT NULL | Days since onboarding required before eligibility |
| `require_recent_transaction` | `BOOLEAN` | NOT NULL | Whether Gate 2 applies |
| `transaction_window_days` | `INT` | NOT NULL | Look-back window for Gate 2 |
| `platform` | `ENUM('PERSONAL_APP','BUSINESS_APP','POS','ALL')` | NOT NULL | Platform scope for this cohort |
| `survey_id` | `BIGINT` | NOT NULL, FK → `survey(id)` | The Survey row this cohort drives |
| `active` | `BOOLEAN` | NOT NULL, DEFAULT false | Only active cohorts are sampled |
| `created_by` | `VARCHAR(255)` | NOT NULL | From `BaseEntity` |
| `created_on` | `TIMESTAMP` | NOT NULL | From `BaseEntity` |
| `last_modified_by` | `VARCHAR(255)` | NOT NULL | From `BaseEntity` |
| `last_modified_on` | `TIMESTAMP` | NOT NULL | From `BaseEntity` |
| `version` | `INT` | NOT NULL | Optimistic lock from `BaseEntity` |

**DDL (specify in DB migrations repo):**

```sql
CREATE TABLE cohort (
    id                         BIGINT          NOT NULL AUTO_INCREMENT,
    name                       VARCHAR(100)    NOT NULL,
    survey_category            ENUM('NPS','CSAT','BRM') NOT NULL,
    segment                    ENUM('PERSONAL_BANKING','BUSINESS_BANKING','AGENTS') NOT NULL,
    min_account_age_days       INT             NOT NULL,
    require_recent_transaction BOOLEAN         NOT NULL,
    transaction_window_days    INT             NOT NULL,
    platform                   ENUM('PERSONAL_APP','BUSINESS_APP','POS','ALL') NOT NULL,
    survey_id                  BIGINT          NOT NULL,
    active                     BOOLEAN         NOT NULL DEFAULT false,
    created_by                 VARCHAR(255)    NOT NULL,
    created_on                 TIMESTAMP       NOT NULL,
    last_modified_by           VARCHAR(255)    NOT NULL,
    last_modified_on           TIMESTAMP       NOT NULL,
    version                    INT             NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_cohort_survey FOREIGN KEY (survey_id) REFERENCES survey(id)
);
```

**Seed rows (apply in same migration):**

```sql
-- Personal Banking NPS cohort (links to the Personal Banking NPS Survey row)
INSERT INTO cohort (name, survey_category, segment, min_account_age_days,
                    require_recent_transaction, transaction_window_days,
                    platform, survey_id, active,
                    created_by, created_on, last_modified_by, last_modified_on, version)
VALUES ('Personal Banking NPS', 'NPS', 'PERSONAL_BANKING', 60,
        true, 30,
        'PERSONAL_APP', <personal_nps_survey_id>, false,
        'system', NOW(), 'system', NOW(), 0);

-- Business Banking NPS cohort (links to the Business Banking NPS Survey row)
INSERT INTO cohort (name, survey_category, segment, min_account_age_days,
                    require_recent_transaction, transaction_window_days,
                    platform, survey_id, active,
                    created_by, created_on, last_modified_by, last_modified_on, version)
VALUES ('Business Banking NPS', 'NPS', 'BUSINESS_BANKING', 60,
        true, 30,
        'BUSINESS_APP', <business_nps_survey_id>, false,
        'system', NOW(), 'system', NOW(), 0);
```

> Note: `active = false` at seed time. The rollout plan activates cohorts after staging verification.

### 3.2 PreprocessedSurvey — new column

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `cohort_id` | `BIGINT` | NULLABLE, FK → `cohort(id)` | NULL for BRM/CSAT rows |

**DDL (separate migration from cohort table):**

```sql
ALTER TABLE preprocessed_survey
    ADD COLUMN cohort_id BIGINT NULL,
    ADD CONSTRAINT fk_ps_cohort FOREIGN KEY (cohort_id) REFERENCES cohort(id);
```

---

## 4. SurveyBody NPS Config Fields

`SurveyBody` is the Java DTO that maps to the JSON stored in `Survey.survey`. Five new typed fields are added for NPS configuration. These fields are read by the sampling job and eligibility gate; they are **never serialised into the client-facing check-in response** (see `CheckInSurveyItem` in the sampling spec).

| Field | Java Type | JSON key | Default | Purpose |
|---|---|---|---|---|
| `weeklyInvitationCap` | `int` | `weeklyInvitationCap` | `0` (required) | Maximum invitations per ISO week for this survey. Enforced by `NpsWeeklySamplePreparationJob`. |
| `reminderMinIntervalHours` | `int` | `reminderMinIntervalHours` | `24` | Minimum hours between the initial dismiss and the reminder. |
| `coolOffDays` | `int` | `coolOffDays` | `90` | Global NPS cool-off in days, measured from `last_nps_triggered_date`. |
| `yearlyTriggerCap` | `int` | `yearlyTriggerCap` | `2` | Maximum number of NPS triggers per calendar year per user. |
| `q2CopyByBand` | `Q2CopyByBand` | `q2CopyByBand` | `{}` | Nested object with `detractor`, `passive`, `promoter` string fields for band-specific Q2 copy. |

The `Q2CopyByBand` nested type:

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public static class Q2CopyByBand {
    private String detractor;  // "Tell us what we can improve…"
    private String passive;    // "What would make your experience a 10?"
    private String promoter;   // "What do you love most about Moniepoint?"
}
```

**Validation rules (applied in service layer, not DB):**
- `weeklyInvitationCap > 0` — required for NPS surveys; zero is treated as misconfiguration and prevents sampling.
- `coolOffDays >= 1`
- `yearlyTriggerCap >= 1`
- `reminderMinIntervalHours >= 1`

---

## 5. CohortEligibilityGate Component Design

### 5.1 Interface

```java
package com.moniepoint.loans.cas.module.analytics.nps.service;

/**
 * Evaluates whether a user's attributes satisfy the eligibility gates for a given cohort.
 *
 * <p>This gate is called exclusively from the weekly sampling job
 * ({@code NpsWeeklySamplePreparationJob}). It is not part of the SpEL pipeline
 * and must not be called from {@code RuleParserHandler} or any event-driven path.
 *
 * <p>Both gates must pass for the user to be eligible:
 * <ul>
 *   <li>Gate 1 — Account age: user's onboarding date is at least {@code cohort.minAccountAgeDays} days ago.</li>
 *   <li>Gate 2 — Recent transaction (optional): if {@code cohort.requireRecentTransaction} is true,
 *       the user's last transaction date is within the last {@code cohort.transactionWindowDays} days.</li>
 * </ul>
 */
public interface CohortEligibilityGate {

    /**
     * @param cohort         the target cohort definition
     * @param userAttributes attributes sourced from Bigtable for this user
     * @param today          the reference date for all gate evaluations (injected for testability)
     * @return {@code true} if the user passes all eligibility gates for this cohort
     */
    boolean evaluate(Cohort cohort, UserAttributes userAttributes, LocalDate today);
}
```

### 5.2 Evaluation algorithm

```
evaluate(cohort, userAttributes, today):

  // Gate 1: Account age
  if userAttributes.onboardingDate == null → return false
  onboardingDate = LocalDate from userAttributes.onboardingDate
  if onboardingDate > today − cohort.minAccountAgeDays → return false

  // Gate 2: Recent transaction (skipped when cohort does not require it)
  if cohort.requireRecentTransaction:
    if userAttributes.lastTxnDate == null → return false
    if userAttributes.lastTxnDate < today − cohort.transactionWindowDays → return false

  return true
```

**Note on `UserAttributes.onboardingDate`:** The field is typed `LocalDateTime` in the current `UserAttributes` class (see `src/main/java/.../dto/v3/UserAttributes.java:74`). Gate 1 uses `onboardingDate.toLocalDate()` to convert before comparison. If `onboardingDate` is non-null but represents a time in the future (data quality issue from Bigtable), Gate 1 will correctly return false.

### 5.3 Edge cases

| Scenario | Outcome | Reason |
|---|---|---|
| `userAttributes.onboardingDate == null` | `false` | Cannot determine account age — exclude conservatively |
| `onboardingDate` is in the future | `false` | `onboardingDate.toLocalDate() > today - minAccountAgeDays` fails Gate 1 |
| `cohort.requireRecentTransaction == false` | Gate 2 skipped entirely | Boolean flag design allows cohorts with no transaction requirement (e.g., new-user cohorts) |
| `userAttributes.lastTxnDate == null` AND `cohort.requireRecentTransaction == true` | `false` | No transaction date → cannot confirm recency requirement |
| `userAttributes.lastTxnDate == today` | `true` for Gate 2 | Same-day transaction satisfies `>= today - windowDays` |
| `cohort.transactionWindowDays == 0` AND `requireRecentTransaction == true` | `true` for Gate 2 (only if `lastTxnDate == today`) | Degenerate case: any transaction today qualifies. Not a valid production config — `transactionWindowDays` must be >= 1 (enforced at cohort seed time). |

### 5.4 Implementation class

```java
@Slf4j
@Component
@RequiredArgsConstructor
public class CohortEligibilityGateImpl implements CohortEligibilityGate {

    @Override
    public boolean evaluate(Cohort cohort, UserAttributes userAttributes, LocalDate today) {
        // Gate 1: Account age
        if (userAttributes.getOnboardingDate() == null) {
            log.debug("Cohort eligibility gate 1 failed: onboardingDate is null for cohort={}", cohort.getName());
            return false;
        }
        LocalDate onboardingDate = userAttributes.getOnboardingDate().toLocalDate();
        LocalDate minOnboardingDate = today.minusDays(cohort.getMinAccountAgeDays());
        if (onboardingDate.isAfter(minOnboardingDate)) {
            log.debug("Cohort eligibility gate 1 failed: onboardingDate={} is after minRequired={}",
                    onboardingDate, minOnboardingDate);
            return false;
        }

        // Gate 2: Recent transaction
        if (cohort.isRequireRecentTransaction()) {
            if (userAttributes.getLastTxnDate() == null) {
                log.debug("Cohort eligibility gate 2 failed: lastTxnDate is null for cohort={}", cohort.getName());
                return false;
            }
            LocalDate earliestAcceptableTxnDate = today.minusDays(cohort.getTransactionWindowDays());
            if (userAttributes.getLastTxnDate().isBefore(earliestAcceptableTxnDate)) {
                log.debug("Cohort eligibility gate 2 failed: lastTxnDate={} is before window start={}",
                        userAttributes.getLastTxnDate(), earliestAcceptableTxnDate);
                return false;
            }
        }

        return true;
    }
}
```

---

## 6. Sequence Diagram: Weekly Sampling Job → CohortEligibilityGate

```
NpsWeeklySamplePreparationJob          CohortStorage        UserAttributesStorage     CohortEligibilityGate      NpsWeeklySampleStorage
           |                                |                        |                         |                         |
  [Mon 00:05 Africa/Lagos]                 |                        |                         |                         |
           |-- findActiveCohorts() -------->|                        |                         |                         |
           |<-- List<Cohort> --------------|                        |                         |                         |
           |                                |                        |                         |                         |
           |  for each cohort:              |                        |                         |                         |
           |    paginate users              |                        |                         |                         |
           |      for each user page:       |                        |                         |                         |
           |-- findUserPage(page, size) ----|----------------------->|                         |                         |
           |<-- List<UserAttributes> -------|------------------------|                         |                         |
           |                                |                        |                         |                         |
           |  for each user in page:        |                        |                         |                         |
           |-- evaluate(cohort, user, today)|----------------------------------->|              |                         |
           |                                |                        |           |              |                         |
           |                                |                        | [Gate 1]  |              |                         |
           |                                |                        | onboarding|              |                         |
           |                                |                        | date check|              |                         |
           |                                |                        |           |              |                         |
           |                                |                        | [Gate 2]  |              |                         |
           |                                |                        | lastTxn   |              |                         |
           |                                |                        | date check|              |                         |
           |                                |                        |           |              |                         |
           |<-- true / false ----------------------------------------|              |                         |
           |                                |                        |                         |                         |
           |  [if true AND not in cool-off AND weekly cap not reached]                         |                         |
           |-- insertSample(userId, cohortId, isoWeek, PENDING) -----|------------------------->                        |
           |<-- NpsWeeklySample ------------------------------------- |-------------------------                        |
           |                                |                        |                         |                         |
           |  [end page loop]               |                        |                         |                         |
           |  [end user loop]               |                        |                         |                         |
           |  [end cohort loop]             |                        |                         |                         |
```

---

## 7. Forward-Looking: From Static Columns to Dynamic Rule-Based Cohorts

### 7.1 Current state (Phase 1)

The Phase 1 `Cohort` entity uses **static columns** to express eligibility gates: `min_account_age_days`, `require_recent_transaction`, `transaction_window_days`. The gates are hardcoded in `CohortEligibilityGateImpl`. Adding a new type of gate (e.g., KYC level, city, monthly transaction volume) requires a schema migration and a code change.

This is intentional: Phase 1 has exactly two cohorts with identical gate shapes (Personal Banking and Business Banking NPS, both requiring account age + recent transaction). Over-engineering a rule engine for two rows would be premature.

### 7.2 Evolution path: dynamic rule_definition column

When the PM or product team asks for cohorts defined by arbitrary attribute combinations — without code changes — the path is:

1. **Add `rule_definition JSON NULL` column** to the `cohort` table. Existing rows have `NULL`, which means "use static columns (legacy mode)".
2. **Build `CohortRuleEngine`** — a SpEL-based evaluator that reads the JSON rule tree, binds `UserAttributes` as the evaluation context, and returns true/false. The engine is structurally identical to the existing `RuleParserHandler` but operates on `UserAttributes` directly (no Kafka event context needed).
3. **Update `CohortEligibilityGate`** — when `cohort.ruleDefinition != null`, delegate to `CohortRuleEngine`; otherwise fall back to static column evaluation. The fallback ensures zero migration cost for existing cohorts.

### 7.3 How industry segmentation tools solve this problem

**customer.io:** Attribute-based JSON rule sets ("condition trees") evaluated against the user's profile at send time. Rules are composed of conditions (`field`, `operator`, `value`) combined with `AND`/`OR` operators. New segments are created in the UI without any code deployment.

**Braze:** "Segments" are computed membership tables refreshed by periodic batch jobs. Segment rules are defined in a UI-driven query builder; the platform runs SQL-like queries against the user attribute store and caches the results as inclusion/exclusion lists.

**Mixpanel:** "Cohorts" are similarly query-based, with the platform evaluating event-property and user-property predicates on demand.

**CAS direction:** The `rule_definition JSON` column + `CohortRuleEngine` (SpEL) maps closest to the customer.io model — the rule tree is stored as data, evaluated in-process. This avoids an external segmentation dependency and keeps eligibility evaluation inside the same transactional boundary as the sampling job. Static columns are **fully forward-compatible**: they coexist with the `rule_definition` column. A future migration can populate `rule_definition` from existing static-column values and then deprecate the old columns — or leave both coexisting indefinitely (the gate checks `rule_definition != null` to decide which path runs).

---

## 8. cohort_id Flow: Sampling Job → PreprocessedSurvey

The `cohort_id` value originates in `NpsWeeklySamplePreparationJob` and flows through four hand-off points before landing in `PreprocessedSurvey.cohortId`.

### 8.1 Hand-off 1: NpsWeeklySample row

When the sampling job inserts a user into `nps_weekly_sample`, it stores `cohort_id` on the row:

```
nps_weekly_sample: { userId, cohortId, surveyId, isoWeek, status=PENDING, ... }
```

### 8.2 Hand-off 2: EventPreprocessSurveyDTO

When the check-in API's `NpsEligibilityResolver` serves the user their NPS survey, it reads the `nps_weekly_sample` row (which carries `cohortId`) and constructs an `EventPreprocessSurveyDTO`. The DTO gains a `cohortId` field:

```java
// EventPreprocessSurveyDTO — new field
private Long cohortId;   // null for BRM/CSAT
```

The DTO is published to the `event-survey-preprocessor` Kafka topic with `cohortId` populated.

### 8.3 Hand-off 3: SurveyPreprocessorListener

`SurveyPreprocessorListener.preprocessSurvey()` already constructs the `PreprocessedSurvey` entity from the DTO before saving. It reads `eventPreprocessSurveyDTO.getCohortId()` and sets `preprocessedSurvey.setCohortId(...)`:

```java
preprocessedSurvey.setCohortId(eventPreprocessSurveyDTO.getCohortId()); // null-safe
```

For BRM/CSAT DTOs where `cohortId` is null, the field remains null — no branch logic required.

### 8.4 Hand-off 4: PreprocessedSurvey.cohort_id

`PreprocessedSurvey` gains the new nullable column:

```java
@Column(name = "cohort_id")
private Long cohortId;
```

The value is readable from any analytics or intelligence query that needs to correlate a survey instance back to its cohort definition.

### 8.5 Data flow diagram

```
NpsWeeklySamplePreparationJob
  inserts nps_weekly_sample { userId, cohortId, surveyId, isoWeek, PENDING }
                   |
                   | (at check-in time)
                   v
NpsEligibilityResolver
  reads nps_weekly_sample → constructs EventPreprocessSurveyDTO { ..., cohortId }
  publishes to Kafka topic: event-survey-preprocessor
                   |
                   v
SurveyPreprocessorListener
  consumes EventPreprocessSurveyDTO
  sets preprocessedSurvey.cohortId = dto.cohortId
  saves PreprocessedSurvey { ..., cohort_id = <cohortId> }
                   |
                   v
PreprocessedSurvey row in MySQL
  cohort_id = <cohortId>  (populated for NPS; NULL for BRM/CSAT)
```
