# NPS Cool-Off Enforcement — Domain Design

> **Status:** Draft — 2026-05-19
> **Relates to:** `impl-specs/2026-05-19-nps-cool-off.md`
> **PRD:** [NPS PRD v1.0 — teamapt PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD)
> **ADRs:** `adrs/ADR-009-nps-cool-off-storage.md`, `adrs/ADR-010-nps-annual-cap-enforcement.md`
> **Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)

---

## 1. Overview

### 1.1 What cool-off is and why it matters

The NPS Cool-Off mechanism prevents survey fatigue by enforcing two independent rate limits on every user:

1. **90-day global cool-off.** A user who has been triggered for NPS cannot be triggered again for at least 90 calendar days from the date of the last trigger. "Triggered" means the survey was served — regardless of whether the user responded, dismissed, or abandoned it. The clock starts at trigger, not at response (PRD §10, AC-05.1).

2. **Annual trigger cap (max 2 per calendar year).** Even if 90 days have elapsed, a user who has already been triggered twice in the current calendar year is excluded from sampling for the remainder of that year (PRD §10, AC-12.5).

Both limits are evaluated together during the weekly sample preparation job. A user must pass both checks to be eligible for sampling.

Cool-off is **global across all NPS measurements** (PRD §10, AC-05.6). A user cannot be in two simultaneous NPS measurements in the same sampling window, and a recent trigger from any NPS measurement blocks the user from all other NPS measurements during the cool-off period.

### 1.2 Scope of this document

This document covers:

- The `NpsUserState` aggregate: schema, invariants, and lifecycle
- The cool-off gate evaluation algorithm (checked at week start)
- The trigger write algorithm (called at serve time from Sampling Spec 2)
- Year rollover logic and edge cases
- Concurrency analysis (concurrent check-in calls, optimistic locking behaviour)
- Relationship to existing `RuleParserHandler.userEligibleFromSurveyHistory()`
- CSAT forward-compatibility pattern

This document does NOT cover:

- The weekly sampling job (`NpsWeeklySamplePreparationJob`) — see `docs/design/nps-sampling-programme-design.md`
- The check-in API surface — see `docs/design/nps-checkin-api-design.md`
- Response classification writes — that is covered in the response capture spec

---

## 2. Domain Model

### 2.1 The `NpsUserState` Aggregate

`NpsUserState` is an aggregate root with a one-to-one relationship with every user who has ever been triggered for NPS. It is the single source of truth for:

- When the user was last triggered (cool-off clock)
- How many times the user has been triggered in the current calendar year (annual cap)
- What the user's last NPS classification was (informational; used for response intelligence, not for eligibility)

A row is created on the user's first NPS trigger. Before the first trigger, `NpsUserStateService.isInCoolOff()` treats a missing row as "not in cool-off" — first-time users are always eligible (subject to other gates such as account age and transaction count).

```
NpsUserState (one row per user who has ever been triggered)
│
├── userId                           → FK to Bigtable user identity; UNIQUE constraint
├── lastNpsTriggeredDate             → DATE; null before first trigger
├── lastNpsResponseClassification    → ENUM; null until first response classified
├── triggerYear                      → SMALLINT; null before first trigger
├── triggerCountYear                 → SMALLINT NOT NULL DEFAULT 0
│
└── (from BaseEntity)
    ├── id, version (@Version), createdBy, createdOn, lastModifiedBy, lastModifiedOn
```

**Invariants enforced by the domain:**

| # | Invariant | Enforcement |
|---|---|---|
| I-1 | `triggerCountYear` never exceeds 2 for the current calendar year | Application code in `writeTriggered()`; gate check in `isInCoolOff()` |
| I-2 | `lastNpsTriggeredDate` is never set at response time — only at trigger time | Service method boundary: `writeTriggered()` is called only from the serve path |
| I-3 | Only one row exists per `userId` | `UNIQUE INDEX` on `user_id` column + upsert pattern |
| I-4 | Concurrent double-trigger cannot both commit | `@Version` optimistic locking on `BaseEntity.version` |

### 2.2 Database Schema

#### Table: `nps_user_state`

```sql
CREATE TABLE nps_user_state (
    id                              BIGINT          NOT NULL AUTO_INCREMENT,
    user_id                         VARCHAR(50)     NOT NULL,
    last_nps_triggered_date         DATE            NULL,
    last_nps_response_classification ENUM(
                                        'PROMOTER',
                                        'PASSIVE',
                                        'DETRACTOR'
                                    )               NULL,
    trigger_year                    SMALLINT        NULL,
    trigger_count_year              SMALLINT        NOT NULL DEFAULT 0,
    version                         INTEGER         NOT NULL DEFAULT 0,
    created_by                      VARCHAR(100)    NULL,
    created_on                      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by                VARCHAR(100)    NULL,
    last_modified_on                TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    CONSTRAINT uq_nps_user_state_user_id UNIQUE (user_id)
);
```

**Column notes:**

| Column | Type | Nullable | Notes |
|---|---|---|---|
| `id` | `BIGINT` | No | Surrogate PK from `BaseEntity` |
| `user_id` | `VARCHAR(50)` | No | Platform user identifier; UNIQUE |
| `last_nps_triggered_date` | `DATE` | Yes | Null before first trigger. Written atomically with `nps_weekly_sample.status=SERVED`. Date only (no time) — cool-off window is always in whole calendar days |
| `last_nps_response_classification` | `ENUM` | Yes | Null until first survey completed and classified. Not an eligibility field |
| `trigger_year` | `SMALLINT` | Yes | Calendar year of the most recent trigger. Null before first trigger. Used with `trigger_count_year` to enforce the annual cap and detect year rollovers |
| `trigger_count_year` | `SMALLINT NOT NULL DEFAULT 0` | No | Number of times user was triggered in `trigger_year`. Resets to 1 when `trigger_year` flips |
| `version` | `INTEGER NOT NULL DEFAULT 0` | No | `@Version` for optimistic concurrency. Incremented by Hibernate on every update |

**Indexes:**

| Name | Columns | Type | Purpose |
|---|---|---|---|
| `PRIMARY` | `id` | Primary | Surrogate PK |
| `uq_nps_user_state_user_id` | `user_id` | Unique | One row per user; fast lookup by userId |

**No additional indexes are needed.** The only access pattern against this table is a point-read by `user_id` (single-row lookup during sampling and serve). There are no range scans or JOIN operations on this table.

---

## 3. Cool-Off Gate Evaluation Algorithm

The gate is evaluated by `NpsUserStateService.isInCoolOff(userId, coolOffDays, yearlyTriggerCap)`. The sampling job calls this for every candidate user before adding them to the weekly sample.

### 3.1 Pseudocode

```
function isInCoolOff(userId, coolOffDays, yearlyTriggerCap) → boolean

    state ← NpsUserStateStorage.findByUserId(userId)

    // No row → user has never been triggered → not in cool-off
    if state is null:
        return false

    today ← LocalDate.now()
    currentYear ← today.year

    // Cool-off window check
    if state.lastNpsTriggeredDate is not null:
        daysSinceLastTrigger ← DAYS.between(state.lastNpsTriggeredDate, today)
        if daysSinceLastTrigger < coolOffDays:
            return true    // inside cool-off window

    // Annual cap check
    if state.triggerYear == currentYear AND state.triggerCountYear >= yearlyTriggerCap:
        return true        // annual cap exhausted

    return false           // eligible
```

### 3.2 Step-by-step explanation

**Step 1 — Row lookup.** The service performs a single point-read on `nps_user_state` by `user_id`. If no row exists, the user has never been triggered and is automatically eligible. This is the hot path for newly onboarded users.

**Step 2 — Cool-off window.** If `last_nps_triggered_date` is set, compute the elapsed days between that date and today. If fewer than `coolOffDays` (default 90) have elapsed, the user is in the cool-off window and is excluded.

- The comparison is `daysSinceLastTrigger < coolOffDays`, which means a user triggered exactly 90 days ago is considered outside the window and is eligible. "Fewer than 90 days" = in cool-off; "exactly 90 or more" = eligible.
- The date arithmetic uses `java.time.temporal.ChronoUnit.DAYS.between(lastTriggeredDate, today)`, which computes whole calendar days.

**Step 3 — Annual cap.** Independently of the cool-off window, if the user's `trigger_year` equals the current calendar year AND their `trigger_count_year` has reached or exceeded `yearlyTriggerCap` (default 2), the user is excluded even if the 90-day window has elapsed.

**Step 4 — Eligible.** If neither gate matched, return `false` — the user is eligible for the current week's sample.

### 3.3 Gate evaluation order

The cool-off window check (Step 2) runs before the annual cap check (Step 3). In practice both checks are O(1) reads from an already-fetched row, so order has no performance implication. The ordering is chosen for semantic clarity: temporal cool-off is the primary gate; the annual cap is an additional ceiling.

### 3.4 Configuration

Both `coolOffDays` and `yearlyTriggerCap` are passed as parameters at call time, sourced from the `SurveyBody` NPS config fields added in Sampling Spec chunk 01:

```java
int coolOffDays     = surveyBody.getCoolOffDays();        // default 90
int yearlyTriggerCap = surveyBody.getYearlyTriggerCap();  // default 2
```

This means the cool-off period and the annual cap are operator-configurable without a code change. Changing these values affects the next week's sampling run (the values are read fresh at job execution time).

---

## 4. Year Rollover Algorithm

### 4.1 Pseudocode

```
function writeTriggered(userId) → NpsUserState

    state ← NpsUserStateStorage.findByUserId(userId)
    today ← LocalDate.now()
    currentYear ← today.year

    if state is null:
        // First-ever trigger for this user
        state ← new NpsUserState()
        state.userId ← userId

    state.lastNpsTriggeredDate ← today

    if state.triggerYear != currentYear:
        // Year has rolled over — reset annual count
        state.triggerYear ← currentYear
        state.triggerCountYear ← 1
    else:
        // Same year — increment
        state.triggerCountYear ← state.triggerCountYear + 1

    try:
        return NpsUserStateStorage.save(state)   // @Version guard fires here
    catch OptimisticLockException:
        // Concurrent serve — re-read and return already-committed state
        return NpsUserStateStorage.findByUserId(userId)
```

### 4.2 Explanation

**New user path.** When no row exists (`state is null`), a new `NpsUserState` is constructed with `userId`. The `@Version` field starts at 0. `lastNpsTriggeredDate` is set to today. Since `triggerYear` is null (not equal to `currentYear`), the code takes the "year has rolled over" branch: sets `triggerYear = currentYear` and `triggerCountYear = 1`. The row is inserted with an INSERT statement.

**Returning user — same year.** If `triggerYear == currentYear`, the count increments. After two triggers in the same year, `triggerCountYear` becomes 2. The next `isInCoolOff()` call in a future sampling run will hit the annual cap gate.

**Returning user — year rollover.** If `triggerYear != currentYear` (including null), the count resets. This handles the case where a user was last triggered in a prior year and is now being triggered in a new year. Their slate is clean for the new year.

### 4.3 Edge case analysis

| Edge case | What happens | Why this is correct |
|---|---|---|
| User triggered Dec 31 2026, then sampled Jan 2 2027 | `trigger_year` flips from 2026 to 2027; `trigger_count_year` resets to 1 | The user had 1 trigger in 2026 and gets 1 in 2027. They still have budget for a second trigger in 2027. |
| User triggered twice in 2026. Sampled Jan 15 2027 after 90 days | `trigger_year` becomes 2027; `trigger_count_year` = 1 | Year rollover resets the cap. The 2026 count is not carried over. |
| User triggered Jan 1 2026, then Jan 1 2027 (exactly 365 days) | If `coolOffDays = 90`, 365 ≥ 90. Annual cap resets. Eligible. | Both gates pass correctly. |
| User has `trigger_year = null` (state row exists but never had a trigger year set — defensive case) | `null != currentYear` evaluates to `true`; year rollover branch taken; `triggerCountYear` resets to 1 | Handles any pre-existing rows that were created before `trigger_year` was introduced |
| Server time zone is UTC; user is in Africa/Lagos (UTC+1) | `LocalDate.now()` uses the JVM default zone. CAS JVM is configured to Africa/Lagos. Week start and trigger dates are computed in Africa/Lagos time | Consistent with the ISO week boundary logic in the sampling job (both use Africa/Lagos `LocalDate.now()`) |

---

## 5. Trigger Write Algorithm with Optimistic Locking

### 5.1 Why optimistic locking matters here

A user may be checking in from two devices simultaneously (e.g. mobile app and web browser, both open at the same time). Without concurrency control, both check-in calls could:

1. Both read the same `NpsWeeklySample` row with `status=PENDING`
2. Both proceed to serve the survey
3. Both write `nps_user_state.last_nps_triggered_date = today`
4. Both increment `trigger_count_year`

This would produce two trigger events for a single user in a single week, consuming two of their annual budget slots and potentially causing duplicate NPS surveys to appear on both devices.

The `@Version` field on `BaseEntity` prevents this. Only the first concurrent write succeeds. The second receives an `OptimisticLockException` from Hibernate, which the service layer catches and resolves to the already-served state.

### 5.2 The atomic write

The trigger write (`writeTriggered(userId)`) is called from the check-in serve path in Sampling Spec 2, chunk 05. It is wrapped in the **same `@Transactional` boundary** as the `nps_weekly_sample.status = SERVED` update. Both writes succeed or both roll back together.

```
Transaction T1 (serve path):
  1. UPDATE nps_weekly_sample SET status='SERVED' WHERE id=? AND version=?
  2. UPSERT nps_user_state (writeTriggered) — last_nps_triggered_date = today, trigger_count_year++
  3. COMMIT  →  both writes visible atomically
```

### 5.3 Concurrent double-serve sequence

```
Thread A                               Thread B
────────────────────────────────────   ────────────────────────────────────
read nps_user_state (version=5)        read nps_user_state (version=5)
serve nps_weekly_sample (PENDING→SERVED)
UPDATE nps_user_state                  serve nps_weekly_sample → fails
  WHERE version=5                         (already SERVED → no-op or guarded)
  SET version=6, count=1 → OK
COMMIT                                 
                                       UPDATE nps_user_state
                                         WHERE version=5
                                         → OptimisticLockException
                                       CATCH OptimisticLockException
                                       re-read nps_user_state (version=6)
                                       return already-served state → OK
```

Thread B's `OptimisticLockException` is caught at the service boundary. The service re-reads the row by `userId` and returns the current (already-committed) state. No error is propagated to the caller. The check-in response for Thread B returns the already-served NPS payload (idempotent).

**Thread A** increments `trigger_count_year` once.
**Thread B** does not increment. The annual budget is consumed exactly once.

---

## 6. Sequence Diagrams

### 6.1 Cool-off check at week start (sampling job)

```
NpsWeeklySamplePreparationJob          NpsUserStateService        NpsUserStateStorage
        │                                      │                          │
        │  for each candidate userId:          │                          │
        │──isInCoolOff(userId,90,2)───────────►│                          │
        │                                      │──findByUserId(userId)───►│
        │                                      │◄── NpsUserState (or null)│
        │                                      │                          │
        │                                      │  [if null]:              │
        │                                      │    return false ─────────┤
        │                                      │                          │
        │                                      │  [if daysSinceTrigger    │
        │                                      │   < coolOffDays]:        │
        │                                      │    return true ──────────┤
        │                                      │                          │
        │                                      │  [if triggerYear==year   │
        │                                      │   AND count >= cap]:     │
        │                                      │    return true ──────────┤
        │                                      │                          │
        │                                      │  [else]:                 │
        │◄─ boolean (inCoolOff) ───────────────│    return false          │
        │                                      │                          │
        │  [if inCoolOff == false]:            │                          │
        │    add userId to candidate pool      │                          │
        │  [if inCoolOff == true]:             │                          │
        │    skip userId                       │                          │
```

The sampling job iterates candidates in batches (batch size configurable, default 1,000). For each batch, `isInCoolOff()` is called per user. The service performs a point-read by `userId` for each call; the `UNIQUE INDEX` on `user_id` makes this O(1) per lookup.

### 6.2 Trigger write at serve time

```
CheckInService        NpsUserStateService      NpsUserStateStorage    MySQL
(Sampling Spec 2)             │                        │                │
       │                      │                        │                │
       │  BEGIN TRANSACTION   │                        │                │
       │                      │                        │                │
       │  [update nps_weekly_sample status=SERVED]     │                │
       │───────────────────────────────────────────────────────────────►│
       │◄──────────────────── OK ──────────────────────────────────────│
       │                      │                        │                │
       │──writeTriggered(uid)─►│                        │                │
       │                      │──findByUserId(uid)─────►│               │
       │                      │◄── NpsUserState/null    │               │
       │                      │                        │                │
       │                      │  [compute new state]   │                │
       │                      │  lastTriggeredDate=today                │
       │                      │  year rollover / increment              │
       │                      │                        │                │
       │                      │──save(state)───────────►│               │
       │                      │                        │──UPDATE/INSERT►│
       │                      │                        │  WHERE version=N│
       │                      │                        │◄── OK (v=N+1)  │
       │◄─ NpsUserState ──────│                        │                │
       │                      │                        │                │
       │  COMMIT TRANSACTION  │                        │                │
       │───────────────────────────────────────────────────────────────►│
       │                      │                        │                │
       │                      │         [on OptimisticLockException]    │
       │                      │──findByUserId(uid)─────►│               │
       │                      │◄── current state        │               │
       │◄─ NpsUserState ──────│                        │                │
       │  (already-served)    │                        │                │
```

---

## 7. Concurrency Analysis

### 7.1 Scenario: two concurrent check-in calls for the same user

**Setup:** User U logs in on mobile (Thread A) and on web (Thread B) at nearly the same time. Both clients call the check-in API within milliseconds. Both see `nps_weekly_sample(U, W21, PENDING)` at the start of their transactions.

**What happens:**

1. Thread A reads `nps_user_state` with `version=5`.
2. Thread B reads `nps_user_state` with `version=5`.
3. Thread A updates `nps_weekly_sample` to `SERVED` and updates `nps_user_state` with `version=5 → 6`. `trigger_count_year` becomes 1. COMMIT succeeds.
4. Thread B attempts to update `nps_weekly_sample`. Depending on the `nps_weekly_sample` locking strategy (governed by Sampling Spec 2), this may fail first — but even if it proceeds, Thread B's update of `nps_user_state` with `WHERE version=5` will fail because the row now has `version=6`. Hibernate throws `OptimisticLockException`.
5. The `NpsUserStateService.writeTriggered()` catch block re-reads `nps_user_state` and returns the already-committed row.
6. The check-in service treats this as an idempotent already-served result and returns the NPS survey payload to Thread B's caller as if the serve had just succeeded.

**Outcome:**
- NPS survey appears on both devices (or only on mobile, depending on client-side de-duplication — that is a client concern).
- `trigger_count_year` is incremented exactly once.
- No duplicate trigger record.
- No error returned to either caller.

### 7.2 Why no retry loop

The service does NOT retry the failed write. Retrying after `OptimisticLockException` would re-attempt the increment, which is semantically wrong — the user has already been triggered. The correct response is to return the already-served state as-is.

### 7.3 Single-device rapid double-tap

If a single device sends two near-simultaneous requests (e.g. a network retry within the same session), the same `OptimisticLockException` pattern applies. The second request receives the already-served response — it does not trigger a second survey.

---

## 8. Cool-Off Scope

The 90-day cool-off and the annual trigger cap are both **global across all NPS measurements**. There is one `nps_user_state` row per user, shared across all active NPS measurements (`NpsMeasurement` rows).

**What this means in practice:**

- If a user is in the Personal Banking NPS cohort and the Business Banking NPS cohort simultaneously, a trigger from either measurement updates the shared `nps_user_state` row and blocks the user from the other measurement for 90 days.
- This is intentional (PRD AC-05.6): the goal is to prevent overall NPS fatigue, not just fatigue within a single measurement.
- The sampling job's cool-off check uses `NpsUserStateService.isInCoolOff()` which reads the single global row — it does not filter by measurement.

**What cool-off is NOT:**

- Not per-cohort (same user in two cohorts → one cool-off)
- Not per-measurement (same user in two measurements → one cool-off)
- Not per-platform (user who checks in on mobile AND web is protected by the same cool-off — the mobile trigger blocks the web measurement from sampling them for 90 days)

---

## 9. Relationship to `RuleParserHandler.userEligibleFromSurveyHistory()`

The existing `RuleParserHandler` (SpEL-based eligibility evaluator for BRM surveys) includes a method `userEligibleFromSurveyHistory()` that acts as a **general rate limiter** for surveys. It checks:

1. No pending (unserved) surveys exist for the user
2. The total number of surveys served in a global window does not exceed a configurable cap

This is **not a cool-off mechanism**. It is a concurrency and saturation guard — it prevents a user from being served multiple active surveys simultaneously and from being flooded with surveys if the scheduling logic misfires.

**NPS bypasses this entirely** — and this is correct behaviour, not a gap.

NPS `PreprocessedSurvey` rows are created by the weekly sampling job (`NpsWeeklySamplePreparationJob`), not by `RuleParserHandler`. The sampling job writes `PreprocessedSurvey` rows directly. `RuleParserHandler` is invoked by the event-driven BRM pipeline (Kafka → `SurveyEvaluatorListener` → `RuleParserHandler`). This Kafka-driven path is not taken for NPS at all.

**No change to `RuleParserHandler` is needed for NPS cool-off.** The NPS cool-off enforcement is a new, dedicated concern owned by `NpsUserStateService`.

| Mechanism | Scope | Where enforced | Used by |
|---|---|---|---|
| `userEligibleFromSurveyHistory()` | General rate-limiting (pending survey count, global window cap) | `RuleParserHandler` | BRM event-driven surveys |
| `NpsUserStateService.isInCoolOff()` | NPS 90-day cool-off + annual cap | New service (this spec) | NPS weekly sampling job |

---

## 10. CSAT Forward-Compatibility

When CSAT cool-off is introduced (a future spec), it will mirror this exact pattern with its own table:

```sql
CREATE TABLE csat_user_state (
    id                                BIGINT      NOT NULL AUTO_INCREMENT,
    user_id                           VARCHAR(50) NOT NULL,
    last_csat_triggered_date          DATE        NULL,
    last_csat_response_classification ENUM(...)   NULL,
    trigger_year                      SMALLINT    NULL,
    trigger_count_year                SMALLINT    NOT NULL DEFAULT 0,
    version                           INTEGER     NOT NULL DEFAULT 0,
    ...
    CONSTRAINT uq_csat_user_state_user_id UNIQUE (user_id)
);
```

CSAT will have its own `CsatUserStateService` with its own `isInCoolOff()` and `writeTriggered()` methods. NPS and CSAT cool-off periods, annual caps, and classification enums are **independently configurable**.

The per-category state table pattern is established by this spec (ADR-009) and documented in `CLAUDE.md` as a Survey Domain Rule so future engineers follow it consistently for each new survey category.

**No shared `survey_user_state` table should be introduced** unless there are five or more active survey categories with the same cool-off semantics (see ADR-009 risk section).
