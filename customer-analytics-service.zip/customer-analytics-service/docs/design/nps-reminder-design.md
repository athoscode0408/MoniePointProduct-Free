# Design: NPS Reminder Logic

**Spec:** [`impl-specs/2026-05-19-nps-reminder.md`](../../impl-specs/2026-05-19-nps-reminder.md)
**ADRs:** [ADR-007 Reminder State Storage](../../adrs/ADR-007-nps-reminder-state-storage.md) · [ADR-008 Partial Completion Handling](../../adrs/ADR-008-nps-partial-completion.md)
**Depends on:** [NPS Sampling Design](nps-sampling-design.md) · [NPS Cohort Definition Design](nps-cohort-definition-design.md)
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)
**Date:** 2026-05-19
**PRD:** [NPS PRD v1.0 — teamapt PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) §9.1, §9.2

---

## 1. Overview

### 1.1 Purpose and PRD requirements

The NPS Reminder mechanism gives a user a second chance to complete the NPS survey after they have explicitly dismissed it (tapped "Ask Me Later" or the X button). The reminder is served passively — it is returned by the existing survey check-in endpoint the next time the user checks in, provided all eligibility conditions are met. There are no push notifications involved.

PRD §9.1 defines the reminder invariants:

- **Eligible on DISMISSED only.** A user who submitted Q1 (NPS rating) without submitting Q2 (follow-up text) is classified as ABANDONED, not DISMISSED. ABANDONED users are NOT eligible for a reminder. Only explicit dismissal qualifies.
- **Maximum one reminder per user per calendar week.** A reminder can be served at most once per `(user_id, cohort_id, iso_week)` tuple. After one reminder is served, no further reminders are issued for that week, regardless of what the user does next.
- **Minimum interval between dismiss and reminder.** The reminder is not shown immediately after dismissal. A configurable minimum number of hours (`SurveyBody.reminderMinIntervalHours`) must elapse before the reminder becomes eligible. This is evaluated at check-in time — the reminder fires on the first check-in on or after the configured interval.
- **Week-bounded.** Reminders never carry over to the next ISO week. If the configured interval has not elapsed before the week closes (Sunday 23:59 Africa/Lagos), no reminder is served and no carryover occurs.
- **Delivered via existing survey endpoint.** The reminder is not a push notification and not a new endpoint. It is the `PreprocessedSurvey` record already associated with the user's NPS sample for the week, returned by `GET /api/surveys/dashboard-info` or `GET /api/surveys/user` when reminder conditions are met.
- **No "type: REMINDER" flag in response.** The client receives the same survey payload as the initial serve. The distinction between a first serve and a reminder is internal to CAS — it is not surfaced to the client.

### 1.2 Single-reminder-per-week invariant

The invariant that at most one reminder is served per `(user_id, cohort_id, iso_week)` tuple is enforced by two complementary mechanisms:

1. **Condition check:** `NpsReminderEligibilityChecker` verifies `reminder_served_at IS NULL` before returning the reminder.
2. **Atomic write:** when the reminder is served, `reminder_served_at` is set to `NOW()` and `status` is transitioned to `REMINDER_SERVED` in the same `@Transactional` boundary as the survey endpoint returning the payload. An `OptimisticLockException` on concurrent check-in is caught and resolved to the already-served state (see §7).

---

## 2. `NpsWeeklySample` Reminder Columns

Two nullable columns are added to `nps_weekly_sample` to track reminder lifecycle. These are the only schema changes required by the reminder feature.

### 2.1 Column definitions

| Column | Type | Nullable | Set When | Cleared |
|---|---|---|---|---|
| `dismissed_at` | `TIMESTAMP` | Yes | Status transitions from SERVED → DISMISSED (user taps explicit dismiss) | Never — written once, immutable |
| `reminder_served_at` | `TIMESTAMP` | Yes | Status transitions from DISMISSED → REMINDER_SERVED (reminder returned to user) | Never — written once, immutable |

### 2.2 DDL specification

These columns are added via a DDL migration in the DB migrations repository:

```sql
ALTER TABLE nps_weekly_sample
    ADD COLUMN dismissed_at        TIMESTAMP NULL AFTER served_at,
    ADD COLUMN reminder_served_at  TIMESTAMP NULL AFTER dismissed_at;
```

Both additions are nullable with no default, ensuring full backward compatibility. Existing rows in any status (`PENDING`, `SERVED`, `RESPONDED`, `EXPIRED`, `ABANDONED`) have both columns as `NULL`, which is semantically correct — they were not dismissed, so they have no dismiss timestamp.

### 2.3 Full column set after migration

| Column | Type | Constraints |
|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT |
| `user_id` | `VARCHAR(50)` | NOT NULL |
| `cohort_id` | `BIGINT` | NOT NULL, FK → `cohort(id)` |
| `iso_week` | `CHAR(8)` | NOT NULL |
| `status` | `ENUM` | NOT NULL |
| `served_at` | `TIMESTAMP` | NULL |
| `dismissed_at` | `TIMESTAMP` | NULL — **new** |
| `reminder_served_at` | `TIMESTAMP` | NULL — **new** |
| `responded_at` | `TIMESTAMP` | NULL |
| `version` | `INT` | NOT NULL |
| `created_by`, `created_on`, `last_modified_by`, `last_modified_on` | — | From `BaseEntity` |

---

## 3. Full State Machine

The following ASCII diagram shows every valid status transition for `NpsWeeklySample`, incorporating the reminder path.

```
                    ┌─────────────────────────────┐
    Monday 00:05    │          PENDING              │
    sampling job    │  (created by preparation job) │
                    └──────────────┬────────────────┘
                                   │
                                   │  user checks in
                                   │  (atomic: status=SERVED, served_at=NOW,
                                   │   NpsUserState.writeTriggered())
                                   ▼
                    ┌──────────────────────────────┐
                    │            SERVED             │
                    └──────────────┬───────────────┘
                                   │
               ┌───────────────────┼──────────────────────┐
               │                   │                       │
               │ user taps         │ user submits          │ ISO week closes
               │ dismiss button    │ Q1 + Q2               │ (no action taken)
               ▼                   ▼                       ▼
    ┌──────────────────┐  ┌─────────────────┐   ┌─────────────────┐
    │    DISMISSED     │  │    RESPONDED    │   │    ABANDONED    │
    │  dismissed_at=NOW│  │  (terminal)     │   │  (terminal)     │
    └────────┬─────────┘  └─────────────────┘   └─────────────────┘
             │
             │  user checks in AND all 4 reminder
             │  conditions met (see §5):
             │  status=DISMISSED, interval elapsed,
             │  reminder_served_at IS NULL,
             │  still in same ISO week
             │  (atomic: status=REMINDER_SERVED,
             │   reminder_served_at=NOW)
             ▼
    ┌──────────────────────────────┐
    │        REMINDER_SERVED        │
    └──────────────┬───────────────┘
                   │
          ┌────────┴──────────┐
          │                   │
          │ user submits      │ ISO week closes
          │ score (Q1±Q2)     │ (no action taken)
          ▼                   ▼
    ┌──────────────┐  ┌───────────────┐
    │   RESPONDED  │  │   ABANDONED   │
    │  (terminal)  │  │  (terminal)   │
    └──────────────┘  └───────────────┘

                    ┌─────────────┐
    PENDING ────────►   EXPIRED   │ ◄── NpsWeeklyExpiredSampleJob
                    │  (terminal) │     (Sunday 23:59 Africa/Lagos)
                    └─────────────┘
                    (rows still PENDING at ISO week close → EXPIRED)
```

**Terminal states:** `RESPONDED`, `EXPIRED`, `ABANDONED`

**Status summary:**

| Status | Entered when | Reminder eligible | Notes |
|---|---|---|---|
| `PENDING` | Sampling job creates row | No | Survey preprocessed; awaiting check-in |
| `SERVED` | User checks in, PENDING → SERVED | No | Trigger written atomically to `NpsUserState` |
| `DISMISSED` | User taps explicit dismiss button | **Yes** (when conditions met) | `dismissed_at` set |
| `REMINDER_SERVED` | Reminder returned at check-in | No (already served once) | `reminder_served_at` set |
| `RESPONDED` | User submits Q1 (± Q2) | No (terminal) | `responded_at` set |
| `EXPIRED` | PENDING at ISO week close | No (terminal) | `NpsWeeklyExpiredSampleJob` |
| `ABANDONED` | SERVED or REMINDER_SERVED at ISO week close | No (terminal) | `NpsWeeklyExpiredSampleJob` second pass |

---

## 4. ABANDONED vs. DISMISSED

These two user behaviours are superficially similar — both result in the user leaving the survey without submitting a score — but they are semantically distinct and handled differently.

### 4.1 Comparison table

| Dimension | DISMISSED | ABANDONED |
|---|---|---|
| User action | Taps "Ask Me Later" or X button before answering any question | Submits Q1 (NPS rating), then exits without submitting Q2 (follow-up text) |
| NPS rating captured | No | **Yes** (Q1 was answered) |
| `NpsWeeklySample.status` | `DISMISSED` | `RESPONDED` |
| `PreprocessedSurvey.state` | `DISMISSED` | `ABANDONED` (preserved for analytics) |
| `dismissed_at` set | Yes | No |
| Reminder eligible | **Yes** | **No** |
| Cool-off applies | Yes (triggered at SERVED) | Yes (triggered at SERVED) |
| Affects analytics funnel | Counted as "dismissed" (no rating) | Counted as "partial completion" (Q1 answered, Q2 not) |

### 4.2 Why ABANDONED is NOT eligible for a reminder

PRD §9.1 explicitly states: "Reminder is eligible only after explicit dismissal. Partial completion (rating submitted, follow-up skipped) is treated as a completed interaction for the purposes of reminder eligibility."

The rationale is:

1. **Rating was captured.** CAS already received the NPS score from Q1. The user has contributed to the NPS metric. Re-prompting them would risk introducing anchoring bias on the qualitative Q2 follow-up — the user already knows their score.
2. **User intent was partial engagement, not deferral.** Dismissal signals "ask me later." Answering Q1 and leaving signals "I've engaged as much as I want to."
3. **Cool-off still applies.** The trigger was recorded at SERVED time. A partial response does not waive the cool-off clock.

### 4.3 NpsWeeklySample.status = RESPONDED for Q1-only submissions

A counter-intuitive design decision: when a user submits Q1 but not Q2, `NpsWeeklySample.status` is set to `RESPONDED`, not `ABANDONED`. The `ABANDONED` distinction is preserved at the `PreprocessedSurvey` level only.

**Why:** The `NpsWeeklySample.status` field models the sampling programme's perspective — "did this user engage enough for their trigger to count toward cool-off?" A Q1 submission counts. Using `RESPONDED` in the sample table prevents any downstream code from accidentally treating Q1-only submissions as reminder-eligible (which would require explicit `status = DISMISSED` check, not `status != RESPONDED`).

`PreprocessedSurvey.state = ABANDONED` is preserved at the survey-lifecycle level so downstream analytics (ClickHouse) can distinguish the Q1-answered-Q2-skipped funnel step from a full response.

### 4.4 Client contract for dismiss vs. Q1 submission

The client MUST emit distinct event types for these two user actions:

| User action | Client event type |
|---|---|
| User taps dismiss / "Ask Me Later" / X | `NPS_SURVEY_DISMISSED` (or equivalent dismiss event) |
| User submits Q1 (NPS score input confirmed) | `NPS_SURVEY_Q1_SUBMITTED` (or equivalent scoring event) |

The backend uses these events to determine which status transition to apply to `NpsWeeklySample`. If the client emits the same event for both actions, CAS cannot distinguish them and one of the two invariants — "reminder on dismiss" or "no reminder on Q1-only" — will be violated.

This is an acceptance criterion for the reminder feature. The mobile client team must confirm their event taxonomy before the reminder delivery path is enabled.

---

## 5. `NpsReminderEligibilityChecker` Component Design

### 5.1 Interface

```java
package com.moniepoint.loans.cas.module.analytics.nps.service;

/**
 * Evaluates whether a user is eligible to receive an NPS reminder at check-in.
 *
 * <p>All four conditions must be true for the reminder to be eligible. Conditions
 * are evaluated in short-circuit order, cheapest check first.
 *
 * <p>This component is called from the survey delivery path (SurveyService or
 * SurveyController extension) after the standard NOT_COMPLETED PreprocessedSurvey
 * lookup. It is invoked only when the user has a DISMISSED NpsWeeklySample row
 * for the current ISO week.
 */
public interface NpsReminderEligibilityChecker {

    /**
     * Returns {@code true} if the given NpsWeeklySample is eligible for a reminder
     * at the current instant.
     *
     * @param sample           the DISMISSED NpsWeeklySample for (userId, cohortId, currentIsoWeek)
     * @param reminderMinIntervalHours minimum hours between dismissal and reminder
     * @return true if all four reminder conditions are met; false otherwise
     */
    boolean isEligible(NpsWeeklySample sample, int reminderMinIntervalHours);
}
```

### 5.2 The four reminder conditions

All four conditions must be true simultaneously. A single false result short-circuits evaluation.

| # | Condition | Field checked | Notes |
|---|---|---|---|
| C-1 | Sample status is DISMISSED | `nps_weekly_sample.status = DISMISSED` | Explicit dismiss action; Q1 submission is NOT DISMISSED |
| C-2 | Still within the same ISO week | `IsoWeekUtil.forDate(LocalDate.now(), ZoneId.of("Africa/Lagos")) == nps_weekly_sample.iso_week` | Week-boundary enforcement; reminder never carries over to next week |
| C-3 | Minimum interval has elapsed | `NOW() - dismissed_at >= reminderMinIntervalHours * 60 minutes` | Evaluated in Africa/Lagos; `dismissed_at` not null when status = DISMISSED |
| C-4 | Reminder not already served | `nps_weekly_sample.reminder_served_at IS NULL` | Single-reminder-per-week invariant; atomic write on first serve prevents second serve |

### 5.3 Short-circuit evaluation order

The conditions are evaluated in cheapest-to-most-expensive order to minimise wasted work on the hot check-in path:

1. **C-1 (status check)** — in-memory check on the already-fetched `NpsWeeklySample` object. O(1), no I/O.
2. **C-2 (week check)** — `IsoWeekUtil.forDate(LocalDate.now(), ...)` is a pure computation. O(1), no I/O. If the week has rolled over, the check fails immediately and no further conditions are evaluated.
3. **C-3 (interval check)** — arithmetic on `dismissed_at` (already on the in-memory object). O(1), no I/O. Placed third because it is the most likely rejection for users who dismiss and check in again quickly (before the minimum interval).
4. **C-4 (reminder_served_at IS NULL)** — in-memory check on the already-fetched object. O(1), no I/O. Placed last because it is the least likely rejection in normal operation (a user who passes C-1–C-3 has almost certainly not been reminded yet — `reminder_served_at` being non-null is a race condition, not the normal path).

All four checks are performed on the in-memory `NpsWeeklySample` object fetched in the survey delivery path. No additional database queries are required for eligibility evaluation itself.

### 5.4 Implementation pseudocode

```java
@Component
@RequiredArgsConstructor
public class NpsReminderEligibilityCheckerImpl implements NpsReminderEligibilityChecker {

    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    @Override
    public boolean isEligible(NpsWeeklySample sample, int reminderMinIntervalHours) {

        // C-1: status must be DISMISSED (not SERVED, not REMINDER_SERVED, not RESPONDED)
        if (sample.getStatus() != NpsSampleStatus.DISMISSED) {
            return false;
        }

        // C-2: still within the same ISO week (week has not closed)
        String currentIsoWeek = IsoWeekUtil.current(LAGOS);
        if (!currentIsoWeek.equals(sample.getIsoWeek())) {
            return false;
        }

        // C-3: minimum interval between dismissal and reminder has elapsed
        Instant dismissedAt  = sample.getDismissedAt();
        long minutesElapsed  = Duration.between(dismissedAt, Instant.now()).toMinutes();
        long requiredMinutes = (long) reminderMinIntervalHours * 60;
        if (minutesElapsed < requiredMinutes) {
            return false;
        }

        // C-4: reminder has not already been served this week
        if (sample.getReminderServedAt() != null) {
            return false;
        }

        return true;
    }
}
```

---

## 6. Survey Delivery Extension

### 6.1 How the existing delivery path works

The existing endpoints `GET /api/surveys/dashboard-info` and `GET /api/surveys/user` return `PreprocessedSurvey` records in `NOT_COMPLETED` state for the calling user. The NPS sampling engine creates a `PreprocessedSurvey` at week start for each sampled user. When `SurveyService.getUserSurveys()` (or equivalent) runs the standard NOT_COMPLETED lookup, it finds the NPS survey and returns it.

After the initial serve (PENDING → SERVED), the `PreprocessedSurvey` record remains in the database. It is not deleted on dismissal. Its `state` transitions to `DISMISSED` when the user dismisses.

### 6.2 The extension

`SurveyService.getUserSurveys()` is extended with the following additional step, executed after the standard NOT_COMPLETED survey lookup:

```
Step 1 (existing): fetch all PreprocessedSurvey records with state = NOT_COMPLETED for userId
Step 2 (NEW):      fetch NpsWeeklySample for (userId, currentIsoWeek) where status = DISMISSED
                   if found AND NpsReminderEligibilityChecker.isEligible(sample, reminderMinIntervalHours):
                       fetch PreprocessedSurvey where userId + cohortId + state = DISMISSED
                       include in the response payload
                       (atomic write: sample.status = REMINDER_SERVED, sample.reminderServedAt = NOW)
Step 3 (existing): assemble and return response
```

The key invariant: the reminder is returned from an *existing* `PreprocessedSurvey` record — the same one that was created at sampling time and has `state = DISMISSED`. No new `PreprocessedSurvey` is created for the reminder.

### 6.3 `reminderMinIntervalHours` source

`reminderMinIntervalHours` is read from `SurveyBody` of the NPS cohort's survey. This is a platform-level configuration — it applies to all users in that cohort uniformly. It is not configurable per app type, per user, or per platform.

```java
SurveyBody surveyBody          = objectMapper.readValue(survey.getSurvey(), SurveyBody.class);
int reminderMinIntervalHours   = surveyBody.getReminderMinIntervalHours();
```

The `reminderMinIntervalHours` field is added to `SurveyBody` as part of the NPS Cohort Definition spec. The reminder spec consumes it.

### 6.4 PreprocessedSurvey lookup for reminder

The `PreprocessedSurvey` lookup for the reminder uses the same storage interface as the initial serve, with a different state filter:

```java
PreprocessedSurvey reminderSurvey = preprocessedSurveyStorage
    .findByUserIdAndCohortIdAndState(userId, sample.getCohortId(), DISMISSED);
```

If the lookup returns null (the `PreprocessedSurvey` record expired or was deleted), the reminder is not served. This is a defensive guard — the normal case is that the `PreprocessedSurvey` record persists for the full ISO week (7-day TTL).

---

## 7. Sequence Diagram — Reminder Served at Check-in

```
Client                SurveyController          SurveyService          NpsReminderEligibilityChecker   NpsWeeklySampleStorage
  │                          │                       │                             │                            │
  │──GET /api/surveys/user──►│                       │                             │                            │
  │                          │──getUserSurveys(uid)─►│                             │                            │
  │                          │                       │                             │                            │
  │                          │              [Step 1: standard NOT_COMPLETED lookup — returns no NPS]            │
  │                          │                       │                             │                            │
  │                          │              [Step 2: reminder check — NEW]         │                            │
  │                          │                       │──findByUserAndWeek(uid,wk)──────────────────────────────►│
  │                          │                       │◄── NpsWeeklySample(DISMISSED)──────────────────────────│
  │                          │                       │                             │                            │
  │                          │                       │──isEligible(sample, hours)─►│                            │
  │                          │                       │                             │ C-1: status == DISMISSED ✓ │
  │                          │                       │                             │ C-2: same ISO week ✓       │
  │                          │                       │                             │ C-3: interval elapsed ✓    │
  │                          │                       │                             │ C-4: reminder_served IS NULL│
  │                          │                       │◄── true ────────────────────│                            │
  │                          │                       │                             │                            │
  │                          │              [BEGIN @Transactional]                 │                            │
  │                          │                       │                             │                            │
  │                          │                       │── save(sample:              │                            │
  │                          │                       │   status=REMINDER_SERVED,   │                            │
  │                          │                       │   reminderServedAt=NOW) ────────────────────────────────►│
  │                          │                       │◄── OK (version+1) ──────────────────────────────────────│
  │                          │                       │                             │                            │
  │                          │              [COMMIT @Transactional]                │                            │
  │                          │                       │                             │                            │
  │                          │                       │── fetch PreprocessedSurvey  │                            │
  │                          │                       │   (userId, cohortId, DISMISSED)                          │
  │                          │                       │── include in survey list    │                            │
  │                          │◄── survey list ───────│                             │                            │
  │                          │   (includes DISMISSED  │                            │                            │
  │                          │    PreprocessedSurvey) │                            │                            │
  │◄── HTTP 200 ─────────────│                       │                             │                            │
  │  (survey payload,        │                       │                             │                            │
  │   no type:REMINDER flag) │                       │                             │                            │
```

**On `OptimisticLockException` (two concurrent check-in calls):**

If two concurrent check-in calls both pass `isEligible()` and both attempt the `DISMISSED → REMINDER_SERVED` transition:

- The first call's `UPDATE WHERE version=N` succeeds. `version` becomes `N+1`. `reminder_served_at` is set.
- The second call's `UPDATE WHERE version=N` finds no matching row (already `N+1`). Hibernate throws `OptimisticLockException`.
- The service catches the exception, re-reads the sample (now `REMINDER_SERVED`), and returns the `PreprocessedSurvey` as if the reminder had just been served. No error propagated.
- Both callers receive the survey payload. The reminder is counted as served exactly once (`reminder_served_at` written once).

---

## 8. Week Boundary Enforcement

### 8.1 How the week boundary is enforced

Condition C-2 (`IsoWeekUtil.current(LAGOS).equals(sample.getIsoWeek())`) enforces the week boundary. It is evaluated at every check-in call. The comparison is a string equality check between the current ISO week string and the week the sample row was created for.

**If the user dismisses on Saturday evening and the week closes (Sunday 23:59):**
- Monday morning check-in: `IsoWeekUtil.current()` returns `"2026-W22"` (new week)
- `sample.getIsoWeek()` is still `"2026-W21"` (old week)
- C-2 fails → reminder NOT served
- The DISMISSED sample for W21 is transitioned to `ABANDONED` by `NpsWeeklyExpiredSampleJob`
- The user may be included in a new week's sample for W22 (subject to cool-off)

**If the minimum interval is 4 hours and the user dismisses on Sunday at 22:00:**
- The interval elapses at Sunday 02:00 next week — but C-2 will fail because the week has closed
- The reminder is never served — this is correct behaviour. The week-bounded invariant takes precedence over the interval condition

There is no "pending reminder" state. The reminder either fires within the same week or it does not fire at all.

### 8.2 No carryover of DISMISSED state

A `DISMISSED` row from week W21 is not carried into week W22. The `NpsWeeklyExpiredSampleJob` transitions all remaining `DISMISSED` and `SERVED` rows to `ABANDONED` at the ISO week boundary. If the user was dismissed but the interval never elapsed, the row ends as `ABANDONED`.

---

## 9. Interaction with Cool-Off

### 9.1 Cool-off is written at SERVED, not at DISMISSED or REMINDER_SERVED

`NpsUserStateService.writeTriggered(userId)` is called exactly once per `(user, cohort, week)` — at the `PENDING → SERVED` transition. The cool-off clock starts at the first serve.

Subsequent status transitions (`SERVED → DISMISSED`, `DISMISSED → REMINDER_SERVED`) do **not** call `writeTriggered()` again. The cool-off state is written once and never modified by the reminder path.

### 9.2 Dismissal and reminder do not extend cool-off

A user who dismisses and then receives a reminder within the same week still has a single trigger recorded in `NpsUserState`. The cool-off period was started at SERVED time and runs for 90 days from that date. Neither the DISMISSED transition nor the REMINDER_SERVED transition modifies `NpsUserState`.

This means:
- If the user dismisses on Wednesday (day 0) and the reminder is served on Thursday (day 1), the cool-off clock runs from the Monday (or whenever the initial SERVED was written).
- The user's eligibility for the next NPS sample is based on when the survey was first served, not when the reminder was served.

### 9.3 Why this is correct

The PRD intent is to prevent survey fatigue. The trigger event that starts the fatigue clock is the delivery of the survey to the user (the first serve). Whether the user immediately dismisses, receives a reminder, or responds in full, the "one NPS touchpoint this week" has already occurred. Resetting or extending the cool-off clock on reminder serve would punish users for engaging with the dismiss-then-reminder flow, which is the opposite of the intended behaviour.

### 9.4 Annual trigger cap

Similarly, the annual trigger cap (max 2 NPS triggers per calendar year) is incremented once — at `PENDING → SERVED`. The reminder does not consume an additional annual budget slot.

---

## 10. Interaction with the Existing `enableAlertingAfterDismissal` Mechanism

CAS has an existing mechanism called `enableAlertingAfterDismissal` on `SurveyBody`. When enabled, a dismissed survey is promoted to a `SurveyAlert` for display as a banner/alert in the app. This is used for BRM and certain CSAT surveys.

**The NPS reminder does NOT use `enableAlertingAfterDismissal`.** The reasons are:

1. `enableAlertingAfterDismissal` produces a `SurveyAlert` — a banner-style notification in a different UI component from the survey modal. The NPS reminder must appear in the same survey modal as the original serve (via the survey check-in endpoint), not as a banner.
2. `enableAlertingAfterDismissal` has no concept of a minimum interval. It triggers a banner immediately on dismissal.
3. `enableAlertingAfterDismissal` has no week-boundary awareness. Banners created by this mechanism can persist across weeks.
4. The NPS reminder has precise PRD requirements (one per week, interval-gated, week-bounded) that the alerting mechanism was not designed to enforce.

**Decision:** NPS reminder uses `NpsReminderEligibilityChecker` exclusively. `enableAlertingAfterDismissal` for NPS cohort surveys must be set to `false` in the survey configuration. This is an operational constraint documented here for survey operators.
