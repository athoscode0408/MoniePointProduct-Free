# Design: NPS Weekly Sampling

**Spec:** [`impl-specs/2026-05-19-nps-sampling.md`](../../impl-specs/2026-05-19-nps-sampling.md)
**ADRs:** [ADR-003 Preprocessing Timing](../../adrs/ADR-003-nps-preprocessing-timing.md) · [ADR-004 Sampling Strategy](../../adrs/ADR-004-nps-sampling-strategy.md) · [ADR-005 Eligible User Source](../../adrs/ADR-005-nps-eligible-user-source.md) · [ADR-006 Daily Distribution](../../adrs/ADR-006-nps-daily-distribution.md)
**Depends on:** [NPS Cohort Definition Design](nps-cohort-definition-design.md) · [NPS Cool-Off Design](nps-cool-off-design.md)
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)
**Date:** 2026-05-19
**PRD:** [NPS PRD v1.0 — teamapt PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD)

---

## 1. Overview

### 1.1 What the NPS Sampling engine does

The NPS Sampling engine is the mechanism by which the NPS programme selects, preprocesses, and delivers surveys to a statistically representative sample of eligible users each calendar week.

The engine has three distinct phases:

```
Phase 1 — Preparation (Monday 00:05 Africa/Lagos, Quartz + ShedLock)
  NpsWeeklySamplePreparationJob scans Bigtable for eligible users,
  applies cool-off exclusion, draws a random sample up to the weekly cap,
  and creates NpsWeeklySample rows (status=PENDING) + PreprocessedSurvey rows
  via the existing Kafka preprocessor topic.

Phase 2 — Delivery (user-triggered, any time during the week)
  Existing check-in endpoint returns PreprocessedSurvey for users whose
  status=PENDING. On first serve, status transitions to SERVED atomically
  with an NpsUserState trigger write.

Phase 3 — Expiry (Sunday 23:59 Africa/Lagos, Quartz + ShedLock)
  NpsWeeklyExpiredSampleJob transitions all remaining PENDING rows to
  EXPIRED at the ISO week boundary.
```

### 1.2 Sampling cadence and the ISO week as atomic unit

The **ISO week** (Monday 00:00 → Sunday 23:59 Africa/Lagos, formatted as `YYYY-Www`) is the atomic measurement unit for NPS sampling. Every design decision in this spec follows from this choice:

- A user is either in a week's sample or not — there is no mid-week addition to a sample.
- The sample is materialised at week start so delivery infrastructure does not need to know how to select users.
- Response rate is measured per ISO week, enabling consistent week-over-week trending.
- PENDING → EXPIRED at week close prevents a stale survey from appearing to users who check in after their cohort's sample window has passed.

**ISO week notation:** `YYYY-Www` format (e.g. `2026-W21`). Computed using `java.time.WeekFields.ISO` in the `Africa/Lagos` timezone. A week begins on Monday and ends on Sunday.

### 1.3 Weekly invitation caps

| Cohort | Weekly cap | Daily soft-target |
|---|---|---|
| Personal Banking NPS | 3,200 | ~457/day |
| Business Banking NPS | 2,134 | ~305/day |

Caps are read from `SurveyBody.weeklyInvitationCap` at job execution time — operator-configurable without a code change.

### 1.4 Relationship to existing CAS survey pipeline

The sampling engine reuses the existing `SurveyPreprocessorListener` and the `event-survey-preprocessor` Kafka topic to create `PreprocessedSurvey` rows. The weekly job acts as a **publisher** to that topic with NPS-specific payloads. The existing delivery path (check-in endpoint → `PreprocessedSurvey` → client response) is unchanged.

```
Existing BRM / CSAT path:
  Analytics Event → SurveyEvaluatorListener → RuleParserHandler
    → EventPreprocessSurveyDTO (cohortId = null)
    → event-survey-preprocessor Kafka topic
    → SurveyPreprocessorListener
    → PreprocessedSurvey saved

NPS sampling path (NEW):
  NpsWeeklySamplePreparationJob
    → EventPreprocessSurveyDTO (cohortId = <cohortId>, verifiedEvent = null)
    → event-survey-preprocessor Kafka topic        ← same topic
    → SurveyPreprocessorListener                   ← same listener
    → PreprocessedSurvey saved (cohort_id populated)
```

---

## 2. `NpsWeeklySample` Aggregate

### 2.1 Role and invariants

`NpsWeeklySample` is the **sampling record** for a single user in a single cohort for a single ISO week. It is the source of truth for:

- Whether a user was drawn into a week's sample (`status = PENDING`)
- Whether the survey was served to them (`status = SERVED`, `served_at` set)
- The lifecycle of the survey through its possible states

**Key invariants:**

| # | Invariant | Enforcement |
|---|---|---|
| I-1 | One row per (user_id, cohort_id, iso_week) | `UNIQUE INDEX(user_id, cohort_id, iso_week)` — insert is idempotent on re-run |
| I-2 | `status` transitions are one-way | Service-layer guards; no direct DB updates from outside the service layer |
| I-3 | `served_at`, `dismissed_at`, `reminder_served_at`, `responded_at` are set at the corresponding status transition and never overwritten | Service-layer guards |
| I-4 | PENDING rows not served by end of ISO week become EXPIRED | `NpsWeeklyExpiredSampleJob` runs at ISO week boundary |
| I-5 | `status = SERVED` is written atomically with `nps_user_state.last_nps_triggered_date` | Both writes in the same `@Transactional` boundary (serve path, chunk 05) |

### 2.2 Entity schema

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT | From `BaseEntity` |
| `user_id` | `VARCHAR(50)` | NOT NULL | Platform user identifier |
| `cohort_id` | `BIGINT` | NOT NULL, FK → `cohort(id)` | Which cohort the user was sampled into |
| `iso_week` | `CHAR(8)` | NOT NULL | e.g. `"2026-W21"`. Computed in Africa/Lagos. `YYYY-Www` format |
| `status` | `ENUM` | NOT NULL | See status table below |
| `served_at` | `TIMESTAMP` | NULL | Set at PENDING → SERVED transition |
| `dismissed_at` | `TIMESTAMP` | NULL | Set at SERVED → DISMISSED transition |
| `reminder_served_at` | `TIMESTAMP` | NULL | Set at DISMISSED → REMINDER_SERVED transition |
| `responded_at` | `TIMESTAMP` | NULL | Set at any terminal → RESPONDED transition |
| `created_by` | `VARCHAR(255)` | NOT NULL | From `BaseEntity` |
| `created_on` | `TIMESTAMP` | NOT NULL | From `BaseEntity` |
| `last_modified_by` | `VARCHAR(255)` | NOT NULL | From `BaseEntity` |
| `last_modified_on` | `TIMESTAMP` | NOT NULL | From `BaseEntity` |
| `version` | `INT` | NOT NULL | Optimistic lock from `BaseEntity.@Version` |

**DDL (specify in DB migrations repo):**

```sql
CREATE TABLE nps_weekly_sample (
    id                  BIGINT          NOT NULL AUTO_INCREMENT,
    user_id             VARCHAR(50)     NOT NULL,
    cohort_id           BIGINT          NOT NULL,
    iso_week            CHAR(8)         NOT NULL,
    status              ENUM(
                            'PENDING',
                            'SERVED',
                            'DISMISSED',
                            'REMINDER_SERVED',
                            'RESPONDED',
                            'EXPIRED',
                            'ABANDONED'
                        )               NOT NULL DEFAULT 'PENDING',
    served_at           TIMESTAMP       NULL,
    dismissed_at        TIMESTAMP       NULL,
    reminder_served_at  TIMESTAMP       NULL,
    responded_at        TIMESTAMP       NULL,
    version             INT             NOT NULL DEFAULT 0,
    created_by          VARCHAR(255)    NOT NULL,
    created_on          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by    VARCHAR(255)    NOT NULL,
    last_modified_on    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    CONSTRAINT uq_nws_user_cohort_week UNIQUE (user_id, cohort_id, iso_week),
    CONSTRAINT fk_nws_cohort FOREIGN KEY (cohort_id) REFERENCES cohort(id),
    INDEX idx_nws_cohort_week_status (cohort_id, iso_week, status)
);
```

**Index notes:**

- `UNIQUE(user_id, cohort_id, iso_week)` — idempotency for the sampling job. Re-running the job for the same week does not create duplicate rows; the INSERT ON DUPLICATE KEY UPDATE pattern (or equivalent upsert) is safe.
- `INDEX(cohort_id, iso_week, status)` — used by the expiry job to find `PENDING` rows for a given cohort and week in a single covering-index scan.

### 2.3 Status state machine

```
                        ┌─────────┐
      Monday 00:05      │         │
    sampling job run    │ PENDING │ ◄── created by NpsWeeklySamplePreparationJob
                        │         │
                        └────┬────┘
                             │
                             │ user checks in → survey returned
                             │ (atomic: served_at = NOW,
                             │  nps_user_state.last_triggered = today)
                             ▼
                        ┌─────────┐
                        │  SERVED │
                        └────┬────┘
                             │
               ┌─────────────┼──────────────────┐
               │             │                  │
               │ dismissed   │ responded        │ no action
               ▼             ▼                  │ (week ends)
          ┌──────────┐  ┌──────────┐            │
          │DISMISSED │  │RESPONDED │◄───────┐   │
          └────┬─────┘  └──────────┘        │   │
               │                            │   │
               │ reminder interval          │   │
               │ elapsed, user checks in    │   │
               ▼                            │   │
        ┌───────────────┐                   │   │
        │REMINDER_SERVED│                   │   │
        └───────┬───────┘                   │   │
                │ responded                 │   │
                └───────────────────────────┘   │
                                                │
                        ┌──────────┐            │
                        │ EXPIRED  │ ◄──────────┘
                        └──────────┘
                  (ISO week boundary,
               NpsWeeklyExpiredSampleJob)

         ┌───────────┐
         │ ABANDONED │  ◄── SERVED or REMINDER_SERVED with no
         └───────────┘       action before EXPIRED (week close)
```

**Terminal states:** `RESPONDED`, `EXPIRED`, `ABANDONED`

**Status meanings:**

| Status | Meaning |
|---|---|
| `PENDING` | User was drawn into the sample; survey preprocessed; waiting for check-in delivery |
| `SERVED` | Survey was returned to the user at check-in; `nps_user_state` trigger written |
| `DISMISSED` | User explicitly dismissed the survey; reminder eligible after `reminderMinIntervalHours` |
| `REMINDER_SERVED` | Reminder was shown to the user (after initial dismiss) |
| `RESPONDED` | User submitted a score; terminal |
| `EXPIRED` | ISO week ended with survey never served; terminal |
| `ABANDONED` | ISO week ended with survey served but no response or dismiss; terminal |

---

## 3. `NpsWeeklySamplePreparationJob` Design

### 3.1 Scheduler configuration

| Property | Value |
|---|---|
| Cron expression | `0 5 0 ? * MON` (Quartz syntax, TZ=Africa/Lagos) |
| Human-readable | Every Monday at 00:05:00 Africa/Lagos |
| ShedLock key | `nps_weekly_sample_preparation` |
| ShedLock min lock time | 5 minutes |
| ShedLock max lock time | 4 hours |
| Batch size config key | `nps.sampling.batch-size` (default 1000) |

The job implements the `ClusteredJob` interface (identical pattern to `PreprocessedSurveyExpirationTriggerJob`). ShedLock prevents concurrent execution on multiple Worker pods. The max lock time of 4 hours provides headroom for a full 24M-user Bigtable scan while preventing an indefinite lock on failure.

### 3.2 Full algorithm

```
execute():

  currentIsoWeek ← IsoWeekUtil.current(ZoneId.of("Africa/Lagos"))
  // e.g. "2026-W21"

  activeCohorts ← cohortStorage.findBySurveyCategoryAndActiveTrue(NPS)

  for each cohort in activeCohorts:

    survey     ← surveyStorage.findById(cohort.surveyId)
    surveyBody ← objectMapper.readValue(survey.survey, SurveyBody.class)

    weeklyInvitationCap ← surveyBody.weeklyInvitationCap    // required > 0
    coolOffDays         ← surveyBody.coolOffDays             // default 90
    yearlyTriggerCap    ← surveyBody.yearlyTriggerCap        // default 2
    batchSize           ← config.nps.sampling.batchSize      // default 1000

    if weeklyInvitationCap <= 0:
      log.warn("weeklyInvitationCap is 0 for cohort={}, skipping", cohort.name)
      continue

    // ── Step 1: Scan eligible users from Bigtable ──────────────────────────
    //
    // userAttributesRepositoryService.scanEligibleUsers() issues a
    // BigtableDataClient.readRows(Query) request with server-side
    // column-value RowFilters for onboardingDate and lastTxnDate.
    // Returns a Stream<String> of userIds that pass the age + txn filter.
    //
    eligibleStream ← userAttributesRepositoryService.scanEligibleUsers(
      minAccountAgeDays        = cohort.minAccountAgeDays,
      transactionWindowDays    = cohort.transactionWindowDays,
      requireRecentTransaction = cohort.requireRecentTransaction,
      batchSize                = batchSize
    )

    // ── Step 2: Exclude users in cool-off (bulk anti-join) ─────────────────
    //
    // A single bulk query loads all currently-in-cool-off user IDs into a
    // HashSet. At steady state this is ~70K rows (weeklyInvitationCap × 13
    // ISO weeks per 90-day window) — fits in ~3.5 MB of heap.
    // Stream filter is then O(1) per user; replaces N individual MySQL
    // point-reads (2–5M for the full eligible pool) with one round trip.
    //
    // findUsersInCoolOff() executes:
    //   SELECT user_id FROM nps_user_state
    //   WHERE last_nps_triggered_date >= :ninetyDaysAgo
    //      OR annual_trigger_count    >= :yearlyTriggerCap
    //
    coolOffIds ← npsUserStateService.findUsersInCoolOff(coolOffDays, yearlyTriggerCap)
    // Set<String>, expected size ~70K at steady state
    candidateStream ← eligibleStream.filter(uid → !coolOffIds.contains(uid))

    // ── Step 3: Random selection up to weekly cap ──────────────────────────
    //
    // Materialise, shuffle, take. Shuffle is Fisher-Yates via Collections.shuffle.
    // For very large eligible pools this list could be large — see §10 for sizing.
    //
    candidates ← candidateStream.collect(toList())
    Collections.shuffle(candidates)
    sampled ← candidates.subList(0, min(candidates.size(), weeklyInvitationCap))

    // ── Step 4: For each sampled user — insert sample row + trigger preprocessing
    //
    for each userId in sampled:

      // Insert sample row — UNIQUE INDEX prevents duplicate on re-run
      npsWeeklySampleStorage.upsert(
        NpsWeeklySample(userId, cohort.id, currentIsoWeek, PENDING)
      )

      // Look up UserAttributes for preprocessing (point-read by userId)
      userAttributes ← userAttributesStorage.findUser(userId, null)

      // Build a placeholder VerifiedAnalyticsEventDTO (NPS is not event-triggered)
      // The SurveyPreprocessorListener.populateContextValuesMap() null-guards this.
      dto ← EventPreprocessSurveyDTO.builder()
        .survey(survey)
        .userAttributes(userAttributes)
        .verifiedAnalyticsEventDTO(null)      // NPS has no triggering event
        .preprocessedSurvey(
            PreprocessedSurvey.builder()
              .userId(userId)
              .surveyId(survey.id)
              .cohortId(cohort.id)
              .isoWeek(currentIsoWeek)
              .build()
        )
        .build()

      // Publish to the existing Kafka preprocessor topic
      surveyPreprocessorKafkaEventPublisher.publish(dto)

    log.info("NPS sampling job: cohort={}, isoWeek={}, sampled={}/{}",
             cohort.name, currentIsoWeek, sampled.size(), weeklyInvitationCap)
```

### 3.3 IsoWeekUtil design

```java
public final class IsoWeekUtil {

    private IsoWeekUtil() {}

    /**
     * Returns the ISO week string for the week containing the current instant,
     * evaluated in the given timezone.
     *
     * @param zone timezone (Africa/Lagos for all NPS computation)
     * @return ISO week string in YYYY-Www format, e.g. "2026-W21"
     */
    public static String current(ZoneId zone) {
        LocalDate today = LocalDate.now(zone);
        WeekFields iso  = WeekFields.ISO;
        int year        = today.get(iso.weekBasedYear());
        int week        = today.get(iso.weekOfWeekBasedYear());
        return String.format("%d-W%02d", year, week);
    }
}
```

**Note on year boundary:** `WeekFields.ISO.weekBasedYear()` handles the ISO week year correctly. January 1 of a calendar year may belong to week 52 or 53 of the prior ISO week year. Using `weekBasedYear()` (not `year()`) prevents the `"2026-W53"` → `"2026-W01"` mis-labelling that would occur if the calendar year field were used instead.

---

## 4. Bigtable Scan Design

### 4.1 Why a new scan method is needed

`UserAttributesStorage.findUser(userId, businessAccountNumber)` is a **point lookup** — it reads a single row by row key (userId). It cannot enumerate users matching a predicate. The sampling job needs to enumerate ~24M users and filter them by `onboardingDate` and `lastTxnDate`. This requires a `BigtableDataClient.readRows(Query)` call with server-side `RowFilter` logic.

A new method is added to `UserAttributesRepositoryService`:

```java
Stream<String> scanEligibleUsers(
    int     minAccountAgeDays,
    int     transactionWindowDays,
    boolean requireRecentTransaction,
    int     batchSize
);
```

### 4.2 Server-side RowFilter construction

Bigtable supports server-side filtering via `RowFilter`. Applying filters server-side avoids transferring rows that fail eligibility criteria to the CAS JVM. For a 24M-row table this is critical — without server-side filters, the network transfer would be prohibitive.

**Filter logic:**

```
Filter 1 (account age):
  column: user_attributes:onboardingDate
  value: bytes(date string)
  operator: timestamp of onboardingDate <= (today - minAccountAgeDays)
  → expressed as: onboardingDate <= cutoffDate (keep rows where account is old enough)

Filter 2 (recent transaction, applied only when requireRecentTransaction=true):
  column: user_attributes:lastTxnDate
  value: bytes(date string)
  operator: lastTxnDate >= (today - transactionWindowDays)
  → expressed as: lastTxnDate >= earliestAcceptableTxnDate
```

**Java API sketch using `com.google.cloud.bigtable.data.v2`:**

```java
public Stream<String> scanEligibleUsers(
        int     minAccountAgeDays,
        int     transactionWindowDays,
        boolean requireRecentTransaction,
        int     batchSize) {

    ZoneId     zone          = ZoneId.of("Africa/Lagos");
    LocalDate  today         = LocalDate.now(zone);
    LocalDate  cutoffDate    = today.minusDays(minAccountAgeDays);

    // Age filter: onboardingDate cell value < (cutoffDate + 1 day).
    // onboardingDate is stored as "yyyy-MM-dd HH:mm:ss" (19 chars). Using
    // endClosed(cutoffDate) would incorrectly exclude users onboarded on
    // cutoffDate itself because "2026-01-15 08:30:00" > "2026-01-15"
    // lexicographically. endOpen(cutoffDate.plusDays(1)) correctly includes
    // all timestamps whose date portion is on or before cutoffDate.
    RowFilter ageFilter = FILTERS.chain()
        .filter(FILTERS.qualifier().exactMatch("onboardingDate"))
        .filter(FILTERS.value().range().endOpen(
            ByteString.copyFromUtf8(cutoffDate.plusDays(1).toString())
        ));

    RowFilter combined;
    if (requireRecentTransaction) {
        LocalDate earliestTxn = today.minusDays(transactionWindowDays);
        RowFilter txnFilter = FILTERS.chain()
            .filter(FILTERS.qualifier().exactMatch("lastTxnDate"))
            .filter(FILTERS.value().range().startClosed(
                ByteString.copyFromUtf8(earliestTxn.toString())
            ));
        // ConditionFilter gives AND semantics across two different columns.
        // FILTERS.interleave() would give OR semantics: a row passes if any
        // cell matches either sub-filter, which incorrectly admits users with
        // an old account but no recent transaction. condition().then().otherwise()
        // behaves as: if ageFilter matches any cell in the row → apply txnFilter
        // (row included only if lastTxnDate cell also passes); otherwise →
        // FILTERS.block() drops all cells → row omitted.
        combined = FILTERS.condition(ageFilter)
            .then(txnFilter)
            .otherwise(FILTERS.block());
    } else {
        combined = ageFilter;
    }

    Query query = Query.create(TABLE_ID)
                       .filter(combined)
                       .limit(batchSize);   // paginate by row-key bookmark

    return StreamSupport.stream(
        dataClient.readRows(query).spliterator(), false
    ).map(Row::getKey).map(ByteString::toStringUtf8);
}
```

### 4.3 Pagination via row-key bookmark

`BigtableDataClient.readRows()` does not automatically page across the entire table when a `.limit()` is set. For a full-table scan, the job reads batches of `batchSize` rows at a time, using the last row key of each batch as the exclusive start key for the next batch:

```
Batch 1: query = Query.create(TABLE_ID).filter(combined).limit(batchSize)
         lastKey = last row key returned

Batch 2: query = Query.create(TABLE_ID)
                      .filter(combined)
                      .range(ByteStringRange.unbounded().startOpen(lastKey))
                      .limit(batchSize)

... continue until returned row count < batchSize (last batch)
```

This pagination strategy is handled inside `scanEligibleUsers()` and transparent to the sampling job — the method returns a lazy `Stream<String>` that pulls the next batch on demand.

### 4.4 Encoding contract

| Qualifier | Stored format | Filter approach |
|---|---|---|
| `onboardingDate` | UTF-8 `"yyyy-MM-dd HH:mm:ss"` (19 chars, datetime) | `endOpen(cutoffDate.plusDays(1))` — see §4.2 comment |
| `lastTxnDate` | UTF-8 `"YYYY-MM-DD"` (10 chars, date only) | `startClosed(earliestTxn)` — date-only strings are lexicographically safe |

`lastTxnDate` uses a date-only format, so lexicographic order is identical to chronological order and `startClosed` is correct.

`onboardingDate` includes a time component. A plain `endClosed(cutoffDate.toString())` bound would incorrectly exclude users onboarded on the cutoff date itself (e.g., `"2026-01-15 08:30:00" > "2026-01-15"` lexicographically). The corrected form uses `endOpen(cutoffDate.plusDays(1))`, which admits all timestamps whose date portion is `<= cutoffDate`.

See [`docs/design/user-attributes-storage-design.md`](user-attributes-storage-design.md) for the full encoding analysis.

---

## 5. Sampling Strategy: Quota Gate vs. Materialized Sample

The PRD (§7.3) requires "randomly selecting eligible users at the start of the week." Two candidate approaches were evaluated.

| Dimension | Option A: Quota Gate (Redis counter at check-in) | Option B: Materialized Sample (weekly batch job) |
|---|---|---|
| Selection timing | At check-in — first users to check in that week are selected | At week start — explicit random draw from full eligible pool |
| Randomness | **Biased** — early-check-in users are over-represented | **Unbiased** — full eligible pool shuffled before selection |
| PRD §7.3 compliance | **Fails** — does not constitute random selection from eligible pool | **Passes** — explicit random selection at week start |
| Audit trail | No record of who was selected; quota counter is ephemeral | `nps_weekly_sample` row per selected user; permanent audit record |
| Daily distribution | Enforces a hard daily cap via counter decrement | Natural distribution via random selection + user check-in patterns |
| Infrastructure | Redis counter (new dependency for NPS) | MySQL table (existing infrastructure) |
| Cap enforcement | Approximate — counter can race across concurrent check-ins | Exact — enforced at sample preparation time, not at serve time |
| Check-in path complexity | Adds eligibility gate logic to check-in path | Check-in path queries pre-materialised sample (simple lookup) |
| Re-run safety | Counter reset required on retry | UNIQUE INDEX makes job re-runs idempotent |
| Week-close cleanup | Quota counters expire via Redis TTL | Expiry job transitions PENDING → EXPIRED |

**Decision: Option B (materialized sample).** See ADR-004 for full rationale.

The quota gate's core failure is that it selects **first-to-check-in** users rather than a random draw from the eligible population. This violates PRD §7.3's representativeness requirement and also means the weekly cap is consumed by users who happen to check in on Monday morning, leaving users who check in later in the week disproportionately under-represented.

---

## 6. Preprocessing at Sample Time

### 6.1 Architecture: job publishes to existing Kafka topic

The sampling job acts as a publisher to the `event-survey-preprocessor` Kafka topic — the same topic that `RuleParserHandler` publishes to for BRM/CSAT. This design means:

- `SurveyPreprocessorListener` runs unchanged for NPS (subject to the null-guard described in §6.2)
- The `PreprocessedSurvey` row created for an NPS sample has a TTL of 7 days (10,080 minutes) — it will expire naturally if the user never checks in during the week, and is explicitly expired by the expiry job
- No new Kafka topic, no new listener class, no changes to delivery infrastructure

This is the lowest-blast-radius approach (ADR-003): the only change to an existing class is a 1-line null-guard.

### 6.2 Null-guard in `SurveyPreprocessorListener.populateContextValuesMap()`

`SurveyPreprocessorListener.populateContextValuesMap()` reads template variable values from `event.*` fields on the `VerifiedAnalyticsEventDTO`. For NPS payloads, `verifiedAnalyticsEventDTO` is `null` because NPS is not event-triggered.

**Required change (1 line):**

```java
// Before (existing code, will NPE for NPS):
contextValuesMap.put("event.type",     event.getType());
contextValuesMap.put("event.platform", event.getPlatform());
// ...

// After (null-guard for NPS):
if (event != null) {
    contextValuesMap.put("event.type",     event.getType());
    contextValuesMap.put("event.platform", event.getPlatform());
    // ... all other event.* puts
}
```

For NPS surveys, no `event.*` template variables are populated. The `SurveyBody` template for NPS surveys must not reference `${event.*}` variables — that constraint is enforced by the survey content, not by code.

### 6.3 PreprocessedSurvey TTL

NPS `PreprocessedSurvey` rows are created at week start. They must expire at week end (Sunday 23:59 Africa/Lagos). The existing `PreprocessedSurveyExpirationTriggerJob` manages TTL-based expiry for all `PreprocessedSurvey` rows. NPS rows are included in this expiry pass.

**TTL for NPS:** 7 days (10,080 minutes) from creation time. A row created at Monday 00:05 expires at Sunday 23:05 — within the same ISO week. The week-close expiry job (chunk 06) handles the `NpsWeeklySample` status transition; `PreprocessedSurveyExpirationTriggerJob` handles the `PreprocessedSurvey` TTL.

---

## 7. Serve Path

### 7.1 What the serve path does

When the check-in endpoint returns a `PreprocessedSurvey` with `category = NPS` and the corresponding `NpsWeeklySample` has `status = PENDING`:

1. Transition `nps_weekly_sample.status` from `PENDING` to `SERVED`, set `served_at = NOW()`
2. Call `NpsUserStateService.writeTriggered(userId)` to record the trigger date and increment the annual counter

Both writes happen in the **same `@Transactional` boundary**. Either both commit or both roll back.

### 7.2 Sequence diagram

```
Client               CheckInService          NpsWeeklySampleStorage     NpsUserStateService
  │                       │                          │                         │
  │─── GET /check-in ────►│                          │                         │
  │                       │                          │                         │
  │                       │── findByUserAndWeek ─────►│                        │
  │                       │◄─ NpsWeeklySample(PENDING)│                        │
  │                       │                          │                         │
  │                       │── BEGIN TRANSACTION ─────────────────────────────  │
  │                       │                          │                         │
  │                       │── updateStatus(SERVED, ──►│                        │
  │                       │   served_at=NOW())        │                        │
  │                       │◄─ OK (version+1)          │                        │
  │                       │                          │                         │
  │                       │── writeTriggered(userId) ─────────────────────────►│
  │                       │                          │    findByUserId(userId)  │
  │                       │                          │◄──────────────────────  │
  │                       │                          │    NpsUserState/null     │
  │                       │                          │                         │
  │                       │                          │    compute new state     │
  │                       │                          │    (date + year + count) │
  │                       │                          │                         │
  │                       │                          │    save(state)           │
  │                       │                          │    WHERE version=N       │
  │                       │◄──────────────────────────────────────────────────│
  │                       │                          │                         │
  │                       │── COMMIT ───────────────────────────────────────── │
  │                       │                          │                         │
  │◄─ PreprocessedSurvey ─│                          │                         │
  │   (NPS survey payload)│                          │                         │
```

### 7.3 OptimisticLockException handling

If two concurrent check-in calls both read `PENDING` and both attempt the PENDING → SERVED transition:

- The first call's `UPDATE WHERE version=N` succeeds → `version` becomes `N+1`
- The second call's `UPDATE WHERE version=N` finds no row matching (version already `N+1`) → Hibernate throws `OptimisticLockException`

The service layer catches `OptimisticLockException`, re-reads the current `NpsWeeklySample` row (now `SERVED`), and returns the survey payload as if the serve had just succeeded. No error is propagated. The trigger count is incremented exactly once.

### 7.4 Already-served idempotency (AC-07.3)

If the user checks in again after their survey is `SERVED`, the check-in endpoint finds `status = SERVED` on the `NpsWeeklySample` row. It returns the existing `PreprocessedSurvey` payload without re-writing `NpsUserState`. The trigger count is not double-incremented.

---

## 8. Week-Close Expiry

### 8.1 Job design

`NpsWeeklyExpiredSampleJob` runs at the ISO week boundary (Sunday 23:59 Africa/Lagos, Quartz cron `0 59 23 ? * SUN` TZ=Africa/Lagos). It transitions all `NpsWeeklySample` rows with `status = PENDING` and `iso_week = currentIsoWeek` to `status = EXPIRED`.

ShedLock key: `nps_weekly_expiry`. The job executes a batched UPDATE:

```sql
UPDATE nps_weekly_sample
SET    status = 'EXPIRED',
       last_modified_on = NOW(),
       last_modified_by = 'system'
WHERE  iso_week = :currentIsoWeek
AND    status   = 'PENDING'
LIMIT  :batchSize;
-- Repeat until affected rows = 0
```

`ABANDONED` status (served but no response before week close) is handled by a separate pass in the same job:

```sql
UPDATE nps_weekly_sample
SET    status = 'ABANDONED'
WHERE  iso_week = :currentIsoWeek
AND    status IN ('SERVED', 'REMINDER_SERVED')
LIMIT  :batchSize;
```

### 8.2 Why PENDING rows must expire

A `PENDING` row for week W21 that is served in week W22 would:

1. Present stale survey content (the `PreprocessedSurvey` template was filled with W21 user attribute values)
2. Consume the user's trigger budget for an off-week delivery
3. Distort W21 response-rate metrics (a response in W22 would be attributed to W21)

Expiring `PENDING` rows at week close keeps each week's measurement clean. If a user misses their week's survey, they may be included in a future week's sample (subject to the weekly cap and cool-off rules).

---

## 9. Daily Distribution Analysis

### 9.1 Why random sampling produces natural daily distribution

The PRD (§7.2) targets approximately 457 Personal Banking and 305 Business Banking deliveries per day — these are weekly-cap / 7 soft targets, not hard per-day limits. The materialized sample approach achieves this naturally without any per-day assignment logic:

**Why:** Users check in throughout the week following their natural usage patterns. The CAS platform serves surveys at check-in. If 3,200 users are randomly drawn from a 24M-user pool:

- The sample is drawn from users with diverse check-in habits — some check in daily, some weekly
- Random sampling ensures no systematic bias toward early-week or late-week check-in patterns
- The resulting delivery distribution across 7 days closely approximates the population's check-in distribution

**Observed distribution:** In a population of 24M users, check-in events follow a roughly uniform distribution across days of the week (with Monday slightly higher due to financial activity patterns). A random 3,200-user sample inherits this distribution, producing ~400–500 deliveries per day.

### 9.2 Why hard per-day caps are rejected

Option A (hard daily cap with `trigger_day` column assignment) was rejected in ADR-006. The core problem:

- If a user is assigned `trigger_day = Wednesday` but only checks in on Thursday, they **miss the week entirely** even though they were willing to engage
- This reduces effective response rate below what random sampling achieves
- Users who check in on Monday generate no NPS delivery regardless of their eagerness, because Monday's quota is filled by the batch
- The implementation adds `trigger_day` column assignment, per-day counter logic, and check-in gate complexity for no statistical benefit

---

## 10. Performance Characteristics

### 10.1 Sampling job expected duration

| Stage | Description | Estimated time |
|---|---|---|
| Bigtable scan (24M users) | Server-side filtered scan; returns ~2–5M eligible users depending on population age distribution | 3–8 minutes (at ~3M rows/min scan rate for filtered queries) |
| Cool-off exclusion (MySQL) | Single `SELECT user_id FROM nps_user_state WHERE ...` bulk-loads ~70K cool-off IDs into a `Set<String>`; stream filter is `O(1)` per user — no per-user DB call | < 1 second (one bulk query + in-memory HashSet construction) |
| Random selection | `Collections.shuffle()` on an in-memory list of ~2–5M userIds | < 30 seconds (in-heap, O(n)) |
| Sample row insertion (6,000 rows max across 2 cohorts) | Upsert 3,200 + 2,134 rows into `nps_weekly_sample` | < 5 seconds |
| Kafka publish (6,000 messages) | Async publish to `event-survey-preprocessor` | < 10 seconds |
| **Total** | | **5–12 minutes** |

**Headroom:** The ShedLock `maxLockTime = 4 hours` provides 20× headroom over the expected worst case. The cron fires at 00:05 Africa/Lagos on Monday; even a 12-minute run completes well before business hours.

### 10.2 Memory sizing for in-memory shuffle

The random-selection step materialises the cool-off-filtered candidate list. At 50 bytes per userId (conservative), 5M candidates require ~250 MB of heap. This is within the CAS Worker's configured `-Xmx` allocation. If memory pressure becomes a concern, the shuffle can be replaced with a reservoir sampling algorithm (`size = weeklyInvitationCap`) that processes the stream without materialising the full list.

### 10.3 Configurable batch size

`nps.sampling.batch-size` (default 1,000) controls:
- The Bigtable read batch size (rows per `readRows()` call)
- The cool-off check batch size (MySQL connection pool throughput)

Increasing to 5,000 reduces round-trip overhead at the cost of higher peak memory per batch. Decreasing to 500 reduces memory pressure at the cost of more round trips. The default of 1,000 is a balanced starting point validated against staging load tests.
