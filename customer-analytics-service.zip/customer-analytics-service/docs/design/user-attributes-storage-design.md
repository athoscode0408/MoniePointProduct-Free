# Design: User Attributes — Bigtable Storage and NPS Eligibility Scan

**Spec:** [`impl-specs/2026-05-19-nps-sampling.md`](../../impl-specs/2026-05-19-nps-sampling.md)
**Depends on:** [NPS Sampling Design](nps-sampling-design.md) · [NPS Cohort Definition Design](nps-cohort-definition-design.md)
**Author:** Mohammed Kamil (`mohammed.kamil@moniepoint.com`)
**Date:** 2026-05-20

---

## 1. Overview

User attributes are stored in a Google Cloud Bigtable table. The `customer-analytics-service` (CAS) is a **read-only consumer** of this table — it does not write to it. The NPS weekly sampling job (`NpsWeeklySamplePreparationJob`) is the only CAS component that issues a full-table scan against this table; all other CAS reads are point lookups by `userId`.

This document covers:
- The Bigtable table structure as observed in CAS source code
- The encoding format of each field relevant to NPS eligibility
- A corrected `RowFilter` specification for the NPS eligibility scan
- Pagination strategy for scanning 24M+ rows
- Write ownership and data provenance
- Performance characteristics

---

## 2. Bigtable Table Structure

### 2.1 Table name

Configured in `application.yml` under the key `bigtable.users-attributes-table`. The resolved table name is `users`.

### 2.2 Column families

| Column family | Config key | Scope |
|---|---|---|
| `user_attributes` | `bigtable.users-attributes-column-family` | Personal account attributes (onboarding date, last transaction date, personal profile fields) |
| `business` | `bigtable.users-business-attributes-column-family` | Business account attributes |

The `UserAttributesRepositoryService.findUser()` point-lookup reads all cells from the row (both families) and maps them to `UserAttributes` via `ObjectMapperHelper.mapRowToPojo()` using Jackson deserialization. The NPS eligibility scan targets qualifiers in the `user_attributes` family.

### 2.3 Row key

Each row's key is the platform `userId` string encoded as UTF-8 bytes. There is no composite key or hash prefix. This has two implications:

1. **Full-table scans traverse rows in lexicographic userId order.** If user IDs are sequential integers or UUIDs, scan distribution across Bigtable tablets will be approximately uniform. If user IDs share a common prefix structure (e.g., country code prefix), some key ranges will be denser than others.
2. **Row-key bookmark pagination is correct.** The sampling job tracks the last-seen row key and uses it as the exclusive start key of the next batch. This works correctly because row keys are unique and ordered.

### 2.4 Qualifiers relevant to NPS eligibility

| Qualifier | Column family | Java field | Java type | Stored encoding | Notes |
|---|---|---|---|---|---|
| `onboardingDate` | `user_attributes` | `UserAttributes.onboardingDate` | `LocalDateTime` | UTF-8 `"yyyy-MM-dd HH:mm:ss"` | 19-character datetime string |
| `lastTxnDate` | `user_attributes` | `UserAttributes.lastTxnDate` | `LocalDate` | UTF-8 `"YYYY-MM-DD"` | 10-character date string |

---

## 3. Encoding Contract and Filter Correctness

### 3.1 `lastTxnDate` — date-only string (YYYY-MM-DD)

`lastTxnDate` is stored as a 10-character ISO-8601 date string, e.g. `"2026-04-15"`. Because all stored values have the same length and format, lexicographic byte order is identical to chronological order:

```
"2025-12-31" < "2026-01-01" < "2026-04-15"  (both lexicographically and chronologically)
```

A Bigtable `value.range().startClosed(ByteString.copyFromUtf8("2026-03-21"))` correctly matches all rows where `lastTxnDate >= "2026-03-21"`.

### 3.2 `onboardingDate` — datetime string (yyyy-MM-dd HH:mm:ss) ⚠

`onboardingDate` is stored as a 19-character datetime string, e.g. `"2024-01-15 08:30:00"`. The NPS sampling design (§4.4) assumes this field is stored as a date-only `"YYYY-MM-DD"` string — **that assumption is incorrect**. The time component must be accounted for in filter construction.

**Impact on `endClosed` filter:**

The sampling job computes `cutoffDate = today - minAccountAgeDays` (a `LocalDate`, e.g. `"2026-01-15"`) and applies an `endClosed` bound at that value. The comparison is:

| Stored value | endClosed bound | Passes? | Correct? |
|---|---|---|---|
| `"2026-01-15 08:30:00"` | `"2026-01-15"` | **No** — `"2026-01-15 08:30:00" > "2026-01-15"` lexicographically | ✗ should pass |
| `"2026-01-14 23:59:59"` | `"2026-01-15"` | Yes — `"2026-01-14..." < "2026-01-15"` | ✓ |
| `"2026-01-16 00:00:00"` | `"2026-01-15"` | No — `"2026-01-16..." > "2026-01-15"` | ✓ correctly excluded |

Users onboarded on the cutoff date itself are incorrectly excluded because the datetime string lexicographically exceeds the date-only bound. This undercounts the eligible pool.

**Correct bound:** Use `endOpen` with `(cutoffDate.plusDays(1)).toString()` as the exclusive upper bound:

```
endOpen("2026-01-16")  →  value < "2026-01-16"
"2026-01-15 23:59:59"  <  "2026-01-16"  ✓  (cutoff date included)
"2026-01-16 00:00:00"  >  "2026-01-16"  ✓  (next day correctly excluded)
```

This correctly includes all timestamps whose date portion is on or before `cutoffDate`.

---

## 4. NPS Eligibility Scan — Corrected RowFilter Design

### 4.1 Age filter

```java
LocalDate cutoffDate    = today.minusDays(cohort.getMinAccountAgeDays());
// Use endOpen with cutoffDate+1 to correctly handle the datetime encoding of onboardingDate.
// endClosed(cutoffDate) would incorrectly exclude users onboarded on cutoffDate itself.
RowFilter ageFilter = FILTERS.chain()
    .filter(FILTERS.qualifier().exactMatch("onboardingDate"))
    .filter(FILTERS.value().range()
        .endOpen(ByteString.copyFromUtf8(cutoffDate.plusDays(1).toString())));
```

### 4.2 Transaction recency filter

```java
LocalDate earliestTxn   = today.minusDays(cohort.getTransactionWindowDays());
// lastTxnDate is stored as YYYY-MM-DD (date-only), so startClosed with date string is correct.
RowFilter txnFilter = FILTERS.chain()
    .filter(FILTERS.qualifier().exactMatch("lastTxnDate"))
    .filter(FILTERS.value().range()
        .startClosed(ByteString.copyFromUtf8(earliestTxn.toString())));
```

### 4.3 Combined filter — AND semantics with ConditionFilter

When `requireRecentTransaction = true`, both gates must pass. `FILTERS.interleave()` must NOT be used — it gives OR semantics (a row passes if any cell matches either sub-filter). A user with an old account but no recent transaction would have their `onboardingDate` cell pass the age filter and incorrectly be included.

`FILTERS.condition()` gives AND semantics:

```java
RowFilter combined;
if (cohort.isRequireRecentTransaction()) {
    // condition(predicate).then(trueFilter).otherwise(falseFilter):
    //   predicate  = ageFilter: does any cell match the onboardingDate + value range?
    //   true       = txnFilter: apply to all cells; row included only if lastTxnDate also passes
    //   false      = block(): drop all cells → row omitted
    combined = FILTERS.condition(ageFilter)
        .then(txnFilter)
        .otherwise(FILTERS.block());
} else {
    combined = ageFilter;
}
```

**Truth table:**

| `onboardingDate` passes age gate | `lastTxnDate` passes txn gate | Filter result |
|---|---|---|
| ✓ | ✓ | Row included ✓ |
| ✓ | ✗ | `then(txnFilter)` returns 0 cells → row omitted ✓ |
| ✗ | ✓ | `otherwise(block())` → row omitted ✓ |
| ✗ | ✗ | `otherwise(block())` → row omitted ✓ |

### 4.4 Full scan method

```java
public Stream<String> scanEligibleUsers(
        int     minAccountAgeDays,
        int     transactionWindowDays,
        boolean requireRecentTransaction,
        int     batchSize) {

    ZoneId    zone         = ZoneId.of("Africa/Lagos");
    LocalDate today        = LocalDate.now(zone);
    LocalDate cutoffDate   = today.minusDays(minAccountAgeDays);

    RowFilter ageFilter = FILTERS.chain()
        .filter(FILTERS.qualifier().exactMatch("onboardingDate"))
        .filter(FILTERS.value().range()
            .endOpen(ByteString.copyFromUtf8(cutoffDate.plusDays(1).toString())));

    RowFilter combined;
    if (requireRecentTransaction) {
        LocalDate earliestTxn = today.minusDays(transactionWindowDays);
        RowFilter txnFilter = FILTERS.chain()
            .filter(FILTERS.qualifier().exactMatch("lastTxnDate"))
            .filter(FILTERS.value().range()
                .startClosed(ByteString.copyFromUtf8(earliestTxn.toString())));
        combined = FILTERS.condition(ageFilter)
            .then(txnFilter)
            .otherwise(FILTERS.block());
    } else {
        combined = ageFilter;
    }

    return paginatedScan(combined, batchSize);
}
```

---

## 5. Pagination Strategy

### 5.1 Row-key bookmark approach

`BigtableDataClient.readRows(Query)` with a `.limit(batchSize)` returns at most `batchSize` rows in a single streaming call. To traverse the full table the job tracks the last returned row key and uses it as the exclusive start of the next batch:

```
Batch 1: Query.create(TABLE_ID).filter(combined).limit(batchSize)
         lastKey = last row key in response

Batch 2: Query.create(TABLE_ID)
              .filter(combined)
              .range(ByteStringRange.unbounded().startOpen(lastKey))
              .limit(batchSize)

... repeat until response.size() < batchSize (last batch signal)
```

The method returns a lazy `Stream<String>` that pulls the next batch on demand. The caller (`NpsWeeklySamplePreparationJob`) sees a single continuous stream.

### 5.2 Recommended batch size

The spec defaults to `nps.sampling.batch-size = 1000`. This creates up to 24,000 sequential HTTP/2 round trips for a 24M-row table. Each round trip adds ~2–5 ms of network overhead, totalling 48–120 seconds in network latency alone before any scan work.

**Recommended batch size: 50,000.**

At 50,000 rows/batch: 480 round trips for 24M rows. Network overhead: ~1–2.4 seconds. Total scan time reduction: significant. Memory per batch: 50,000 × 50 bytes ≈ 2.5 MB — well within heap budget. The `nps.sampling.batch-size` config key controls both Bigtable batch size and downstream cool-off check batch size; these should be split into separate config keys if they diverge.

### 5.3 Fault tolerance

If the gRPC stream is interrupted mid-scan, the job resumes from the last successfully processed row key. Only the in-progress batch is lost; earlier batches are already filtered and held in the candidate stream. The 4-hour ShedLock window provides headroom for recovery.

---

## 6. Write Path and Ownership

CAS contains no `mutateRow` calls targeting the `users` Bigtable table. User attributes (including `onboardingDate` and `lastTxnDate`) are written by an upstream service outside CAS. The write path, update frequency, and data quality guarantees (e.g. how quickly `lastTxnDate` is updated after a transaction) are owned by that upstream service.

**Implications for NPS sampling:**

- `lastTxnDate` reflects the most recent transaction as of the time that upstream service last wrote the row. There may be a lag between a user completing a transaction and the Bigtable row being updated. This lag determines the practical accuracy of the 30-day transaction recency gate.
- `onboardingDate` is set once at account creation and does not change. The datetime encoding (`yyyy-MM-dd HH:mm:ss`) represents the account creation timestamp in the upstream service's local time.
- CAS must not write to the `users` table as a side effect of the NPS scan. The scan is read-only.

---

## 7. Null and Missing Column Handling

### 7.1 Server-side (Bigtable filter)

If a row has no `onboardingDate` cell (e.g., a newly created account row that hasn't been fully populated), the `ageFilter` matches no cells. The row is omitted from the scan results — correctly treated as ineligible.

If `requireRecentTransaction = true` and a row has no `lastTxnDate` cell, the `txnFilter` returns no cells. The `condition(ageFilter).then(txnFilter)` path produces 0 cells even if `ageFilter` matched → row omitted. This is the correct conservative behaviour (no transaction record → ineligible).

### 7.2 Java-side (UserAttributes deserialization for preprocessing)

`UserAttributesRepositoryService.findUser(userId, null)` is called per sampled user during preprocessing (up to 6,000 calls per sampling run). `UserAttributes.onboardingDate` is typed `LocalDateTime` with `@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")`. If the cell is absent or unparseable, Jackson sets the field to `null`. `CohortEligibilityGateImpl.evaluate()` already null-guards this field (Gate 1 returns `false` if `onboardingDate == null`).

---

## 8. Performance Characteristics

| Stage | Description | Estimate |
|---|---|---|
| Bigtable scan — 24M rows, server-side filtered | Only matching cells transferred; ~2–5M rows pass eligibility filters | 1–3 minutes at 50K batch size |
| Network overhead | 480 round trips × ~3 ms per trip at 50K batch size | ~1.5 seconds |
| Row key extraction | `Row::getKey` → `ByteString::toStringUtf8` per matched row | Negligible (CPU-bound, ~500 ms for 5M rows) |

**Data volume transferred:**

With the condition filter returning only `lastTxnDate` cells for matching rows (one cell per row), each matching row transmits approximately:
- Row key (userId): ~20–36 bytes
- One cell (lastTxnDate qualifier + 10-byte value + metadata): ~80 bytes

For 5M matching rows: ~500 MB transferred from Bigtable to CAS Worker. Without server-side filters, a full-table unfiltered scan would transfer ~24M rows × ~200 bytes/row = ~4.8 GB. Server-side filters reduce network transfer by roughly 10×.

**Parallel scan option (future):**

If the sequential scan becomes the job's rate-limiting step, the key space can be split into N disjoint ranges (by userId prefix) and scanned concurrently in a thread pool. Bigtable tablets are distributed by row key range, so parallel prefix scans hit different Bigtable nodes. At N=8, wall-clock scan time reduces by approximately 8×. This is not needed at current scale (24M users, 4-hour ShedLock window) but is architecturally straightforward.
