# Dev / Staging Access Catalog — Customer Analytics Service

Fill in the **Connection Details** column for each environment before submitting access requests.
For SaaS platforms that require an invite, the **Access Contact** column names who to reach.

---

## 1. Databases & Storage

### 1.1 MySQL (Primary Database)

| Field | Dev | Staging |
|---|---|---|
| Host / IP | | |
| Port | 3306 | 3306 |
| Database name | `customer_analytics` | `customer_analytics` |
| Username | | |
| Password | | |
| Config property | `spring.datasource.url` | `spring.datasource.url` |

**Notes:**
- Schema is managed via Liquibase in the separate `analytics-service-migration-repo`.
- Schema changes are deployed via a dedicated migration webhook — coordinate with the DBA team before running migrations manually.
- Local default: `jdbc:mysql://localhost:3306/customer_analytics`

---

### 1.2 Google Cloud Bigtable

| Field | Dev | Staging |
|---|---|---|
| GCP Project ID | | |
| Bigtable Instance ID | | |
| Service Account Key file | | |
| K8s Secret name | `google-credentials` | `google-credentials` |
| Key file name in secret | `bigtable-dev.json` | `bigtable-staging.json` |
| Config property | `bigtable.project-id` / `bigtable.instance-id` | `bigtable.project-id` / `bigtable.instance-id` |
| Emulator host (local only) | `localhost:8086` | N/A |

**Access Contact:** Request GCP IAM access and service account key from the **Platform / Infrastructure team**.
The service account needs `roles/bigtable.user` on the target instance.

---

### 1.3 Redis

| Field | Dev | Staging |
|---|---|---|
| Host / IP | | |
| Port | 6379 | 6379 |
| Password / Auth token | | |
| TLS enabled | | |
| Config property | `spring.redis.host` / `spring.redis.password` | `spring.redis.host` / `spring.redis.password` |

**Notes:** Local default: `localhost:6379` (no auth, no TLS).

---

## 2. Message Broker

### 2.1 Apache Kafka

| Field | Dev | Staging |
|---|---|---|
| Bootstrap servers | | |
| Security protocol | | |
| SASL mechanism | | |
| SASL username | | |
| SASL password | | |
| Config property | `spring.kafka.bootstrap-servers` | `spring.kafka.bootstrap-servers` |

**Topics to request access to (produce + consume):**

| Topic config key | Direction |
|---|---|
| `kafka.topic.customer-analytics-event` | Consume |
| `kafka.topic.raw-analytics-event` | Consume |
| `kafka.topic.verified-analytics-event` | Produce + Consume |
| `kafka.topic.event-completed-survey` | Produce + Consume |
| `kafka.topic.event-survey-preprocessor` | Produce + Consume |
| `kafka.topic.event-validated-survey` | Produce + Consume |
| `kafka.topic.event-survey-push-notification` | Produce |
| `kafka.topic.event-retry-id` | Produce + Consume |
| `kafka.topic.event-retry-id-range` | Produce + Consume |
| `kafka.topic.customer-profile-updates-event` | Consume |

**Consumer groups to request:**

| Config key |
|---|
| `spring.kafka.consumer.group-id` |
| `spring.kafka.consumer-groups.braze-group-id` |
| `spring.kafka.consumer-groups.customerio-group-id` |
| `spring.kafka.consumer-groups.googleanalytics-group-id` |
| `spring.kafka.consumer-groups.mixpanel-group-id` |
| `spring.kafka.consumer-groups.singular-group-id` |
| `spring.kafka.consumer-groups.survey-evaluator-group-id` |

---

## 3. Internal Moniepoint Services

### 3.1 Spring Cloud Config Server

| Field | Dev | Staging |
|---|---|---|
| URL | | |
| Config property | `CONFIG_URL` (env var) | `CONFIG_URL` (env var) |
| K8s internal DNS | `http://wclms-config-server.wclms.svc.cluster.local:8888` | |

**Notes:** This must be accessible first — all other connection strings are loaded from it.

---

### 3.2 Cosmos (Auth & Identity Service)

| Field | Dev | Staging |
|---|---|---|
| Base URL | | |
| Client ID | | |
| Client secret | | |
| Config property | `integrations.cosmos.base-url` / `integrations.cosmos.credentials` | same |

---

### 3.3 NOS (Notification Orchestration Service)

| Field | Dev | Staging |
|---|---|---|
| Base URL | | |
| Auth token / credentials | | |
| Config property | `integrations.nos.base-url` | `integrations.nos.base-url` |

---

### 3.4 Banner Service

| Field | Dev | Staging |
|---|---|---|
| Base URL | | |
| Auth token / credentials | | |
| Config property | `integrations.banner.base-url` | `integrations.banner.base-url` |

---

### 3.5 Rewards Service

| Field | Dev | Staging |
|---|---|---|
| Base URL | | |
| Auth token / credentials | | |
| Config property | `integrations.rewards.base-url` | `integrations.rewards.base-url` |

---

## 4. External SaaS Platforms

### 4.1 Braze

| Field | Dev | Staging |
|---|---|---|
| REST endpoint (base URL) | | |
| API key | | |
| iOS campaign ID | | |
| Android campaign ID | | |
| Web campaign ID | | |
| Config property | `integrations.braze.*` | `integrations.braze.*` |

**Access Contact:** Request a dev/staging workspace invite and API key from the **CRM / Growth team** (Braze admin).

---

### 4.2 CustomerIO

| Field | Dev | Staging |
|---|---|---|
| Base URL | | |
| API key | | |
| Site ID | | |
| Config property | `integrations.customerio.*` | `integrations.customerio.*` |

**Access Contact:** Request workspace access and API credentials from the **CRM / Growth team** (CustomerIO admin).

---

### 4.3 Mixpanel

| Field | Dev | Staging |
|---|---|---|
| Base URL | `https://api.mixpanel.com/` | `https://api.mixpanel.com/` |
| Query API URL | `https://mixpanel.com/api/` | `https://mixpanel.com/api/` |
| Project token | | |
| Config property | `integrations.mixpanel.project-token` | `integrations.mixpanel.project-token` |

**Access Contact:** Request project access and a service account token from the **Data / Analytics team** (Mixpanel admin).

---

### 4.4 Google Analytics (GA4)

| Field | Dev | Staging |
|---|---|---|
| Base URL | `https://www.google-analytics.com` | `https://www.google-analytics.com` |
| Android Personal — API secret | | |
| Android Personal — Firebase App ID | | |
| Android Business — API secret | | |
| Android Business — Firebase App ID | | |
| iOS Personal — API secret | | |
| iOS Personal — Firebase App ID | | |
| iOS Business — API secret | | |
| iOS Business — Firebase App ID | | |
| Web Personal — API secret | | |
| Web Personal — Measurement ID | | |
| Web Business — API secret | | |
| Web Business — Measurement ID | | |
| Config property prefix | `integrations.googleanalytics.*` | `integrations.googleanalytics.*` |

**Access Contact:** Request GA4 property access and Measurement Protocol API secrets from the **Data / Analytics team** (Google Analytics admin).

---

### 4.5 Singular

| Field | Dev | Staging |
|---|---|---|
| Base URL | `https://s2s.singular.net/` | `https://s2s.singular.net/` |
| API key | | |
| Config property | `integrations.singular.api-key` | `integrations.singular.api-key` |

**Access Contact:** Request S2S API key from the **Growth / Mobile Attribution team** (Singular admin).

---

### 4.6 New Relic

| Field | Dev | Staging |
|---|---|---|
| License key | | |
| Account ID | | |
| Application name | `Customer Analytics Service` | `Customer Analytics Service` |
| Environment variable | `NEW_RELIC_LICENSE_KEY` | `NEW_RELIC_LICENSE_KEY` |

**Access Contact:** Request an account invite and license key from the **Platform / DevOps team** (New Relic admin).

---

## 5. Kubernetes & Container Registry

### 5.1 Kubernetes Cluster

| Field | Dev | Staging |
|---|---|---|
| Cluster name / context | | |
| Namespace | `wclms` | `wclms` |
| Kubeconfig / credentials | | |

**Permissions needed:** `get`, `list`, `watch` on pods, deployments, configmaps, and secrets within the `wclms` namespace.

---

### 5.2 Docker / Container Image Registry

| Field | Value |
|---|---|
| Registry | `registry.gitlab.com` |
| Repository path | `tcosmos/moniepoint-loans/projects/common/services/customer-analytics-service` |
| K8s pull secret | `mpt-img-regcred-gar` |

**Access Contact:** Request GitLab registry read access from the **DevOps / Platform team**.
