# Implementation Spec: Public Braze Event Whitelist API

## Document Info

| Field | Value |
|---|---|
| Status | Draft |
| Author | DR Chibs (`chibuike.dennis@moniepoint.com`) |
| Date | 2026-08-18 |
| PRD | PO-396 (mobile/web send analytics events directly to Braze) |
| Deployment Units | API Handler only (public REST endpoint; no worker/Kafka/Quartz involvement) |
| Companion Design Doc | N/A |
| ADRs | N/A |
| Depends on | Existing `supported_events` / `analytics_event_providers` schema and `AnalyticsEventProviderRepositoryService` allow-list cache (no schema change) |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Where does the whitelist come from? | The same source backend-routed Braze events already use: `supported_events` joined to `analytics_event_providers` via `providers_event_types`, read through the existing `AnalyticsEventProviderRepositoryService` allow-list (Redis-cached under `CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY`). No new table, no new cache key. Guarantees client-side and server-side whitelists can never diverge. |
| D-02 | Which path/verb, and version? | `GET /api/v1/white-listed-events`, on a new, dedicated `WhitelistedEventsController` (`module/analytics/controller/v1/`) — **not** added to `AnalyticsControllerV3`'s `/api/v3/events` path, since that path already serves `POST /api/v3/events` (pushing events) and reusing it for a `GET` "list configuration" endpoint would be confusing. This is a new API surface, so it starts its own versioning at `v1` rather than inheriting `v3` from the unrelated event-ingestion endpoints. |
| D-03 | Does this require a `PUBLIC_URIS` / security-config change? | Yes. Unlike the (rejected) `/api/v3/events` reuse, `/api/v1/white-listed-events` is a brand-new path with no existing entry in `SecurityPropertiesConfig.PUBLIC_URIS`, so it is added explicitly (Tier-3 change, `common/security/**`, requires 2 CODEOWNER approvals). |
| D-04 | Should the handler carry `@PreAuthorize`? | No. This is a genuinely open, pre-login endpoint (per AC), matching the existing `WebhookController` precedent (fully public, no method-level authorization at all) rather than `UserInfoController`'s `!isAuthenticated() \|\| hasAuthority(...)` (which still gates authenticated callers behind an authority that doesn't apply here). |
| D-05 | `expires_at` semantics | Server time + a configurable TTL (`cas.public-braze-events.ttl-seconds`, default 6h/21600s), truncated to seconds — a client-side "don't refetch before this" hint, not a persisted/static value. The literal `2027-12-20T00:00:00Z` in the ticket's sample payload is treated as a placeholder from mobile's integration testing, not a fixed target date. 6h (rather than 24h) was chosen to keep client-side staleness bounded given whitelist changes are operational/admin-driven and can happen at short notice. |
| D-06 | Cache invalidation on writes to `supported_events` | Already wired: `EventConfigService.createEventConfig` evicts `CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY` on every write. No new eviction path needed since this feature reads the same cache key. |

---

## 1. Context

### 1.1 Why now

PO-396 moves some analytics events to be sent directly from Mobile/Web to Braze, bypassing CAS. Before FE can safely do this, it needs to know — including before the user authenticates — which event names are currently whitelisted for Braze, so it doesn't fire events Braze/CAS don't expect. A mobile integration already exists against a fixed response shape (see below), authored ahead of this backend implementation.

### 1.2 Scope summary

1. `GET /api/v1/white-listed-events` — new, fully public endpoint on a new `WhitelistedEventsController`, returning the current Braze-whitelisted event list.
2. `AnalyticsEventProviderRepositoryService.getAllowListedEventTypes(EventProvider)` — new read method reusing the existing allow-list cache.
3. `AnalyticsService.getPubliclyAllowedBrazeEvents()` — new service method assembling the response DTO with a computed `expiresAt`.
4. `BrazeAllowedEventsResponse` DTO (`module/analytics/dto/v1/`) — new, matches the FE-integrated shape exactly.
5. `SecurityPropertiesConfig.PUBLIC_URIS` — add `/api/v1/white-listed-events`.

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | `BrazeAllowedEventsResponse` DTO (`module/analytics/dto/v1`) | API Handler | New |
| 2 | `AnalyticsEventProviderRepositoryService.getAllowListedEventTypes(EventProvider)` | API Handler | Modified |
| 3 | `AnalyticsService` / `AnalyticsServiceImpl` — `getPubliclyAllowedBrazeEvents()` | API Handler | Modified |
| 4 | `WhitelistedEventsController` (`module/analytics/controller/v1`) — `GET /white-listed-events` | API Handler | New |
| 5 | `SecurityPropertiesConfig.PUBLIC_URIS` — add `/api/v1/white-listed-events` | API Handler | Modified (Tier 3) |
| 6 | Unit tests (repository-service, service, controller) | API Handler | New |

### Out of scope

| # | Component | Reason |
|---|---|---|
| — | New Redis cache key / TTL for the event list itself | Reuses existing `SUPPORTED_PROVIDERS_CACHE_KEY` allow-list, already evicted on write |
| — | Non-Braze providers in this response | AC and mobile integration are Braze-specific; other providers are not exposed pre-login |
| — | DB schema changes | None required; reads existing `supported_events`/`analytics_event_providers` tables |
| — | Reusing `/api/v3/events` | Rejected — that path serves `POST` event ingestion; overloading it with a `GET` config-listing endpoint would be confusing (D-02) |

---

## 3. Architecture

```
FE (pre-login)  --GET /api/v1/white-listed-events-->  WhitelistedEventsController.getWhitelistedBrazeEvents()
                                              |
                                              v
                                     AnalyticsService.getPubliclyAllowedBrazeEvents()
                                              |
                                              v
                          AnalyticsEventProviderRepositoryService.getAllowListedEventTypes(BRAZE)
                                              |
                                              v
                        Redis (SUPPORTED_PROVIDERS_CACHE_KEY) --miss--> supported_events JOIN analytics_event_providers
```

Only one Tier 3 path is touched: `SecurityPropertiesConfig.PUBLIC_URIS` (adds one literal string, `common/security/**`, requires 2 CODEOWNER approvals). `entity/`, `enums/`, and `module/kafka/` are unmodified.

---

## 4. Security Threat Model

- Endpoint is intentionally unauthenticated by design (AC: "API should be public, FE needs to discover whitelisted events before user logs in").
- Information exposed is limited to event **type names** already whitelisted for a third-party analytics vendor — no PII, no user-scoped data, no write capability.
- No new attack surface on `supported_events` writes — this feature is read-only and reuses the existing admin write/eviction path (`EventConfigService`), which remains behind its existing internal/admin access controls.
- Response is a small, low-cardinality list (Braze-whitelisted event types only), well within the <1KB per-payload constraint.

---

## 5. Rollout Plan

Single-MR change, no feature flag needed (net-new endpoint on a net-new path; no behavior change to any existing endpoint). Verify in `dev`/`staging` that `GET /api/v1/white-listed-events` returns 200 without an `Authorization` header before promoting, and that the `PUBLIC_URIS` change has the required 2 CODEOWNER approvals given it touches `common/security/**`.
