# Implementation Spec: New Relic → Datadog Instrumentation Migration

## Document Info

| Field | Value |
|---|---|
| Status | Draft — code, Dockerfile, and k8s label changes done in the working tree as of 2026-09-02, pending review/commit. D-12 below still blocks the k8s labels taking effect once merged. |
| Author | DR Chibs (`chibuike.dennis@moniepoint.com`) |
| Date | 2026-09-01 |
| PRD | Org-wide APM vendor migration (New Relic → Datadog) — CAS's slice of it |
| Deployment Units | Both — API Handler (Dockerfile, controllers, most services) and background worker (Kafka listeners, jobs) |
| Companion Design Doc | N/A |
| ADRs | N/A — the vendor decision is made org-wide; this spec covers CAS's "how", not the "whether" |
| Depends on | Platform/SRE confirming the Datadog Cluster Agent + Admission Controller is enabled for the `wclms` namespace (see D-12, blocking) |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Where does the vendor-facing code live? | Extend the two existing wrapper classes, `common/util/Telemetry.java` and `common/util/CorrelationIds.java`, rather than introduce a new package. Both already exist for exactly this purpose; the problem today is that most of the 25 direct `NewRelic.*` call sites bypass them, not that the abstraction is missing. |
| D-02 | `pom.xml` — is the already-removed `newrelic-api` dependency the accepted starting point? | Yes (confirmed with author). `pom.xml` currently has an uncommitted local edit removing `newrelic-api`, which breaks compilation of 32 files. This spec treats that removal as step zero and adds `com.datadoghq:dd-trace-api` (compile scope) and `io.micrometer:micrometer-registry-datadog` (runtime) in its place. |
| D-03 | `@Trace(dispatcher = true)` at controller/Kafka-listener entry points (21 sites) | Drop the annotation entirely rather than port it 1:1. This org already runs Datadog's Kubernetes Admission Controller / Single-Step Instrumentation elsewhere (see D-10) — the injected agent auto-instruments Spring MVC dispatch and Kafka consumer poll without a manual annotation. Verify in a lower environment once the pod label lands (see Rollout) before relying on this for all 21 sites. |
| D-04 | Remaining bare `@Trace` (23 sites, internal service/helper/repository methods) | Swap the import to `datadog.trace.api.Trace`. `dd-trace-api`'s `@Trace` takes `operationName`/`resourceName`, both **static strings only** (no dynamic values) — add them only where the bare method name is ambiguous; otherwise the default (method name) is fine, same as today. |
| D-05 | `@Trace(async = true)` (`RuleParserHandler.parseRule`) + the `Token` handoff in `SurveyEvaluatorListener` | No direct Datadog annotation equivalent exists, and `com.newrelic.api.agent.Token` stopped compiling the moment `newrelic-api` was removed, forcing a decision now rather than after a spike. Resolved: dropped the `Token` parameter and the `token.linkAndExpire()` call entirely; `parseRule` is now `@Trace` (no `async` flag) with no manual cross-thread linking. **Known gap**: until D-10/D-12 land and get verified, the async `parseRule` span may show up as a disconnected trace rather than a child of the triggering Kafka-consume trace — confirm in a lower environment (see Rollout §3) and only build a manual `GlobalTracer` capture/activate helper if the agent's own executor auto-instrumentation doesn't already relink it. |
| D-06 | `Segment` (3 sites: `RuleParserHandler` "RuleParser", `SurveyPreprocessorListener` "SurveyPreprocessor", `UserAttributesRepositoryService` "BigTableRead") | Add `Telemetry.runInSpan(String name, Runnable/Supplier<T> work)`, wrapping Datadog's OpenTracing API (`GlobalTracer.get().buildSpan(name).start()` + `Scope` + `span.finish()` in a `finally`). Collapses each call site's manual try/finally into one line and keeps the OpenTracing types out of business code. |
| D-07 | `NewRelic.recordMetric` (14 sites across `ObjectMapperHelper`, `AbstractKafkaEventPublisher`, `AnalyticsServiceImpl`) | Add `Telemetry.recordMetric(String name, double value)` backed by an injected `MeterRegistry` (Micrometer is already on the classpath transitively via `spring-boot-starter-actuator`), shipped to Datadog via `micrometer-registry-datadog`'s HTTP-API reporter — Datadog's own docs recommend this over a raw DogStatsD client for this exact case. |
| D-08 | `Telemetry.onStageDone` (New Relic Insights custom event `"CasStage"`) | No 1:1 Datadog "custom event" equivalent. Replace with a single structured `log.info` call carrying the same fields (`stage`, `correlationId`, `success`, `durationMs`) — this already matches the repo's own logging rule, and Datadog's log-trace correlation (D-09) stitches it to the trace automatically once shipped to Datadog Log Management. |
| D-09 | `CorrelationIds` trace/span extraction | Swap `NewRelic.getAgent().getTraceMetadata().getTraceId()/getSpanId()` for `datadog.trace.api.CorrelationIdentifier.getTraceId()/getSpanId()`. Keep the existing custom MDC keys (`trace.id`, `span.id`) as-is — `application-local.yml`'s `logging.pattern.console` (mirrored in staging/prod via the config server) explicitly interpolates `%X{trace.id}`/`%X{span.id}`, so this is a live, load-bearing code path, not dead weight; confirmed the hard way after an earlier pass in this same migration briefly deleted it on the mistaken assumption that Datadog's automatic log injection made it redundant. **Caveat**: Datadog's own automatic log-trace correlation (D-08) keys off its reserved `dd.trace_id`/`dd.span_id` attributes, not this app's custom `trace.id`/`span.id` names — the plain-text pattern here keeps the values human-readable in every log line, but won't feed Datadog's "jump from log to trace" UI feature unless Platform/SRE also configures a Log Pipeline remapper for these field names, or the pattern/keys are changed to match Datadog's convention. Out of scope here; flagging for whoever owns the Datadog Log Management side. |
| D-10 | Docker/K8s agent attachment | **Do not** bake a `-javaagent` jar into the Dockerfile. Checked three sibling services already migrated in `moniepoint-gitops-staging-environment` (`moniepoint-crm-service`, `fixed-deposit-savings`, `moniepoint-savings-service`): all use Datadog's Kubernetes Admission Controller, triggered by a `java_apm: datadog` pod label plus `tags.datadoghq.com/{service,env,version}` labels — the agent is injected automatically at pod creation. No jar download, no license key, no `-javaagent` flag in any of them. CAS should follow the same pattern (see Scope §6). |
| D-11 | Hardcoded `NEW_RELIC_LICENSE_KEY` in `Dockerfile` | Out of scope to fix as part of this migration (it's being deleted along with the rest of the NR block), but flagging: it's a committed plaintext secret and should be rotated in New Relic regardless of this migration, since it remains in git history. |
| D-12 | **Open, blocking** — is the Datadog Cluster Agent / Admission Controller already enabled for the `wclms` namespace? | Unknown from this repo. CAS's k8s manifests live in-repo (`kubernetes/templates/`), unlike the sibling services above which are GitOps-managed. Must be confirmed with Platform/SRE before merging the label changes in Scope §6 — otherwise the label is a silent no-op and CAS loses APM coverage in the gap between removing New Relic and Datadog actually being wired up. |

---

## 1. Context

### 1.1 Why now

Org-wide APM vendor migration from New Relic to Datadog. CAS currently has 32 files importing `com.newrelic.api.agent.*`: 44 active `@Trace` annotations (1 commented out) plus 25 direct `NewRelic.*` API call sites (metrics, transaction naming, segments, async tokens, one custom Insights event). Someone had already started this locally — `pom.xml` has an uncommitted edit removing the `newrelic-api` dependency, which currently breaks the build (12 files fail `cannot find symbol: class Trace`). This spec picks up from there.

### 1.2 Scope summary

1. `common/util/Telemetry.java` — add `recordMetric(String, double)` and `runInSpan(...)`; reimplement `onStageDone` as a structured log line instead of an NR Insights event.
2. `common/util/CorrelationIds.java` — swap New Relic trace-metadata calls for `datadog.trace.api.CorrelationIdentifier`.
3. 32 files — swap `com.newrelic.api.agent.Trace` import to `datadog.trace.api.Trace`; drop `dispatcher = true` sites entirely (D-03); resolve `async = true` per the D-05 spike.
4. 10 direct-call files (`ObjectMapperHelper`, `AbstractKafkaEventPublisher`, `AnalyticsServiceImpl`, `SurveyEvaluatorListener`, `CompletedSurveyListener`, `SurveyPreprocessorListener`, `UserAttributesRepositoryService`, `RuleParserHandler`, plus the two facade classes) — route through the new `Telemetry` methods instead of calling `NewRelic.*` directly.
5. `pom.xml` — remove `newrelic.version` property (already done, uncommitted); add `dd-trace-api` + `micrometer-registry-datadog`.
6. `Dockerfile` — remove the New Relic agent download/license-key/`-javaagent` block.
7. `kubernetes/templates/api-handler/deployment.yml` and `.../consumer/deployment.yml` — add `java_apm: datadog` + `tags.datadoghq.com/*` labels and `DD_ENV`/`DD_SERVICE` env, matching the org's established pattern.

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type | Tier |
|---|---|---|---|---|
| 1 | `common/util/Telemetry.java` | Both | Modified | — |
| 2 | `common/util/CorrelationIds.java` | Both | Modified | — |
| 3 | `common/security/CosmosJwtAuthenticationConverter.java` | API Handler | Modified (annotation import only) | **Tier 3** |
| 4 | `module/kafka/listener/*.java` (10 files: `SingularEventListener`, `BrazeEventListener`, `CustomerAnalyticsEventListener`, `SurveyEvaluatorListener`, `MixpanelEventListener`, `CompletedSurveyListener`, `EventRetryIDListener`, `EventRetryIDRangeListener`, `RawAnalyticsEventListener`, `SurveyPreprocessorListener`) | Worker | Modified | **Tier 3** |
| 5 | `module/kafka/service/impl/AbstractKafkaEventPublisher.java` | Both | Modified (metrics + annotation) | **Tier 3** |
| 6 | `module/analytics/controller/**` (`SurveyController`, `AdminNpsPipelineController`, `WhitelistedEventsController`, `AnalyticsControllerV3`) | API Handler | Modified (annotation import only) | — |
| 7 | `module/analytics/service/impl/**` (`RuleParserHandler`, `AnalyticsServiceImpl`, `BannerService`, `CustomerAnalyticsKafkaEventPublisher`, `RuntimeSurveyScheduler`, `SessionServiceImpl`, `SurveyEventCompletionService`) | Both | Modified | — |
| 8 | `module/analytics/repository/service/**` (`UserAttributesRepositoryService`, `PreprocessedSurveyRepositoryService`, `AnalyticsEventProviderRepositoryService`) | Both | Modified | — |
| 9 | `module/job/controller/AdminJobController.java` | API Handler | Modified (annotation import only) | — |
| 10 | `integrations/mixpanel/**`, `integrations/singular/**`, `outbound/OutboundUtils.java` | Both | Modified (annotation import only) | — |
| 11 | `common/util/ObjectMapperHelper.java` | Both | Modified (metrics) | — |
| 12 | `pom.xml` | Both | Modified | — |
| 13 | `Dockerfile` | Both (built once, shared image) | Modified | — |
| 14 | `kubernetes/templates/api-handler/deployment.yml`, `.../consumer/deployment.yml` | Both | Modified | — |
| 15 | Unit tests for `Telemetry.recordMetric` / `runInSpan` (using Micrometer's `SimpleMeterRegistry`, no mocking needed) | — | New | — |

Rows 3, 4, 5 are Tier 3 (`common/security/**` and `module/kafka/**`) and each need 2 CODEOWNER approvals per this repo's rules, even though the changes there are import swaps rather than logic changes.

### Out of scope

- Rotating the hardcoded New Relic license key (D-11) — separate follow-up.
- Deciding whether the Datadog Cluster Agent is enabled cluster-wide for `wclms` (D-12) — Platform/SRE's call, tracked as a blocking dependency, not solved here.
- Historical New Relic dashboards/alerts/NRQL queries — assumed handled by whoever owns the org-wide migration; not a CAS code change.
- Any change to `module/analytics/enums/**` or `module/analytics/entity/**` (the currently-uncommitted `NpsSampleStatus.CHECKPOINT` addition is unrelated in-progress work and is not touched by this spec).

---

## 3. Rollout / Sequencing

1. **Compile first, instrument second.** Land `pom.xml` + the mechanical `@Trace` import swap + `Telemetry`/`CorrelationIds` changes as one MR so the build goes green again on Datadog types. Don't wire up the k8s labels yet.
2. **Confirm D-12 with Platform/SRE** before merging the k8s manifest changes — otherwise ship the code change but hold the label rollout.
3. **Spike D-05** (async span propagation) in isolation against a lower environment once the label is live, before deciding whether `RuleParserHandler`'s manual token/segment code needs a Datadog equivalent or can be deleted outright.
4. **Verify D-03** (dropped `dispatcher = true` sites) by checking a sample Kafka listener and controller actually produce traces in Datadog post-rollout, before assuming all 21 sites are covered by auto-instrumentation.
5. Roll the Dockerfile/k8s change out to the worker and API-handler deployments together, since they share one image.

---

## 4. Testing

- `Telemetry.recordMetric` / `runInSpan`: unit-testable directly against Micrometer's `SimpleMeterRegistry` — no mocking needed, per this repo's rule to prefer real implementations for infra that has a lightweight in-memory double.
- No behavioral change to business logic in any of the 32 touched files — existing tests should continue to pass unmodified; this is instrumentation-only.
- Manual verification in a lower environment (per Rollout §3–4) before considering the migration complete — trace/metric delivery can't be verified by JaCoCo/unit tests.
