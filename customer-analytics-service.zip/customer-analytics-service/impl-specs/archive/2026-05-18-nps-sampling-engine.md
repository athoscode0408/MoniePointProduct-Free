# Implementation Spec: NPS Sampling Programme Enhancement

## Document Info

| Field | Value |
|---|---|
| Status | Draft — All 12 Challenge Questions Resolved; Ready for `/validate-spec` and Chunk-Spec Generation |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-18 |
| PRD | [NPS PRD — teamapt Confluence PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) (v1.0, draft, April 2026) |
| Deployment Units | API Handler + Background Worker |
| Mission Type | **Strike Team (3 engineers)** — chunk count is 8 spanning eligibility, sampling, delivery, measurement, intelligence, and daily budget enforcement; multiple distinct judgment domains (sampling statistics, payload budgeting, calendar-week temporal logic, cohort resolution) |
| Scope Mode | Overview — chunk specs to follow per chunk |
| File | `impl-specs/2026-05-18-nps-sampling-engine.md` |
| Companion Design Doc | [`docs/design/nps-sampling-programme-design.md`](../docs/design/nps-sampling-programme-design.md) — entity schemas, invariants, sequence diagrams, component design |
| Check-in API Design Options | [`docs/design/nps-checkin-api-design.md`](../docs/design/nps-checkin-api-design.md) — 3 stances (A/B/C), engineer picks for chunk 05 |
| ADRs | [`ADR-001 nps_user_state vs Bigtable`](../adrs/ADR-001-nps-cool-off-storage.md), [`ADR-002 ISO-week atomicity`](../adrs/ADR-002-nps-calendar-week-atomicity.md), [`ADR-003 Rolling avgs delegation`](../adrs/ADR-003-nps-rolling-averages-delegation.md) |

---

## Decisions Resolved (2026-05-18)

| # | Topic | Resolution |
|---|---|---|
| C-01 | Transaction count gate | `>= 1` transaction in last 30 days (PRD label authoritative; logic column was an error) |
| C-02 | Rolling averages | Aggregated downstream by data team Airflow; CAS produces atomic weekly scores only |
| C-03 | Check-in API | Foundational design via `/design-an-interface` (separate workstream); `dashboard-info` stays as banner display API |
| C-04 | POS heartbeat | Does not exist anywhere yet → POS NPS deferred to a later phase |
| C-05 | Cool-off scope | NPS-specific; global across NPS measurements; CSAT/BRM get their own per-category state |
| C-06 | `last_nps_triggered_date` storage | CAS-owned `nps_user_state` MySQL table (Bigtable is read-only) |
| C-07 | Cohort library | Built inside chunk 01 |
| C-08 | Weekly AI summary | Deferred to Phase 1.5 spec; Phase 1 ships raw responses by classification |
| C-09 | 50KB daily per-client budget | Redis-backed counter built inside chunk 05 |
| C-10 | Anthropic key + PII strip | Moot for Phase 1 (deferred with C-08) |
| C-11 | "Twice per year" cap | Hard cap enforced; `trigger_year` + `trigger_count_year` columns on `nps_user_state` |
| C-12 | NPS survey definitions | Admin-managed `Survey` rows + typed NPS config inside `SurveyBody` JSON |

**Net effect:** Phase 1 ships in **8 chunks (~5,750 lines)** instead of the originally drafted 10 (~6,400 lines). POS heartbeat NPS and weekly AI summary are out of Phase 1 and ship in follow-up specs.

---

## 1. Context

### 1.1 Why now

The CX team is launching an **always-on Brand NPS programme** across Personal App, Business App, and POS. Today the customer-analytics-service (CAS) supports survey delivery for BRM (brand relationship measurement) — and `SurveyCategory.NPS` exists as an enum value at `src/main/java/com/moniepoint/loans/cas/module/analytics/enums/SurveyCategory.java:3` [VERIFIED] — but there is **no NPS-specific sampling, cool-off, weekly measurement, calendar-week atomicity, or AI summary infrastructure** in this service today.

The CX leadership needs a statistically reliable weekly NPS score at 95% confidence and ±3% margin of error. That requires:
- A sample of **1,067 respondents per week per app** (sample size formula `n = (Z² × p × (1-p)) / E²` at 95% / ±3%)
- Weekly invitation caps of **3,200 (Personal)** and **2,134 (Business)** assuming 30–35% and 50% response rates respectively
- A 90-day global cool-off to prevent fatigue
- Calendar-week-bounded measurement windows so weekly scores are atomic and comparable

### 1.2 Scope summary

This spec covers the **Phase 1 NPS programme** as described in the PRD §3. Phase 2 (AI-powered dynamic follow-up for vague detractor responses) is explicitly out of scope; it ships as a separate spec once Phase 1 has produced 200–300 historical responses for evaluator calibration (PRD §18 "Vagueness Threshold Calibration").

### 1.3 Legacy Check Summary

**Legacy system:** None. This is the first NPS programme in the platform. CAS already serves BRM surveys, but BRM uses event-triggered windows (not cohort sampling) and has no cool-off mechanic — it is not a legacy NPS implementation being replaced.

**Key existing components reviewed:**
- `Survey` entity [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/Survey.java:17-43`] — survey definitions
- `PreprocessedSurvey` entity [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/PreprocessedSurvey.java:17-54`] — per-user survey instances with TTL and state
- `PreprocessedSurveyState` enum [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/enums/PreprocessedSurveyState.java:3-5`] — `NOT_READY, NOT_COMPLETED, COMPLETED, EXPIRED, ABANDONED, DISMISSED`
- `RuleParserHandler` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/service/impl/RuleParserHandler.java:44-265`] — SpEL-based eligibility evaluation
- `RuntimeSurveyScheduler` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/service/impl/RuntimeSurveyScheduler.java:14-131`] — hash-based 3-window distribution over survey duration in days (BRM-specific)
- `SurveyController` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/controller/SurveyController.java`] — `GET /api/surveys/dashboard-info` is the **current de-facto check-in surface**; architecture doc references `POST /v*/check-in` (aspirational — endpoint does not exist)
- Kafka pipeline: `SurveyEventListener` → `SurveyEvaluatorListener` → `SurveyPreprocessorListener` → `CompletedSurveyListener` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/kafka/listener/*Listener.java`] — proven event-driven survey preprocessing
- `PreprocessedSurveyExpirationTriggerJob` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/job/jobs/PreprocessedSurveyExpirationTriggerJob.java:16-52`] — Quartz scheduled job pattern for survey lifecycle

**Capabilities that exist and will be reused:**
- Survey JSON payload model and per-user enrichment (`SurveyBody`, `EventPreprocessSurveyDTO`)
- `PreprocessedSurvey` state machine — `DISMISSED` and `ABANDONED` lifecycle states already handle PRD §9 (reminder eligibility) and PRD §11 (Q1-only "partial completion")
- Multi-survey single-payload via `EventPreprocessSurveyDTO`
- Test doubles `FakeSurveyStorage`, `FakePreprocessedSurveyStorage`, `FakeCacheService`

**Capabilities that do not exist and must be built (treated as [PROPOSED]):**
- Cohort definition / cohort library (PRD §5)
- Weekly sample preparation job + `nps_weekly_sample` table
- Cool-off tracking (`last_nps_triggered_date`) — Bigtable is read-only for CAS, so this must be CAS-owned
- Calendar-week atomicity (ISO week numbering across queries)
- POST check-in endpoint that resolves NPS + CSAT in a single pass
- POS heartbeat NPS delivery
- Weekly NPS score aggregation engine + rolling averages
- Weekly AI summary engine
- NPS Intelligence View API (PM-facing)
- Per-request payload budget enforcement (<1KB combined NPS+CSAT)

**Doc/code discrepancy flagged:** Architecture doc `architecture/c4model/03-component-api-handler.mmd:20` shows `POST /v*/check-in` as the check-in surface, but no such endpoint exists in source. The closest existing endpoint is `GET /api/surveys/dashboard-info`. The PRD describes check-in as a write-style operation that **records** `last_nps_triggered_date` at trigger — that is incompatible with a `GET`. See [Challenge Question C-03](#challenge-questions).

---

## 2. Scope

### In scope (PRD §3 "In Scope")

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | NPS cohort + measurement configuration (entities, admin endpoints) | API Handler | New |
| 2 | NPS eligibility engine (account age, transaction count, cool-off) | Worker | New |
| 3 | Weekly sample preparation job | Worker | New |
| 4 | Check-in API NPS integration — wire NPS eligibility + sample lookup into the check-in API (shape designed separately via `/design-an-interface`, see [C-03](#c-03-resolved)) | API Handler | New |
| 5 | Survey response + reminder logic (week-bounded, dismiss-only reminder) | Worker | Modified |
| 6 | Weekly NPS aggregation (score, %, rolling averages) | Worker | New |
| 7 | NPS Intelligence View API (PM-facing) — quantitative signals + raw free-text responses by classification | API Handler | New |
| 8 | Logging, weekly summary report, payload budget enforcement | Both | New |

### Out of scope

- **POS NPS delivery:** POS heartbeat infrastructure does not exist yet in any service (per [C-04](#c-04-resolved)). PRD §3 and US-17 are deferred. POS NPS ships as a follow-up once POS heartbeat is built.
- **Phase 1.5:** Weekly AI summary engine — structured promoter/detractor synthesis of free-text responses. Deferred per [C-08](#c-08-resolved). Phase 1 exposes raw responses by classification; Phase 1.5 adds the AI synthesis on top.
- **Phase 2:** AI-powered dynamic follow-up question for vague detractor responses (PRD §18). Separate spec once Phase 1 produces calibration data.
- **Check-in API design itself:** the *shape* of the check-in API (path, verb, request/response schema, trigger condition surface) is being designed in a separate foundational exercise via `/design-an-interface` per [C-03](#c-03-resolved). This spec assumes a check-in API will exist; chunk 05 wires NPS into it.
- **BI Platform changes:** Weekly summary data export to ClickHouse/Airflow is handled by the existing analytics pipeline ([VERIFIED: `architecture/c4model/02-container.mmd:51`]). This spec produces the Kafka events the BI Platform already consumes; no ETL changes are part of this spec.
- **Survey UI rendering** (web modal, mobile bottom sheet, POS minimal view). Frontend teams own this. Backend exposes the survey JSON; clients render it.
- **Push notification campaigns for NPS reminders.** Reminder logic is in-app on next qualifying check-in only.

---

## 3. Design Decisions

| # | Decision | Rationale | Alternatives Considered |
|---|---|---|---|
| D1 | Introduce a new top-level subdomain package `module/analytics/nps/` for NPS-specific entities, services, jobs. Shared survey infrastructure stays in `module/analytics/`. | Keeps NPS concerns isolated so CSAT (next feature) can mirror the structure under `module/analytics/csat/`. Avoids polluting the generic survey domain with category-specific code. | (a) Keep everything in `module/analytics/` with `Nps*` prefixes — rejected, leads to drift. (b) Create a top-level `module/nps/` — rejected, breaks the analytics module boundary. |
| D2 | Cool-off tracking lives in a **CAS-owned table `nps_user_state`** keyed by `user_id`, holding `last_nps_triggered_date` and `last_nps_response_classification`. **Cool-off is NPS-specific** [Resolved per [C-05](#c-05-resolved)] — CSAT and BRM each have their own cool-off settings tracked in separate per-category tables. Not in Bigtable. | Bigtable is read-only for CAS [VERIFIED: `architecture/c4model/02-container.mmd:43`]. Cool-off must be writable at trigger time; only CAS-owned MySQL supports that. Optimistic concurrency via `BaseEntity.version` prevents double-trigger on concurrent logins. Per-category separation lets each survey programme tune its cadence independently. | (a) Bigtable — rejected, read-only. (b) Reuse `PreprocessedSurvey` row to track cool-off — rejected, doesn't model the per-user state cleanly and complicates queries across cohorts. (c) Single shared `survey_user_state` for all categories — rejected, conflates programmes with very different cool-off semantics. |
| D3 | Calendar week is identified by **ISO-8601 week-date** (`YYYY-Www` e.g. `2026-W20`), stored as a `CHAR(8)` column. All weekly aggregates and sample membership join on this column. Week boundaries follow `java.time.WeekFields.ISO`. | ISO weeks have a single global definition, do not vary by locale, and are timezone-stable when computed against the user's local zone at trigger time. The PRD says "calendar week" without specifying ISO — but week-aligned reporting across multiple regions requires a canonical week format. | (a) Epoch-week integer — rejected, less debuggable. (b) Date range `(week_start, week_end)` — rejected, redundant when ISO week is unambiguous. |
| D4 | Weekly sample is **materialised** in `nps_weekly_sample` (user_id, week, measurement_id, status) at week start by a Quartz job using ShedLock. Eligibility re-checked at trigger time against gates that can change mid-week (e.g. cool-off from a new sibling cohort if multiple measurements run). | Materialised sample enforces the weekly cap (PRD §7.2 — 3,200/2,134) deterministically. Re-checking gates at trigger time defends against staleness without recomputing the sample. | (a) Compute eligibility lazily at every check-in — rejected, no way to enforce a hard weekly cap. (b) Materialise only the cap, randomise at check-in — rejected, makes "even daily distribution" (PRD §7.3) unenforceable. |
| D5 | **Reuse** `Survey` + `PreprocessedSurvey` entities — do not introduce parallel NPS entities. NPS surveys are admin-configured rows in `Survey` with `category=NPS`, and per-user NPS instances are `PreprocessedSurvey` rows with NPS-specific `additional_data` (cohort ID, week, classification). | Survey, dashboard fetch, alert promotion, push notification, and lifecycle/expiry already work end-to-end. Mirroring all of it for NPS would duplicate ~12 classes. | (a) Dedicated `NpsSurvey` / `NpsResponse` entities — rejected, breaks the unified survey fetch view (`SurveyController.getDashboardInfo`). |
| D6 | A **new dedicated check-in API** is introduced, separate from the existing `GET /api/surveys/dashboard-info` which stays unchanged as the **banner display** API [Resolved per [C-03](#c-03-resolved)]. The check-in API returns: (a) surveys the user is eligible for and sampled into, (b) trigger conditions, (c) optionally the survey contents and schema. Exact path, verb, request, and response schema are designed via `/design-an-interface` as a separate foundational design exercise — the chosen design becomes the input to chunk 05. | The PRD requires a single round trip resolving NPS+CSAT and writing `last_nps_triggered_date` at trigger. The existing `dashboard-info` endpoint serves a different purpose (banner display) and must not be conflated. The check-in API is foundational and will be reused by CSAT and future survey categories — it warrants a deliberate design pass rather than an inline decision. | (a) Repurpose `dashboard-info` — rejected, conflates two concerns. (b) Decide the shape inline in this spec — rejected, the API will outlive every measurement programme; design needs side-by-side option comparison. |
| D7 | **Weekly AI summary is deferred to a follow-up spec** [Resolved per [C-08](#c-08-resolved)]. Phase 1 ships all quantitative signals (NPS score, %s, rolling averages, response funnel) and **raw free-text response access** by classification. The structured AI synthesis (promoter drivers vs detractor drivers) ships in a Phase 1.5 spec once Phase 1 is live and we have a free-text corpus to calibrate against. | Phase 1 delivers business value with quantitative trends + raw qualitative access. AI summary requires its own design pass (model selection, PII strip strategy, security review, cost analysis) and is not blocking the core programme. Deferring reduces Phase 1 chunk count from 10 to 9. | (a) Ship AI summary in Phase 1 with Anthropic Claude — rejected, premature. (b) Ship with a pre-built sentiment library — rejected, doesn't match PRD's structured-output requirement. |
| D8 | Weekly NPS score, %s, rolling averages, and respondent counts are **persisted in `nps_weekly_score`** (one row per measurement per ISO week), computed by a Quartz job at week close + 6 hours. Reads (PM intelligence view) serve from this table. | Aggregations over millions of `PreprocessedSurvey` rows are too slow for an interactive PM view; the table is the read-side projection. Computing post-close gives late responses time to settle (responses past close are discarded per PRD §12.1, but a 6h buffer absorbs clock skew across services). | (a) Compute on read — rejected, latency. (b) Streaming aggregation in Kafka — rejected, premature complexity. |
| D9 | Payload budget enforcement is a **`@Component CheckInPayloadBudgetGuard` [PROPOSED]** that measures the serialised `CheckInResponse` byte length and rejects > 1024 B with a structured warning metric. Daily per-client 50KB budget is enforced by a new Redis-backed counter (`SurveyQuotaService` [PROPOSED] — does not exist in `src/`; built as part of chunk 05 per [C-09](#c-09-resolved)). | Hard size checks at the boundary keep the spec's 1KB invariant testable. No existing rate-limiter for per-client byte budgets was found in `src/` (grep confirms zero matches for `SurveyQuotaService`); chunk 05 builds it. | (a) Trust the design — rejected, PRD calls it non-negotiable. (b) Reuse an existing limiter — none found. |
| D10 | **Feature flag** `nps.programme.enabled` (per-tenant: `personal`, `business`, `pos`) gates the entire NPS pipeline. Disabled flag = no sampling, no triggers, no check-in payload entries — but the codepath is exercised in dev/staging. | Lets us ship code dark and enable per platform during rollout. Aligns with CLAUDE.md feature-flag-driven rollout. | (a) No flag — rejected, single-shot enable too risky for a 24M+ user base. |

---

## 4. Architecture

### 4.1 High-level component map (per chunk)

```
                       ┌────────────────────────────────────────────────────────────┐
                       │                       API Handler                          │
                       │                                                             │
   Client ──────────►  │  CheckInController [PROPOSED — shape TBD per C-03]         │
   (check-in API)      │   └─► CheckInPrecommitService [PROPOSED]                   │
                       │        ├─► NpsEligibilityResolver [PROPOSED]               │
                       │        ├─► CsatEligibilityResolver [NEXT FEATURE — CSAT spec] │
                       │        └─► CheckInPayloadBudgetGuard [PROPOSED]            │
                       │                                                             │
   PM ────GET────────► │  NpsIntelligenceController [PROPOSED]                      │
   /api/v3/nps/...     │   └─► NpsIntelligenceService [PROPOSED]                    │
                       │                                                             │
   Admin ─POST───────► │  AdminNpsCohortController [PROPOSED]                       │
                       │   └─► NpsCohortService [PROPOSED]                          │
                       └────────────────────────────────────────────────────────────┘
                                          │ MySQL (CAS-owned)
                                          ▼
   ┌────────────────────────────────────────────────────────────────────────────┐
   │ Tables (all [PROPOSED] — DDL goes to separate DB migrations repo)          │
   │   nps_cohort                — cohort library (segment, age, entity)        │
   │   nps_measurement           — PM-configured measurement (cohort × scope)   │
   │   nps_user_state            — per-user NPS cool-off + last classification  │
   │   nps_weekly_sample         — materialised weekly invitations              │
   │   nps_weekly_score          — read-side aggregation per measurement × week │
   │ Reused: survey, preprocessed_survey, survey_alert                          │
   └────────────────────────────────────────────────────────────────────────────┘
                                          ▲
                                          │
                       ┌────────────────────────────────────────────────────────────┐
                       │                  Background Worker                         │
                       │                                                             │
                       │ Quartz Jobs (ShedLock) [all PROPOSED]                      │
                       │   • NpsWeeklySamplePreparationJob — runs Mon 00:05 (Africa/│
                       │     Lagos), prepares sample for current ISO week           │
                       │   • NpsWeeklyScoreAggregationJob — runs Mon 06:00, aggregat│
                       │     -es prior ISO week                                     │
                       │   • NpsReminderEvaluationJob — opportunistic; reminder is  │
                       │     served at next check-in, no scheduler tick needed      │
                       │                                                             │
                       │ Kafka Listeners                                            │
                       │   • SurveyEvaluatorListener [VERIFIED] — extended to route │
                       │     NPS via NpsEligibilityResolver                         │
                       │   • CompletedSurveyListener [VERIFIED] — extended to write │
                       │     classification (Promoter/Passive/Detractor) and respond│
                       │     -ent counts for the week                               │
                       │                                                             │
                       │ (AI summary engine deferred to Phase 1.5 spec — see C-08)  │
                       └────────────────────────────────────────────────────────────┘
```

### 4.2 Data flow — happy path (Personal App user becomes a respondent)

1. **Monday 00:05** — `NpsWeeklySamplePreparationJob` opens ISO week `2026-W21`. For each active measurement: resolve eligible users from `nps_cohort` × inclusion gates, exclude users in cool-off, randomly select up to `nps.invitation.cap.personal=3200`, insert rows into `nps_weekly_sample` with `status=PENDING`.
2. **Tuesday** — user logs in. Client invokes the check-in API (shape per `/design-an-interface` output). API Handler calls `NpsEligibilityResolver.resolve(userId)`:
   - Lookup `nps_weekly_sample(user, currentWeek, status=PENDING)` → hit.
   - Re-check cool-off gate against `nps_user_state.last_nps_triggered_date` (defends against staleness mid-week).
   - Atomically: set `nps_weekly_sample.status=SERVED`, write `nps_user_state.last_nps_triggered_date=NOW` (optimistic lock via `@Version`).
   - Return NPS survey reference (or full schema, per check-in API design) in the check-in response payload (combined with CSAT pre-commitment, total < 1024 B; `CheckInPayloadBudgetGuard` asserts).
3. **Tuesday + 5 min** — user picks 9, submits Q2 ("Amazing! …"). Client POSTs response. The existing survey completion path (`CompletedSurveyListener` [VERIFIED]) handles persistence; new `NpsResponseClassifier` [PROPOSED] tags the row with `classification=PROMOTER` and `iso_week=2026-W21`. The `qualitativeResponse` free-text field is stored in the DB but masked in all structured logs as `[redacted-N-chars]`. Raw text is accessible only via the Intelligence View API read path (`GET /api/v3/nps/measurements/{id}/responses`), which requires `NPS_INTELLIGENCE_READ` authority. Reference: `patterns/pii-masking.md`.
4. **Next Monday 06:00** — `NpsWeeklyScoreAggregationJob` reads completed `PreprocessedSurvey` rows for week `2026-W21`, computes NPS = %Promoters − %Detractors, % per band, response rate, persists to `nps_weekly_score`.
5. **PM** opens Intelligence View → `GET /api/v3/nps/measurements/{id}/weekly-scores?from=W17&to=W21` returns the read-side projection in < 200ms. Raw free-text responses are accessible via a paginated `GET /api/v3/nps/measurements/{id}/responses?week=W21&classification=DETRACTOR` endpoint.
6. **Phase 1.5 (out of scope here)** — weekly AI summary job synthesises promoter / detractor drivers from free-text responses (deferred per [C-08](#c-08-resolved)).

### 4.3 POS heartbeat variant

The POS heartbeat endpoint (existing — see [C-04](#challenge-questions)) is extended to include the NPS survey payload when (a) merchant is in current week's sample, (b) `pos.activeTransaction=false` is confirmed by the device's heartbeat body. Same cool-off / reminder / measurement rules apply.

### 4.4 Tier 3 paths touched

Per CLAUDE.md, all three of these require **2 codeowner approvals**:
- `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/` — adding `NpsCohort`, `NpsMeasurement`, `NpsUserState`, `NpsWeeklySample`, `NpsWeeklyScore` entities
- `src/main/java/com/moniepoint/loans/cas/module/analytics/enums/` — adding `NpsRespondentClassification {PROMOTER, PASSIVE, DETRACTOR}`, `NpsWeeklySampleStatus {PENDING, SERVED, RESPONDED, EXPIRED, DISMISSED}`
- `src/main/java/com/moniepoint/loans/cas/module/kafka/` — new event type `NpsResponseClassifiedEvent` published on existing topic `event-completed-survey`

---

## 5. Chunk List

Each chunk is independently mergeable behind the `nps.programme.enabled` feature flag. Order reflects dependencies — sample preparation can't ship before cohort config exists, intelligence view can't ship before aggregation produces data.

| ID | Name | Description | Modules | Est. lines (impl + test) | Depends on |
|----|------|-------------|---------|--------------------------|------------|
| 01 | Cohort library + NPS measurement model + SurveyBody NPS fields | (a) Cohort library: `NpsCohort` entity, cohort attribute model per PRD §5.2 (segment, customer age band, entity, platform), admin CRUD; (b) `NpsMeasurement` entity (cohort × scope), admin CRUD; (c) Extend `SurveyBody` JSON with typed NPS fields (`weeklyInvitationCap`, `reminderMinIntervalHours`, `coolOffDays`, `yearlyTriggerCap`, `q2CopyByBand`) per [C-12](#c-12-resolved); existing `AdminSurveyController` is reused unchanged. Endpoints for cohort/measurement CRUD under `/internal/admin/nps/*`. | API Handler | ~1,100 | — |
| 02 | NPS user state (cool-off + year cap) | `NpsUserState` entity with `last_nps_triggered_date`, `last_nps_response_classification`, `trigger_year`, `trigger_count_year` (per [C-11](#c-11-resolved)); storage with atomic upsert via `@Version` optimistic lock; eviction job for stale rows | Both | ~500 | 01 |
| 03 | NPS eligibility engine | `NpsEligibilityResolver` evaluating account age (≥ 60 days), transaction count (≥ 1 — per [C-01](#c-01-resolved)), 90-day cool-off, AND year cap (max 2 triggers per calendar year — per [C-11](#c-11-resolved)). Reads `UserAttributesStorage` [VERIFIED] and `NpsUserState`; integrates into existing `RuleParserHandler`. Includes test scenario: user with 2 triggers this year is excluded even after 90d cool-off elapses. | Worker | ~650 | 01, 02 |
| 04 | Weekly sample preparation job | `NpsWeeklySamplePreparationJob` (Quartz + ShedLock), random sampling up to caps (Personal: 3,200; Business: 2,134), even daily distribution metadata, observability metrics | Worker | ~700 | 01, 02 |
| 05 | Check-in API NPS integration + daily budget | (a) `NpsEligibilityResolver` + atomic sample/state write inside the check-in controller (shape from `/design-an-interface` output — see Rollout Plan step 0); (b) `CheckInPayloadBudgetGuard` (<1KB per request); (c) Redis-backed `SurveyQuotaService` daily byte budget tracker (<50KB per client per day, per [C-09](#c-09-resolved)). | API Handler | ~1,200 | 03, 04 |
| 06 | Response capture & week-bounded validation | Extend `CompletedSurveyListener`, `NpsResponseClassifier`, response-after-week-close discard with `Response Discarded` event, reminder logic (dismissed-only, configurable interval, single per week) | Worker | ~650 | 05 |
| 07 | Weekly aggregation engine (atomic scores only) | `NpsWeeklyScoreAggregationJob`, `nps_weekly_score` table with **atomic weekly scores only** (rolling averages aggregated downstream by the data team's Airflow pipeline per [C-02](#c-02-resolved)). Persists: NPS, promoter %, passive %, detractor %, population / sample / respondent / response rate. Publishes `NpsWeeklyScoreComputed` Kafka event for downstream Airflow ETL. | Worker | ~450 | 06 |
| 08 | NPS Intelligence View API | PM-facing `GET /api/v3/nps/measurements/*` endpoints: weekly atomic scores, %s, funnel, raw responses by classification (paginated). Rolling-average views served by BI Platform (Grafana/ClickHouse), not CAS. | API Handler | ~500 | 07 |

Total: **~5,750 lines** across **8 chunks** (1,100 + 500 + 650 + 700 + 1,200 + 650 + 450 + 500). Strike Team (3) can run chunks 01, 02, and 04 in parallel after a one-day kickoff sync (04 depends on 01+02 only — it uses `UserAttributesStorage` directly and does not need the `NpsEligibilityResolver` from chunk 03). Chunk 05 waits on the check-in API design output (Rollout Plan step 0).

> **Idempotency is a first-class acceptance criterion for the check-in API design output:** every call resolving the same `(userId, isoWeek)` pair must produce the same sample-served state and must not double-write `NpsUserState`. This requirement must appear explicitly in the `/design-an-interface` brief.

> **Chunk 04 dependency note:** Sample preparation at week start reads eligibility gates directly from `UserAttributesStorage` [VERIFIED] and `NpsUserState` (chunk 02). The full `NpsEligibilityResolver` (chunk 03) is built for real-time check-in use; it is not needed by the batch sampling job.

**Out of Phase 1:**
- **POS heartbeat NPS delivery** — POS heartbeat infrastructure does not exist yet (per [C-04](#c-04-resolved)). Ships in a follow-up phase once POS heartbeat is built.
- **Weekly AI summary** (Phase 1.5) — `outbound/anthropic/AnthropicMessagesClient`, PII strip pipeline, `NpsWeeklyAiSummaryJob`, 24h SLO from week close (per [C-08](#c-08-resolved)).

---

## 6. Capability Test Strategy

Per-chunk unit/integration/slice tests are specified in the per-chunk spec. The cross-cutting concerns below apply to the capability as a whole.

### 6.1 Contract tests

- Check-in API contract (shape per `/design-an-interface` output) — request/response schema pinned via OpenAPI snapshot test. Mobile and Web client teams must regenerate clients off this snapshot before changes ship.
- Kafka event `NpsResponseClassifiedEvent` — Avro/JSON schema pinned for downstream BI Platform consumption (ClickHouse Kafka table engine, see `architecture/c4model/02-container.mmd:51`).
- NPS Intelligence View API — OpenAPI snapshot covering weekly scores, trend, %s, funnel, and paginated raw responses by classification.

### 6.2 E2E tests

- **Golden path:** new user → 60 days elapse → 2 transactions in 30 days → sampled in week W → checks in → serves NPS payload < 1024B → submits rating 9 → classification PROMOTER → aggregated into weekly score at W close.
- **Cool-off path:** triggered user checks in next day → eligibility resolver returns no NPS payload, only CSAT.
- **Cap path:** N+1th eligible user in a week is not in `nps_weekly_sample` → no trigger.
- **Discard path:** user submits a response 1 hour after week close → response discarded, event logged, no weekly_score change.
- **Reminder path:** user dismisses on day 1 → returns day 2 (above min interval) → reminder shown once → returns day 3 → no further prompt.

### 6.3 Performance / load targets

| Operation | P99 | Throughput |
|---|---|---|
| Check-in API (NPS+CSAT resolution) | < 80 ms | 5,000 rps sustained |
| `NpsWeeklySamplePreparationJob` (full Personal cohort, ~24M users) | < 10 min wall clock | runs once per week |
| `NpsWeeklyScoreAggregationJob` (all measurements, one week) | < 5 min | runs once per week |
| `GET /api/v3/nps/measurements/{id}/weekly-scores` (read-side) | < 200 ms | 50 rps |
| `GET /api/v3/nps/measurements/{id}/responses?week=&classification=` (paginated raw responses) | < 300 ms (page of 50) | 20 rps |

### 6.4 Smoke tests (post-deployment)

- Check-in API returns 200 with an empty NPS payload for a synthetic test user that fails all gates — verifies the codepath without producing real data.
- `nps_user_state` upsert verified with a fixed-week test fixture so we know optimistic locking didn't regress.

---

## 7. Rollout Plan

Order is strict — earlier steps gate later ones.

| Step | Action | Rollback |
|------|--------|----------|
| 0 | Approve the check-in API design via `/design-an-interface` (separate workstream). Chunk 05 cannot start until this lands. | Re-open the design exercise. |
| 1 | Merge all 9 chunks with `nps.programme.enabled=false` (default). Deploy to staging. | n/a |
| 2 | Coordinate with DB migrations team to apply DDL for the 5 new tables (cohort, measurement, user_state, weekly_sample, weekly_score). Migration is **additive only** — no rollback DDL needed; tables sit empty. | Drop unused tables if abandoning. |
| 3 | Run end-to-end staging smoke with synthetic cohort of 50 users. Verify check-in payload, sample preparation, aggregation, AI summary. | Disable flag. |
| 4 | Enable flag `nps.programme.enabled[personal]=true` for 1% of Personal users via tenant-scoped allowlist. Run for 1 week. | Disable allowlist. |
| 5 | Compare week's score against PM's manual NPS calculation on the same sample — must match within rounding. | Disable allowlist; investigate divergence. |
| 6 | Scale Personal to 10% → 50% → 100% over 4 weeks. | Disable flag at any step. |
| 7 | Repeat steps 4–6 for Business. | Disable Business flag. |
| 8 | POS NPS rollout is **deferred** until POS heartbeat infrastructure is built (see [C-04](#c-04-resolved)). Ships as a follow-up phase. | n/a |
| 9 | `GET /api/surveys/dashboard-info` stays — it serves the survey banner display, a separate concern from check-in [Resolved per [C-03](#c-03-resolved)]. No deprecation as part of this rollout. | n/a |

Per CLAUDE.md, this is a Tier 3 change (entities + enums + kafka). Two codeowner approvals required at each MR.

---

## 8. Security Threat Model

Evaluated against OWASP API Security Top 10 for the NPS surface introduced in this spec. Every risk marked **Yes** has Impact and Mitigation populated.

| OWASP Risk | Applicable | Impact | Mitigation |
|---|---|---|---|
| API1 — Broken Object Level Authorization | **Yes** | `GET /api/v3/nps/measurements/{id}/responses` exposes free-text responses linked to `userId`. A PM principal with access to one measurement could enumerate responses from a different measurement's `id`. | `NpsIntelligenceController` [PROPOSED] validates the calling principal's authority scope against `measurementId → NpsMeasurement.cohortId → entityScope` at the service layer before any query executes. Integration test asserts 403 on cross-measurement access. |
| API2 — Broken Authentication | **Yes** | Admin CRUD endpoints at `/internal/admin/nps/*` must not be reachable from the public internet. They carry no `@PreAuthorize` (per CLAUDE.md internal-endpoint convention), relying entirely on network-layer protection. | k8s Ingress does not route `/internal/` path prefix to the public; protected by cluster network policy. Integration test asserts that a request originating outside the cluster boundary receives a connection-refused response, not a 401/403 (which would indicate the route exists). |
| API3 — Broken Object Property Level Authorization | **Yes** | The check-in response may include a `SurveyBody` containing internal config fields (`weeklyInvitationCap`, `coolOffDays`, `yearlyTriggerCap`) that are operational metadata and must not reach the client. | The check-in response DTO is a purpose-built `CheckInSurveyItem` [PROPOSED] record that maps only client-visible fields (surveyId, schema copy, triggerConditions). `SurveyBody` config fields are never serialized into this record. Covered by a unit test asserting no config field appears in the serialized response. |
| API4 — Unrestricted Resource Consumption | **Yes** | (a) `NpsWeeklySamplePreparationJob` iterating 24M+ eligible users in an unbounded query risks OOM and prolonged lock-hold. (b) `GET /api/v3/nps/measurements/{id}/weekly-scores` scanning unbounded history risks slow queries and large result sets. | (a) Job uses paginated batch processing (`nps.sampling.batch-size`, default 1,000 rows per page); ShedLock prevents concurrent re-runs. (b) Intelligence View enforces a max date-range cap (`nps.intelligence.max-weeks`, default 52); requests exceeding the cap receive a 400 with a descriptive error. |
| API5 — Broken Function Level Authorization | **No** | All public endpoints use `@PreAuthorize`; admin endpoints use k8s network policy. No function-level bypass identified in the proposed design. | — |
| API6 — Unrestricted Access to Sensitive Business Flows | **Yes** | A duplicate check-in call (network retry, double-tap) could double-trigger the NPS survey — writing `last_nps_triggered_date` twice and double-consuming the user's annual cap. | `NpsWeeklySample.status` transition PENDING → SERVED is guarded by the `@Version` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/common/entity/BaseEntity.java`] optimistic lock. A concurrent second call receives `OptimisticLockException`; the service layer catches this and returns the already-served state without re-writing `NpsUserState`. Unit test: two concurrent `serve()` calls on the same sample row; one succeeds, one is idempotently resolved. |
| API7 — Server Side Request Forgery | **No (Phase 1)** | No user-supplied URLs are followed in Phase 1. No outbound HTTP calls are driven by user-controlled input. Anthropic API integration is deferred to Phase 1.5. | — |
| API8 — Security Misconfiguration | **Yes** | `GET /api/v3/nps/measurements/{id}/responses` exposes free-text survey responses that may contain PII (e.g. a user naming a person in their feedback). The endpoint must be explicitly authorized and free-text must be excluded from structured logs. | Endpoint annotated with `@PreAuthorize("hasAuthority(@Authorities.NPS_INTELLIGENCE_READ)")`. Free-text `qualitativeResponse` fields are logged only as `[redacted-N-chars]` per PII masking rule (`patterns/pii-masking.md`). Both requirements are acceptance criteria for chunk 08. |
| API9 — Improper Inventory Management | **No** | All proposed endpoints are documented in OpenAPI. No shadow/undocumented routes introduced. | — |
| API10 — Unsafe Consumption of APIs | **No (Phase 1)** | BigTable user-attribute reads (`UserAttributesStorage.findUser()` [VERIFIED]) are typed, bounded queries with no user-supplied data echoed back as a URL, command, or filename. Anthropic API consumption is deferred to Phase 1.5 and will require its own threat-model row in the Phase 1.5 spec. | — |

### Cross-cutting security rules (CLAUDE.md enforced)

| Rule | Application to NPS |
|---|---|
| **PII Protection** | `qualitativeResponse` (free-text) and `userId` excluded from INFO-level logs. Free-text accessible only via authenticated Intelligence View endpoint. |
| **Idempotency** | Check-in trigger write path guarded by `@Version` (API6 above). Admin POST endpoints (cohort/measurement CRUD) carry an `Idempotency-Key` header requirement — specified as acceptance criterion in chunk 05 and chunk 01 chunk specs. |
| **No Secrets in Code** | Anthropic API key (Phase 1.5) to be stored in Vault / Secret Manager — not in `application.yml`. Requirement captured in Phase 1.5 spec. |
| **No Silent Exception Swallowing** | `OptimisticLockException` on double-trigger re-throw as structured `ServerException`; not silently swallowed. Covered by chunk 05 error-path test. |

---

## Challenge Questions

Resolve every numbered question before chunk specs are written. Unresolved questions block chunk 01.

### C-01 [Resolved] — Eligibility threshold: 1 transaction

**Resolution (engineer, 2026-05-18):** Use **`transaction_count(last_30_days) >= 1`**. The PRD label "1 transaction in last 30 days" is the authoritative copy; the logic column `>= 2` and AC-04.1 are PRD authoring errors and will be fed back to the PM for correction.

**Impact on spec:** Chunk 03 (NpsEligibilityResolver) enforces `>= 1`. Engagement gate test scenarios in chunk 03 cover `count=0` (excluded), `count=1` (included), `count=2+` (included).

### C-02 [Resolved] — Rolling averages computed by data team Airflow pipeline, not CAS

**Resolution (engineer, 2026-05-18):** Rolling averages (4 / 7 / 12 / 28-week or whichever set the PRD finalises) are aggregated by the **data team's Airflow pipeline** downstream from CAS — they feed the BI Platform dashboards. CAS produces only the atomic weekly score and persists it in `nps_weekly_score`. Airflow reads from the BI Platform feed (Kafka `event-completed-survey` and / or MySQL replica) and computes rolling views.

**Impact on spec:**
- Chunk 07 (Weekly aggregation engine, formerly chunk 08) trims rolling-average computation; it only persists atomic weekly scores. Estimated lines drop ~650 → ~450.
- Chunk 08 (Intelligence View API, formerly chunk 09) exposes weekly atomic scores only. Rolling-average views are served by the BI Platform (Grafana) reading from ClickHouse.
- §6.3 performance row for `weekly-scores` endpoint stays — atomic scores still served from CAS read-side projection.
- §4.1 architecture diagram comment: rolling averages happen downstream in Airflow / ClickHouse, not in CAS.

**Follow-up:** Confirm with the data team owning Airflow that the `nps_weekly_score` table is being read (or that CAS publishes a `NpsWeeklyScoreComputed` Kafka event) so the Airflow ETL can run.

### C-03 [Resolved] — Check-in API is a separate foundational design

**Resolution (engineer, 2026-05-18):** The existing `GET /api/surveys/dashboard-info` is the **banner display** API — it tells the client "the user has a survey waiting" and is not the check-in concept. The check-in API is a separate, foundational API that returns:

1. Surveys the user is **eligible for and has been sampled into**
2. Trigger conditions (when the survey should be shown — e.g. dashboard load, POS heartbeat, etc.)
3. Optionally, the survey contents and schema (so the client can render without a follow-up call)

Because the check-in API is foundational (used by NPS, CSAT, future categories) and the shape decision is expensive to reverse, the API design is being run as a **separate workstream via `/design-an-interface`** — that skill produces side-by-side design options with parallel sub-agents. The chosen design becomes the input to chunk 05 in this spec.

**Impact on spec:**
- D6 updated to reflect "shape TBD via /design-an-interface".
- Rollout plan adds step 0: "Approve check-in API design before chunk 05 starts."
- `dashboard-info` endpoint stays unchanged — no deprecation in scope.
- Chunk 05 description marked as "blocked until check-in API design approved".

**Next step:** Engineer to invoke `/design-an-interface` for the check-in API once this overview spec is finalised.

### C-04 [Resolved] — POS heartbeat does not exist yet; POS NPS deferred

**Resolution (engineer, 2026-05-18):** The POS heartbeat infrastructure **does not exist** anywhere yet. Building it is a substantial workstream (heartbeat endpoint, active-transaction signalling, multi-survey payload, device fleet rollout) that is out of scope for the NPS Phase 1 spec.

**Impact on spec:**
- Chunk 07 (POS heartbeat NPS delivery) is **removed from Phase 1**.
- §2 Out of scope adds "POS NPS delivery — requires POS heartbeat infrastructure which does not exist yet; ships once heartbeat is in place".
- §2 Scope row for POS removed; PRD §3 still calls POS in scope but the dependency (heartbeat) is missing.
- US-17 (POS Heartbeat Delivery) acceptance criteria are deferred — flag back to PM.
- Phase 1 chunk count drops 9 → 8.

**Follow-up:** Surface to PM that POS NPS ships only after POS heartbeat infrastructure is delivered as a separate workstream.

### C-05 [Resolved] — Cool-off is NPS-specific, applied globally across NPS measurements

**Resolution (engineer, 2026-05-18):** The 90-day cool-off is **NPS-specific** — it does NOT span CSAT or BRM. Each survey category has its own cool-off settings. Within NPS, the cool-off is **global across all NPS measurements** (one user appears in at most one NPS measurement's sample per 90-day window).

**Impact on spec:**
- D2 updated: cool-off table is `nps_user_state` (NPS-specific name), and CSAT/BRM will get their own per-category state tables.
- Chunk 04 sample preparation excludes users with `nps_user_state.last_nps_triggered_date > NOW − 90 days` before any cohort-specific selection — applies across all active NPS measurements.
- CSAT (next feature) builds its own `csat_user_state` mirroring this pattern; cool-off periods are independently configurable per category.

### C-06 [Resolved] — CAS-owned `nps_user_state` table confirmed

**Resolution (engineer, 2026-05-18):** Use the CAS-owned MySQL table `nps_user_state` as per design decision D2. No Bigtable write path required.

**Impact on spec:** D2 stands as written. Chunk 02 implements the table and storage.

### C-07 [Resolved] — Build cohort library inside chunk 01

**Resolution (engineer, 2026-05-18):** Chunk 01 builds both the cohort library (segment, customer age, entity attributes per PRD §5.2) AND the measurement model on top of it.

**Impact on spec:** Chunk 01 est. lines bumped ~700 → ~1,000 (adds ~300 lines for cohort library admin endpoints, storage, and validation). Chunk 01 description in §5 updated to call out both responsibilities.

### C-08 [Resolved] — AI summary deferred to Phase 1.5

**Resolution (engineer, 2026-05-18):** **Drop chunk 10 (Weekly AI summary) from Phase 1.** Phase 1 ships all quantitative signals (NPS score, %s, rolling averages, response/sample/population funnel) and **raw free-text response access by classification** (paginated endpoint). The structured AI synthesis (promoter drivers vs detractor drivers) ships in a Phase 1.5 spec on top of the data Phase 1 produces.

**Impact on spec:**
- Chunk count drops from 10 → 9; total est. lines drops ~6,400 → ~5,650.
- D7 updated to reflect deferral.
- §2 Out of scope adds Phase 1.5 line item.
- §4.1 Architecture component map removes `NpsWeeklyAiSummaryJob` and `AnthropicMessagesClient`.
- §4.2 Data flow step 5 retains raw response access; AI summary step removed.
- §6.1 Contract tests removes Anthropic recorded fixtures.
- §6.3 Performance table removes the AI summary row.
- §6.4 Smoke tests removes Anthropic smoke.
- `nps_weekly_summary` table removed from §4.1.
- C-10 (Anthropic key + PII strip approval) becomes moot for Phase 1 and is dropped from the open question list.

### C-09 [Resolved] — Build per-client byte budget tracker in chunk 05

**Resolution (engineer, 2026-05-18):** Build a Redis-backed daily byte counter keyed by `client_id`, evaluated by `CheckInPayloadBudgetGuard`. Hard reject + structured metric when the 50KB/day budget is exceeded. Lives inside chunk 05.

**Impact on spec:** Chunk 05 est. lines bumped ~800 → ~1,200 (adds ~400 lines for Redis counter, key/TTL design, eviction, observability metric `nps.check_in.daily_budget_exceeded`). Chunk 05 description in §5 updated.

### C-10 — Dropped

Moot after C-08 resolution (AI summary deferred to Phase 1.5). Will resurface in the Phase 1.5 spec.

### C-11 [Resolved] — Hard cap: max 2 NPS triggers per calendar year

**Resolution (engineer, 2026-05-18):** The "twice per year" rule is a **hard ceiling** on top of the 90-day cool-off. AC-12.5 is enforced literally.

**Impact on spec:**
- `nps_user_state` adds a `trigger_count_year SMALLINT NOT NULL DEFAULT 0` column and a `trigger_year SMALLINT NOT NULL` column (so we know which year the count belongs to and reset on year rollover).
- Chunk 03 (eligibility resolver) adds an annual-trigger gate: `nps_user_state.trigger_year == currentYear AND nps_user_state.trigger_count_year >= 2` → exclude.
- Chunk 05 atomic trigger write increments `trigger_count_year` (and resets when the year flips).
- Chunk 02 entity reflects both columns.
- Test scenario added to chunk 03: user with 2 triggers already in current year is excluded even if last trigger > 90 days ago.

### C-12 [Resolved] — Admin-managed Survey rows; NPS config lives inside SurveyBody JSON

**Codebase finding (2026-05-18):** CAS today has the `Survey` entity [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/Survey.java:17-43`] with a JSON `survey` column storing `SurveyBody` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/dto/v3/SurveyBody.java`]. `AdminSurveyController` already supports CRUD on Survey rows. **Zero NPS survey rows are seeded today** — the `SurveyCategory.NPS` enum value exists but no rows reference it.

**Resolution (engineer, 2026-05-18):** Use the existing admin-managed Survey row pattern with NPS-specific config encoded as **typed fields inside `SurveyBody` JSON**. This aligns with the prior codebase analysis recommendation (`docs/codebase-analysis-nps-csat-2026-05-18.md:285`) and avoids a DB schema change for config.

**Impact on spec:**
- Up to 4 admin-managed Survey rows seeded post-deployment: Personal+Mobile, Personal+Web, Business+Mobile, Business+Web. (POS row deferred until POS heartbeat exists — per [C-04](#c-04-resolved).)
- `SurveyBody` gains typed fields `[PROPOSED]`: `weeklyInvitationCap`, `reminderMinIntervalHours`, `coolOffDays` (default 90), `yearlyTriggerCap` (default 2), `q2CopyByBand: { detractor, passive, promoter }` for A/B-editable Q2 copy. Chunk 01 adds these to `SurveyBody`.
- Fetch and render pipeline unchanged — existing `PreprocessedSurveyRepositoryService` and `SurveyPreprocessorListener` handle multi-category JSON correctly today.
- Chunk 01 description updated to call out the seeded Survey rows (via existing `AdminSurveyController`) as part of post-merge configuration — not code work.

---

## Next Steps After Resolution

1. Engineer resolves C-01 … C-12 inline in this document.
2. Run `/validate-spec impl-specs/2026-05-18-nps-sampling-engine.md` to catch internal inconsistencies before chunk specs are written.
3. For each chunk in `§5 Chunk List` (in dependency order), generate a chunk spec via `/generate-impl-spec` in chunk mode.
4. Strike Team kickoff: assign chunks 01 / 02 / 04 to parallel engineers; chunks 03 / 05 onwards are sequential.
5. After chunks 01-05 land, repeat the same overview-then-chunks process for CSAT (PRD: PO1/3308421134) — CSAT can reuse the cohort, eligibility, check-in, and aggregation foundations established here.
