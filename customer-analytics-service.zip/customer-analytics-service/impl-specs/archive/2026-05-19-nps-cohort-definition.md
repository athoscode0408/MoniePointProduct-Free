# Implementation Spec: NPS Cohort Definition

## Document Info

| Field | Value |
|---|---|
| Status | Draft |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-19 |
| PRD | [NPS PRD — teamapt Confluence PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) (v1.0, April 2026) |
| Deployment Units | API Handler + Background Worker |
| Companion Design Doc | [`docs/design/nps-cohort-definition-design.md`](../docs/design/nps-cohort-definition-design.md) — entity schemas, gate algorithm, sequence diagrams, forward-looking evolution path |
| ADRs | [`ADR-001 Cohort Design Strategy`](../adrs/ADR-001-cohort-design-strategy.md), [`ADR-002 Cohort Eligibility Integration`](../adrs/ADR-002-cohort-eligibility-integration.md) |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Entity name: `Cohort` vs `NpsCohort` | Named `Cohort` — reusable for CSAT and BRM without schema changes. `survey_category` column scopes it per category. |
| D-02 | Cohort management model | Engineering-seeded via DB migrations only. No PM admin CRUD API for cohorts. |
| D-03 | Phase 1 seed cohorts | Two: Personal Banking NPS + Business Banking NPS. Both require 60-day account age and 1 transaction in last 30 days. |
| D-04 | Eligibility gate integration | `CohortEligibilityGate` service, called from weekly sampling job only. SpEL pipeline (`RuleParserHandler`) is not modified. See ADR-002. |
| D-05 | `cohort_id` placement | Explicit `@Column(name = "cohort_id")` on `PreprocessedSurvey`. Not inside `additionalData` JSON. |
| D-06 | `NpsMeasurement` entity | Not introduced. `Cohort.survey_id` FK directly links a cohort to its survey row. |
| D-07 | SurveyBody NPS config fields | 5 new typed fields added to `SurveyBody`: `weeklyInvitationCap`, `reminderMinIntervalHours`, `coolOffDays`, `yearlyTriggerCap`, `q2CopyByBand`. |
| D-08 | Cohort design strategy | DB-seeded static columns. Forward-compatible with future `rule_definition JSON` column. See ADR-001. |

---

## 1. Context

### 1.1 Why now

The NPS Sampling Programme spec (`2026-05-18-nps-sampling-engine.md`) was authored with a placeholder for "build cohort library inside chunk 01" (decision C-07, resolved 2026-05-18). That spec treated cohort definition as a sub-component of the larger 8-chunk NPS programme. As spec work progressed, the cohort model revealed enough design surface — entity schema, eligibility gate integration, `SurveyBody` config fields, forward-compatible DB design — to warrant its own focused spec before implementation begins.

This spec covers **only the cohort definition layer**: the `Cohort` entity, the `CohortEligibilityGate` service, the `cohort_id` column on `PreprocessedSurvey`, and the five new `SurveyBody` NPS config fields. The weekly sampling job that calls `CohortEligibilityGate` is specified in the NPS Sampling Programme spec; this spec defines the components that job depends on.

### 1.2 Scope summary

This spec delivers the foundational cohort infrastructure that the NPS weekly sampling job, the check-in API, and the intelligence view depend on. It does not introduce any user-facing API changes — no new endpoints, no changes to existing endpoints. It is entirely a Worker + entity-layer change with a single new `cohort_id` column on a shared entity.

### 1.3 Legacy check (what exists, what is reused)

**What exists today:**

- `Survey` entity [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/Survey.java`] — survey definitions with `category = NPS` supported as an enum value but no NPS rows seeded.
- `SurveyCategory` enum [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/enums/SurveyCategory.java`] — `BRM, CSAT, NPS` already defined.
- `PreprocessedSurvey` entity [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/entity/PreprocessedSurvey.java`] — per-user survey instances. Has `additionalData` JSON column but no `cohort_id`.
- `SurveyBody` DTO [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/dto/v3/SurveyBody.java`] — JSON model for the `Survey.survey` column. Has `@JsonAnySetter` for unknown fields; NPS config fields will be added as typed fields.
- `UserAttributes` DTO [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/dto/v3/UserAttributes.java`] — includes `lastTxnDate: LocalDate` (line 96) and `onboardingDate: LocalDateTime` (line 74). Both available for gate evaluation.
- `SurveyEvaluatorListener` → `RuleParserHandler` [VERIFIED] — SpEL pipeline for BRM/CSAT. **Not modified by this spec.**
- `EventPreprocessSurveyDTO` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/dto/v3/EventPreprocessSurveyDTO.java`] — Kafka payload from eligibility gate to preprocessor. Needs a `cohortId` field added.
- `SurveyPreprocessorListener` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/kafka/listener/SurveyPreprocessorListener.java`] — persists `PreprocessedSurvey`. Needs one line added to propagate `cohortId`.
- `BaseEntity` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/common/entity/BaseEntity.java`] — `id`, audit fields, `@Version`. All new entities extend this.
- Quartz job pattern [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/job/jobs/PreprocessedSurveyExpirationTriggerJob.java`] — `ClusteredJob` interface, ShedLock convention. Reused for future NPS sampling job.

**What does not exist and is built by this spec:**

- `Cohort` entity — `[PROPOSED]`
- `CohortStorage` repository — `[PROPOSED]`
- `CohortEligibilityGate` interface + `CohortEligibilityGateImpl` — `[PROPOSED]`
- `SurveySegment`, `CohortPlatform` enums — `[PROPOSED]`
- `cohort_id` column on `PreprocessedSurvey` — `[PROPOSED]`
- `cohortId` field on `EventPreprocessSurveyDTO` — `[PROPOSED]`
- Five new typed fields on `SurveyBody` — `[PROPOSED]`

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | `Cohort` entity with all columns, `CohortStorage` repository | Worker | New |
| 2 | DB DDL spec: `cohort` table + two seed rows (Personal Banking NPS, Business Banking NPS) | DB Migrations repo | New |
| 3 | `SurveySegment` enum (`PERSONAL_BANKING`, `BUSINESS_BANKING`, `AGENTS`) | Worker | New |
| 4 | `CohortPlatform` enum (`PERSONAL_APP`, `BUSINESS_APP`, `POS`, `ALL`) | Worker | New |
| 5 | `CohortEligibilityGate` interface + `CohortEligibilityGateImpl` | Worker | New |
| 6 | Nullable `cohort_id` column on `PreprocessedSurvey` entity | Both | Modified |
| 7 | DB DDL spec: `ALTER TABLE preprocessed_survey ADD COLUMN cohort_id` | DB Migrations repo | New |
| 8 | `cohortId` field on `EventPreprocessSurveyDTO` | Worker | Modified |
| 9 | `SurveyPreprocessorListener` — propagate `cohortId` to `PreprocessedSurvey` | Worker | Modified |
| 10 | Five NPS config fields on `SurveyBody` + `Q2CopyByBand` nested type | Both | Modified |
| 11 | Unit tests for `CohortEligibilityGateImpl` (all gate scenarios) | Both | New |

### Out of scope

| # | Component | Reason |
|---|---|---|
| — | Weekly sampling job (`NpsWeeklySamplePreparationJob`) | Specified in `2026-05-18-nps-sampling-engine.md` chunk 04. Depends on this spec's components but is not in this spec. |
| — | `NpsUserState` entity and cool-off tracking | Specified in `2026-05-18-nps-sampling-engine.md` chunk 02. |
| — | Admin CRUD API for cohorts | Cohorts are engineering-managed via DB migrations. No PM-facing admin endpoints. |
| — | Check-in API integration | Chunk 05 of the NPS Sampling Programme spec. Depends on this spec's `Cohort` entity. |
| — | NPS Intelligence View API | Chunk 08 of the NPS Sampling Programme spec. |
| — | CSAT cohort definition | Future spec. `Cohort` entity designed to support CSAT but no CSAT rows seeded here. |
| — | `NpsMeasurement` entity | Not introduced. `Cohort.survey_id` FK replaces it for Phase 1. |
| — | `rule_definition JSON` column | Phase 2 evolution. The static-column design is forward-compatible. See ADR-001 §Forward-Looking. |

---

## 3. Design Decisions

| # | Decision | ADR |
|---|---|---|
| D1 | Cohort membership criteria stored as static columns on a DB-seeded `cohort` table. Evaluation logic in typed Java (`CohortEligibilityGateImpl`). New cohorts added via DB row inserts, not code changes. | [ADR-001 Cohort Design Strategy](../adrs/ADR-001-cohort-design-strategy.md) |
| D2 | Cohort eligibility evaluated by a dedicated `CohortEligibilityGate` service called from the weekly sampling job only. SpEL pipeline (`RuleParserHandler`) is not modified. | [ADR-002 Cohort Eligibility Integration](../adrs/ADR-002-cohort-eligibility-integration.md) |

---

## 4. Architecture

### 4.1 Component map

```
                  ┌───────────────────────────────────────────────────┐
                  │               Background Worker                    │
                  │                                                    │
                  │  NpsWeeklySamplePreparationJob  [SAMPLING SPEC]   │
                  │    ├─► CohortStorage.findActiveCohorts()  [NEW]   │
                  │    ├─► UserAttributesStorage.findUser()  [REUSED] │
                  │    └─► CohortEligibilityGate.evaluate()   [NEW]   │
                  │                                                    │
                  │  SurveyPreprocessorListener  [MODIFIED]           │
                  │    └─► reads EventPreprocessSurveyDTO.cohortId    │
                  │         sets PreprocessedSurvey.cohortId  [NEW]   │
                  └───────────────────────────────────────────────────┘
                                     │ MySQL (CAS-owned)
                                     ▼
  ┌─────────────────────────────────────────────────────────────────────┐
  │ Tables                                                               │
  │   cohort          [NEW]  — cohort definitions (2 seed rows)         │
  │   preprocessed_survey    — gains cohort_id BIGINT NULL  [MODIFIED]  │
  │ Reused (unchanged): survey, nps_weekly_sample, nps_user_state       │
  └─────────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────────┐
  │ DTOs (both deployment units)                                         │
  │   EventPreprocessSurveyDTO  — gains cohortId: Long  [MODIFIED]      │
  │   SurveyBody  — gains 5 NPS config fields  [MODIFIED]               │
  └─────────────────────────────────────────────────────────────────────┘
```

**SpEL pipeline (BRM/CSAT) — unchanged:**

```
Analytics Event → SurveyEvaluatorListener → RuleParserHandler → EventPreprocessSurveyDTO
  (cohortId = null) → SurveyPreprocessorListener → PreprocessedSurvey (cohort_id = NULL)
```

**NPS cohort evaluation path (new):**

```
NpsWeeklySamplePreparationJob
  → CohortEligibilityGate.evaluate(cohort, user, today)
  → [pass] → insert nps_weekly_sample row (cohortId, userId, isoWeek, PENDING)
  → [at check-in] → NpsEligibilityResolver (sampling spec)
  → EventPreprocessSurveyDTO (cohortId populated)
  → SurveyPreprocessorListener
  → PreprocessedSurvey (cohort_id = <cohortId>)
```

### 4.2 Data flow — cohort evaluation in the sampling job

```
Monday 00:05 Africa/Lagos
  NpsWeeklySamplePreparationJob.execute():
    cohorts = CohortStorage.findBySurveyCategoryAndActiveTrue(NPS)   // 2 cohorts
    for each cohort in cohorts:
      invitationCap = surveyBody.weeklyInvitationCap                  // from SurveyBody
      sampledCount = 0
      page = 0
      while sampledCount < invitationCap:
        users = UserAttributesStorage.findPage(cohort.segment, page, batchSize)
        if users.isEmpty(): break
        for each user in users:
          if CohortEligibilityGate.evaluate(cohort, user, today)      // Gate 1 + Gate 2
             AND NOT npsUserStateStorage.isInCoolOff(user.id)         // cool-off check
             AND sampledCount < invitationCap:
            npsWeeklySampleStorage.insert(userId, cohort.id, cohort.surveyId, isoWeek, PENDING)
            sampledCount++
        page++
```

### 4.3 Tier 3 paths touched

Per CLAUDE.md, these require **2 CODEOWNER approvals**:

| Path | Change | Reason |
|---|---|---|
| `src/main/java/**/module/analytics/entity/` | Add `Cohort` entity; modify `PreprocessedSurvey` (new `cohortId` field) | Entity changes have DB implications; coordinate DDL with DB migrations repo |
| `src/main/java/**/module/analytics/enums/` | Add `SurveySegment`, `CohortPlatform` enums | Enum changes break Kafka consumers if serialised as STRING — risk is low here (not on Kafka payloads) but Tier 3 approval still required |
| `src/main/java/**/module/kafka/` | Modify `EventPreprocessSurveyDTO` (add `cohortId` field) | Kafka event contract change; coordinate with consumers |

---

## 5. Chunk List

| ID | Name | Description | Modules | Est. lines (impl + test) | Depends on |
|----|------|-------------|---------|--------------------------|------------|
| C-01 | Cohort entity + CohortStorage + DDL + seed data | (a) `Cohort` entity with all columns per design doc §3.1; (b) `SurveySegment` and `CohortPlatform` enums; (c) `CohortStorage` repository (`findBySurveyCategoryAndActiveTrue(SurveyCategory)`); (d) DDL spec for `cohort` table + two seed rows (Personal Banking NPS, Business Banking NPS) to raise in DB migrations repo. No admin API — cohorts are engineering-managed only. | Worker | ~350 | — |
| C-02 | cohort_id on PreprocessedSurvey + DTO + listener propagation | (a) Nullable `cohortId: Long` field on `PreprocessedSurvey` entity with `@Column(name = "cohort_id")`; (b) DDL spec for `ALTER TABLE preprocessed_survey ADD COLUMN cohort_id` to raise in DB migrations repo; (c) `cohortId: Long` field on `EventPreprocessSurveyDTO`; (d) One-line addition to `SurveyPreprocessorListener.preprocessSurvey()` to propagate `dto.getCohortId()` to the entity before save. | Worker | ~100 | C-01 |
| C-03 | CohortEligibilityGate service + unit tests | (a) `CohortEligibilityGate` interface with `evaluate(Cohort, UserAttributes, LocalDate): boolean`; (b) `CohortEligibilityGateImpl` implementation with Gate 1 (account age) and Gate 2 (recent transaction); (c) Full unit test suite covering all gate scenarios (see §6). | Worker | ~300 | C-01 |
| C-04 | SurveyBody NPS config fields | (a) Five new typed fields on `SurveyBody`: `weeklyInvitationCap: int`, `reminderMinIntervalHours: int`, `coolOffDays: int`, `yearlyTriggerCap: int`, `q2CopyByBand: Q2CopyByBand`; (b) `Q2CopyByBand` nested static class with `detractor`, `passive`, `promoter` string fields; (c) Validation constraints (`weeklyInvitationCap > 0`, `coolOffDays >= 1`, `yearlyTriggerCap >= 1`, `reminderMinIntervalHours >= 1`) applied in any service that reads these fields; (d) Deserialization test asserting correct round-trip for NPS survey JSON with all five fields populated; (e) Deserialization test asserting BRM/CSAT `SurveyBody` payloads without the new fields still deserialise correctly (backward compatibility). | Both | ~200 | — |

Total: **~950 lines** across **4 chunks**. Chunks C-01 and C-04 are independent and can be parallelised. C-02 depends on C-01 (needs `Cohort` entity to write the FK). C-03 depends on C-01 (needs `Cohort` entity as a method parameter). C-02 and C-03 can run in parallel after C-01 merges.

---

## 6. Capability Test Strategy

### C-01 — Cohort entity + CohortStorage

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-01.1 | `CohortStorage.findBySurveyCategoryAndActiveTrue(NPS)` returns only active NPS rows | Unit (H2) | Two active NPS rows → 2 returned; one inactive → excluded |
| T-01.2 | `CohortStorage.findBySurveyCategoryAndActiveTrue(CSAT)` returns empty when no CSAT cohorts exist | Unit (H2) | Returns empty list |
| T-01.3 | Cohort FK to survey is enforced | Integration (TestContainers) | Insert cohort with non-existent survey_id → constraint violation |
| T-01.4 | `BaseEntity.version` increments on update | Unit (H2) | Optimistic lock prevents concurrent modification |

### C-02 — cohort_id column + propagation

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-02.1 | `SurveyPreprocessorListener` sets `cohortId` on `PreprocessedSurvey` when DTO carries a `cohortId` | Unit | Saved `PreprocessedSurvey.cohortId` equals DTO value |
| T-02.2 | `SurveyPreprocessorListener` leaves `cohortId` null when DTO has null `cohortId` (BRM path) | Unit | Saved `PreprocessedSurvey.cohortId` is null |
| T-02.3 | `PreprocessedSurvey` with null `cohort_id` is accepted by DB (nullable column) | Integration (TestContainers) | Save + reload → `cohortId` is null |
| T-02.4 | `EventPreprocessSurveyDTO` with `cohortId` serialises and deserialises correctly | Unit | Round-trip JSON preserves `cohortId` value; null is omitted by `@JsonInclude` if applicable |

### C-03 — CohortEligibilityGate

| # | Scenario | Gate | Expected |
|---|---|---|---|
| T-03.1 | User with 61-day-old account, transaction yesterday, cohort requires 60 days + recent txn | Both | `true` |
| T-03.2 | User with 59-day-old account, recent transaction | Gate 1 | `false` — account too young |
| T-03.3 | User with 61-day-old account, last transaction 31 days ago, window is 30 days | Gate 2 | `false` — transaction too old |
| T-03.4 | User with 61-day-old account, `lastTxnDate = null`, cohort requires recent transaction | Gate 2 | `false` — null lastTxnDate |
| T-03.5 | User with 61-day-old account, `lastTxnDate = null`, cohort does NOT require recent transaction | Gate 2 skipped | `true` |
| T-03.6 | User with `onboardingDate = null` | Gate 1 | `false` — cannot determine account age |
| T-03.7 | User with `onboardingDate` in the future | Gate 1 | `false` — future onboarding date |
| T-03.8 | User with account exactly 60 days old (boundary: `onboardingDate = today - 60`), cohort `minAccountAgeDays = 60` | Gate 1 | `true` — boundary is inclusive |
| T-03.9 | User with account exactly 61 days old, cohort `minAccountAgeDays = 60` | Gate 1 | `true` |
| T-03.10 | User with `lastTxnDate = today`, window 30 days | Gate 2 | `true` — same-day transaction qualifies |
| T-03.11 | User with `lastTxnDate = today - 30` exactly (boundary), window 30 days | Gate 2 | `true` — boundary is inclusive |
| T-03.12 | `evaluate()` is deterministic: same inputs on two calls return same result | Both | `true == true` |

### C-04 — SurveyBody NPS config fields

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-04.1 | Full NPS `SurveyBody` JSON with all 5 new fields deserialises correctly | Unit | All fields populated; `q2CopyByBand` nested object parsed |
| T-04.2 | `SurveyBody` JSON without new fields (legacy BRM payload) deserialises correctly | Unit | All new fields default to 0 / null; no Jackson exception |
| T-04.3 | `SurveyBody` with `q2CopyByBand` omitted deserialises to null nested object | Unit | `q2CopyByBand` is null; no NPE in gate logic |
| T-04.4 | Round-trip serialise → deserialise preserves all 5 fields | Unit | Serialised JSON contains all 5 fields; deserialised DTO equals original |

### Cross-cutting acceptance criteria

- All new enums (`SurveySegment`, `CohortPlatform`) are annotated `@Enumerated(EnumType.STRING)` and have a test asserting the enum string values match the DB ENUM definition.
- `Cohort` and the modified `PreprocessedSurvey` are annotated with `@Tag("simulation")` tests covering entity state transitions (per CLAUDE.md testing rules).
- JaCoCo threshold (50% line and branch) must pass. `CohortEligibilityGateImpl` is expected to reach ~90% coverage from the scenario tests above.

---

## 7. Rollout Plan

| Step | Action | Deployment Unit | Rollback |
|------|--------|-----------------|----------|
| 1 | Merge C-04 (SurveyBody fields) behind no feature flag — it is backward-compatible. Deploy to staging. | Both | Revert the PR. Existing BRM/CSAT payloads are unaffected. |
| 2 | Merge C-01 (Cohort entity + storage). Deploy to staging. Cohort table does not exist yet — entity is registered but no Quartz job reads it yet. | Worker | Revert the PR. No runtime impact until DB migration runs. |
| 3 | Coordinate with DB migrations team: apply DDL for `cohort` table. Verify seed rows inserted. **Do not activate cohorts yet** (`active = false`). | DB Migrations repo | Drop the `cohort` table (no data affected). |
| 4 | Merge C-02 (cohort_id on PreprocessedSurvey). Deploy to staging. | Both | Revert PR. Column not yet in DB — entity field is present but not written. |
| 5 | Coordinate with DB migrations team: apply `ALTER TABLE preprocessed_survey ADD COLUMN cohort_id`. | DB Migrations repo | `ALTER TABLE preprocessed_survey DROP COLUMN cohort_id`. |
| 6 | Merge C-03 (CohortEligibilityGate). Deploy to staging. Gate is a `@Component` but not called until the sampling job is wired. | Worker | Revert PR. No runtime impact until sampling job is implemented. |
| 7 | Run staging smoke: (a) Query `cohort` table — confirm 2 seed rows, `active = false`. (b) Verify `preprocessed_survey` schema has `cohort_id` column. (c) Submit a BRM survey event — confirm `cohortId = null` on the resulting `PreprocessedSurvey`. | Staging | N/A |
| 8 | This spec is complete. Pass cohort components to NPS Sampling Programme spec for chunk 04 (sampling job) and chunk 05 (check-in API integration). Cohorts remain `active = false` until the sampling job is ready for activation. | — | N/A |

> DB migrations live in a **separate repository**. DDL changes in steps 3 and 5 must be raised as separate MRs in that repo and coordinated with the DBA team before merging entity changes here.

---

## 8. Security Threat Model

Evaluated against OWASP API Security Top 10 for the surface introduced in this spec.

| OWASP Risk | Applicable | Impact | Mitigation |
|---|---|---|---|
| API1 — Broken Object Level Authorization | **No** | This spec introduces no new API endpoints. `Cohort` rows are not exposed via any API. | — |
| API2 — Broken Authentication | **No** | No new endpoints. The sampling job runs as a background process with no HTTP surface. | — |
| API3 — Broken Object Property Level Authorization | **Yes** | `SurveyBody` gains five new config fields (`weeklyInvitationCap`, `coolOffDays`, `yearlyTriggerCap`, etc.). These fields are operational metadata and must not be serialised into the client-facing check-in response payload. | When the check-in API (sampling spec chunk 05) constructs the `CheckInSurveyItem` DTO, it maps only client-visible fields from `SurveyBody`. The five new config fields must not appear in the mapping. This is specified as an acceptance criterion in chunk 05 of the sampling spec, and a unit test must assert that no config field name appears in the serialised `CheckInSurveyItem` JSON. |
| API4 — Unrestricted Resource Consumption | **Yes** | `CohortEligibilityGate.evaluate()` is called once per user per cohort in the sampling job. For 24M users across 2 cohorts, this is ~48M evaluations. Unbounded iteration risks OOM and long job duration. | The sampling job (sampling spec chunk 04) uses paginated batch processing (`cohort.sampling.batch-size`, default 1,000 rows per page) and ShedLock to prevent concurrent re-runs. `CohortEligibilityGate.evaluate()` itself is a pure function with O(1) cost — the resource concern is the upstream user pagination, not the gate. |
| API5 — Broken Function Level Authorization | **No** | No new endpoints. | — |
| API6 — Unrestricted Access to Sensitive Business Flows | **No** | `CohortEligibilityGate.evaluate()` is a read-only predicate. It does not write state. Double-invocation for the same user returns the same result without side effects. | — |
| API7 — Server Side Request Forgery | **No** | No outbound HTTP calls introduced in this spec. | — |
| API8 — Security Misconfiguration | **Yes** | The `Cohort` entity's `survey_id` FK allows an incorrectly-seeded row to link a cohort to the wrong survey (e.g., a CSAT survey row linked from an NPS cohort), causing NPS users to receive the wrong survey JSON. | (a) The seed migration must be reviewed by 2 codeowners before merge (Tier 3 entity change). (b) A post-migration smoke test asserts `cohort.survey_id → survey.category == NPS` for all NPS cohort rows. (c) `CohortStorage.findBySurveyCategoryAndActiveTrue()` only returns cohorts matching the requested category, so a mis-categorised cohort would not be surfaced to the sampling job. |
| API9 — Improper Inventory Management | **No** | No new endpoints introduced. No shadow routes. | — |
| API10 — Unsafe Consumption of APIs | **No** | `UserAttributesStorage.findUser()` is a typed, bounded Bigtable read. `CohortEligibilityGate.evaluate()` performs only date arithmetic on the returned attributes — no user-supplied input is echoed into a URL, command, or filename. | — |

### Cross-cutting security rules (CLAUDE.md enforced)

| Rule | Application to this spec |
|---|---|
| **Tier 3 — 2 CODEOWNER approvals** | Entity changes (`Cohort`, `PreprocessedSurvey`), enum additions, `EventPreprocessSurveyDTO` Kafka contract change all require 2 approvals per CLAUDE.md. |
| **No PII in logs** | `UserAttributes` fields (name, phone, account number) must not appear in DEBUG logs from `CohortEligibilityGateImpl`. Gate logging uses only `cohort.getName()` and boolean outcomes. Verified by log content assertion in unit tests. |
| **DB migrations in separate repo** | DDL for `cohort` table and `ALTER TABLE preprocessed_survey` must be raised in the DB migrations repo, not in this repo. |
| **Constructor injection** | `CohortEligibilityGateImpl` uses `@RequiredArgsConstructor`. No `@Autowired` field injection. |
| **Typed exceptions** | Any `RuntimeException` from date arithmetic in `CohortEligibilityGateImpl` must be caught and wrapped as `ServerException` with structured logging — not swallowed silently. |
