# Implementation Spec: Cohort Platform

## Document Info

| Field | Value |
|---|---|
| Status | Draft — revised 2026-05-25 |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-21 |
| Revised | 2026-05-25 — BigQuery execution path replaced by ClickHouse + Airflow pipeline |
| Deployment Units | API Handler |
| Companion Design Doc | [`docs/design/clickhouse-airflow-pipeline-design.md`](../../docs/design/clickhouse-airflow-pipeline-design.md) |
| ADRs | [`ADR-001 Cohort Design Strategy`](../../adrs/ADR-001-cohort-design-strategy.md), [`ADR-002 Cohort Eligibility Integration`](../../adrs/ADR-002-cohort-eligibility-integration.md) |
| Supersedes | [`impl-specs/archive/2026-05-19-nps-cohort-definition.md`](../archive/2026-05-19-nps-cohort-definition.md) — static-column cohort design archived |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Entity name | `Cohort` — reusable across NPS, CSAT, BRM. Category, segment, and platform scoped by `rule_definition` rules — no static columns. |
| D-02 | Rule format | JsonLogic AST stored in `rule_definition JSON` column. Compiled to ClickHouse SQL by the Airflow pipeline. |
| D-03 | Membership storage | `nps_weekly_sample` table populated directly by Airflow with the final sampled list. The intermediate `user_cohorts` membership table is not needed — Airflow resolves membership and sampling in a single pipeline pass. |
| D-04 | Query layer | ClickHouse (`cx_analytics.user_attributes_historical_data_final`), executed by the Airflow DAG `cas_nps_weekly_pipeline`. CAS stores the rules; Airflow compiles and executes them. |
| D-05 | Eligibility rules | Stored in `eligibility_rule` table, one row per rule per cohort. Airflow reads these rules and applies them against `nps_user_state` (MySQL). |
| D-06 | Sampling config | Stored as `sampling_config JSON` column on `cohort`. Airflow reads this to determine algorithm and cap. |
| D-07 | PM-facing UI | Phase 1: none. Rules seeded manually as JsonLogic JSON in DB by engineering. Phase 2: `react-querybuilder` integration. |
| D-08 | Date arithmetic in rules | `{ "days_ago": N }` custom operator token — stored in JsonLogic, compiled by Airflow to `today() - N` in ClickHouse. |
| D-09 | CohortEligibilityGate | Retired. NPS sampling job reads from `nps_weekly_sample` (pre-populated by Airflow), not from Bigtable or `user_cohorts`. |
| D-10 | CohortResolutionJob | **Not built.** Cohort resolution runs in Airflow, not in CAS. CAS owns configuration; Airflow owns execution. |
| D-11 | Pipeline trigger | Airflow DAG `cas_nps_weekly_pipeline` runs on its own cron schedule (Sunday 22:00 Africa/Lagos). `AirflowDagTriggerService` in CAS provides a manual trigger path for admin use only. |

---

## 1. Context

### 1.1 Why this spec exists

CAS is the owner of survey programme configuration: which users belong to which cohort, what eligibility rules apply, and how the weekly sample is drawn. These configurations are expressed as structured data (JsonLogic rules, JSON configs) stored in MySQL and consumed by an Airflow pipeline.

This spec defines the CAS-side components: the entities, repositories, and DDL that the Airflow pipeline reads from and writes to, plus the simplified `NpsWeeklySamplePreparationJob` that bridges the pre-computed sample into the survey delivery path.

The Airflow DAG itself (`cas_nps_weekly_pipeline`) is maintained by the data platform team and documented in [`docs/design/clickhouse-airflow-pipeline-design.md`](../../docs/design/clickhouse-airflow-pipeline-design.md), which serves as the interface contract between CAS and the Airflow team.

### 1.2 Separation of concerns

```
Cohort Platform (this spec)
  ├── Cohort definition    — Cohort entity, rule_definition JSON, sampling_config JSON
  ├── Eligibility rules    — eligibility_rule table (Airflow reads to apply exclusions)
  ├── Airflow trigger      — AirflowDagTriggerService (admin manual trigger only)
  └── Pipeline observability — survey_pipeline_audit table (Airflow writes funnel metrics)

NPS Programme (impl-specs/nps/2026-05-19-nps-sampling.md)
  └── NpsWeeklySamplePreparationJob
        reads nps_weekly_sample (PENDING rows written by Airflow)
        → publishes Kafka → SurveyPreprocessorListener → PreprocessedSurvey
```

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | `Cohort` entity — `rule_definition JSON NULL`, `sampling_config JSON NULL`, `compiled_clickhouse_sql TEXT NULL` | API Handler | New |
| 2 | DDL: `cohort` table with JSON + compiled SQL columns + two seed rows | DB Migrations repo | New |
| 4 | `CohortStorage` repository (`findByActiveTrue`) | API Handler | New |
| 5 | `eligibility_rule` table + `EligibilityRule` entity + `EligibilityRuleStorage` | API Handler | New |
| 6 | Seed data: eligibility rules for Personal Banking NPS and Business Banking NPS cohorts | DB Migrations repo | New |
| 7 | `survey_pipeline_audit` table + DDL | DB Migrations repo | New |
| 8 | `AirflowDagTriggerService` — HTTP client to Airflow REST API (admin manual trigger) | API Handler | New |
| 9 | `AirflowConfig` `@ConfigurationProperties` record (`baseUrl`, `dagId`, `apiToken`) | API Handler | New |
| 10 | Unit tests for all new components | API Handler | New |

### Out of scope

| # | Component | Reason |
|---|---|---|
| — | `CohortResolutionJob` | Replaced by Airflow. Not built in CAS. |
| — | `CohortQueryExecutor` (BigQuery/ClickHouse client) | Airflow owns query execution. Not needed in CAS. |
| — | `user_cohorts` table + `CohortMembershipRepository` | Replaced by Airflow-populated `nps_weekly_sample`. Not built. |
| — | `cohort_resolution_checkpoint` table | Not needed — Airflow manages its own state. |
| — | `JsonLogicToSqlCompiler` (SQL generation) | Airflow Python owns compilation. Not needed in CAS for Phase 1. |
| — | BigQuery SDK dependency | Not added to pom.xml. |
| — | ClickHouse SDK dependency | Not needed in CAS — Airflow queries ClickHouse directly. |
| — | PM-facing cohort admin UI | Phase 2. Rules seeded by engineering in Phase 1. |
| — | CSAT cohorts | Future spec. `Cohort` entity designed to support CSAT. |

---

## 3. Design Decisions

| # | Decision | ADR |
|---|---|---|
| D1 | JsonLogic AST for rule definition, compiled to ClickHouse SQL by Airflow | [ADR-001 Cohort Design Strategy](../../adrs/ADR-001-cohort-design-strategy.md) |
| D2 | Airflow-populated `nps_weekly_sample` replaces `user_cohorts` intermediary | [ADR-002 Cohort Eligibility Integration](../../adrs/ADR-002-cohort-eligibility-integration.md) |

---

## 4. Architecture

### 4.1 Component map

```
  ┌───────────────────────────────────────────────────────────────┐
  │                     API Handler (CAS)                          │
  │                                                                │
  │  AirflowDagTriggerService  [NEW — admin manual trigger only]  │
  │    └─► POST /api/v1/dags/cas_nps_weekly_pipeline/dagRuns      │
  └───────────────────────────────────────────────────────────────┘

  ┌───────────────────────────────────────────────────────────────┐
  │         Airflow DAG: cas_nps_weekly_pipeline                   │
  │         (maintained by data platform team)                     │
  │                                                                │
  │  READS from CAS MySQL:                                        │
  │    cohort (rule_definition, sampling_config, active)          │
  │    eligibility_rule (rule_type, rule_config, rule_order)      │
  │    nps_user_state (last_nps_triggered_date, annual counts)    │
  │                                                                │
  │  QUERIES: cx_analytics.user_attributes_historical_data_final  │
  │                                                                │
  │  WRITES to CAS MySQL:                                         │
  │    nps_weekly_sample (user_id, cohort_id, iso_week, PENDING)  │
  │    survey_pipeline_audit (funnel: population/eligible/sample) │
  └───────────────────────────────────────────────────────────────┘

  ┌───────────────────────────────────────────────────────────────┐
  │  Tables (CAS MySQL)                                            │
  │    cohort                       [NEW — rule_definition,       │
  │                                  compiled_clickhouse_sql,     │
  │                                  sampling_config cols]        │
  │    eligibility_rule             [NEW]                         │
  │    survey_pipeline_audit        [NEW]                         │
  │    nps_weekly_sample            [written by Airflow,          │
  │                                  read by NPS sampling job]    │
  └───────────────────────────────────────────────────────────────┘
```

### 4.2 Rule data flow

```
Engineering seeds cohort + eligibility_rule rows in MySQL.

Sunday 22:00 Africa/Lagos — Airflow DAG runs:
  1. Reads cohort table → rule_definition (JsonLogic)
  2. Reads eligibility_rule table → per-cohort exclusion rules
  3. Queries ClickHouse with compiled rule_definition → cohort member list
  4. Joins with nps_user_state (MySQL) → applies eligibility exclusions
  5. Applies sampling (SIMPLE_RANDOM or HASH_BASED)
  6. Writes to nps_weekly_sample (status=PENDING)
  7. Writes funnel counts to survey_pipeline_audit

Monday 01:00 Africa/Lagos — NpsWeeklySamplePreparationJob runs:
  Reads PENDING rows from nps_weekly_sample → publishes Kafka
```

---

## 5. Entity Schemas

### 5.1 Cohort entity

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT | From `BaseEntity` |
| `name` | `VARCHAR(100)` | NOT NULL | e.g. "Personal Banking NPS" |
| `survey_id` | `BIGINT` | NOT NULL, FK → `survey(id)` | The Survey this cohort drives |
| `rule_definition` | `JSON` | NULLABLE | JsonLogic AST. NULL = not yet configured. Category, segment, and platform constraints are expressed as rules inside this field. |
| `compiled_clickhouse_sql` | `TEXT` | NULLABLE | Pre-compiled ClickHouse SQL derived from `rule_definition`. Airflow reads this directly; if NULL, Airflow compiles from `rule_definition` and writes the result back. |
| `sampling_config` | `JSON` | NULLABLE | Sampling algorithm config. NULL = `SIMPLE_RANDOM` with default cap |
| `active` | `BOOLEAN` | NOT NULL, DEFAULT false | Only active cohorts are processed by Airflow |
| BaseEntity audit fields | — | — | `created_by`, `created_on`, `last_modified_by`, `last_modified_on`, `version` |

**`sampling_config` examples:**

```json
// SIMPLE_RANDOM (default when NULL) — Personal Banking NPS
{ "type": "SIMPLE_RANDOM", "cap": 3200 }

// SIMPLE_RANDOM — Business Banking NPS
{ "type": "SIMPLE_RANDOM", "cap": 2134 }

// HASH_BASED — stable A/B cohort, rotate salt quarterly
{ "type": "HASH_BASED", "bucketNumerator": 13, "bucketDenominator": 100, "salt": "nps_q3_2026", "cap": 3200 }
```

**DDL:**

```sql
CREATE TABLE cohort (
    id                       BIGINT        NOT NULL AUTO_INCREMENT,
    name                     VARCHAR(100)  NOT NULL,
    survey_id                BIGINT        NOT NULL,
    rule_definition          JSON          NULL,
    compiled_clickhouse_sql  TEXT          NULL,
    sampling_config          JSON          NULL,
    active                   BOOLEAN       NOT NULL DEFAULT false,
    created_by               VARCHAR(255)  NOT NULL,
    created_on               TIMESTAMP     NOT NULL,
    last_modified_by         VARCHAR(255)  NOT NULL,
    last_modified_on         TIMESTAMP     NOT NULL,
    version                  INT           NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_cohort_survey FOREIGN KEY (survey_id) REFERENCES survey(id)
);
```

**Seed rows:**

```sql
-- Personal Banking NPS cohort
INSERT INTO cohort (name, survey_id,
                    rule_definition, compiled_clickhouse_sql, sampling_config, active,
                    created_by, created_on, last_modified_by, last_modified_on, version)
VALUES (
    'Personal Banking NPS',
    <personal_nps_survey_id>,
    JSON_OBJECT(
        'and', JSON_ARRAY(
            JSON_OBJECT('==', JSON_ARRAY(JSON_OBJECT('var', 'customer_type'), 'PERSONAL')),
            JSON_OBJECT('<=', JSON_ARRAY(JSON_OBJECT('var', 'joining_date'), JSON_OBJECT('days_ago', 60))),
            JSON_OBJECT('>=', JSON_ARRAY(JSON_OBJECT('var', 'last_txn_date'), JSON_OBJECT('days_ago', 30)))
        )
    ),
    -- compiled_clickhouse_sql: NULL initially; Airflow compiles on first run and writes back
    NULL,
    JSON_OBJECT('type', 'SIMPLE_RANDOM', 'cap', 3200),
    false, 'system', NOW(), 'system', NOW(), 0
);

-- Business Banking NPS cohort
INSERT INTO cohort (name, survey_id,
                    rule_definition, compiled_clickhouse_sql, sampling_config, active,
                    created_by, created_on, last_modified_by, last_modified_on, version)
VALUES (
    'Business Banking NPS',
    <business_nps_survey_id>,
    JSON_OBJECT(
        'and', JSON_ARRAY(
            JSON_OBJECT('==', JSON_ARRAY(JSON_OBJECT('var', 'customer_type'), 'BUSINESS')),
            JSON_OBJECT('<=', JSON_ARRAY(JSON_OBJECT('var', 'joining_date'), JSON_OBJECT('days_ago', 60))),
            JSON_OBJECT('>=', JSON_ARRAY(JSON_OBJECT('var', 'last_txn_date'), JSON_OBJECT('days_ago', 30)))
        )
    ),
    NULL,
    JSON_OBJECT('type', 'SIMPLE_RANDOM', 'cap', 2134),
    false, 'system', NOW(), 'system', NOW(), 0
);
```

### 5.2 `eligibility_rule` table

One row per exclusion rule per cohort. Airflow reads all active rules for a cohort and applies them in `rule_order` sequence.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT | |
| `cohort_id` | `BIGINT` | NOT NULL, FK → `cohort(id)` | Which cohort this rule applies to |
| `rule_order` | `INT` | NOT NULL | Evaluation sequence; lower = applied first |
| `rule_type` | `VARCHAR(50)` | NOT NULL | `COOL_OFF`, `ANNUAL_CAP`, `CROSS_PROGRAMME_CAP` |
| `rule_config` | `JSON` | NOT NULL | Typed config parameters (see design doc §6) |
| `active` | `BOOLEAN` | NOT NULL DEFAULT true | Inactive rules are skipped without deletion |
| `created_on` | `TIMESTAMP` | NOT NULL | |

**DDL:**

```sql
CREATE TABLE eligibility_rule (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    cohort_id   BIGINT       NOT NULL,
    rule_order  INT          NOT NULL,
    rule_type   VARCHAR(50)  NOT NULL,
    rule_config JSON         NOT NULL,
    active      BOOLEAN      NOT NULL DEFAULT true,
    created_on  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_cohort_order (cohort_id, rule_order),
    CONSTRAINT fk_er_cohort FOREIGN KEY (cohort_id) REFERENCES cohort(id)
);
```

**Seed rows (applied after cohort seed rows, using the cohort IDs from above):**

```sql
-- Personal Banking NPS: COOL_OFF (90 days)
INSERT INTO eligibility_rule (cohort_id, rule_order, rule_type, rule_config, active, created_on)
SELECT id, 1, 'COOL_OFF',
    '{"type":"COOL_OFF","sourceTable":"nps_user_state","dateField":"last_nps_triggered_date","days":90}',
    true, NOW()
FROM cohort WHERE name = 'Personal Banking NPS';

-- Personal Banking NPS: ANNUAL_CAP (2 per year)
INSERT INTO eligibility_rule (cohort_id, rule_order, rule_type, rule_config, active, created_on)
SELECT id, 2, 'ANNUAL_CAP',
    '{"type":"ANNUAL_CAP","sourceTable":"nps_user_state","countField":"annual_trigger_count","yearField":"trigger_year","maxCount":2}',
    true, NOW()
FROM cohort WHERE name = 'Personal Banking NPS';

-- Business Banking NPS: COOL_OFF (90 days)
INSERT INTO eligibility_rule (cohort_id, rule_order, rule_type, rule_config, active, created_on)
SELECT id, 1, 'COOL_OFF',
    '{"type":"COOL_OFF","sourceTable":"nps_user_state","dateField":"last_nps_triggered_date","days":90}',
    true, NOW()
FROM cohort WHERE name = 'Business Banking NPS';

-- Business Banking NPS: ANNUAL_CAP (2 per year)
INSERT INTO eligibility_rule (cohort_id, rule_order, rule_type, rule_config, active, created_on)
SELECT id, 2, 'ANNUAL_CAP',
    '{"type":"ANNUAL_CAP","sourceTable":"nps_user_state","countField":"annual_trigger_count","yearField":"trigger_year","maxCount":2}',
    true, NOW()
FROM cohort WHERE name = 'Business Banking NPS';
```

### 5.3 `survey_pipeline_audit` table

Written by Airflow after each pipeline run. Read by the Journey Intelligence View for funnel display.

```sql
CREATE TABLE survey_pipeline_audit (
    cohort_id        BIGINT       NOT NULL,
    context_key      VARCHAR(50)  NOT NULL,   -- ISO week: "2026-W22"
    run_date         DATE         NOT NULL,
    population_size  INT          NOT NULL,   -- users matching cohort rule in ClickHouse
    eligible_size    INT          NOT NULL,   -- after eligibility exclusions
    sample_size      INT          NOT NULL,   -- final sampled count (≤ cap)
    status           VARCHAR(20)  NOT NULL,   -- 'COMPLETE' | 'PARTIAL' | 'FAILED'
    PRIMARY KEY (cohort_id, context_key)
);
```

---

## 6. Java Components

### 6.1 `Cohort` entity

```java
@Entity
@Table(name = "cohort")
@Data
@EqualsAndHashCode(callSuper = true)
public class Cohort extends BaseEntity {

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "survey_id", nullable = false)
    private Long surveyId;

    @Column(name = "rule_definition", columnDefinition = "JSON")
    private String ruleDefinition;

    @Column(name = "compiled_clickhouse_sql", columnDefinition = "TEXT")
    private String compiledClickhouseSql;

    @Column(name = "sampling_config", columnDefinition = "JSON")
    private String samplingConfig;

    @Column(nullable = false)
    private boolean active;
}
```

### 6.2 `CohortStorage` repository

```java
public interface CohortStorage extends JpaRepository<Cohort, Long> {

    List<Cohort> findByActiveTrue();
}
```

### 6.3 `EligibilityRule` entity

```java
@Entity
@Table(name = "eligibility_rule")
@Data
public class EligibilityRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cohort_id", nullable = false)
    private Long cohortId;

    @Column(name = "rule_order", nullable = false)
    private int ruleOrder;

    @Column(name = "rule_type", nullable = false, length = 50)
    private String ruleType;

    @Column(name = "rule_config", nullable = false, columnDefinition = "JSON")
    private String ruleConfig;

    @Column(nullable = false)
    private boolean active = true;

    @Column(name = "created_on", nullable = false)
    private LocalDateTime createdOn;
}
```

### 6.4 `EligibilityRuleStorage` repository

```java
public interface EligibilityRuleStorage extends JpaRepository<EligibilityRule, Long> {

    @Query("SELECT r FROM EligibilityRule r WHERE r.cohortId = :cohortId AND r.active = true ORDER BY r.ruleOrder")
    List<EligibilityRule> findActiveByCohortId(@Param("cohortId") Long cohortId);
}
```

### 6.5 `AirflowDagTriggerService`

Provides admin-only manual triggering of the Airflow pipeline. Not used in normal weekly operation.

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class AirflowDagTriggerService {

    private final AirflowConfig config;
    private final RestClient restClient;

    /**
     * Triggers the Airflow NPS pipeline DAG for a specific ISO week.
     * Used by the admin API for manual re-runs only.
     * Normal weekly runs are scheduled in Airflow directly.
     *
     * @param isoWeek ISO week string e.g. "2026-W22", or null for current week
     */
    public void triggerNpsPipeline(@Nullable String isoWeek) {
        String body = isoWeek != null
            ? """{"conf":{"triggered_by":"cas_admin","iso_week":"%s"}}""".formatted(isoWeek)
            : """{"conf":{"triggered_by":"cas_admin"}}""";

        try {
            restClient.post()
                .uri(config.baseUrl() + "/api/v1/dags/" + config.dagId() + "/dagRuns")
                .header("Authorization", "Bearer " + config.apiToken())
                .contentType(MediaType.APPLICATION_JSON)
                .body(body)
                .retrieve()
                .toBodilessEntity();

            log.info("Triggered Airflow DAG dagId={} isoWeek={}", config.dagId(), isoWeek);
        } catch (Exception e) {
            log.error("Failed to trigger Airflow DAG dagId={} error={}", config.dagId(), e.getMessage());
            throw new ServerException("Failed to trigger Airflow pipeline: " + e.getMessage());
        }
    }
}
```

### 6.6 `AirflowConfig`

```java
@ConfigurationProperties(prefix = "airflow")
public record AirflowConfig(
    String baseUrl,
    String dagId,
    String apiToken
) {}
```

**`application.yml` properties:**

```yaml
airflow:
  base-url: ${AIRFLOW_BASE_URL}
  dag-id: cas_nps_weekly_pipeline
  api-token: ${AIRFLOW_API_TOKEN}
```

---

## 7. Chunk List

| ID | Name | Description | Est. lines (impl + test) | Depends on |
|----|------|-------------|--------------------------|------------|
| C-01 | `Cohort` entity + `CohortStorage` + DDL | (a) `Cohort` entity with `rule_definition JSON`, `compiled_clickhouse_sql TEXT`, and `sampling_config JSON` columns — no `survey_category`, `segment`, or `platform` columns (constraints expressed as rules); (b) `CohortStorage` with `findByActiveTrue`; (c) DDL for `cohort` table; (d) Two seed rows with JsonLogic `rule_definition`, `compiled_clickhouse_sql = NULL` (Airflow compiles on first run), and `sampling_config` for Personal Banking NPS (cap 3200) and Business Banking NPS (cap 2134). | ~280 | — |
| C-02 | `eligibility_rule` table + `EligibilityRuleStorage` + seed data | (a) `EligibilityRule` entity; (b) `EligibilityRuleStorage.findActiveByCohortId()`; (c) DDL for `eligibility_rule` table; (d) Seed rows: COOL_OFF (90 days) and ANNUAL_CAP (2/year) for both NPS cohorts; (e) Unit tests: `findActiveByCohortId` returns only active rules in order; inactive rule excluded; unknown cohort returns empty list. | ~250 | C-01 |
| C-03 | `survey_pipeline_audit` table | (a) DDL for `survey_pipeline_audit` with PRIMARY KEY `(cohort_id, context_key)` and all funnel columns; (b) No Java entity required — Airflow writes this table directly via MySQL hook; (c) Optional: `SurveyPipelineAuditStorage` read-only interface for the Journey Intelligence View (if that view is in scope for this spec). | ~50 | — |
| C-04 | `AirflowDagTriggerService` + `AirflowConfig` | (a) `AirflowConfig` `@ConfigurationProperties` record; (b) `AirflowDagTriggerService.triggerNpsPipeline(String isoWeek)` using `RestClient`; (c) Unit tests: successful trigger logs correctly; HTTP error throws `ServerException`; null isoWeek sends conf without iso_week field. | ~150 | — |

**Total: ~750 lines** across **4 chunks**. C-01 and C-03/C-04 are independent and can be parallelised. C-02 depends on C-01.

---

## 8. Capability Test Strategy

### C-01 — Cohort entity + CohortStorage

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-01.1 | `findByActiveTrue()` returns only active cohort rows | Unit (H2) | Two active rows returned; inactive row excluded |
| T-01.2 | `rule_definition` round-trips through Jackson serialisation | Unit | JSON written; read back; equals original AST string |
| T-01.3 | `compiled_clickhouse_sql` persists and reloads correctly | Unit (H2) | TEXT value written; read back unchanged |
| T-01.4 | `sampling_config` round-trips correctly | Unit | `SIMPLE_RANDOM` config written; read back; cap preserved |
| T-01.5 | Cohort with `rule_definition = NULL` and `compiled_clickhouse_sql = NULL` is persisted without error | Unit (H2) | `active = false` row with null cols saves and reloads cleanly |

### C-02 — EligibilityRule + EligibilityRuleStorage

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-02.1 | `findActiveByCohortId(1)` returns rules in `rule_order` sequence | Unit (H2) | COOL_OFF (order=1) returned before ANNUAL_CAP (order=2) |
| T-02.2 | Inactive rule excluded | Unit (H2) | Rule with `active=false` not returned |
| T-02.3 | Unknown cohort returns empty list | Unit (H2) | `findActiveByCohortId(999)` returns empty list, no exception |
| T-02.4 | `rule_config` JSON round-trips correctly | Unit | COOL_OFF config written; `days` field reads back as 90 |

### C-04 — AirflowDagTriggerService

| # | Scenario | Type | Assertion |
|---|---|---|---|
| T-04.1 | Successful trigger logs DAG ID and ISO week | Unit (mocked RestClient) | `INFO` log contains `dagId` and `isoWeek` |
| T-04.2 | HTTP error from Airflow throws `ServerException` | Unit | `RestClientException` → `ServerException` propagated |
| T-04.3 | Null `isoWeek` sends request body without `iso_week` field | Unit | Request body contains only `triggered_by` in `conf` |

### Cross-cutting acceptance criteria

- JaCoCo threshold (50% line and branch) must pass.
- No `user_id` values appear in `INFO`-level log statements (PII protection).

---

## 9. Tier 3 Paths

Per CLAUDE.md, these require **2 CODEOWNER approvals**:

| Path | Change | Reason |
|---|---|---|
| `src/main/java/**/module/analytics/entity/` | Add `Cohort` entity (`rule_definition`, `compiled_clickhouse_sql`, `sampling_config` columns) | Entity changes have DB implications |

---

## 10. Rollout Plan

| Step | Action | Deployment Unit | Rollback |
|------|--------|-----------------|----------|
| 1 | Merge C-01 (Cohort entity). Deploy to staging. Entity present; Airflow not yet reading it. | API Handler | Revert PR. |
| 2 | DB migrations: apply `cohort` table DDL + seed rows. Verify `rule_definition` and `sampling_config` not null. Set `active = false`. | DB Migrations repo | Drop `cohort` table. |
| 3 | Merge C-02 (eligibility_rule). Deploy. | API Handler | Revert PR. |
| 4 | DB migrations: apply `eligibility_rule` DDL + seed rows. | DB Migrations repo | Drop `eligibility_rule` table. |
| 5 | Merge C-03 (survey_pipeline_audit DDL). | DB Migrations repo | Drop table. |
| 6 | Merge C-04 (AirflowDagTriggerService). Deploy with `airflow.base-url` pointing to staging Airflow. | API Handler | Revert PR. |
| 7 | Coordinate with data platform team: point Airflow staging DAG at staging CAS MySQL. Run DAG manually. Verify: (a) cohort + eligibility_rule rows read correctly; (b) `nps_weekly_sample` populated with PENDING rows; (c) `survey_pipeline_audit` row written with correct funnel counts. | Staging | Set `cohort.active = false`. |
| 8 | Enable NPS sampling job (see NPS Sampling spec rollout) — depends on Airflow having populated `nps_weekly_sample`. | Staging | Disable flag. |
| 9 | Production: set `cohort.active = true`. Coordinate Airflow production schedule. Monitor `survey_pipeline_audit.sample_size` after first run. | Production | Set `active = false`. |

> The NPS sampling job **must not be enabled in production** until step 9 confirms Airflow has written PENDING rows to `nps_weekly_sample`.

---

## 11. Security Threat Model

| OWASP Risk | Applicable | Mitigation |
|---|---|---|
| API1 — Broken Object Level Auth | **No** | No new public API endpoints. `AirflowDagTriggerService` is admin-only, secured by network policy. |
| API3 — Broken Object Property Level Auth | **No** | `rule_definition` and `sampling_config` are internal — never serialised to client responses. |
| API4 — Unrestricted Resource Consumption | **Yes** | Airflow pipeline bounded by ClickHouse query scope. `AirflowDagTriggerService` is admin-only; rate-limiting not required but calls are logged. |
| API8 — Security Misconfiguration | **Yes** | (a) Cohorts default to `active = false` — Airflow does nothing until engineering activates. (b) `AirflowConfig.apiToken` is loaded from env var `AIRFLOW_API_TOKEN`, never hardcoded. |
| API10 — Unsafe Consumption of APIs | **Yes** | Airflow HTTP errors caught and wrapped as `ServerException`. `RestClient` timeout configured via `airflow.connect-timeout-ms` and `airflow.read-timeout-ms`. |

### Cross-cutting security rules

| Rule | Application |
|---|---|
| **No PII in logs** | `AirflowDagTriggerService` logs only `dagId` and `isoWeek`. No `user_id` values. |
| **Tier 3 — 2 CODEOWNER approvals** | `Cohort` entity + `SurveySegment` enum. |
| **DB migrations in separate repo** | All DDL raised in DB migrations repo. |
| **Constructor injection** | All new `@Component` / `@Service` classes use `@RequiredArgsConstructor`. |
