# Flowchart — Cohort Platform Components

Spec: [`2026-05-21-cohort-platform.md`](../2026-05-21-cohort-platform.md)

## CAS API Handler

```mermaid
flowchart TD
    AIRFLOW(["☁ Airflow DAG\ncas_nps_weekly_pipeline\n(data platform team)"])
    CH(["☁ ClickHouse\ncx_analytics.\nuser_attributes_historical_data_final"])

    subgraph WORKER["⚙ CAS API Handler"]
        direction TB
        TRIG["AirflowDagTriggerService\nAdmin manual trigger only\nPOST /dagRuns"]
        CS["CohortStorage\nSpring Data JPA"]
        ERS["EligibilityRuleStorage\nSpring Data JPA"]
    end

    subgraph DB["🗄 CAS MySQL"]
        direction LR
        T_COHORT[(cohort\nrule_definition · sampling_config)]
        T_ER[(eligibility_rule\nrule_type · rule_config · rule_order)]
        T_NUS[(nps_user_state\neligibility state)]
        T_NWS[(nps_weekly_sample\nPENDING rows)]
        T_AUDIT[(survey_pipeline_audit\nfunnel metrics)]
    end

    TRIG -->|"POST /dagRuns\n(admin only)"| AIRFLOW
    AIRFLOW -->|"1 · reads active cohorts\nrule_definition, sampling_config"| T_COHORT
    AIRFLOW -->|"2 · reads eligibility rules"| T_ER
    AIRFLOW -->|"3 · queries user attributes"| CH
    AIRFLOW -->|"4 · reads eligibility state"| T_NUS
    AIRFLOW -->|"5 · writes PENDING rows"| T_NWS
    AIRFLOW -->|"6 · writes funnel metrics"| T_AUDIT

    CS --->|JDBC| T_COHORT
    ERS --->|JDBC| T_ER

    classDef job       fill:#f4a261,stroke:#e76f51,color:#000,font-weight:bold
    classDef component fill:#457b9d,stroke:#1d3557,color:#fff
    classDef db        fill:#e9c46a,stroke:#e76f51,color:#000
    classDef external  fill:#a8dadc,stroke:#457b9d,color:#000

    class TRIG,CS,ERS component
    class T_COHORT,T_ER,T_NUS,T_NWS,T_AUDIT db
    class AIRFLOW,CH external
```

## Database Tables

```mermaid
flowchart LR
    subgraph DB["🗄 CAS MySQL"]
        direction TB
        T_SURVEY[(survey\nexisting)]
        T_COHORT[(cohort\nrule_definition JSON\ncompiled_clickhouse_sql TEXT\nsampling_config JSON · active)]
        T_ER[(eligibility_rule\ncohort_id · rule_order\nrule_type · rule_config · active)]
        T_NWS[(nps_weekly_sample\nuser_id · cohort_id\niso_week · status PENDING)]
        T_AUDIT[(survey_pipeline_audit\ncohort_id · context_key\npopulation/eligible/sample size)]
    end

    CS["CohortStorage\nJPA"]
    ERS["EligibilityRuleStorage\nJPA"]

    T_COHORT -->|"FK survey_id"| T_SURVEY
    T_ER -->|"FK cohort_id"| T_COHORT
    T_NWS -->|"FK cohort_id"| T_COHORT

    CS -->|reads| T_COHORT
    ERS -->|reads| T_ER

    classDef component fill:#457b9d,stroke:#1d3557,color:#fff
    classDef db        fill:#e9c46a,stroke:#e76f51,color:#000

    class CS,ERS component
    class T_SURVEY,T_COHORT,T_ER,T_NWS,T_AUDIT db
```
