# Cohort Resolution Flow — Nightly Job

Triggered: **daily at 23:00 Africa/Lagos** via Quartz + ShedLock.

```mermaid
flowchart TD
    START(["🕐 23:00 Africa/Lagos\nCohortResolutionJob starts"])

    subgraph SETUP["Per-run setup"]
        LOAD["Load active cohorts\nCohortStorage → cohort table"]
    end

    subgraph PER_COHORT["For each active cohort"]
        direction TB
        COMPILE["Compile rule_definition\nJsonLogicToSqlCompiler → SQL WHERE"]
        CHECKPOINT["Resume or init checkpoint\nCohortResolutionCheckpointStorage"]

        subgraph CHUNK_LOOP["Chunk loop"]
            direction TB
            FETCH["Fetch next chunk\nCohortQueryExecutor → BigQuery\nSELECT user_id LIMIT N OFFSET M"]
            EMPTY{Chunk empty?}
            UPSERT["Bulk upsert user_cohorts\nCohortMembershipRepository\nON DUPLICATE KEY JSON_ARRAY_APPEND"]
            ADVANCE["Advance checkpoint offset\noffset += chunkSize"]
        end

        COMPLETE["Mark checkpoint COMPLETED"]
        FAILED["Mark checkpoint FAILED\ncontinue to next cohort"]
    end

    MORE{More cohorts?}
    DONE(["✓ Run complete"])

    START        --> LOAD
    LOAD         --> COMPILE
    COMPILE      --> CHECKPOINT
    CHECKPOINT   --> FETCH
    FETCH        --> EMPTY
    EMPTY        -->|"yes — all pages done"| COMPLETE
    EMPTY        -->|no| UPSERT
    UPSERT       --> ADVANCE
    ADVANCE      --> FETCH
    COMPILE      -->|"BigQuery error"| FAILED
    UPSERT       -->|"MySQL error"| FAILED
    COMPLETE     --> MORE
    FAILED       --> MORE
    MORE         -->|yes| COMPILE
    MORE         -->|no| DONE

    classDef trigger  fill:#2a9d8f,stroke:#264653,color:#fff,font-weight:bold
    classDef step     fill:#457b9d,stroke:#1d3557,color:#fff
    classDef decision fill:#f4a261,stroke:#e76f51,color:#000,font-weight:bold
    classDef terminal fill:#264653,stroke:#264653,color:#fff
    classDef error    fill:#e63946,stroke:#c1121f,color:#fff

    class START trigger
    class LOAD,COMPILE,CHECKPOINT,FETCH,UPSERT,ADVANCE,COMPLETE step
    class EMPTY,MORE decision
    class DONE terminal
    class FAILED error
```

## Key invariants

| # | Invariant |
|---|---|
| 1 | **Chunk loop** — repeats until BigQuery returns an empty page. Default chunk size: 5,000 rows. |
| 2 | **ShedLock** — key `cohort_resolution_job` (`maxLockTime=6h`). One node runs at a time. |
| 3 | **Partial failure** — BigQuery or MySQL error on one cohort marks it FAILED and moves to the next. Other cohorts still resolve. |
| 4 | **Idempotency** — `JSON_CONTAINS` guard inside `JSON_ARRAY_APPEND` prevents duplicate cohort IDs in the array. |
| 5 | **Resumability** — checkpoint stores `last_offset`; a restarted run resumes from that offset, not from 0. |
