# Implementation Spec: NPS Cool-Off Enforcement

## Document Info

| Field | Value |
|---|---|
| Status | Draft |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-19 |
| PRD | [NPS PRD — AC-05.1–AC-05.6, AC-12.1–AC-12.5](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) (v1.0, April 2026) |
| Deployment Units | Background Worker (sampling job uses `NpsUserStateService` for cool-off gate); API Handler (trigger write occurs in serve path at check-in time) |
| Companion Design Doc | [`docs/design/nps-cool-off-design.md`](../../docs/design/nps-cool-off-design.md) |
| ADRs | [`ADR-009` — cool-off storage](../../adrs/ADR-009-nps-cool-off-storage.md), [`ADR-010` — annual cap enforcement](../../adrs/ADR-010-nps-annual-cap-enforcement.md) |
| Spec File | `impl-specs/nps/2026-05-19-nps-cool-off.md` |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Cool-off state storage | CAS-owned MySQL table `nps_user_state` (Bigtable is read-only). Full analysis in `adrs/archive/ADR-001-nps-cool-off-storage.md`; re-affirmed in ADR-009. |
| D-02 | Year rollover enforcement | Application-code logic in `NpsUserStateService.writeTriggered()` compares `trigger_year` to `LocalDate.now().getYear()` at write time. No scheduled reset job. See ADR-010. |
| D-03 | Cool-off check timing | Cool-off is evaluated **only at week start** during `NpsWeeklySamplePreparationJob`. There is no mid-week re-verification at serve time. This is a deliberate performance trade-off: the sampling window is one week, the cool-off window is 90 days, so staleness risk is negligible. |
| D-04 | Bypass of `userEligibleFromSurveyHistory()` | NPS bypasses `RuleParserHandler.userEligibleFromSurveyHistory()` naturally — NPS `PreprocessedSurvey` rows are written by the sampling job directly, not via the `RuleParserHandler` Kafka pipeline. No code change to `RuleParserHandler` is needed. |
| D-05 | Trigger write atomicity | `NpsUserStateService.writeTriggered()` is called within the same `@Transactional` boundary as the `nps_weekly_sample.status = SERVED` update (implemented in Sampling Spec 2, chunk 05). This spec provides the service method; the atomic call site is in Sampling Spec 2. |
| D-06 | Concurrent double-trigger | `@Version` optimistic locking on `BaseEntity` prevents double-write. `OptimisticLockException` is caught in `writeTriggered()` and resolved by returning the already-committed row. No retry loop. |
| D-07 | Cool-off scope | Global across all NPS measurements for a user. Not per-cohort, not per-measurement, not per-platform. One `nps_user_state` row per user. |
| D-08 | CSAT cool-off | Out of scope for this spec. CSAT will follow the same pattern with its own `csat_user_state` table (independent cool-off period and cap). |

---

## 1. Context

### 1.1 Why now

Phase 1 of the NPS Sampling Programme (`impl-specs/2026-05-18-nps-sampling-engine.md`) introduces weekly cohort sampling with a 90-day global cool-off and a maximum of 2 triggers per user per calendar year (PRD §10, AC-05.1–AC-05.6, AC-12.1–AC-12.5). Without enforcement of these limits, users will receive NPS surveys more frequently than the PRD allows, leading to response fatigue and biased data.

This spec delivers the `NpsUserState` entity, the `NpsUserStateService` that evaluates the cool-off gate and writes trigger state, and the integration of that service into the weekly sampling job. The trigger write call site itself is delivered in Sampling Spec 2 (chunk 05) because it requires the `nps_weekly_sample.status = SERVED` atomic update that lives there.

### 1.2 Scope summary

This spec covers three implementation units:

1. **`NpsUserState` entity + `NpsUserStateStorage` repository + DDL spec** — the aggregate root and its persistence layer
2. **`NpsUserStateService`** — the gate evaluation (`isInCoolOff()`) and trigger write (`writeTriggered()`) methods, including year rollover and `OptimisticLockException` handling
3. **Integration into `NpsWeeklySamplePreparationJob`** — wiring `isInCoolOff()` into the per-user eligibility filter during weekly sample preparation

What is NOT in this spec:

- The call site for `writeTriggered()` (in Sampling Spec 2, chunk 05, alongside `nps_weekly_sample.status = SERVED`)
- Response classification writes to `last_nps_response_classification` (separate concern in response capture spec)
- CSAT cool-off (mirrors this pattern in a future spec)
- Mid-week re-verification of cool-off at serve time (not required — cool-off is checked only at week start)

### 1.3 Legacy check — what exists today

**There is no NPS cool-off enforcement today.** There is no `nps_user_state` table and no `NpsUserStateService`.

The nearest existing mechanism is `RuleParserHandler.userEligibleFromSurveyHistory()` [VERIFIED: `src/main/java/com/moniepoint/loans/cas/module/analytics/service/impl/RuleParserHandler.java`], which provides a general rate-limiting check for the BRM event-driven survey pipeline:

- Checks that the user has no pending (unserved) survey
- Checks that the total number of surveys served within a configurable global window does not exceed a cap

**This is not a cool-off.** It is a concurrency guard and saturation limiter. Specifically:

1. It has no concept of "90 days since last trigger" — it checks whether a survey is currently pending, not how long ago one was served.
2. It is invoked by the Kafka-driven BRM pipeline (`SurveyEvaluatorListener` → `RuleParserHandler`). NPS does not use this pipeline — NPS `PreprocessedSurvey` rows are created directly by the sampling job. `RuleParserHandler` is never called in the NPS flow.
3. It has no concept of an annual trigger cap.

**No change to `RuleParserHandler` is needed for NPS cool-off.** This spec introduces a new, dedicated service that owns NPS cool-off state exclusively.

---

## 2. Scope

### In scope

| Component | Change Type | Deployment Unit |
|---|---|---|
| `NpsUserState` entity | New | Both (entity is shared; accessed by Worker and API Handler) |
| `NpsUserStateStorage` repository | New | Both |
| `NpsUserStateService` interface + `NpsUserStateServiceImpl` | New | Both |
| `NpsUserStateService.isInCoolOff(userId, coolOffDays, yearlyTriggerCap)` | New | Worker (called by sampling job) |
| `NpsUserStateService.writeTriggered(userId)` | New | API Handler (called from Sampling Spec 2 serve path) |
| Year rollover logic in `writeTriggered()` | New | API Handler |
| `OptimisticLockException` handling in `writeTriggered()` | New | API Handler |
| Integration of `isInCoolOff()` into `NpsWeeklySamplePreparationJob` eligible-user filter | Modified | Worker |
| DDL specification for `nps_user_state` table | New | DB migrations repo (spec only — see §4) |
| Unit tests for `NpsUserStateService` (all gate + rollover + concurrency scenarios) | New | Both |

### Out of scope

| Item | Reason |
|---|---|
| `writeTriggered()` call site (atomic with `nps_weekly_sample.status=SERVED`) | Lives in Sampling Spec 2, chunk 05 — that spec owns the serve transaction |
| Mid-week cool-off re-verification at serve time | Not required — cool-off is checked only at week start (D-03) |
| `last_nps_response_classification` write | Written when a survey response is classified — a concern of the response capture spec |
| CSAT cool-off (`csat_user_state`) | Future spec; mirrors this pattern |
| `NpsUserState` row eviction / archival for inactive users | Deferred; table rows are small and the set of ever-triggered users grows slowly |

---

## 3. Design Decisions

| Decision | ADR |
|---|---|
| Cool-off state lives in a CAS-owned MySQL table `nps_user_state` (not Bigtable, not `PreprocessedSurvey`) | [ADR-009](../adrs/ADR-009-nps-cool-off-storage.md) |
| Annual cap enforced by application-code year rollover in `writeTriggered()` (not a DB CHECK constraint, not a scheduled reset job) | [ADR-010](../adrs/ADR-010-nps-annual-cap-enforcement.md) |

---

## 4. Architecture

### 4.1 Component map

```
Background Worker                               API Handler
────────────────────────────────────────────   ────────────────────────────────────────
NpsWeeklySamplePreparationJob [PROPOSED]       CheckInService [Sampling Spec 2]
  └─► NpsUserStateService                        └─► NpsUserStateService
        └─► NpsUserStateStorage                        └─► NpsUserStateStorage
              └─► nps_user_state (MySQL)                     └─► nps_user_state (MySQL)
```

**`NpsUserStateService`** (interface + impl in `module/analytics/nps/`) exposes:

- `boolean isInCoolOff(String userId, int coolOffDays, int yearlyTriggerCap)` — read-only gate; `@Transactional(readOnly = true)`
- `NpsUserState writeTriggered(String userId)` — write; `@Transactional`

**`NpsUserStateStorage`** is a Spring Data JPA repository extending `CrudRepository<NpsUserState, Long>` with a single custom finder:

- `Optional<NpsUserState> findByUserId(String userId)`

**`NpsWeeklySamplePreparationJob`** (Sampling Spec 2, chunk 04) is modified to call `isInCoolOff()` during its eligible-user filter pass. The job iterates candidates in configurable batches; `isInCoolOff()` is called once per candidate per batch iteration.

### 4.2 Data flow — cool-off check at week start

```
Monday 00:05 (Africa/Lagos)
  NpsWeeklySamplePreparationJob.runForWeek(isoWeek)
    │
    ├── For each active NpsMeasurement:
    │     │
    │     └── For each candidate userId (batch-paginated from UserAttributesStorage):
    │           │
    │           ├── Apply pre-cool-off eligibility gates:
    │           │     accountAgeDays >= 60
    │           │     transactionCount(last30Days) >= 1
    │           │
    │           ├── NpsUserStateService.isInCoolOff(userId, coolOffDays, yearlyTriggerCap)
    │           │     ├── findByUserId(userId) → NpsUserState or null
    │           │     ├── null → return false (first-time user, eligible)
    │           │     ├── daysSinceTrigger < coolOffDays → return true (in cool-off window)
    │           │     ├── triggerYear==thisYear AND count>=cap → return true (annual cap)
    │           │     └── → return false (eligible)
    │           │
    │           └── [if false] → add to candidate pool for random selection
    │
    └── Random selection up to weeklyInvitationCap
          INSERT INTO nps_weekly_sample (userId, measurementId, isoWeek, status=PENDING)
```

### 4.3 Data flow — trigger write at serve time

This path is implemented in **Sampling Spec 2, chunk 05**. `NpsUserStateService.writeTriggered()` (from this spec) is called within that transaction.

```
Check-in API call (userId, isoWeek)
  │
  ├── Lookup nps_weekly_sample(userId, isoWeek, status=PENDING) → hit
  │
  ├── BEGIN TRANSACTION
  │     ├── UPDATE nps_weekly_sample SET status=SERVED, version=N+1 WHERE id=? AND version=N
  │     └── NpsUserStateService.writeTriggered(userId)
  │           ├── findByUserId(userId) → NpsUserState or null
  │           ├── Compute new state: lastTriggeredDate=today, year rollover or increment
  │           ├── save(state) → UPDATE WHERE version=M → success OR OptimisticLockException
  │           │     └── [OptimisticLockException]
  │           │           └── findByUserId(userId) → return already-committed state
  │           └── return NpsUserState
  │
  └── COMMIT → both writes atomic
```

### 4.4 Tier 3 paths touched

Per `CLAUDE.md`, the following paths require **2 CODEOWNER approvals**:

| Path | Change |
|---|---|
| `src/main/java/**/module/analytics/entity/` | New `NpsUserState.java` entity |

New files in `module/analytics/nps/` sub-package (entity, service, storage) are the primary deliverables. The modification to `NpsWeeklySamplePreparationJob` (in `module/job/jobs/`) is a single method call addition and does not touch a Tier 3 path.

---

## 5. Chunk List

| ID | Name | Description | Modules | Est. lines (impl + test) | Depends on |
|----|------|-------------|---------|--------------------------|------------|
| **01** | `NpsUserState` entity + `NpsUserStateStorage` + DDL spec | `NpsUserState.java` extending `BaseEntity` with all columns; `NpsUserStateStorage.java` (`CrudRepository` + `findByUserId`); DDL specification for `nps_user_state` table with `UNIQUE INDEX` on `user_id`; no migration script (migrations repo) | `module/analytics/nps/entity/`, `module/analytics/nps/repository/` | ~300 | — |
| **02** | `NpsUserStateService` — gate + write + year rollover + concurrency | `NpsUserStateService` interface; `NpsUserStateServiceImpl` with `isInCoolOff()` (read-only gate: null check, 90-day window, annual cap) and `writeTriggered()` (upsert with year rollover, `OptimisticLockException` catch); full unit test suite covering all scenarios in §6 | `module/analytics/nps/service/`, `module/analytics/nps/service/impl/` | ~400 | 01 |
| **03** | Integration into `NpsWeeklySamplePreparationJob` | Wire `NpsUserStateService.isInCoolOff()` into the per-user eligible-user filter loop inside `NpsWeeklySamplePreparationJob`; read `coolOffDays` and `yearlyTriggerCap` from `SurveyBody` at job execution time; integration test asserting that a user with `lastNpsTriggeredDate = today - 30` is excluded from the produced sample | `module/job/jobs/NpsWeeklySamplePreparationJob.java` | ~100 | 01, 02 |

> **Note on chunk 05 of Sampling Spec 2:** The atomic trigger write — calling `NpsUserStateService.writeTriggered()` within the same transaction as `nps_weekly_sample.status = SERVED` — is implemented in **Sampling Spec 2, chunk 05**. That chunk depends on this spec's chunk 02 being merged first. The dependency is:
>
> `This spec (01 → 02 → 03)` must be merged before `Sampling Spec 2, chunk 05`.

---

## 6. Capability Test Strategy

### Key test scenarios for `NpsUserStateServiceImpl`

| # | Scenario | Setup | Expected result |
|---|---|---|---|
| T-01 | First-time user — null state | `findByUserId()` returns empty | `isInCoolOff()` returns `false` |
| T-02 | In cool-off window — 89 days elapsed | `lastNpsTriggeredDate = today - 89` | `isInCoolOff()` returns `true` |
| T-03 | Exactly at boundary — 90 days elapsed | `lastNpsTriggeredDate = today - 90` | `isInCoolOff()` returns `false` (boundary is exclusive — 90 days elapsed means eligible) |
| T-04 | Outside cool-off window — 91 days elapsed | `lastNpsTriggeredDate = today - 91` | `isInCoolOff()` returns `false` |
| T-05 | Annual cap hit — same year, count = 2 | `triggerYear = thisYear`, `triggerCountYear = 2` | `isInCoolOff()` returns `true` even if 91+ days elapsed |
| T-06 | Annual cap not hit — same year, count = 1 | `triggerYear = thisYear`, `triggerCountYear = 1`, `lastTriggeredDate = today - 95` | `isInCoolOff()` returns `false` |
| T-07 | Year rollover — trigger_year = prior year | `triggerYear = thisYear - 1`, `triggerCountYear = 2`, `lastTriggeredDate = today - 91` | `isInCoolOff()` returns `false` (prior-year count does not apply); `writeTriggered()` resets `triggerCountYear = 1` and `triggerYear = thisYear` |
| T-08 | First trigger write — no prior row | `findByUserId()` returns empty | `writeTriggered()` inserts new row with `lastNpsTriggeredDate = today`, `triggerYear = thisYear`, `triggerCountYear = 1` |
| T-09 | Second trigger write — same year | Existing row with `triggerYear = thisYear`, `triggerCountYear = 1` | `writeTriggered()` increments `triggerCountYear = 2` |
| T-10 | Year rollover write | Existing row with `triggerYear = thisYear - 1`, `triggerCountYear = 2` | `writeTriggered()` sets `triggerYear = thisYear`, `triggerCountYear = 1` |
| T-11 | Concurrent double-serve | Two threads call `writeTriggered()` with same `userId`; second sees stale version | First thread commits; second receives `OptimisticLockException`; service catches and returns already-committed row; `triggerCountYear` incremented exactly once |
| T-12 | `trigger_year = null` (defensive) | Row exists but `triggerYear = null` | `null != thisYear` → rollover branch; `triggerYear = thisYear`, `triggerCountYear = 1` |

### Integration test for sampling job integration (chunk 03)

| # | Scenario | Setup | Expected result |
|---|---|---|---|
| IT-01 | User in cool-off excluded from sample | Insert `nps_user_state` with `lastNpsTriggeredDate = today - 30`; run job | User not present in `nps_weekly_sample` for the current week |
| IT-02 | User outside cool-off included | Insert `nps_user_state` with `lastNpsTriggeredDate = today - 95`; run job with matching cohort | User present in `nps_weekly_sample` with `status=PENDING` |
| IT-03 | New user (no state row) included | No `nps_user_state` row for userId | User present in `nps_weekly_sample` |
| IT-04 | Annual cap exhausted user excluded | `triggerYear = thisYear`, `triggerCountYear = 2`, `lastTriggeredDate = today - 95` | User not present in `nps_weekly_sample` |

---

## 7. Rollout Plan

| Step | Action | Rollback |
|---|---|---|
| 1 | Merge chunk 01 (`NpsUserState` entity + `NpsUserStateStorage`) behind `nps.programme.enabled=false` | No user impact; table is empty and unused |
| 2 | Raise DDL migration in the DB migrations repository: `CREATE TABLE nps_user_state (...)` with `UNIQUE INDEX`. Coordinate deployment with DBA team before merging chunk 01 to staging | Drop table if abandoning |
| 3 | Merge chunk 02 (`NpsUserStateService`) behind flag | No user impact; service is not called until sampling job is wired up |
| 4 | Merge chunk 03 (sampling job integration) behind flag | No user impact while `nps.programme.enabled=false` |
| 5 | Enable `nps.programme.enabled=true` in staging. Run sampling job against synthetic cohort. Verify that (a) users with recent `nps_user_state` rows are excluded, (b) the produced `nps_weekly_sample` respects cool-off, (c) `writeTriggered()` is called from Sampling Spec 2 chunk 05 and creates/updates rows correctly | Disable flag; inspect `nps_user_state` rows in staging |
| 6 | Enable for 1% of Personal users in production. After 1 full sampling cycle, verify `nps_user_state` row counts match expected trigger volume | Disable flag; no data corruption risk (table is write-once-per-week per user) |
| 7 | Scale to full rollout per the broader NPS sampling rollout plan (`impl-specs/2026-05-18-nps-sampling-engine.md` §7) | Disable flag at any step |

**Dependency on Sampling Spec 2:** This spec's chunk 01 and chunk 02 must be merged and deployed before Sampling Spec 2 chunk 05 can land (chunk 05 calls `writeTriggered()`). Chunk 03 (sampling job integration) may be merged in parallel with chunk 05, but the sampling job only runs if the flag is enabled, so ordering is flexible.

---

## 8. Security Threat Model

Evaluated against OWASP API Security Top 10 for the surface introduced by this spec.

| OWASP Risk | Applicable | Impact | Mitigation |
|---|---|---|---|
| API1 — Broken Object Level Authorization | No | `NpsUserStateService` is an internal service with no REST endpoints. Access is only via internal service-to-service calls (sampling job and check-in serve path). No object-level authorization is needed. | — |
| API2 — Broken Authentication | No | No public endpoint introduced in this spec. `nps_user_state` is accessed exclusively via `NpsUserStateService` from internal call sites. | — |
| API3 — Broken Object Property Level Authorization | No | `NpsUserState` is never returned in an API response in this spec. Classification write is in the response capture spec. | — |
| API4 — Unrestricted Resource Consumption | **Yes** | `NpsWeeklySamplePreparationJob` calls `isInCoolOff()` once per candidate user. With 24M+ potential users in the Personal cohort, a naive implementation could hold a large result set in memory. | Job iterates candidates in configurable batches (`nps.sampling.batch-size`, default 1,000). `isInCoolOff()` performs a single point-read per user (indexed by `user_id`). ShedLock prevents concurrent re-runs of the same job instance. No full-table scan on `nps_user_state`. |
| API5 — Broken Function Level Authorization | No | Service methods are package-private to `module/analytics/nps/`. No admin endpoint exposed. | — |
| API6 — Unrestricted Access to Sensitive Business Flows | **Yes** | Concurrent check-in calls (network retry, double-tap, dual-device) could cause double-trigger: writing `last_nps_triggered_date` twice in one week and consuming two annual budget slots for a single intentional trigger. | `@Version` on `BaseEntity` provides optimistic locking. The second concurrent `writeTriggered()` call receives `OptimisticLockException`. The service catches this exception and returns the already-committed state without incrementing `trigger_count_year` a second time. The annual budget is consumed exactly once per trigger event. Unit test T-11 covers this. |
| API7 — Server Side Request Forgery | No | No outbound HTTP calls in this spec. | — |
| API8 — Security Misconfiguration | **Yes** | `last_nps_response_classification` contains user behaviour data. `user_id` is a PII-adjacent identifier. Both must be excluded from structured logs. | `NpsUserStateService` logs only `userId` at DEBUG level (not at INFO). `lastNpsResponseClassification` is never logged. Log masking rule: `userId` logged as a correlation identifier only; no state fields logged at INFO or above. Consistent with `patterns/pii-masking.md`. |
| API9 — Improper Inventory Management | No | No new public endpoints. | — |
| API10 — Unsafe Consumption of APIs | No | `NpsUserStateStorage` performs typed, indexed reads from CAS-owned MySQL. No user-supplied data is echoed back as a query parameter, URL, or command. | — |

### Cross-cutting security rules (CLAUDE.md)

| Rule | Application |
|---|---|
| **Typed exceptions only** | `writeTriggered()` does not swallow `OptimisticLockException` silently — it catches, re-reads the row, and returns. All other unexpected exceptions propagate as `ServerException`. No raw `RuntimeException` thrown. |
| **`@Transactional` on writes** | `writeTriggered()` annotated with `@Transactional`. `isInCoolOff()` annotated with `@Transactional(readOnly = true)`. |
| **Constructor injection** | `NpsUserStateServiceImpl` uses `@RequiredArgsConstructor` (Lombok). No `@Autowired` field injection. |
| **No silent exception swallowing** | `OptimisticLockException` is explicitly caught and the re-read result is returned. The catch is not silent — it produces a DEBUG log entry indicating the idempotent resolution with the `userId` and resolved `version`. |
