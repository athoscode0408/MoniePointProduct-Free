# Implementation Spec: NPS Reminder Logic

## Document Info

| Field | Value |
|---|---|
| Status | Draft |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-19 |
| PRD | [NPS PRD — teamapt Confluence PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) (v1.0, April 2026) §9.1, §9.2 |
| PRD References | US-11, AC-11.1, AC-11.2, AC-11.3, AC-11.4, AC-11.5, AC-11.6 |
| Deployment Units | API Handler (survey delivery extension, reminder serve) |
| Companion Design Doc | [`docs/design/nps-reminder-design.md`](../../docs/design/nps-reminder-design.md) |
| ADRs | [ADR-007 Reminder State Storage](../../adrs/ADR-007-nps-reminder-state-storage.md), [ADR-008 Partial Completion Handling](../../adrs/ADR-008-nps-partial-completion.md) |
| Depends on | [`impl-specs/nps/2026-05-19-nps-sampling.md`](2026-05-19-nps-sampling.md) — `NpsWeeklySample` entity, `DISMISSED` status, `NpsWeeklySampleStorage`, `SurveyBody.reminderMinIntervalHours` field |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Where to store `dismissed_at` and `reminder_served_at` | Extend `NpsWeeklySample` with two nullable TIMESTAMP columns. Co-locates all per-(user, cohort, week) state in one row; no JOIN or second query at check-in. See ADR-007. |
| D-02 | ABANDONED vs. DISMISSED — are they both reminder-eligible? | No. ABANDONED (`NpsWeeklySample.status = RESPONDED`, `PreprocessedSurvey.state = ABANDONED`) is NOT reminder-eligible. Only `NpsWeeklySample.status = DISMISSED` qualifies. See ADR-008. |
| D-03 | Is a "type: REMINDER" flag added to the survey response? | No. The client receives the same `PreprocessedSurvey` payload as the initial serve. No new field or flag in the response. Not in PRD. |
| D-04 | Is the reminder delivered as a push notification? | No. Reminder is delivered passively at check-in via the existing survey delivery endpoints (`GET /api/surveys/dashboard-info`, `GET /api/surveys/user`). No push notification infrastructure required. |
| D-05 | Does the reminder reset or extend the cool-off clock? | No. `NpsUserStateService.writeTriggered()` is called once at `PENDING → SERVED`. The DISMISSED and REMINDER_SERVED transitions do not modify `NpsUserState`. Cool-off runs from the original serve date. See design doc §9. |
| D-06 | Do reminders carry over to the next ISO week? | No. Condition C-2 in `NpsReminderEligibilityChecker` enforces week-bounded delivery. If the interval has not elapsed before week close, no reminder is served. |
| D-07 | Is `enableAlertingAfterDismissal` used for NPS reminders? | No. NPS reminder uses `NpsReminderEligibilityChecker` exclusively. `enableAlertingAfterDismissal` produces a `SurveyAlert` banner, which is a different UI component, has no interval gate, and has no week-boundary awareness. NPS cohort surveys must have `enableAlertingAfterDismissal = false`. |

---

## 1. Context

### 1.1 Why now

The NPS Sampling spec (`2026-05-19-nps-sampling.md`) delivered the `NpsWeeklySample` entity and the full PENDING → SERVED → DISMISSED / RESPONDED / EXPIRED state machine. The NPS Cohort Definition spec (`2026-05-19-nps-cohort-definition.md`) added `SurveyBody.reminderMinIntervalHours` as a platform-level configuration field.

With both foundational pieces in place, the reminder feature is the next step in the NPS engagement loop. Without reminders, users who dismiss the survey on first serve have no further opportunity to respond within the same week, reducing the programme's effective response rate.

### 1.2 Legacy check

**`enableAlertingAfterDismissal`** is an existing mechanism on `SurveyBody` that creates a `SurveyAlert` record when a survey is dismissed. This mechanism is used by BRM surveys to surface a dismissal reminder as a banner in the app. It was evaluated as a candidate for NPS reminders and rejected (D-07 above, design doc §10).

**Decision:** NPS reminder uses a new, dedicated `NpsReminderEligibilityChecker` component. `enableAlertingAfterDismissal` is not touched. NPS survey operators must set `enableAlertingAfterDismissal = false` in the NPS `SurveyBody` configuration to prevent the legacy banner mechanism from firing when an NPS survey is dismissed.

### 1.3 Scope summary

This spec delivers:

1. Two new nullable TIMESTAMP columns on `NpsWeeklySample`: `dismissed_at` and `reminder_served_at`, plus the DDL migration spec
2. `NpsReminderEligibilityChecker` service — evaluates all four reminder conditions in short-circuit order
3. Extension of `SurveyService.getUserSurveys()` to include DISMISSED NPS surveys in the response when all reminder conditions are met
4. Atomic write when the reminder is served: `reminder_served_at = NOW()`, `status = REMINDER_SERVED` in a single `@Transactional`
5. Explicit documentation of the ABANDONED vs. DISMISSED distinction and client event contract

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | `NpsWeeklySample` entity — add `dismissedAt` and `reminderServedAt` fields | API Handler + Worker | Modified |
| 2 | DDL spec: `ALTER TABLE nps_weekly_sample ADD COLUMN dismissed_at, ADD COLUMN reminder_served_at` | DB Migrations repo | New |
| 3 | `NpsReminderEligibilityChecker` interface + `NpsReminderEligibilityCheckerImpl` | API Handler | New |
| 4 | `SurveyService.getUserSurveys()` extension — call checker, include DISMISSED NPS surveys | API Handler | Modified |
| 5 | Atomic reminder write — `NpsWeeklySampleStorage.markReminderServed()` in `@Transactional` | API Handler | New |
| 6 | Client contract documentation — dismiss event vs. Q1 submission event distinction | N/A | Documentation |
| 7 | Unit + integration tests for all new components | API Handler | New |

### Out of scope

| # | Component | Reason |
|---|---|---|
| — | Push notification reminders | Not in PRD. Reminder is check-in only (passive delivery) |
| — | "type: REMINDER" flag in survey response | Not in PRD. Client receives standard `PreprocessedSurvey` payload |
| — | Cross-week reminders | Not in PRD. Week-bounded invariant; DISMISSED rows not carried over |
| — | Multiple reminders per week | PRD §9.1 limits to one reminder per user per week |
| — | ABANDONED-to-reminder pathway | Rejected in ADR-008. ABANDONED users (Q1 submitted) are not reminder-eligible |
| — | `enableAlertingAfterDismissal` changes | NPS reminder does not use this mechanism. Legacy mechanism unchanged |
| — | Response classification from reminder | Handled by existing `CompletedSurveyListener`; no change needed |

---

## 3. Design Decisions

| # | Decision | ADR |
|---|---|---|
| D-01 | Reminder state co-located on `NpsWeeklySample` (two nullable TIMESTAMP columns) | [ADR-007](../adrs/ADR-007-nps-reminder-state-storage.md) |
| D-02 | ABANDONED ≠ DISMISSED; only DISMISSED is reminder-eligible | [ADR-008](../adrs/ADR-008-nps-partial-completion.md) |

---

## 4. Architecture

### 4.1 Component map

```
  ┌──────────────────────────────────────────────────────────────────────────┐
  │                              API Handler                                  │
  │                                                                           │
  │  SurveyController                                          [MODIFIED]    │
  │    └─► SurveyService.getUserSurveys(userId)               [MODIFIED]    │
  │             │                                                             │
  │             │── Step 1: existing NOT_COMPLETED lookup                    │
  │             │   PreprocessedSurveyStorage.findByUserIdAndState(           │
  │             │       userId, NOT_COMPLETED)                               │
  │             │                                                             │
  │             │── Step 2: NPS reminder check (NEW)                         │
  │             │   NpsWeeklySampleStorage.findByUserIdAndIsoWeek(           │
  │             │       userId, currentIsoWeek)                              │
  │             │     → if status == DISMISSED:                              │
  │             │         NpsReminderEligibilityChecker.isEligible(          │
  │             │             sample, reminderMinIntervalHours)              │
  │             │           → if eligible:                                   │
  │             │               [BEGIN @Transactional]                       │
  │             │               NpsWeeklySampleStorage.markReminderServed()  │
  │             │               [COMMIT]                                     │
  │             │               fetch PreprocessedSurvey(DISMISSED)         │
  │             │               include in survey list                       │
  │             │                                                             │
  │  NpsReminderEligibilityChecker             [NEW]                         │
  │    C-1: status == DISMISSED                                              │
  │    C-2: IsoWeekUtil.current() == sample.isoWeek                         │
  │    C-3: NOW() - dismissedAt >= reminderMinIntervalHours * 60 min        │
  │    C-4: reminderServedAt IS NULL                                         │
  └──────────────────────────────────────────────────────────────────────────┘
                          │ MySQL (CAS-owned)
                          ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │  Tables                                                                   │
  │    nps_weekly_sample — gains dismissed_at, reminder_served_at  [MODIFIED]│
  │  Unchanged: preprocessed_survey, nps_user_state, cohort, survey          │
  └──────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Data flow — reminder served at check-in

```
User calls GET /api/surveys/user (or /api/surveys/dashboard-info)
  SurveyService.getUserSurveys(userId):

    currentIsoWeek ← IsoWeekUtil.current(ZoneId.of("Africa/Lagos"))

    // Step 1: standard NOT_COMPLETED lookup (existing, unchanged)
    surveys ← preprocessedSurveyStorage.findByUserIdAndState(userId, NOT_COMPLETED)

    // Step 2: NPS reminder check (NEW)
    sample ← npsWeeklySampleStorage.findByUserIdAndIsoWeek(userId, currentIsoWeek)
    if sample != null AND checker.isEligible(sample, reminderMinIntervalHours):

        // Atomic write: DISMISSED → REMINDER_SERVED
        // BEGIN @Transactional
        sample.status          ← REMINDER_SERVED
        sample.reminderServedAt ← now()
        npsWeeklySampleStorage.save(sample)   // @Version guard fires here
        // COMMIT @Transactional

        // Fetch the existing DISMISSED PreprocessedSurvey for this user+cohort
        reminderSurvey ← preprocessedSurveyStorage
            .findByUserIdAndCohortIdAndState(userId, sample.cohortId, DISMISSED)
        if reminderSurvey != null:
            surveys.add(reminderSurvey)

    return surveys   // standard + reminder (if applicable)

// On OptimisticLockException from markReminderServed():
//   re-read sample (status = REMINDER_SERVED)
//   fetch PreprocessedSurvey(DISMISSED) and include in response
//   no error propagated (idempotent)
```

### 4.3 Data flow — ABANDONED state flow (Q1-only submission)

```
User submits Q1 (NPS rating submitted, Q2 not submitted)
  Backend receives NPS_SURVEY_Q1_SUBMITTED event

  CompletedSurveyListener (existing):
    preprocessedSurvey.state ← ABANDONED
    preprocessedSurveyStorage.save(preprocessedSurvey)

  NpsWeeklySampleStorage (existing serve path):
    sample.status      ← RESPONDED
    sample.respondedAt ← now()
    npsWeeklySampleStorage.save(sample)

  // reminder_served_at remains NULL
  // dismissed_at remains NULL
  // NpsReminderEligibilityChecker C-1 will return false for this sample
  //   (status == RESPONDED, not DISMISSED)
  // No reminder will ever be served for this user for this week
```

### 4.4 Tier 3 paths touched

Per CLAUDE.md, these require **2 CODEOWNER approvals**:

| Path | Change | Reason |
|---|---|---|
| `src/main/java/**/module/analytics/entity/` | Modify `NpsWeeklySample` entity (add `dismissedAt`, `reminderServedAt` fields) | Entity changes have DB implications; coordinate DDL with DB migrations repo |
| `src/main/java/**/module/analytics/service/` | Extend `SurveyService.getUserSurveys()` (survey delivery path) | Core survey delivery — regression risk for BRM and CSAT paths |

---

## 5. Chunk List

| ID | Name | Description | Modules | Est. lines (impl + test) | Depends on |
|----|------|-------------|---------|--------------------------|------------|
| C-01 | Add `dismissed_at` and `reminder_served_at` columns to `NpsWeeklySample` + DDL migration spec | (a) Add `dismissedAt: Instant` and `reminderServedAt: Instant` nullable fields to `NpsWeeklySample` entity with `@Column(name = "dismissed_at")` and `@Column(name = "reminder_served_at")` annotations; (b) DDL migration spec for DB migrations repo: `ALTER TABLE nps_weekly_sample ADD COLUMN dismissed_at TIMESTAMP NULL AFTER served_at, ADD COLUMN reminder_served_at TIMESTAMP NULL AFTER dismissed_at`; (c) Update `NpsWeeklySampleStorage` with `markDismissed(NpsWeeklySample)` method — sets `dismissedAt = now()`, `status = DISMISSED` atomically; (d) Add `markReminderServed(NpsWeeklySample)` method — sets `reminderServedAt = now()`, `status = REMINDER_SERVED` atomically; (e) Invariant documentation: `dismissedAt` and `reminderServedAt` are written once and never overwritten; (f) Unit test: `markDismissed()` sets both `status` and `dismissedAt` in a single save; (g) Unit test: `markReminderServed()` sets both `status` and `reminderServedAt` in a single save; (h) `@Tag("simulation")` test: full DISMISSED → REMINDER_SERVED transition with version increment; (i) Verify backward compat: existing rows in PENDING/SERVED/RESPONDED/EXPIRED/ABANDONED have both columns as NULL — no data migration required. | API Handler | ~80 | `NpsWeeklySample` entity from sampling spec C-01 |
| C-02 | `NpsReminderEligibilityChecker` service — all 4 conditions, short-circuit evaluation | (a) `NpsReminderEligibilityChecker` interface with `isEligible(NpsWeeklySample sample, int reminderMinIntervalHours): boolean`; (b) `NpsReminderEligibilityCheckerImpl` implementing the four conditions in short-circuit order: C-1 (status == DISMISSED), C-2 (current ISO week == sample.isoWeek), C-3 (interval elapsed), C-4 (reminderServedAt IS NULL); (c) `IsoWeekUtil.forDate(LocalDate, ZoneId)` static method for week-boundary check (if not already present from sampling spec — verify before adding); (d) Duration arithmetic: `Duration.between(sample.getDismissedAt(), Instant.now()).toMinutes() >= reminderMinIntervalHours * 60L`; (e) Unit test: all four conditions true → returns true; (f) Unit test: C-1 false (status = SERVED) → returns false, no further evaluation; (g) Unit test: C-1 true, C-2 false (different ISO week) → returns false; (h) Unit test: C-1 + C-2 true, C-3 false (interval not elapsed) → returns false; (i) Unit test: C-1 + C-2 + C-3 true, C-4 false (reminderServedAt not null) → returns false; (j) Unit test: zero-hour interval (`reminderMinIntervalHours = 0`) — immediate eligibility on same check-in that dismissed (edge case: dismissal and check-in in same transaction window); (k) Unit test: ISO week boundary — dismissedAt in W21, check-in in W22 → C-2 fails; (l) Unit test: interval boundary — dismissed exactly `reminderMinIntervalHours * 60 minutes` ago → eligible (inclusive boundary); (m) Test naming follows `{method}_{scenario}_{expectedResult}` convention. | API Handler | ~250 | C-01 |
| C-03 | Survey delivery extension — `SurveyService.getUserSurveys()` extended to call checker, atomic reminder write, `OptimisticLockException` handling | (a) After the standard NOT_COMPLETED `PreprocessedSurvey` lookup in `SurveyService.getUserSurveys()` (or equivalent), add NPS reminder step: `npsWeeklySampleStorage.findByUserIdAndIsoWeek(userId, currentIsoWeek)` → if found, call `checker.isEligible()`; (b) If eligible: within a `@Transactional` method, call `npsWeeklySampleStorage.markReminderServed(sample)`, then fetch `PreprocessedSurvey` by `(userId, cohortId, DISMISSED)` and include in the result list; (c) `OptimisticLockException` from `markReminderServed()` is caught: re-read the sample (now REMINDER_SERVED), fetch the `PreprocessedSurvey`, include in the result list — idempotent response; (d) If `reminderSurvey` (DISMISSED PreprocessedSurvey) is null after eligibility check (defensive guard — expired or missing): log `WARN` and skip reminder; do not throw; (e) BRM and CSAT paths must be verified to be unaffected — the new NPS step is conditional on finding a DISMISSED `NpsWeeklySample` row for the current week; (f) `reminderMinIntervalHours` read from `SurveyBody` of the NPS cohort's survey via `objectMapper.readValue(survey.getSurvey(), SurveyBody.class).getReminderMinIntervalHours()`; (g) Unit test: user has DISMISSED sample + all 4 conditions met → DISMISSED PreprocessedSurvey included in result, `markReminderServed()` called once; (h) Unit test: user has DISMISSED sample but interval not elapsed → checker returns false → no reminder in result; (i) Unit test: user has DISMISSED sample + already REMINDER_SERVED (`reminderServedAt != null`) → C-4 fails → no second reminder; (j) Unit test: user has no `NpsWeeklySample` row for current week → reminder check is a no-op → existing NOT_COMPLETED surveys returned unchanged; (k) Unit test: `OptimisticLockException` → re-read, reminder included in response, `markReminderServed()` effectively called once; (l) Unit test: BRM survey delivery path unchanged — BRM user with no DISMISSED NPS sample receives no NPS reminder; (m) `@Tag("simulation")` test: full end-to-end flow — DISMISSED sample → check-in after interval → REMINDER_SERVED written → `PreprocessedSurvey` returned → second check-in → no second reminder. | API Handler | ~250 | C-01, C-02 |

**Total: ~580 lines** across **3 chunks**. C-01 must complete before C-02 and C-03. C-02 and C-03 can proceed in parallel after C-01 merges (C-03 depends on C-02's interface, but the interface can be finalized in C-02 without the full implementation being merged).

---

## 6. Capability Test Strategy

### Key scenarios per acceptance criteria

| # | AC | Scenario | Test type | Assertion |
|---|---|---|---|---|
| T-01 | AC-11.1 | User dismisses NPS survey; checks in again after `reminderMinIntervalHours` elapsed, same ISO week | Integration (`@Tag("simulation")`) | `NpsWeeklySample.status = REMINDER_SERVED`; `reminderServedAt` set; DISMISSED `PreprocessedSurvey` returned in response |
| T-02 | AC-11.1 | User dismisses; checks in before interval elapsed | Unit | Checker C-3 false → no reminder in response; `NpsWeeklySample.status` remains DISMISSED |
| T-03 | AC-11.2 | User already received reminder (`reminderServedAt != null`); checks in again | Unit | Checker C-4 false → no second reminder; status remains REMINDER_SERVED |
| T-04 | AC-11.3 | User submits Q1 only (ABANDONED) → `NpsWeeklySample.status = RESPONDED` | Unit | Checker C-1 false → no reminder evaluated; `PreprocessedSurvey.state = ABANDONED` preserved |
| T-05 | AC-11.4 | User fully responded (Q1 + Q2 → RESPONDED, COMPLETED) | Unit | Checker C-1 false (status = RESPONDED) → no reminder |
| T-06 | AC-11.5 | Week closes before interval elapses; new week begins | Unit | Checker C-2 false (different ISO week) → no reminder; old DISMISSED row transitions to ABANDONED in expiry job; no carryover to new week |
| T-07 | AC-11.6 | `reminderMinIntervalHours` is read from `SurveyBody` (platform-level, same for all users in cohort) | Unit | Two users in same cohort with same dismiss time both become eligible at the same instant (`reminderMinIntervalHours` is not per-user or per-app-type) |
| T-08 | — | Concurrent check-in calls both pass eligibility → `OptimisticLockException` on second | Unit | First call writes REMINDER_SERVED; second catches exception, re-reads, returns reminder in response; `reminderServedAt` written exactly once |
| T-09 | — | BRM user regression — no DISMISSED NPS sample → survey delivery unchanged | Unit | No `NpsWeeklySample` row found → NPS reminder step is a no-op → BRM surveys returned normally |
| T-10 | — | `reminderMinIntervalHours = 0` — immediate eligibility | Unit | User dismisses and checks in in the same minute → eligible (interval = 0 minutes >= 0 minutes required) |
| T-11 | — | `reminderSurvey` (DISMISSED PreprocessedSurvey) is null after eligibility check (defensive guard) | Unit | `WARN` logged; no reminder in response; no exception thrown |
| T-12 | — | ISO week boundary: dismiss on Sunday evening, check-in Monday morning | Unit | C-2 fails (new week) → no reminder; DISMISSED row becomes ABANDONED at week close |

### Coverage requirements

- `NpsReminderEligibilityCheckerImpl`: ≥ 90% line coverage (all four conditions and all short-circuit branches exercised)
- `SurveyService` reminder extension: ≥ 80% line coverage
- BRM and CSAT regression: existing `SurveyService` tests must remain green after the NPS reminder extension is merged

---

## 7. Rollout Plan

| Step | Action | Deployment Unit | Rollback |
|------|--------|-----------------|---------|
| 0 | Merge all 3 chunks with reminder check guarded by `nps.reminder.enabled = false`. When the flag is false, `SurveyService.getUserSurveys()` skips the NPS reminder step entirely (Step 2 is a no-op). `NpsReminderEligibilityChecker` is present but never called. | API Handler | Revert PRs. Flag defaults to false. No DB rows touched. |
| 1 | Apply DB migration: `ALTER TABLE nps_weekly_sample ADD COLUMN dismissed_at TIMESTAMP NULL, ADD COLUMN reminder_served_at TIMESTAMP NULL`. Migration is additive — no existing rows affected. Both columns default to NULL. | DB Migrations repo | `ALTER TABLE nps_weekly_sample DROP COLUMN dismissed_at, DROP COLUMN reminder_served_at`. |
| 2 | Verify that the dismiss event path writes `dismissed_at` correctly in staging: trigger an NPS survey for a test user, dismiss it, confirm `nps_weekly_sample.dismissed_at` is set and `status = DISMISSED`. | Staging | N/A |
| 3 | Enable `nps.reminder.enabled = true` in staging for a test cohort. Verify: (a) User dismisses → `dismissed_at` written; (b) After `reminderMinIntervalHours` elapsed, check-in returns DISMISSED `PreprocessedSurvey`; (c) `reminder_served_at` written, `status = REMINDER_SERVED`; (d) Second check-in within same week → no second reminder; (e) BRM survey delivery unaffected for test users without DISMISSED NPS samples. | Staging | `nps.reminder.enabled = false`. |
| 4 | Confirm client event taxonomy with mobile team: verify `NPS_SURVEY_DISMISSED` and `NPS_SURVEY_Q1_SUBMITTED` are distinct events and routed to the correct backend handlers. This is a cross-team dependency and must be completed before production enablement. | Client + API Handler | N/A (contract verification; no deployment) |
| 5 | Enable `nps.reminder.enabled = true` for 5% of users in production. Monitor: `reminder_served_at` write rate per day; no double-reminder incidents (`reminderServedAt` set more than once per sample, which should be impossible but is worth monitoring for 24 hours); BRM survey delivery rate unchanged. | Production | `nps.reminder.enabled = false`. |
| 6 | Full ramp: enable for all users. | Production | Feature flag off. |

**Pre-production checklist:**
- DB migration reviewed and approved by 2 CODEOWNERs (Tier 3 entity change)
- Client team confirms distinct event types for dismiss vs. Q1 submission (acceptance criterion for AC-11.3)
- `SurveyService` regression tests pass on staging with NPS reminder enabled
- Grafana panel configured: `reminder_served_at` write rate per cohort per ISO week
- AlertManager alert configured: double-reminder detection (`reminder_served_at` non-null count > expected single-serve ceiling per week)

---

## 8. Security Threat Model

Evaluated against OWASP API Security Top 10 for the surface introduced in this spec.

| OWASP Risk | Applicable | Impact | Mitigation |
|---|---|---|---|
| API1 — Broken Object Level Authorization | **No** | No new endpoints. The reminder is returned through the existing authenticated survey delivery endpoint. The existing `userId` authorization on that endpoint applies. | — |
| API2 — Broken Authentication | **No** | No new auth surface. Reminder path is part of an existing authenticated endpoint. | — |
| API3 — Broken Object Property Level Authorization | **Yes** | `NpsWeeklySample.dismissedAt` and `reminderServedAt` are internal programme fields that must not be returned to clients. The survey delivery response returns only `PreprocessedSurvey` payload (standard survey fields). | Survey delivery maps `PreprocessedSurvey` → `SurveyResponseItem` DTO. No `NpsWeeklySample` fields appear in the mapping. Unit test asserts no `dismissedAt`, `reminderServedAt`, or `status` field in the serialised response. |
| API4 — Unrestricted Resource Consumption | **Yes** | The reminder check adds one `NpsWeeklySampleStorage.findByUserIdAndIsoWeek()` call per check-in call for any user who may have a DISMISSED sample. | The lookup is a single point-read by `(user_id, iso_week)` using the existing `UNIQUE INDEX(user_id, cohort_id, iso_week)`. If no row is found (the common case for users not in a current week's NPS sample), the call returns null quickly and the reminder step is skipped. No scan, no JOIN, no secondary query. |
| API5 — Broken Function Level Authorization | **No** | No new internal admin endpoints. | — |
| API6 — Unrestricted Access to Sensitive Business Flows | **Yes** | Double-reminder on concurrent check-in calls: two simultaneous check-in calls both pass `isEligible()` and both attempt `DISMISSED → REMINDER_SERVED`. Second call must not write a second reminder. | `@Version` optimistic locking on `NpsWeeklySample` (from `BaseEntity`) prevents concurrent double-write. The second call's `UPDATE WHERE version=N` fails with `OptimisticLockException`. The service catches this, re-reads the sample (now `REMINDER_SERVED`), and returns the reminder payload idempotently. `reminderServedAt` is written exactly once. |
| API7 — Server Side Request Forgery | **No** | No outbound HTTP calls introduced. All new logic is MySQL reads/writes. | — |
| API8 — Security Misconfiguration | **Yes** | If `reminderMinIntervalHours = 0` is inadvertently set in `SurveyBody`, users would receive the reminder on the same check-in that dismisses the survey — potentially in the same request if the dismiss event is processed synchronously before the next check-in. | `SurveyBody.reminderMinIntervalHours` must be validated as `>= 1` in the `SurveyBody` schema validation. A zero-interval reminder is not a security vulnerability per se (the reminder just appears immediately), but it violates the spirit of the interval gate. Validator added in the `SurveyBody` cohort spec or this spec (whichever introduces the field validation). |
| API9 — Improper Inventory Management | **No** | No new endpoints, no shadow routes. | — |
| API10 — Unsafe Consumption of APIs | **No** | No new external API consumption. The reminder feature is entirely internal (MySQL reads/writes). | — |

### Cross-cutting security rules (CLAUDE.md enforced)

| Rule | Application |
|---|---|
| **Tier 3 — 2 CODEOWNER approvals** | `NpsWeeklySample` entity modification (add columns), `SurveyService` modification (survey delivery path) — both Tier 3 paths |
| **No PII in logs** | `NpsReminderEligibilityChecker` logs use only `cohortId`, `isoWeek`, and boolean outcome. No `userId`, no `dismissedAt` timestamp in log statements |
| **DB migrations in separate repo** | DDL for `ALTER TABLE nps_weekly_sample` is specified here but raised in the DB migrations repo |
| **Constructor injection** | `NpsReminderEligibilityCheckerImpl` uses `@RequiredArgsConstructor`. No `@Autowired` field injection |
| **Typed exceptions** | `OptimisticLockException` is the only expected exception from the reminder write path. It is caught at the service boundary and resolved to an idempotent already-served state. All other exceptions are propagated as `ServerException` |
