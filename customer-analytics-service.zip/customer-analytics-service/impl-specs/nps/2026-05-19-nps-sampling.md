# Implementation Spec: NPS Weekly Sampling

## Document Info

| Field | Value |
|---|---|
| Status | Draft — revised 2026-05-25 |
| Author | Mohammed Kamil (`mohammed.kamil@moniepoint.com`) |
| Date | 2026-05-19 — updated 2026-05-21, 2026-05-25 |
| PRD | [NPS PRD — teamapt Confluence PO1/3295740048](https://teamapt.atlassian.net/wiki/spaces/PO1/pages/3295740048/NPS+PRD) (v1.0, April 2026) |
| Deployment Units | Background Worker (sampling job, expiry job, Kafka consumer) + API Handler (serve path) |
| Companion Design Doc | [`docs/design/nps-sampling-design.md`](../../docs/design/nps-sampling-design.md), [`docs/design/clickhouse-airflow-pipeline-design.md`](../../docs/design/clickhouse-airflow-pipeline-design.md) |
| ADRs | [ADR-003 Preprocessing Timing](../../adrs/ADR-003-nps-preprocessing-timing.md), [ADR-004 Sampling Strategy](../../adrs/ADR-004-nps-sampling-strategy.md), [ADR-006 Daily Distribution](../../adrs/ADR-006-nps-daily-distribution.md) |
| Depends on | [`impl-specs/cohort/2026-05-21-cohort-platform.md`](../cohort/2026-05-21-cohort-platform.md) — `Cohort` entity, `CohortStorage`, `eligibility_rule` table, `survey_pipeline_audit` table; [`impl-specs/nps/2026-05-19-nps-cool-off.md`](2026-05-19-nps-cool-off.md) — `NpsUserStateService.writeTriggered()` |

---

## Decisions Resolved

| # | Topic | Resolution |
|---|---|---|
| D-01 | Preprocessing timing | At sample time (Monday job) via existing Kafka topic. Zero change to check-in path. 1-line null-guard in `SurveyPreprocessorListener.populateContextValuesMap()`. See ADR-003. |
| D-02 | Sampling strategy | Materialised weekly sample — Airflow writes PENDING rows; Monday CAS job publishes Kafka. Not quota gate at check-in. See ADR-004. |
| D-03 | Eligible user source | Airflow pipeline populates `nps_weekly_sample` (PENDING) by Sunday 22:00 Africa/Lagos. `NpsWeeklySamplePreparationJob` reads these pre-computed rows on Monday 01:00. CAS does not perform cohort lookup, cool-off filtering, or sampling — those are Airflow responsibilities. |
| D-04 | Daily distribution | Soft target — natural distribution from Airflow's random selection; no `trigger_day` column. See ADR-006. |
| D-05 | `NpsWeeklySample` entity design | Per-user-per-cohort-per-week sampling record. Status machine: PENDING → SERVED → (DISMISSED / RESPONDED / ABANDONED / EXPIRED). UNIQUE INDEX on `(user_id, cohort_id, iso_week)` for idempotency. INDEX on `(cohort_id, iso_week, status)` for expiry job. |
| D-06 | Serve path atomic write | `nps_weekly_sample.status = SERVED` + `NpsUserStateService.writeTriggered()` in the same `@Transactional` boundary. `OptimisticLockException` caught and resolved to already-served state. |
| D-07 | Null-guard in `SurveyPreprocessorListener` | One-line `if (event != null)` guard around all `event.*` map puts in `populateContextValuesMap()`. Existing BRM/CSAT paths are unaffected. |
| D-08 | ISO week computation | `java.time.WeekFields.ISO.weekBasedYear()` + `weekOfWeekBasedYear()` in `Africa/Lagos` timezone. `IsoWeekUtil.current(ZoneId)` utility class. |
| D-09 | NPS job scheduling dependency | Airflow DAG `cas_nps_weekly_pipeline` runs Sunday 22:00 Africa/Lagos and populates `nps_weekly_sample`. `NpsWeeklySamplePreparationJob` runs Monday 01:00 (3-hour buffer guarantees Airflow has completed). If `nps_weekly_sample` has no PENDING rows for the current week, the job logs a warning and exits without error. |
| D-10 | Sampling and eligibility config | Weekly cap, sampling algorithm, cool-off days, and annual cap are configured in `cohort.sampling_config` and `eligibility_rule` (Cohort Platform spec). `SurveyBody` retains only survey-content fields (`reminderMinIntervalHours`, `q2CopyByBand`). |

---

## 1. Context

### 1.1 Why now

The NPS Cohort Platform spec (`cohort/2026-05-21-cohort-platform.md`) defines the `Cohort` entity, `eligibility_rule` table, and `survey_pipeline_audit` table. The NPS Cool-Off spec (`2026-05-19-nps-cool-off.md`) defines `NpsUserState` and `NpsUserStateService`. The Airflow pipeline (`cas_nps_weekly_pipeline`) reads those configurations, queries ClickHouse for cohort membership, applies eligibility filtering, samples, and writes the result to `nps_weekly_sample` before Monday 01:00.

This spec builds the CAS-side components that complete the NPS sampling flow: the `NpsWeeklySample` entity that Airflow writes to, the simplified `NpsWeeklySamplePreparationJob` that bridges the pre-computed sample into Kafka, the serve path, and the expiry job.

### 1.2 Scope summary

This spec delivers:

1. `NpsWeeklySample` entity + `NpsWeeklySampleStorage`
2. `NpsWeeklySamplePreparationJob` — reads Airflow-populated PENDING rows → publishes Kafka
3. `SurveyBody` survey-content fields (`reminderMinIntervalHours`, `q2CopyByBand`)
4. `EventPreprocessSurveyDTO.cohortId` field + `PreprocessedSurvey.cohort_id` column
5. Null-guard in `SurveyPreprocessorListener.populateContextValuesMap()`
6. Serve path — atomic SERVED state + trigger write
7. Week-close expiry job

### 1.3 What sampling and eligibility config this spec does NOT own

| Config | Owner | Location |
|---|---|---|
| Weekly invitation cap (3200 / 2134) | Cohort Platform spec | `cohort.sampling_config.cap` |
| Cool-off window (90 days) | Cohort Platform spec | `eligibility_rule` row with `rule_type = COOL_OFF` |
| Annual trigger cap (2/year) | Cohort Platform spec | `eligibility_rule` row with `rule_type = ANNUAL_CAP` |
| Sampling algorithm | Cohort Platform spec | `cohort.sampling_config.type` |

These were previously `SurveyBody` fields (`weeklyInvitationCap`, `coolOffDays`, `yearlyTriggerCap`). They are now in the Cohort Platform's data model where Airflow can read them directly.

### 1.4 Legacy check

**What exists and is reused (unchanged or minimally modified):**

- `SurveyPreprocessorListener` [VERIFIED] — receives one null-guard addition
- `EventPreprocessSurveyDTO` [VERIFIED] — gains `cohortId: Long` field
- `PreprocessedSurvey` entity [VERIFIED] — gains `cohort_id` and `iso_week` columns
- `UserAttributesStorage.findUser()` [VERIFIED] — called by listener on the NPS path
- Quartz + ShedLock pattern [VERIFIED: `PreprocessedSurveyExpirationTriggerJob`] — reused exactly
- `SurveyPreprocessorKafkaEventPublisher` [VERIFIED] — reused without modification
- `CohortStorage.findBySurveyCategoryAndActiveTrue()` [PROPOSED: Cohort Platform C-01] — consumed by preparation job to resolve survey IDs per cohort

**What does not exist and is built by this spec:**

- `NpsWeeklySample` entity — `[PROPOSED]`
- `NpsWeeklySampleStorage` repository — `[PROPOSED]`
- `IsoWeekUtil` utility class — `[PROPOSED]`
- `NpsSampleStatus` enum — `[PROPOSED]`
- `NpsWeeklySamplePreparationJob` (simplified) — `[PROPOSED]`
- `NpsWeeklyExpiredSampleJob` — `[PROPOSED]`
- `cohortId` field on `EventPreprocessSurveyDTO` — `[PROPOSED]`
- `cohort_id` and `iso_week` columns on `PreprocessedSurvey` — `[PROPOSED]`
- Two survey-content fields on `SurveyBody` — `[PROPOSED]`
- Serve-path integration in check-in service — `[PROPOSED]`

---

## 2. Scope

### In scope

| # | Component | Deployment Unit | Change Type |
|---|---|---|---|
| 1 | `NpsWeeklySample` entity with all columns and status enum | Worker | New |
| 2 | `NpsWeeklySampleStorage` — `upsert()`, `findByUserAndWeek()`, `findPendingByIsoWeek()` | Worker | New |
| 3 | DDL spec: `nps_weekly_sample` table | DB Migrations repo | New |
| 4 | `NpsSampleStatus` enum | Worker | New |
| 5 | `IsoWeekUtil.current(ZoneId)` utility | Worker | New |
| 6 | `NpsWeeklySamplePreparationJob` — reads PENDING rows, publishes Kafka | Worker | New |
| 7 | Two survey-content fields on `SurveyBody`: `reminderMinIntervalHours`, `q2CopyByBand` | Both | Modified |
| 8 | `cohortId: Long` field on `EventPreprocessSurveyDTO` | Worker | Modified |
| 9 | `cohort_id BIGINT NULL` column on `PreprocessedSurvey` entity + DDL | Both | Modified |
| 10 | `iso_week CHAR(8)` column on `PreprocessedSurvey` entity + DDL | Both | Modified |
| 11 | `SurveyPreprocessorListener.populateContextValuesMap()` — 1-line null-guard + cohortId + isoWeek propagation | Worker | Modified |
| 12 | Serve path — PENDING → SERVED atomic write + `NpsUserStateService.writeTriggered()` | API Handler | New |
| 13 | `NpsWeeklyExpiredSampleJob` — PENDING → EXPIRED at ISO week boundary | Worker | New |
| 14 | Unit + integration tests for all new components | Both | New |

### Out of scope

| # | Component | Reason |
|---|---|---|
| — | Cohort membership lookup / `user_cohorts` | Not built — Airflow resolves and writes `nps_weekly_sample` directly |
| — | Cool-off exclusion logic in CAS sampling job | Moved to Airflow. CAS job reads pre-filtered PENDING rows |
| — | Sampling / shuffle logic in CAS | Moved to Airflow |
| — | `weeklyInvitationCap`, `coolOffDays`, `yearlyTriggerCap` on `SurveyBody` | Moved to `cohort.sampling_config` and `eligibility_rule` table (Cohort Platform spec) |
| — | Bigtable `RowFilter` scan | Replaced by ClickHouse query in Airflow |
| — | `CohortEligibilityGate` | Retired |
| — | Check-in API shape (request/response contract) | Separate workstream |
| — | POS heartbeat NPS delivery | Phase 1 out of scope |
| — | Response classification (`RESPONDED` status, NPS score) | Separate spec |
| — | NPS aggregation and scoring | Separate intelligence view spec |

---

## 3. Design Decisions

| # | Decision | ADR |
|---|---|---|
| D-01 | Preprocessing at sample time via existing Kafka topic; 1-line null-guard only | [ADR-003](../../adrs/ADR-003-nps-preprocessing-timing.md) |
| D-02 | Materialised weekly sample (Airflow writes PENDING, CAS publishes Kafka) | [ADR-004](../../adrs/ADR-004-nps-sampling-strategy.md) |
| D-03 | Airflow populates `nps_weekly_sample`; CAS sampling job is Kafka publisher only | [ADR-002](../../adrs/ADR-002-cohort-eligibility-integration.md) |
| D-04 | Soft daily distribution — no `trigger_day` column | [ADR-006](../../adrs/ADR-006-nps-daily-distribution.md) |

---

## 4. Architecture

### 4.1 Component map

```
  ┌──────────────────────────────────────────────────────────────────────────┐
  │                   Airflow (data platform team)                            │
  │  cas_nps_weekly_pipeline  (Sunday 22:00 Africa/Lagos)                    │
  │    ClickHouse → filter MySQL → sample → INSERT nps_weekly_sample PENDING │
  └─────────────────────────────────┬────────────────────────────────────────┘
                                    │ writes PENDING rows
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │                         Background Worker                                 │
  │                                                                           │
  │  NpsWeeklySamplePreparationJob  (Mon 01:00 Africa/Lagos)   [NEW]         │
  │    ├─► NpsWeeklySampleStorage.findPendingByIsoWeek()       [NEW]         │
  │    │     └─► SELECT PENDING rows for current ISO week                    │
  │    ├─► CohortStorage.findById()  (to resolve survey_id)   [cohort plat] │
  │    └─► SurveyPreprocessorKafkaEventPublisher.publish()     [REUSED]      │
  │                                                                           │
  │  SurveyPreprocessorListener  [MODIFIED — null-guard + cohortId + isoWeek]│
  │    └─► UserAttributesStorage.findUser()  (NPS: attrs null in DTO)        │
  │                                                                           │
  │  NpsWeeklyExpiredSampleJob  (Sun 23:59 Africa/Lagos)        [NEW]        │
  └──────────────────────────────────────────────────────────────────────────┘
                          │ Kafka (event-survey-preprocessor)
                          ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │                           API Handler                                     │
  │  CheckInService / NpsEligibilityResolver                  [MODIFIED]     │
  │    ├─► NpsWeeklySampleStorage.findByUserAndWeek()         [NEW]          │
  │    ├─► NpsWeeklySampleStorage.updateStatus(SERVED)        [NEW]          │
  │    └─► NpsUserStateService.writeTriggered()               [cool-off spec]│
  └──────────────────────────────────────────────────────────────────────────┘
                          │ MySQL (CAS-owned)
                          ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │  Tables                                                                   │
  │    nps_weekly_sample    [NEW — written by Airflow, read by CAS job]      │
  │    preprocessed_survey  — gains cohort_id, iso_week  [MODIFIED]          │
  │  From Cohort Platform: cohort, eligibility_rule                           │
  └──────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Data flow — weekly sample preparation

```
Sunday 22:00 Africa/Lagos — Airflow pipeline completes:
  nps_weekly_sample populated with PENDING rows for iso_week = "2026-W22"
  survey_pipeline_audit updated with funnel counts

Monday 01:00 Africa/Lagos — NpsWeeklySamplePreparationJob.execute():
  currentIsoWeek ← IsoWeekUtil.current("Africa/Lagos")
  // e.g. "2026-W22"

  pendingRows ← npsWeeklySampleStorage.findPendingByIsoWeek(currentIsoWeek)
  // SELECT * FROM nps_weekly_sample
  // WHERE iso_week = ? AND status = 'PENDING'

  if pendingRows.isEmpty():
    log.warn("NPS preparation: no PENDING rows for week={}, skipping", currentIsoWeek)
    return

  // Group by cohort to avoid repeated survey lookups
  pendingByCohort ← pendingRows.groupBy(row → row.cohortId)

  for each (cohortId, rows) in pendingByCohort:
    cohort ← cohortStorage.findById(cohortId)
    survey ← surveyStorage.findById(cohort.surveyId)

    for each row in rows:
      dto ← EventPreprocessSurveyDTO.builder()
        .survey(survey)
        .userAttributes(null)               // fetched by SurveyPreprocessorListener
        .verifiedAnalyticsEventDTO(null)    // NPS has no triggering event
        .preprocessedSurvey(
            PreprocessedSurvey.builder()
              .userId(row.userId)
              .surveyId(survey.id)
              .cohortId(cohortId)
              .isoWeek(currentIsoWeek)
              .build()
        )
        .build()

      surveyPreprocessorKafkaEventPublisher.publish(dto)

  log.info("NPS preparation: week={}, published={}", currentIsoWeek, pendingRows.size())
```

**Idempotency**: re-running the job re-publishes Kafka events. `SurveyPreprocessorListener` saves `PreprocessedSurvey` with `INSERT ON DUPLICATE KEY` semantics; a re-publish does not create a second survey for the user.

### 4.3 Data flow — serve path

```
Client calls GET /check-in
  CheckInService:
    sample ← NpsWeeklySampleStorage.findByUserAndWeek(userId, currentIsoWeek)
    if sample == null OR sample.status != PENDING → return (no NPS this week)

    // @Transactional
    sample.status = SERVED; sample.servedAt = now()
    NpsWeeklySampleStorage.save(sample)
    NpsUserStateService.writeTriggered(userId)   // same transaction

    return PreprocessedSurvey(NPS payload)

  // On OptimisticLockException:
    re-read sample (already SERVED)
    return existing PreprocessedSurvey (idempotent)
```

### 4.4 Tier 3 paths touched

| Path | Change | Reason |
|---|---|---|
| `src/main/java/**/module/analytics/entity/` | Add `NpsWeeklySample`; modify `PreprocessedSurvey` (`cohort_id`, `iso_week`) | Entity changes have DB implications |
| `src/main/java/**/module/analytics/enums/` | Add `NpsSampleStatus` | Enum stored as STRING — cannot rename after insert |
| `src/main/java/**/module/kafka/` | Modify `SurveyPreprocessorListener` (null-guard) + `EventPreprocessSurveyDTO` (cohortId) | Kafka contract change |

---

## 5. SurveyBody Survey-Content Fields

`SurveyBody` gains two typed fields for NPS survey content configuration. Sampling and eligibility parameters that were previously here (`weeklyInvitationCap`, `coolOffDays`, `yearlyTriggerCap`) are now owned by the Cohort Platform (`cohort.sampling_config` and `eligibility_rule` table).

| Field | Java Type | Default | Purpose |
|---|---|---|---|
| `reminderMinIntervalHours` | `int` | `24` | Min hours between initial serve and reminder. CAS-owned: used by the serve path reminder logic. |
| `q2CopyByBand` | `Q2CopyByBand` | `{}` | Band-specific Q2 copy shown to the user (detractor / passive / promoter). CAS-owned: appears in the `PreprocessedSurvey` payload. |

```java
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public static class Q2CopyByBand {
    private String detractor;
    private String passive;
    private String promoter;
}
```

---

## 6. `NpsWeeklySample` Aggregate

### 6.1 Entity schema

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | `BIGINT` | PK, AUTO_INCREMENT | From `BaseEntity` |
| `user_id` | `VARCHAR(50)` | NOT NULL | Platform user identifier |
| `cohort_id` | `BIGINT` | NOT NULL, FK → `cohort(id)` | Which cohort (written by Airflow) |
| `iso_week` | `CHAR(8)` | NOT NULL | e.g. `"2026-W21"`. `YYYY-Www` format, Africa/Lagos |
| `status` | `ENUM` | NOT NULL | See §6.2 |
| `served_at` | `TIMESTAMP` | NULL | PENDING → SERVED |
| `dismissed_at` | `TIMESTAMP` | NULL | SERVED → DISMISSED |
| `reminder_served_at` | `TIMESTAMP` | NULL | DISMISSED → REMINDER_SERVED |
| `responded_at` | `TIMESTAMP` | NULL | Any terminal → RESPONDED |
| BaseEntity audit fields | — | — | `created_by`, `created_on`, `last_modified_by`, `last_modified_on`, `version` |

**DDL:**

```sql
CREATE TABLE nps_weekly_sample (
    id                  BIGINT          NOT NULL AUTO_INCREMENT,
    user_id             VARCHAR(50)     NOT NULL,
    cohort_id           BIGINT          NOT NULL,
    iso_week            CHAR(8)         NOT NULL,
    status              ENUM(
                            'PENDING',
                            'SERVED',
                            'DISMISSED',
                            'REMINDER_SERVED',
                            'RESPONDED',
                            'EXPIRED',
                            'ABANDONED'
                        )               NOT NULL DEFAULT 'PENDING',
    served_at           TIMESTAMP       NULL,
    dismissed_at        TIMESTAMP       NULL,
    reminder_served_at  TIMESTAMP       NULL,
    responded_at        TIMESTAMP       NULL,
    version             INT             NOT NULL DEFAULT 0,
    created_by          VARCHAR(255)    NOT NULL,
    created_on          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_modified_by    VARCHAR(255)    NOT NULL,
    last_modified_on    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    CONSTRAINT uq_nws_user_cohort_week UNIQUE (user_id, cohort_id, iso_week),
    CONSTRAINT fk_nws_cohort FOREIGN KEY (cohort_id) REFERENCES cohort(id),
    INDEX idx_nws_cohort_week_status (cohort_id, iso_week, status)
);
```

**Index notes:**

- `UNIQUE(user_id, cohort_id, iso_week)` — idempotency for Airflow's INSERT ON DUPLICATE KEY and for the CAS job's Kafka re-publish safety
- `INDEX(cohort_id, iso_week, status)` — used by the preparation job (`WHERE iso_week = ? AND status = 'PENDING'`) and the expiry job

### 6.2 Status state machine

```
Airflow (Sunday 22:00)
  inserts row                   ┌─────────┐
  status = PENDING ─────────── ►│ PENDING │
                                 └────┬────┘
                                      │
                                      │ user checks in → survey returned
                                      │ (atomic: served_at = NOW,
                                      │  nps_user_state.last_triggered = today)
                                      ▼
                                 ┌─────────┐
                                 │  SERVED │
                                 └────┬────┘
                                      │
                        ┌─────────────┼──────────────────┐
                        │             │                  │
                        │ dismissed   │ responded        │ no action
                        ▼             ▼                  │ (week ends)
                   ┌──────────┐  ┌──────────┐            │
                   │DISMISSED │  │RESPONDED │◄───────┐   │
                   └────┬─────┘  └──────────┘        │   │
                        │                            │   │
                        │ reminder interval elapsed  │   │
                        ▼                            │   │
                ┌───────────────┐                   │   │
                │REMINDER_SERVED│                   │   │
                └───────┬───────┘                   │   │
                        │ responded                 │   │
                        └───────────────────────────┘   │
                                                        │
                                ┌──────────┐            │
                                │ EXPIRED  │ ◄──────────┘
                                └──────────┘
                          (ISO week boundary,
                       NpsWeeklyExpiredSampleJob)

                 ┌───────────┐
                 │ ABANDONED │  ◄── SERVED or REMINDER_SERVED
                 └───────────┘       with no action before EXPIRED
```

**Terminal states:** `RESPONDED`, `EXPIRED`, `ABANDONED`

---

## 7. Chunk List

| ID | Name | Description | Est. lines | Depends on |
|----|------|-------------|------------|------------|
| C-01 | `NpsWeeklySample` entity + storage + DDL | `NpsWeeklySample` entity, `NpsSampleStatus` enum, `NpsWeeklySampleStorage` (`upsert`, `findByUserAndWeek`, `findPendingByIsoWeek`), `IsoWeekUtil`, DDL for `nps_weekly_sample`. | ~300 | Cohort Platform C-01 |
| C-02 | `SurveyBody` survey-content fields | `reminderMinIntervalHours` and `q2CopyByBand` on `SurveyBody` + `Q2CopyByBand` nested type + deserialization tests (NPS payload round-trip; legacy BRM payload unaffected). | ~100 | — |
| C-03 | `PreprocessedSurvey` additions + DTO + listener | (a) `cohort_id BIGINT NULL` + `iso_week CHAR(8) NULL` on `PreprocessedSurvey`; (b) `cohortId: Long` on `EventPreprocessSurveyDTO`; (c) DDL for both columns; (d) Null-guard in `SurveyPreprocessorListener.populateContextValuesMap()`; (e) Fetch `UserAttributes` in listener when `dto.getUserAttributes()` is null (NPS path); (f) Propagate `cohortId` and `isoWeek` from DTO to entity; (g) Unit tests: null event does not NPE; BRM path unchanged; cohortId/isoWeek propagate correctly. | ~200 | C-01 |
| C-04 | `NpsWeeklySamplePreparationJob` | Job implementing `ClusteredJob`; cron `0 0 1 ? * MON` TZ=Africa/Lagos; ShedLock key `nps_weekly_sample_preparation` maxLockTime=2h; reads PENDING rows for current ISO week grouped by cohort; publishes Kafka events; feature flag `nps.programme.enabled`; logs count; unit tests (happy path, no PENDING rows, flag off, idempotent re-run). | ~200 | C-01, C-02, Cohort Platform C-01 |
| C-05 | Serve path — PENDING → SERVED atomic write | Serve-path integration; `@Transactional` SERVED write + `writeTriggered()`; `OptimisticLockException` handling; unit + `@Tag("simulation")` tests. | ~200 | C-01, cool-off spec |
| C-06 | `NpsWeeklyExpiredSampleJob` | Sunday 23:59 TZ=Africa/Lagos; batched UPDATE PENDING→EXPIRED; SERVED→ABANDONED; feature flag gate; unit tests. | ~150 | C-01 |

**Total: ~1,150 lines**. C-01 and C-02 are independent. C-03 depends on C-01. C-04 depends on C-01, C-02, and Cohort Platform C-01. C-05 and C-06 depend on C-01.

---

## 8. Capability Test Strategy

| # | Scenario | Components | Type | Assertion |
|---|---|---|---|---|
| T-01 | Happy path: Airflow has inserted PENDING rows; job publishes Kafka and logs count | C-04 | Unit | `publish()` called once per PENDING row; log contains correct count |
| T-02 | No PENDING rows for current ISO week | C-04 | Unit | Job logs warning; `publish()` never called; no exception |
| T-03 | Multiple cohorts in PENDING rows: survey lookup per cohort not per user | C-04 | Unit | `surveyStorage.findById()` called once per unique cohort, not once per row |
| T-04 | Feature flag `nps.programme.enabled = false`: job no-ops | C-04 | Unit | No DB reads; no Kafka publishes |
| T-05 | Re-run same week: Kafka re-published; `PreprocessedSurvey` not duplicated | C-03, C-04 | Integration | `INSERT ON DUPLICATE KEY` in listener absorbs re-publish; row count unchanged |
| T-06 | Happy path serve: user checks in → survey returned, status SERVED, trigger written | C-05 | Integration | `nps_weekly_sample.status = SERVED`; `nps_user_state.last_triggered = today` |
| T-07 | Already-served user checks in again same week | C-05 | Unit | Status already SERVED → existing `PreprocessedSurvey` returned; `writeTriggered` NOT called again |
| T-08 | `OptimisticLockException` on double-serve | C-05 | Unit | First thread succeeds; second catches exception, returns already-served state; trigger count incremented once |
| T-09 | Week-close expiry: PENDING → EXPIRED; SERVED → ABANDONED; RESPONDED unchanged | C-06 | Unit | Status transitions correct; prior-week rows unaffected |
| T-10 | Null-guard: NPS DTO with `verifiedEvent = null` does not NPE | C-03 | Unit | `populateContextValuesMap()` completes; no `event.*` keys in context |
| T-11 | BRM regression: DTO with `verifiedEvent != null` still populates `event.*` keys | C-03 | Unit | Null-guard does not affect BRM path |
| T-12 | `SurveyBody` with `reminderMinIntervalHours` and `q2CopyByBand` deserialises correctly | C-02 | Unit | Round-trip JSON preserves both fields |
| T-13 | Legacy BRM `SurveyBody` without new fields deserialises without exception | C-02 | Unit | New fields default to 0/null; no Jackson exception |

---

## 9. Rollout Plan

| Step | Action | Deployment Unit | Rollback |
|------|--------|-----------------|---------|
| 0 | **Cohort Platform (impl-specs/cohort/2026-05-21-cohort-platform.md) must be live** and `cohort.active = false` (Airflow not yet reading). | Cohort Platform spec | N/A |
| 1 | Merge C-01, C-02 (independent). Deploy with `nps.programme.enabled = false`. | Worker + Both | Revert PRs. |
| 2 | DB migrations: `nps_weekly_sample`, `ALTER TABLE preprocessed_survey ADD COLUMN cohort_id`, `ALTER TABLE preprocessed_survey ADD COLUMN iso_week`. | DB Migrations | Drop tables/columns. |
| 3 | Merge C-03, C-04, C-05, C-06. Deploy. All jobs check `nps.programme.enabled = false` and no-op. | Worker + API | Revert PRs. |
| 4 | Coordinate with data platform team: enable Airflow staging DAG. Set `cohort.active = true` for staging cohorts. Verify: (a) Airflow writes PENDING rows to staging `nps_weekly_sample`; (b) `survey_pipeline_audit` row written. | Staging | Set `cohort.active = false`. |
| 5 | Enable `nps.programme.enabled = true`. Trigger `NpsWeeklySamplePreparationJob` manually. Verify: `PreprocessedSurvey` rows created with `cohort_id` and `iso_week` set. | Staging | Disable flag. |
| 6 | Production ramp: enable Airflow production pipeline for both cohorts. Enable `nps.programme.enabled = true`. Monitor `survey_pipeline_audit.sample_size` and `PreprocessedSurvey` row counts. | Production | Disable flag; set `cohort.active = false`. |

---

## 10. Security Threat Model

| OWASP Risk | Applicable | Mitigation |
|---|---|---|
| API3 | **Yes** | `NpsWeeklySample.status` and `cohort_id` must not appear in the `CheckInSurveyItem` client response. Unit test asserts absence of both fields in serialised response. |
| API4 | **Yes** | `findPendingByIsoWeek` returns up to `cap` rows per cohort (max 3200 + 2134 = 5334 rows total across both NPS cohorts). In-memory grouping is negligible. `Collections.shuffle()` is no longer needed — no large in-memory list. ShedLock prevents concurrent runs. |
| API6 | **Yes** | Double-serve risk: `@Version` optimistic locking + `OptimisticLockException` handling. `trigger_count_year` incremented exactly once per serve. |
| API8 | **Yes** | `nps.programme.enabled` defaults to `false`. Job requires Airflow to have populated `nps_weekly_sample` first (step 4 in rollout). |

### Cross-cutting security rules

| Rule | Application |
|---|---|
| **Tier 3 — 2 CODEOWNER approvals** | `NpsWeeklySample` entity, `NpsSampleStatus` enum, `SurveyPreprocessorListener` and `EventPreprocessSurveyDTO` Kafka changes |
| **No PII in logs** | Preparation job logs use only `cohort.name`, `isoWeek`, and integer counts. No `userId` values at INFO level. |
| **DB migrations in separate repo** | All DDL raised in DB migrations repo. |
| **Constructor injection** | All new `@Component` / `@Service` classes use `@RequiredArgsConstructor`. |
