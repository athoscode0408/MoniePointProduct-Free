# Flowchart — NPS Programme Components

Spec: [`2026-05-19-nps-sampling.md`](../2026-05-19-nps-sampling.md)

`CohortMembershipRepository` and `user_cohorts` are owned by the Cohort Platform.

## Background Worker — Sampling Pipeline

```mermaid
flowchart LR
    subgraph DB_IN["🗄 MySQL (inputs)"]
        direction TB
        T_UC[(user_cohorts\nCohort Platform)]
        T_NS[(nps_user_state\ncool-off state)]
        T_COHORT[(cohort\nSurveyBody config)]
    end

    subgraph WORKER["⚙ CAS Background Worker"]
        direction TB
        JOB["🕐 NpsWeeklySamplePreparationJob\nMonday 01:00 · Quartz + ShedLock"]
        EXPIRY["🕐 NpsWeeklyExpiredSampleJob\nSunday 23:59 · Quartz + ShedLock"]

        subgraph ELIGIBILITY["Eligibility (MySQL only — no Bigtable)"]
            direction TB
            MR["CohortMembershipRepository\nJSON_CONTAINS on user_cohorts"]
            COOLOFF["NpsUserStateService\nbulk anti-join on nps_user_state"]
        end

        subgraph PREPROCESSING["Preprocessing (Bigtable in listener)"]
            direction TB
            PUB["SurveyPreprocessorKafkaEventPublisher\nPublishes userAttributes=null"]
            LISTENER["SurveyPreprocessorListener\nFetches attrs · saves PreprocessedSurvey"]
            ATTR["UserAttributesStorage\nBigtable point-lookup"]
            PUB -->|"Kafka: event-survey-preprocessor"| LISTENER
            LISTENER -->|"NPS path: attrs null"| ATTR
        end
    end

    subgraph DB_OUT["🗄 MySQL (outputs)"]
        direction TB
        T_WS[(nps_weekly_sample\nPENDING rows)]
        T_PS[(preprocessed_survey\ncohort_id · iso_week)]
    end

    BT([☁ Cloud Bigtable\nUser attributes])

    T_COHORT -->|"1 · load cohorts"| JOB
    T_UC -->|"2 · fetch members"| MR
    T_NS -->|"3 · load cool-off set"| COOLOFF
    MR --> JOB
    COOLOFF --> JOB
    JOB -->|"4 · upsert PENDING"| T_WS
    JOB -->|"5 · publish event"| PUB
    LISTENER -->|"8 · write"| T_PS
    ATTR -->|gRPC| BT
    EXPIRY -->|"expires / abandons"| T_WS

    classDef job      fill:#f4a261,stroke:#e76f51,color:#000,font-weight:bold
    classDef service  fill:#457b9d,stroke:#1d3557,color:#fff
    classDef db       fill:#e9c46a,stroke:#e76f51,color:#000
    classDef external fill:#a8dadc,stroke:#457b9d,color:#000

    class JOB,EXPIRY job
    class MR,COOLOFF,PUB,LISTENER,ATTR service
    class T_UC,T_NS,T_COHORT,T_WS,T_PS db
    class BT external
```

## API Handler — Serve Path

```mermaid
flowchart LR
    USER(["👤 Mobile / Web User"])

    subgraph API["🌐 CAS API Handler"]
        direction TB
        CTRL["CheckInController\nGET /check-in"]
        RESOLVER["NpsEligibilityResolver\n@Transactional serve-path"]
        STORAGE["NpsWeeklySampleStorage\nReads PENDING · writes SERVED"]
        COOLOFF["NpsUserStateService\nwriteTriggered()"]
        DELIVERY["SurveyDeliveryService\nAssembles CheckInSurveyItem"]
    end

    subgraph DB["🗄 CAS MySQL"]
        direction TB
        T_WS[(nps_weekly_sample)]
        T_NS[(nps_user_state)]
        T_PS[(preprocessed_survey)]
    end

    USER -->|"1 · GET /check-in"| CTRL
    CTRL -->|"2 · resolve"| RESOLVER
    RESOLVER -->|"3 · find PENDING\n4 · write SERVED"| STORAGE
    RESOLVER -->|"5 · writeTriggered\nsame @Transactional"| COOLOFF
    RESOLVER -->|"6 · get payload"| DELIVERY
    DELIVERY -->|"7 · CheckInSurveyItem"| CTRL
    CTRL -->|"8 · response"| USER

    STORAGE <-->|JDBC| T_WS
    COOLOFF -->|JDBC| T_NS
    DELIVERY -->|JDBC| T_PS

    classDef controller fill:#6d597a,stroke:#3d2b56,color:#fff
    classDef service    fill:#457b9d,stroke:#1d3557,color:#fff
    classDef db         fill:#e9c46a,stroke:#e76f51,color:#000
    classDef person     fill:#2a9d8f,stroke:#264653,color:#fff

    class CTRL controller
    class RESOLVER,STORAGE,COOLOFF,DELIVERY service
    class T_WS,T_NS,T_PS db
    class USER person
```

## Database Tables

```mermaid
flowchart TB
    subgraph DB["🗄 CAS MySQL"]
        direction LR
        T_COHORT[(cohort\nCohort Platform)]
        T_UC[(user_cohorts\nCohort Platform)]
        T_WS[(nps_weekly_sample\nUNIQUE: user · cohort · week\nstatus state machine)]
        T_NS[(nps_user_state\nlast_triggered · annual_count\nINDEX last_triggered)]
        T_PS[(preprocessed_survey\n+ cohort_id FK\n+ iso_week)]
    end

    T_WS -->|"FK cohort_id"| T_COHORT
    T_PS -->|"FK cohort_id"| T_COHORT

    classDef db          fill:#e9c46a,stroke:#e76f51,color:#000
    classDef db_platform fill:#a8dadc,stroke:#457b9d,color:#000

    class T_WS,T_NS,T_PS db
    class T_COHORT,T_UC db_platform
```
