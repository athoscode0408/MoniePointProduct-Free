# NPS Sampling Flows

> **Prerequisite**: `CohortResolutionJob` must have completed (Sunday 23:00) before the sampling job runs. `user_cohorts` must be populated.

---

## Flow 1 — Weekly Sample Preparation (Monday 01:00)

The sampling job reads only from MySQL. No Bigtable dependency — attribute lookup is deferred to `SurveyPreprocessorListener`.

```mermaid
flowchart TD
    START(["🕐 Monday 01:00 Africa/Lagos\nNpsWeeklySamplePreparationJob starts"])

    subgraph PER_COHORT["For each active NPS cohort"]
        direction TB

        LOAD_CONFIG["Load cohort + SurveyBody config\nweeklyInvCap · coolOffDays · yearlyTriggerCap"]

        subgraph ELIGIBILITY["Eligibility — MySQL only, no Bigtable"]
            direction LR
            MEMBERS["Fetch cohort members\nJSON_CONTAINS on user_cohorts"]
            COOLOFF["Load cool-off exclusion set\none query on nps_user_state"]
        end

        FILTER["Filter · shuffle · cap\nin-memory\nstream.filter · shuffle · subList(cap)"]

        subgraph PER_USER["For each sampled user"]
            direction TB
            UPSERT["Upsert NpsWeeklySample\nstatus = PENDING"]
            PUBLISH["Publish EventPreprocessSurveyDTO\nuserAttributes = null"]
        end

        MORE_COHORT{More cohorts?}
    end

    subgraph LISTENER["SurveyPreprocessorListener (async, Kafka consumer)"]
        direction TB
        CONSUME["Consume EventPreprocessSurveyDTO"]
        FETCH_ATTRS["Fetch UserAttributes\nUserAttributesStorage → Bigtable\n(NPS path: attrs null in DTO)"]
        SAVE_PS["Persist PreprocessedSurvey\ncohort_id · iso_week populated"]
    end

    DONE(["✓ Sample prepared"])

    START        --> LOAD_CONFIG
    LOAD_CONFIG  --> MEMBERS
    LOAD_CONFIG  --> COOLOFF
    MEMBERS      --> FILTER
    COOLOFF      --> FILTER
    FILTER       --> UPSERT
    UPSERT       --> PUBLISH
    PUBLISH      -->|"Kafka: event-survey-preprocessor"| CONSUME
    CONSUME      --> FETCH_ATTRS
    FETCH_ATTRS  --> SAVE_PS
    PUBLISH      --> MORE_COHORT
    MORE_COHORT  -->|yes| LOAD_CONFIG
    MORE_COHORT  -->|no| DONE

    classDef trigger  fill:#2a9d8f,stroke:#264653,color:#fff,font-weight:bold
    classDef step     fill:#457b9d,stroke:#1d3557,color:#fff
    classDef decision fill:#f4a261,stroke:#e76f51,color:#000,font-weight:bold
    classDef terminal fill:#264653,stroke:#264653,color:#fff
    classDef async    fill:#6d597a,stroke:#3d2b56,color:#fff

    class START trigger
    class LOAD_CONFIG,MEMBERS,COOLOFF,FILTER,UPSERT,PUBLISH,CONSUME,FETCH_ATTRS,SAVE_PS step
    class MORE_COHORT decision
    class DONE terminal
```

---

## Flow 2 — Serve Path (Check-In → SERVED)

```mermaid
flowchart LR
    USER(["👤 Mobile / Web User"])

    subgraph API["🌐 CAS API Handler"]
        direction TB
        CTRL["CheckInController\nGET /check-in"]
        LOOKUP["Find NpsWeeklySample\nuser_id · current ISO week"]
        PENDING{status\n= PENDING?}
        NO_NPS["Return: no NPS this week"]

        subgraph TXN["@Transactional boundary"]
            direction TB
            SERVE["Update status → SERVED\nservedAt = now()"]
            TRIGGER["writeTriggered(userId)\nnps_user_state · annual_count++"]
        end

        GET_PS["Fetch PreprocessedSurvey\nSurveyDeliveryService"]
        RESPOND["Return CheckInSurveyItem\nNPS config fields excluded"]
    end

    OPT_LOCK{OptimisticLock\nexception?}
    REREAD["Re-read already-SERVED row\nreturn existing survey\ntriggerCount unchanged"]

    USER        -->|"1 · GET /check-in"| CTRL
    CTRL        --> LOOKUP
    LOOKUP      --> PENDING
    PENDING     -->|no| NO_NPS
    PENDING     -->|yes| SERVE
    SERVE       --> TRIGGER
    TRIGGER     --> GET_PS
    GET_PS      --> RESPOND
    RESPOND     -->|"2 · CheckInSurveyItem"| USER
    SERVE       --> OPT_LOCK
    OPT_LOCK    -->|yes| REREAD

    classDef person   fill:#2a9d8f,stroke:#264653,color:#fff,font-weight:bold
    classDef step     fill:#457b9d,stroke:#1d3557,color:#fff
    classDef decision fill:#f4a261,stroke:#e76f51,color:#000,font-weight:bold
    classDef txn      fill:#e9c46a,stroke:#e76f51,color:#000
    classDef terminal fill:#264653,stroke:#264653,color:#fff

    class USER person
    class CTRL,LOOKUP,SERVE,TRIGGER,GET_PS,RESPOND,REREAD step
    class PENDING,OPT_LOCK decision
    class NO_NPS terminal
```

## Key invariants

| # | Flow | Invariant |
|---|---|---|
| 1 | Sampling | Sampling job has **no Bigtable dependency** — eligibility reads only `user_cohorts` and `nps_user_state`. Bigtable access is in the Kafka listener. |
| 2 | Sampling | `findUsersInCoolOff()` runs **once per cohort** — not per user. ~68K IDs at steady state ≈ 3.4 MB. |
| 3 | Sampling | `Collections.shuffle()` on up to ~5M candidates ≈ 250 MB peak heap. Reservoir sampling is the documented fallback. |
| 4 | Sampling | `NpsWeeklySampleStorage.upsert()` is idempotent — UNIQUE INDEX on `(user_id, cohort_id, iso_week)` absorbs re-runs. |
| 5 | Serve | `@Transactional` boundary covers both the SERVED status write and `writeTriggered()`. `OptimisticLockException` → return already-SERVED state; trigger count incremented exactly once. |
| 6 | Serve | NPS config fields (`weeklyInvitationCap`, `coolOffDays`, etc.) are **never** included in the `CheckInSurveyItem` response. |
