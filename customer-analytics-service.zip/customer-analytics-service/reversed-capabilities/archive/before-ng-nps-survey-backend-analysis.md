# Backend Analysis: NPS Survey (NG)

**Capability**: NPS Survey — Net Promoter Score  
**Capability ID**: CAPABILITY-CXAN-NPSS  
**Market**: NG (Nigeria)  
**Platform**: PLATFORM-CXAN — CX Analytics  
**Channel**: API (backend-only; no frontend code available for this capability)  
**Service**: customer-analytics-service (CAS)  
**Analysis date**: 2026-05-19  
**Source base path**: `src/main/java/com/moniepoint/loans/cas`

---

## Scope Notes

**In scope**: All code paths exercised by `SurveyCategory.NPS` and the shared survey infrastructure through which NPS flows — survey CRUD, eligibility evaluation, preprocessing pipeline, completion/dismissal/abandonment handling, expiry, push notification dispatch, banner assignment, survey-alert promotion, and all six REST endpoints that deliver surveys to clients.

**Shared infrastructure documented here**: The Kafka pipeline (`SurveyEventListener → SurveyEvaluatorListener → SurveyPreprocessorListener → CompletedSurveyListener → SurveyPushNotificationListener`), the three MySQL tables (`survey`, `preprocessed_survey`, `survey_alert`), the Redis cache layers, and all outbound integrations (NOS, Banner Service, Cosmos) are shared across NPS, CSAT, and BRM. They are documented in full here; NPS-specific behaviour within shared components is called out explicitly.

**Out of scope** (excluded, listed for context):
- CSAT survey business logic — same pipeline, different `SurveyCategory.CSAT` branch
- BRM survey business logic — `SurveyCategory.BRM` branch, `randomizeSurveyAssignment` flag
- Analytics event routing to external providers (Braze, Mixpanel, CustomerIO, Google Analytics, Singular) — separate capability
- Check-in endpoints not related to survey delivery (`/api/v3/events`, `/api/v3/event`, `/api/v3/user-info`)
- Event retry infrastructure (`AnalyticsEventRetryTriggerJob`, `EventDeadLetterCleanupTriggerJob`, `UnsupportedEventsCleanupTriggerJob`) — not survey-specific
- Customer profile update pipeline (`customer-profile-updates-event` topic)

---

## 1. Endpoint Inventory

| ID | Method | Path | Version | Controller | Auth Annotations | Feeds |
|----|--------|------|---------|------------|-----------------|-------|
| API-1 | GET | `/api/surveys/dashboard-info` | v3 | `SurveyController.getDashboardInfo()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 |
| API-2 | GET | `/api/surveys/dashboard-info` (param variant) | v3 | `SurveyController.getDashboardInfoByParams()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 |
| API-3 | GET | `/api/surveys/user` | v3 | `SurveyController.getSurveysByUserId()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004 |
| API-4 | GET | `/api/surveys/{id}` | v3 | `SurveyController.getSurveyById()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001 |
| API-5 | GET | `/api/surveys/{surveyId}/history` | v3 | `SurveyController.getSurveyHistory()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005 |
| API-6 | GET | `/api/surveys/schema/{surveyId}` | v3 | `SurveyController.getSurveySchema()` | `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002 |
| API-7 | POST | `/internal/admin/surveys` | admin | `AdminSurveyController.createSurvey()` | None (permitAll via `SecurityPropertiesConfig.PUBLIC_URIS`) | STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001 |
| API-8 | PUT | `/internal/admin/surveys` | admin | `AdminSurveyController.updateSurvey()` | None (permitAll via `SecurityPropertiesConfig.PUBLIC_URIS`) | STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002 |

**Notes:**
- API-1 and API-2 are the same logical operation — API-1 resolves `userId` from `@AuthenticationPrincipal`, API-2 accepts `username` and `moniepointAgentId` as query parameters. The CLAUDE.md describes API-1 as the "check-in pre-commitment endpoint" shared by NPS and CSAT.
- `/internal/admin/**` is explicitly listed in `SecurityPropertiesConfig.PUBLIC_URIS` with a code comment noting this is temporary pending network-policy enforcement.
- All `SurveyController` methods are annotated `@Trace(dispatcher = true)` (New Relic).

---

## 2. Async Handlers

| ID | Type | Topic / Schedule / Trigger | Handler Class | Purpose | Feeds |
|----|------|---------------------------|---------------|---------|-------|
| AH-1 | Kafka Consumer | `${kafka.topic.verified-analytics-event}` (group: `survey-evaluator-group-id`) | `SurveyEventListener` | Fan-out filter: reads verified analytics events, strips those without a userId, re-publishes remainder to `event-validated-survey` topic for survey rule evaluation | STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001 |
| AH-2 | Kafka Consumer | `${kafka.topic.event-validated-survey}` (group: `survey-evaluator-group-id`) | `SurveyEvaluatorListener` | Loads all survey rules from cache/DB, fetches user attributes from Bigtable, evaluates each rule's SpEL expression. If rule matches, delegates to `RuleParserHandler.parseRule()` which performs eligibility checks and publishes to preprocessor topic | STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003 |
| AH-3 | Kafka Consumer | `${kafka.topic.event-survey-preprocessor}` (group: `survey-evaluator-group-id`) | `SurveyPreprocessorListener` | Receives `EventPreprocessSurveyDTO`, performs string-substitution of user/event attributes into the survey JSON template, sets state to `NOT_COMPLETED`, persists finalised `PreprocessedSurvey`, optionally assigns banner, enqueues push notification for mobile platforms | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002 |
| AH-4 | Kafka Consumer | `${kafka.topic.event-survey-push-notification}` (group: `survey-evaluator-group-id`) | `SurveyPushNotificationListener` | Receives `NotificationRequest`, calls `NotificationOrchestrationService.sendPushNotification()` which calls NOS `/v2/notification` via Feign | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002 |
| AH-5 | Kafka Consumer | `${kafka.topic.event-completed-survey}` (group: `survey-evaluator-group-id`) | `CompletedSurveyListener` | Receives `AnalyticsEventRequestDTO` containing `SURVEY_COMPLETED`, `SURVEY_DISMISSED`, or `SURVEY_ABANDONED` event names. Delegates to `SurveyEventCompletionService.processCompletedSurveyEvent()` | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003, STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004 |
| AH-6 | Scheduled Job (Quartz / ShedLock) | `${survey.preprocessed-survey-expiry-frequency}` (cron, value from config server — [AMBIGUOUS: actual cron expression not in codebase]) | `PreprocessedSurveyExpirationTriggerJob` | Bulk-updates `preprocessed_survey` rows where `ttl < NOW()` and `state IN ('NOT_COMPLETED','NOT_READY')` to `EXPIRED`, up to `${survey.expiry-fetch-limit:100}` rows per execution | — (system-internal; no user-facing story) |

---

## 3. Integration Inventory (Outbound Calls)

| Target Service | Protocol | Purpose | Client Class | Circuit Breaker? | Timeout |
|---------------|----------|---------|-------------|-----------------|---------|
| NOS (Notification Orchestration Service) | REST (Feign) | Send push notification to mobile device for survey delivery; event name `RENDER_ANALYTICS_SURVEY` | `NOSClient` | No (no FallbackFactory, no Resilience4j) | Feign default: connect 2000ms, read 10000ms |
| Banner Service | REST (Feign) | Assign banner to user when `SurveyBody.assignBanner=true`; unassign banner on survey completion | `BannerClient` | No (no FallbackFactory, no Resilience4j) | Feign default: connect 2000ms, read 10000ms |
| Cosmos (OAuth2 server) | REST (Feign) | Obtain OAuth2 client_credentials token; used by `OutboundUtils.getToken()` for NOS and Banner Service auth headers | `CosmosClient` | No (no FallbackFactory, no Resilience4j) | Feign default: connect 2000ms, read 10000ms |
| Google Bigtable | gRPC (Bigtable SDK v2) | Read user attributes (demographics, account info, BRM data, `onboardingDate`, `lastTxnDate`, etc.) for survey rule evaluation and schema enrichment | `UserAttributesRepositoryService` (implements `UserAttributesStorage`) | No | SDK-managed |
| MySQL (primary datasource) | Spring Data JPA | Read/write `survey`, `preprocessed_survey`, `survey_alert` tables | `SurveyStorage`, `PreprocessedSurveyStorage`, `SurveyAlertStorage` | N/A (DB) | HikariCP pool |
| Redis | Spring Data Redis | Cache preprocessed surveys by user and by id, cache survey rules, cache survey alerts, cache Cosmos tokens, cache user attributes | `RedisCacheServiceImpl` | N/A (cache) | N/A |

---

## 4. External Provider Inventory (Third-Party APIs)

No third-party external provider APIs are involved in the NPS survey delivery path. All integrations are either internal Moniepoint services (NOS, Banner Service, Cosmos) or infrastructure (Bigtable, MySQL, Redis, Kafka).

The analytics provider integrations (Braze, Mixpanel, CustomerIO, Google Analytics, Singular) are out of scope for NPS survey delivery — they handle event routing, not survey management.

---

## 5. Events Published

| Event | Topic (property key / resolved name) | Trigger | Payload Summary | Consumers |
|-------|--------------------------------------|---------|----------------|-----------|
| Verified analytics events (survey-filtered) | `kafka.topic.event-validated-survey` | `SurveyEventListener.handleEvent()` — on receiving a batch of `VerifiedAnalyticsEventDTO` from the verified-analytics-event topic that have a non-blank userId | `VerifiedAnalyticsEventDTO` — event id, userId, platform, timestamp, event data, user attributes, event providers | `SurveyEvaluatorListener` |
| Partially preprocessed survey | `kafka.topic.event-survey-preprocessor` | `RuleParserHandler.enqueueSurveyForPreprocessing()` — after SpEL rule match and eligibility check pass | `EventPreprocessSurveyDTO` — survey definition, user attributes, verified event, `PreprocessedSurvey` (state=NOT_READY) | `SurveyPreprocessorListener` |
| Push notification request | `kafka.topic.event-survey-push-notification` | `SurveyPreprocessorListener.enqueuePushNotification()` — after preprocessing completes for ANDROID or IOS platforms | `NotificationRequest` — surveyID, eventTime, renderLocation, ttl, priority, userId, deviceType, appDomain | `SurveyPushNotificationListener` |
| Survey completion event (completed/dismissed/abandoned) | `kafka.topic.event-completed-survey` | `AnalyticsServiceImpl.pushResizedEvents()` — client submits an analytics event with `eventName` = `SURVEY_COMPLETED`, `SURVEY_DISMISSED`, or `SURVEY_ABANDONED` | `BaseAnalyticsEventRequestDTO` — event id, userId, event data containing `meta.surveyId`, `meta.surveySchemaId`, `meta.source` | `CompletedSurveyListener` |

---

## 6. Events Consumed

| Event | Topic (property key) | Consumer Class | Action | Idempotent? |
|-------|----------------------|----------------|--------|-------------|
| Verified analytics events (all providers) | `kafka.topic.verified-analytics-event` | `SurveyEventListener` | Filters for events with valid userId; republishes to `event-validated-survey` topic | No explicit dedup — Kafka consumer group provides at-least-once delivery |
| Survey-eligible analytics events | `kafka.topic.event-validated-survey` | `SurveyEvaluatorListener` | Loads survey rules (cached), fetches user from Bigtable, evaluates SpEL rules via `RuleParserHandler` | No — duplicate delivery causes duplicate preprocessing checks (guarded by eligibility history check) |
| Partially preprocessed survey | `kafka.topic.event-survey-preprocessor` | `SurveyPreprocessorListener` | Completes preprocessing: substitutes user/event vars into survey JSON, sets state to NOT_COMPLETED, saves to DB, optionally assigns banner or enqueues push notification | No — duplicate delivery could create duplicate `PreprocessedSurvey` rows |
| Push notification request | `kafka.topic.event-survey-push-notification` | `SurveyPushNotificationListener` | Calls `NotificationOrchestrationService.sendPushNotification()` → NOS `/v2/notification` | No — duplicate delivery sends duplicate push notifications |
| Survey completion/dismissal/abandonment | `kafka.topic.event-completed-survey` | `CompletedSurveyListener` | Resolves the matching `PreprocessedSurvey`, updates state to COMPLETED/DISMISSED/ABANDONED, deletes/evicts survey alerts if applicable | Partially — on COMPLETED path, `resolveRegularSurvey()` only resolves rows in NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED states, so re-processing a COMPLETED row returns null and exits safely |

---

## 7. Database Tables

| Table | Read / Write | Key Columns | Interleaved In | CDC Outbox? | Indexes |
|-------|-------------|-------------|----------------|-------------|---------|
| `survey` | RW | `id` (PK, BIGINT auto-increment), `rule` (LONGTEXT, SpEL expression), `priority` (INT, default 10), `survey` (LONGTEXT, serialised `SurveyBody` JSON), `location_web` (VARCHAR 50, NOT NULL), `location_mobile` (VARCHAR 50, NOT NULL), `category` (VARCHAR 50, nullable — `BRM`/`CSAT`/`NPS`), `start` (TIMESTAMP, nullable), `duration_days` (INT, nullable), `created_by`, `created_on`, `last_modified_by`, `last_modified_on`, `version` | None | No | No custom indexes documented in migrations (PK only) |
| `preprocessed_survey` | RW | `id` (PK, BIGINT auto-increment), `user` (VARCHAR 50, NOT NULL — userId), `event` (VARCHAR 50, NOT NULL — triggering event id), `priority` (INT, default 10), `survey_id` (BIGINT, NOT NULL, FK → `survey.id` ON DELETE CASCADE), `survey` (LONGTEXT, nullable — personalised survey JSON), `ttl` (TIMESTAMP, nullable — delivery expiry), `location` (VARCHAR 50, nullable — render location), `state` (VARCHAR 50, nullable — `PreprocessedSurveyState` enum), `completed_on` (TIMESTAMP, nullable), `additional_data` (LONGTEXT, nullable — JSON: `accountNumber`, `brmId`, `source`) | None | No | `idx_preprocessed_survey_user_state_ttl` (user, state, ttl); `idx_preprocessed_survey_user_survey_state_ttl` (user, survey_id, state, ttl); `idx_preprocessed_survey_user_state_completed_on` (user, state, completed_on); `idx_preprocessed_survey_user_survey_state_completed_on` (user, survey_id, state, completed_on) |
| `survey_alert` | RW | `id` (PK, BIGINT auto-increment), `user` (VARCHAR 50, NOT NULL), `preprocessed_survey_id` (BIGINT, NOT NULL), `survey_id` (BIGINT, nullable), `account_number` (VARCHAR 50, NOT NULL), `moniepoint_agent_id` (VARCHAR 50, NOT NULL), `ttl` (TIMESTAMP, NOT NULL), `event` (VARCHAR 50, NOT NULL — original triggering event id), `alert_type`, `alert_icon`, `alert_priority` (INT), `alert_title`, `alert_message`, `alert_action_label`, `alert_dismissible` (BOOLEAN), `alert_start_time` (TIMESTAMP) | None | No | No custom indexes documented in migrations |

**[GAP]** No `nps_user_state` table exists. The CLAUDE.md rule "Cool-off: minimum 90 days from trigger date (`last_nps_triggered_date`), applied globally across all NPS measurements" and "Cool-off clock starts at trigger, not at response" require a user-scoped record. Currently no such table or column exists. The prior codebase analysis (`codebase-analysis-nps-csat-2026-05-18.md`) identifies this as NET-NEW: a dedicated `NpsUserState` table keyed by `(user_id)` with `last_nps_triggered_date` and `yearly_trigger_count`.

**[GAP]** No `nps_score` or `nps_classification` column on `preprocessed_survey`. The survey response payload (Q1 numeric score) is captured via analytics event but there is no persisted column to store the extracted score or PROMOTER/PASSIVE/DETRACTOR classification.

**[GAP]** No `nps_weekly_sample`, `nps_weekly_score`, or `nps_weekly_ai_summary` tables exist. Weekly sampling and score aggregation are identified as NET-NEW.

---

## 8. Cache Inventory

| Key Pattern | Store | TTL | Invalidation | Purpose |
|-------------|-------|-----|-------------|---------|
| `cas-survey-rules` | Redis | `${survey.rules-cache-ttl-mins:1440}` × 60 seconds (default 1440 min = 24 hours) | Deleted on `createSurvey()` and `updateSurvey()` via `cacheService.deleteFromCache(CacheKeys.CAS_SURVEY_RULES_KEY)` | Caches the full list of `Survey` entities (all survey rules) to avoid DB scan on every `SurveyEvaluatorListener` invocation |
| `pps-user:<userId>` | Redis | `${survey.preprocessed-survey-cache-by-user-ttl-mins:10080}` × 60 seconds (default 10080 min = 7 days) | Overwritten on append; updated on survey completion (non-DISMISSED states remove the entry); overwritten on `PreprocessedSurveyExpirationTriggerJob` side effects | Caches the list of active `PreprocessedSurvey` rows for a user (states NOT_COMPLETED, DISMISSED, TTL not elapsed) |
| `pps-id:<surveyId>` | Redis | `${survey.preprocessed-survey-cache-by-id-mins:10080}` × 60 seconds (default 10080 min = 7 days) | Deleted on survey COMPLETED or ABANDONED via `removeSurveyFromCache()`; deleted on `removePreprocessedSurveyBySurveyId()` | Caches a single `PreprocessedSurvey` by its id (used by `GET /api/surveys/{id}`) |
| `survey-alert:<userId>:<moniepointAgentId>` | Redis | `${survey.survey-alert-cache-ttl-mins:720}` × 60 seconds (default 720 min = 12 hours) | Evicted on `saveSurveyAlert()` and on `handleCompletionSideEffects()` when COMPLETED or ABANDONED and displayModalType=ALERT | Caches the list of `SurveyAlert` rows for a user+agent combination (used by `GET /api/surveys/dashboard-info`) |
| `pps-user-attributes:<userId>` | Redis | `${survey.preprocessed-survey-cache-by-id-mins:1440}` × 60 seconds (configurable via `UserAttributesRepositoryService.USER_ATTRIBUTES_CACHE_TTL`) | Not explicitly evicted — TTL-only expiry | Caches raw Bigtable row (column-qualifier → value map) for user attributes lookup |
| `cas-access-token` | Redis | Cosmos token `expires_in` minus 300 seconds (5-minute buffer before actual expiry) | Not explicitly evicted — TTL-only expiry | Caches the Cosmos OAuth2 client_credentials access token used by NOS and Banner Service HTTP calls |

---

## 9. Feature Flags & Config

| Flag / Config | Source | Controls | Default |
|---------------|--------|----------|---------|
| `survey.preprocessed-survey-expiry-frequency` | Config server (external) | Cron expression for `PreprocessedSurveyExpirationTriggerJob` | [AMBIGUOUS: not in local application.yml — value in config server] |
| `survey.expiry-fetch-limit` | Config server | Max number of surveys expired per job execution | `100` |
| `survey.preprocessed-survey-ttl-mins` | Config server | TTL of a `PreprocessedSurvey` once it moves to NOT_COMPLETED (set in `SurveyPreprocessorListener`); also used for banner expiry in `BannerService` | `10080` (7 days) |
| `survey.not-ready-survey-ttl-mins` | Config server | TTL of a `PreprocessedSurvey` in NOT_READY state (before preprocessing is complete) | `180` (3 hours) |
| `survey.response-window-mins` | Config server | Global lookback window for "all surveys completed across any survey" eligibility check | `7` minutes |
| `survey.max-response-in-window` | Config server | Max total surveys completed in `response-window-mins` before user is ineligible | `2` |
| `survey.response-window-mins-individual-survey` | Config server | Per-survey lookback window for individual-survey recency check | `30` minutes |
| `survey.max-response-in-window-individual-survey` | Config server | Max completions of the same survey in `response-window-mins-individual-survey` | `1` |
| `survey.check-user-survey-history` | Config server | Master switch — if false, skips the `userEligibleFromSurveyHistory()` check entirely | `true` |
| `survey.rules-cache-ttl-mins` | Config server | Redis TTL for the survey rules cache | `1440` (24 hours) |
| `survey.preprocessed-survey-cache-by-id-mins` | Config server | Redis TTL for `pps-id:<id>` cache entries | `10080` (7 days) |
| `survey.preprocessed-survey-cache-by-user-ttl-mins` | Config server | Redis TTL for `pps-user:<userId>` cache entries | `10080` (7 days) |
| `survey.survey-alert-cache-ttl-mins` | Config server | Redis TTL for `survey-alert:<userId>:<agentId>` cache entries | `720` (12 hours) |
| `survey.image-location-url` | Config server | URL prefix for BRM image URLs (used in schema enrichment and `SurveyEvaluatorListener`) | [AMBIGUOUS: not in codebase — required config] |
| `bigtable.users-attributes-table` | Config server | Bigtable table name for user attributes | [AMBIGUOUS: not in codebase — required config] |
| `kafka.topic.verified-analytics-event` | Config server | Kafka topic name for verified analytics events | [AMBIGUOUS: logical name from codebase analysis suggests `verified-analytics-event`] |
| `kafka.topic.event-validated-survey` | Config server | Kafka topic name for survey-validated events | [AMBIGUOUS: logical name from codebase analysis] |
| `kafka.topic.event-survey-preprocessor` | Config server | Kafka topic name for partially preprocessed surveys | [AMBIGUOUS] |
| `kafka.topic.event-survey-push-notification` | Config server | Kafka topic name for push notification requests | [AMBIGUOUS] |
| `kafka.topic.event-completed-survey` | Config server | Kafka topic name for survey completion events | [AMBIGUOUS] |
| `integrations.nos.base-url` | Config server | Base URL for NOS Feign client | [AMBIGUOUS] |
| `integrations.banner.base-url` | Config server | Base URL for Banner Service Feign client | [AMBIGUOUS] |
| `integrations.cosmos.base-url` | Config server | Base URL for Cosmos OAuth2 server | [AMBIGUOUS] |
| `integrations.cosmos.credentials` | Config server | Base64-encoded `client_id:client_secret` for Cosmos token request | [AMBIGUOUS: sensitive secret] |
| `redis.default.expiry-update` | Config server | Default Redis TTL in seconds for generic `cacheString()` calls | `86400` (24 hours) |
| `events.max-request-size-in-bytes` | Config server | Maximum payload size for analytics event batches before recursive halving | `2621440` (2.5 MB) |
| `events.max-no-of-events` | Config server | Maximum number of events per batch before recursive halving | `2000` |
| `events.drop-oversize-events` | Config server | If true, drops batches exceeding size/count limits rather than halving | `false` |

**[GAP]** No `nps.weekly-cap.personal` or `nps.weekly-cap.business` config properties exist. The CLAUDE.md documents weekly sample caps of 3,200 (Personal) and 2,134 (Business) as invariants, but there is no config property or enforcement mechanism in the current codebase.

**[GAP]** No `nps.cool-off-days` config property. The 90-day cool-off is documented in CLAUDE.md but not enforced in any current code path.

---

## 10. Security Annotations

| Annotation | Endpoints | Behaviour |
|-----------|-----------|-----------|
| `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` | API-1, API-2, API-3, API-4, API-5, API-6 | Requires JWT bearer token with `can_fetch_survey` authority (using `COSMOS_ROLE_` prefix convention). Resolves against `MultiProviderAuthManager` (Cosmos, Moniebook, Monnify JWT decoders). |
| No annotation (`permitAll`) | API-7, API-8 (`/internal/admin/**`) | Listed in `SecurityPropertiesConfig.PUBLIC_URIS` — unauthenticated access permitted. Code comment acknowledges this is temporary pending network policy. |
| `@Trace(dispatcher = true)` | API-1 through API-6 | New Relic APM transaction tracing — not a security annotation but applied to all public endpoints. |

**Auth model summary:** Stateless OAuth2 resource server. JWT validated against RSA public keys from three issuers: Cosmos, Moniebook, and Monnify. `MultiProviderAuthManager` tries each decoder in sequence. `CSRF` disabled. No session state.

---

## 11. Resilience Patterns

| Pattern | Target | Config |
|---------|--------|--------|
| Redis cache (survey rules) | `SurveyEvaluatorListener` | Rules cached 24 hours — evaluator survives DB unavailability for up to 24 hours |
| Redis cache (preprocessed surveys) | `SurveyController` read paths | Surveys served from cache — survives DB unavailability within TTL window |
| Cosmos token cache | `OutboundUtils.getToken()` | Token cached in Redis until `expires_in - 300` seconds — survives Cosmos unavailability within token validity |
| Async execution (`@Async("appExecutor")`) | `RuleParserHandler.parseRule()`, `SurveyEventCompletionService.processCompletedSurveyEvent()`, `AnalyticsServiceImpl.handleRawAnalyticsEvents()` | Offloads processing to thread pool; does not block Kafka consumer thread |
| Recursive batch halving | `AnalyticsServiceImpl.pushEvents()` | Recursively halves oversized event batches until under `max-request-size-in-bytes` and `max-no-of-events` limits |
| **ABSENT: Circuit Breaker** | NOS, Banner Service, Cosmos clients | No Resilience4j `@CircuitBreaker`, `@Retry`, or `@Bulkhead`. No FallbackFactory on any of these three clients. NOS is in the critical path for NPS push notification delivery — a timeout or outage propagates as an unhandled exception. |
| **ABSENT: Retry on NOS** | NOS push notification | No retry logic on `NotificationOrchestrationService.sendPushNotification()`. On Feign exception, the error is logged and `false` is returned silently — push notification is permanently lost. |

---

## 12. Service Dependency Graph

```
customer-analytics-service (API process)
  ├→ MySQL/primary (Spring Data JPA, sync)
  │   ├→ survey table (RW)
  │   ├→ preprocessed_survey table (RW)
  │   └→ survey_alert table (RW)
  ├→ Redis (Spring Data Redis, sync)
  │   ├→ pps-user:<userId>
  │   ├→ pps-id:<surveyId>
  │   ├→ survey-alert:<userId>:<agentId>
  │   ├→ cas-survey-rules
  │   ├→ pps-user-attributes:<userId>
  │   └→ cas-access-token
  └→ Spring Security (JWT validation, stateless)

customer-analytics-service (Worker process)
  ├→ Kafka (consumed topics)
  │   ├→ verified-analytics-event → SurveyEventListener
  │   ├→ event-validated-survey → SurveyEvaluatorListener
  │   ├→ event-survey-preprocessor → SurveyPreprocessorListener
  │   ├→ event-survey-push-notification → SurveyPushNotificationListener
  │   └→ event-completed-survey → CompletedSurveyListener
  ├→ Kafka (published topics)
  │   ├→ event-validated-survey (SurveyEvaluatorKafkaEventPublisher)
  │   ├→ event-survey-preprocessor (SurveyPreprocessorKafkaEventPublisher)
  │   ├→ event-survey-push-notification (SurveyPushNotificationKafkaEventPublisher)
  │   └→ event-completed-survey (surveyCompletedEventPublisher in AnalyticsServiceImpl)
  ├→ Google Bigtable (gRPC, sync)
  │   └→ user-attributes table (read-only for survey evaluation)
  ├→ NOS / Notification Orchestration Service (REST Feign, sync, no fallback)
  │   └→ POST /v2/notification
  ├→ Banner Service (REST Feign, sync, no fallback)
  │   ├→ POST /api/v1/back-office/banners/assign
  │   └→ DELETE /api/v1/back-office/banners/unassign
  ├→ Cosmos / OAuth2 Server (REST Feign, sync, no fallback)
  │   └→ POST /oauth/token (client_credentials)
  ├→ MySQL/primary (Spring Data JPA, sync)
  │   └→ same tables as API process
  ├→ Redis (same keyspace as API process)
  └→ Quartz (clustered scheduler — PreprocessedSurveyExpirationTriggerJob)
```

---

## 13. Request/Response Contracts

### API-1 / API-2: GET /api/surveys/dashboard-info — Request

| Parameter | Source | Type | Required | Notes |
|-----------|--------|------|----------|-------|
| `userId` | `@AuthenticationPrincipal` JWT username (API-1) OR `username` query param (API-2) | String | Yes | Must be non-blank; throws `BadRequestException` if blank |
| `moniepointAgentId` | `@RequestHeader("moniepointAgentId")` (API-1) OR `moniepointAgentId` query param (API-2) | String | Yes | Agent/terminal identifier used to scope survey alerts |

### API-1 / API-2: GET /api/surveys/dashboard-info — Response (`SurveyAlertsResponse`)

| Field | Type | Notes |
|-------|------|-------|
| `alerts` | `List<SurveyAlertDTO>` | Only alerts where `ttl > now` AND `alertStartTime <= now` |

### SurveyAlertDTO

| Field | Type | Notes |
|-------|------|-------|
| `id` | String | Maps to `survey_alert.event` (the triggering event id, not the alert's own id) |
| `type` | String | `alert_type` from `SurveyBody.alertType` |
| `icon` | String | `alert_icon` |
| `priority` | int | `alert_priority` |
| `title` | String | `alert_title` |
| `message` | String | `alert_message` |
| `action.label` | String | `alert_action_label` |
| `action.target` | String | Hardcoded as `/survey/<surveyId>` |
| `isDismissible` | boolean | `alert_dismissible` |

### API-3: GET /api/surveys/user — Request

| Parameter | Source | Type | Required | Notes |
|-----------|--------|------|----------|-------|
| `userId` | JWT username | String | Yes | Must be non-blank |

### API-3: GET /api/surveys/user — Response (`List<PreprocessedSurveyDTO>`)

| Field | Type | Notes |
|-------|------|-------|
| `id` | Long | `preprocessed_survey.id` |
| `user` | String | userId |
| `surveyId` | Long | FK to `survey.id` |
| `survey` | String | Personalised survey JSON (the full `SurveyBody` string with user variables substituted) |
| `event` | String | Triggering event id |
| `ttl` | LocalDateTime | Delivery expiry timestamp |
| `priority` | int | Survey priority (default 10) |
| `location` | String | Render location hint (web or mobile screen identifier) |
| `displayModalType` | String | Extracted from `SurveyBody.displayModalType` (`alert` or other value) |

### API-4: GET /api/surveys/{id} — Request

| Parameter | Source | Type | Required | Notes |
|-----------|--------|------|----------|-------|
| `id` | Path variable | Long | Yes | `preprocessed_survey.id` |
| `userId` | JWT username | String | Yes | Ownership check: returns 404 if `dto.user != userId` (case-insensitive) |

### API-4: GET /api/surveys/{id} — Response

Same as `PreprocessedSurveyDTO` above. Returns 404 if not found, TTL expired, or userId mismatch.

### API-5: GET /api/surveys/{surveyId}/history — Request

| Parameter | Source | Type | Required | Notes |
|-----------|--------|------|----------|-------|
| `surveyId` | Path variable | Long | Yes | FK to `survey.id` |
| `startDate` | Query param | LocalDate (ISO format) | Yes | Start of date range |
| `endDate` | Query param | LocalDate (ISO format) | Yes | End of date range (inclusive to 23:59:59) |
| `userId` | JWT username | String | Yes | Filters results to this user |

### API-5: GET /api/surveys/{surveyId}/history — Response (`SurveyHistoryResponse`)

| Field | Type | Notes |
|-------|------|-------|
| `surveys` | `List<SurveyHistoryItemDTO>` | All `preprocessed_survey` rows for user+surveyId within `lastModifiedOn` date range |

### SurveyHistoryItemDTO

| Field | Type | Format | Notes |
|-------|------|--------|-------|
| `id` | Long | | `preprocessed_survey.id` |
| `event` | String | | Triggering event id |
| `ttl` | LocalDateTime | `yyyy-MM-dd HH:mm:ss` | Delivery expiry |
| `state` | PreprocessedSurveyState | | Current state enum value |
| `completedOn` | LocalDateTime | `yyyy-MM-dd HH:mm:ss` | When completed/abandoned/dismissed (null if not yet done) |
| `additionalData` | Object | JSON | Parsed `additional_data` JSON (accountNumber, brmId, source); raw string if parse fails |

### API-6: GET /api/surveys/schema/{surveyId} — Request

| Parameter | Source | Type | Required | Notes |
|-----------|--------|------|----------|-------|
| `surveyId` | Path variable | Long | Yes | FK to `survey.id` |
| UserAttributes fields | `@ModelAttribute` query params | See UserAttributes DTO | No | Optional user context for template variable substitution |

### API-6: GET /api/surveys/schema/{surveyId} — Response (`SurveySchemaDTO`)

| Field | Type | Notes |
|-------|------|-------|
| `id` | Long | `survey.id` (or the `preprocessed_survey.survey_id` if a personalised record exists for the user) |
| `survey` | String (raw JSON) | Survey JSON with `${user.FieldName}` variables substituted with actual values if user attributes provided and `${}` tokens present. Otherwise, raw `survey.survey` from DB. |
| `preprocessedSurveyId` | Long | `preprocessed_survey.id` if a personalised record was found for the user; null otherwise |

### API-7: POST /internal/admin/surveys — Request (`SurveyCreateRequest`)

| Field | Type | Required | Validation | Notes |
|-------|------|----------|-----------|-------|
| `id` | Long | No | — | Ignored on create; must be set and > 0 on update (API-8 guard) |
| `rule` | String | Yes | `@NotBlank` | SpEL expression evaluated against `RulesContext(event, user)` |
| `priority` | Integer | Yes | `@NotNull` | Lower = higher priority (default 10) |
| `survey` | `Map<String, Object>` | Yes | `@NotNull` | Raw survey JSON structure; serialised as `SurveyBody`; BOM/zero-width-space stripped |
| `locationWeb` | String | Yes | `@NotBlank` | Web render location identifier |
| `locationMobile` | String | Yes | `@NotBlank` | Mobile render location identifier |

### API-7: POST /internal/admin/surveys — Response

| Field | Type | Notes |
|-------|------|-------|
| (body) | Long | `survey.id` of the newly created survey |

### API-8: PUT /internal/admin/surveys — Response

Returns HTTP 202 on success; HTTP 400 if `id` is null or ≤ 0.

---

## 14. Validation Rules (Bean Validation)

| DTO | Field | Annotation | Constraint | Message |
|-----|-------|-----------|-----------|---------|
| `SurveyCreateRequest` | `rule` | `@NotBlank` | Must not be blank | "rule can't be empty." |
| `SurveyCreateRequest` | `priority` | `@NotNull` | Must not be null | "priority can't be null." |
| `SurveyCreateRequest` | `survey` | `@NotNull` | Must not be null | (default message) |
| `SurveyCreateRequest` | `locationWeb` | `@NotBlank` | Must not be blank | "locationWeb can't be empty." |
| `SurveyCreateRequest` | `locationMobile` | `@NotBlank` | Must not be blank | "locationMobile can't be empty." |
| `SurveyController` (all methods) | `userId` (from JWT) | Manual guard | `StringUtils.isBlank()` → throws `BadRequestException` | "userId cannot be null or empty" (from `ApplicationConstants.NULL_USER_ID_MESSAGE`) |
| `AdminSurveyController.updateSurvey` | `request.id` | Manual guard | `id == null || id <= 0L` → returns HTTP 400 | (no body) |

**Server-side business validations** (not Bean Validation annotations):
- `getSurveyById()`: userId ownership check — returns 404 if `dto.user.equalsIgnoreCase(userId)` is false
- `fetchSurveyAlerts()`: filters alerts where `ttl > now` AND `alertStartTime <= now` before returning
- `fetchSurveysByUserId()` / `fetchSurveyById()`: only returns rows in states `NOT_COMPLETED` or `DISMISSED` with `ttl > now`
- `userEligibleFromSurveyHistory()`: blocks survey creation if user has open surveys for same schema, or if recently completed too many surveys in the response window

---

## 15. State Machines & Entity Lifecycles

### PreprocessedSurvey States

```
[EVENT TRIGGER]
      │
      ▼
  NOT_READY ─────────────────────────────────────────► EXPIRED
      │          (ttl < now, set by expiry job)
      │ (SurveyPreprocessorListener: preprocessing complete)
      ▼
NOT_COMPLETED ──────────────────────────────────────► EXPIRED
      │              (ttl < now, set by expiry job)
      │
      ├──(SURVEY_DISMISSED event)──► DISMISSED ──(re-delivery window active)──► NOT_COMPLETED (via alerting)
      │                                    │
      │                                    └──(alerting condition met)──► survey_alert row created
      │
      ├──(SURVEY_ABANDONED event)──► ABANDONED (terminal)
      │
      └──(SURVEY_COMPLETED event)──► COMPLETED (terminal)
```

| Transition | Trigger | Side Effects |
|-----------|---------|-------------|
| Created as NOT_READY | `RuleParserHandler.parseRule()`: SpEL rule matched, eligibility passed | `PreprocessedSurvey` saved with `ttl = event.timestamp + not-ready-survey-ttl-mins (default 3h)`, `state = NOT_READY`; `EventPreprocessSurveyDTO` published to preprocessor topic |
| NOT_READY → NOT_COMPLETED | `SurveyPreprocessorListener.preprocessSurvey()`: preprocessing complete | Survey JSON populated with user variables; `ttl` extended to `event.timestamp + preprocessed-survey-ttl-mins (default 7d)`; `state = NOT_COMPLETED`; saved to DB; written to Redis cache; if `assignBanner=true` → banner assigned; if mobile platform → push notification enqueued |
| NOT_COMPLETED → DISMISSED | `SurveyEventCompletionService.finalizeAndSave()`: `SURVEY_DISMISSED` event received | `state = DISMISSED`; cache NOT cleared (DISMISSED surveys remain available for re-delivery); if `enableAlertingAfterDismissal=true` AND SpEL alerting condition passes → `survey_alert` row created, `displayModalType` changed to `alert`, survey updated in cache |
| NOT_COMPLETED/DISMISSED → COMPLETED | `SurveyEventCompletionService.finalizeAndSave()`: `SURVEY_COMPLETED` event received | `state = COMPLETED`; `completedOn` set to event timestamp; if `assignBanner=true` → banner unassigned; if `displayModalType=ALERT` → `survey_alert` rows deleted and cache evicted; survey removed from user cache and id cache |
| NOT_COMPLETED/DISMISSED/ABANDONED/EXPIRED → ABANDONED | `SurveyEventCompletionService.finalizeAndSave()`: `SURVEY_ABANDONED` event received | `state = ABANDONED`; `completedOn` set to event timestamp; if `displayModalType=ALERT` → alert rows deleted and cache evicted; survey removed from user cache and id cache |
| NOT_COMPLETED/NOT_READY → EXPIRED | `PreprocessedSurveyExpirationTriggerJob`: `ttl < NOW()` | Bulk native SQL update; up to `expiry-fetch-limit` rows per run; no cache invalidation in job (cache entries expire independently by TTL) |

### Survey (Rule Definition) Lifecycle

Surveys are created and updated by admin operators via `AdminSurveyController`. There is no state machine — surveys are always active once created. Deletion is via database (no delete endpoint exists in the codebase).

---

## 16. Multi-Tenancy & Scoping

| Scope | How Identified | How Enforced |
|-------|---------------|-------------|
| User scope | `userId` extracted from JWT `@AuthenticationPrincipal` username in all `SurveyController` methods | All DB queries include `user = :userId`; `getSurveyById()` additionally checks `dto.user.equalsIgnoreCase(userId)` at the application layer |
| Agent/POS scope | `moniepointAgentId` header (API-1) or query param (API-2) | Passed to `fetchSurveyAlerts(userId, moniepointAgentId)` which scopes the `survey_alert` lookup and Redis cache key to `(userId, moniepointAgentId)` |
| App domain scope | `appDomain` from analytics event payload (`properties.app_domain` or event-level `appDomain` field) | Used in `NotificationOrchestrationService`: maps `CONSUMER` → `PERSONAL` for the NOS `banking-domain` header; determines which app receives the push notification |
| Platform scope | `platform` field on `VerifiedAnalyticsEventDTO` | Used in `RuleParserHandler` to select `webLocation` vs `mobileLocation`; used in `SurveyPreprocessorListener` to decide whether to send push notification (ANDROID/IOS only) |

**No market/country scoping at the service layer.** CAS is a single-market NG service. There is no `market`, `country`, or `tenant` discriminator on any entity or request.

---

## 17. API Versioning

| Version | Status | Endpoints | Notes |
|---------|--------|-----------|-------|
| v3 (survey endpoints) | Current | API-1 through API-6 (path prefix `/api/surveys/`) | All six survey delivery endpoints are unversioned in the path but belong to the v3 DTO package (`module/analytics/dto/v3/`) |
| admin (internal) | Current | API-7, API-8 (`/internal/admin/surveys`) | No version in path; secured by network policy |
| v1/v2/v3 (analytics events) | Current | `POST /api/v1/push-event`, `POST /api/v2/push-event`, `POST /api/v3/event`, `POST /api/v3/events` | Out of scope for NPS survey delivery; listed for completeness |

---

## 18. Pagination Patterns

| Endpoint | Pattern | Page Size | Sort |
|----------|---------|-----------|------|
| API-3: GET /api/surveys/user | No pagination — returns all active surveys for user | Bounded by surveys in state NOT_COMPLETED or DISMISSED with TTL > now | No explicit sort; relies on DB natural order |
| API-5: GET /api/surveys/{surveyId}/history | No pagination — returns all rows in date range | Bounded by date range parameters | No explicit sort |
| API-6: GET /api/surveys/schema/{surveyId} | N/A — returns single record | — | — |
| `PreprocessedSurveyExpirationTriggerJob` | LIMIT-based batch | `${survey.expiry-fetch-limit:100}` rows per run | `ORDER BY id ASC` (in native query) |

---

## 19. Endpoint Documentation

### API-1 / API-2: GET /api/surveys/dashboard-info [API-1 / API-2]
**Controller**: `SurveyController.getDashboardInfo()` / `SurveyController.getDashboardInfoByParams()` in `module/analytics/controller/SurveyController.java`
**Service**: `PreprocessedSurveyRepositoryService.fetchSurveyAlerts(userId, moniepointAgentId)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003

#### Business Rules
- This is the **check-in pre-commitment endpoint** per the CLAUDE.md specification. It is called on app open / screen transition to determine whether to show a survey alert (e.g., NPS or CSAT trigger in alert display mode).
- Returns only `SurveyAlert` rows, not `PreprocessedSurvey` rows directly. Alerts are promoted from dismissed surveys when `enableAlertingAfterDismissal=true` and the alerting condition evaluates to true.
- Alerts are filtered at return time: `ttl > now` AND `alertStartTime <= now`. The `alertStartTime` gate allows delayed display after dismissal (controlled by `SurveyBody.displayDelayPeriodInSecs`).
- Redis cache is checked first (`survey-alert:<userId>:<agentId>`). On cache hit, the filter is applied in-memory. On cache miss, DB is queried via `SurveyAlertStorage.findByUserAndMoniepointAgentIdAndTtlAfter()`.
- The two variants (API-1 and API-2) are distinguished by Spring `params` condition. API-2 is used by non-JWT callers (e.g., POS heartbeat) that pass credentials as query parameters.
- Per CLAUDE.md: "NPS and CSAT eligibility must be resolved in a **single check-in pass** — no separate server call." This endpoint fulfils that constraint for the alert display mode. For the standard survey delivery mode, `GET /api/surveys/user` (API-3) is the equivalent.

#### Validations (Server-Side)
- `userId` must be non-blank (from JWT or `username` param). Throws `BadRequestException("userId cannot be null or empty")` if blank.

#### Data Flow
```
Client → SurveyController.getDashboardInfo(user, moniepointAgentId)
       → PreprocessedSurveyRepositoryService.fetchSurveyAlerts(userId, moniepointAgentId)
           → RedisCacheServiceImpl.getCachedSurveyAlerts(userId, moniepointAgentId)
               ↓ (cache miss)
           → SurveyAlertStorage.findByUserAndMoniepointAgentIdAndTtlAfter(userId, moniepointAgentId, now)
           → RedisCacheServiceImpl.cacheSurveyAlerts(...)
       → Filter alerts: ttl > now AND alertStartTime <= now
       → Map to SurveyAlertDTO (action.target = "/survey/<surveyId>")
       → ResponseEntity<SurveyAlertsResponse>
```

#### Integration Points
| System | Protocol | Purpose |
|--------|----------|---------|
| Redis | Spring Data Redis | Read/write survey-alert cache |
| MySQL | Spring Data JPA | Read `survey_alert` table on cache miss |

#### Error Handling
| Condition | Code | Message | Recovery |
|-----------|------|---------|----------|
| `userId` blank | 400 | `ApplicationConstants.NULL_USER_ID_MESSAGE` | Client must provide valid JWT or username param |
| Survey alert not found | 200 | Empty `alerts` list | Not an error — returns empty list |
| DB unavailable | 500 | Generic error | `GenericControllerAdvice.handleUnknownException()` |
| Auth failure | 401/403 | Cosmos/Moniebook/Monnify JWT validation error | `CosmosAuthenticationEntryPoint` |

---

### API-3: GET /api/surveys/user [API-3]
**Controller**: `SurveyController.getSurveysByUserId()` in `module/analytics/controller/SurveyController.java`
**Service**: `PreprocessedSurveyRepositoryService.fetchSurveysByUserId(userId)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004

#### Business Rules
- Returns all `PreprocessedSurvey` rows for the user that are in state `NOT_COMPLETED` or `DISMISSED` and have `ttl > now`.
- Redis cache (`pps-user:<userId>`) is checked first. On cache miss, DB is queried and result is cached.
- After fetching, each DTO has `displayModalType` enriched from the nested `SurveyBody` JSON — this field is not stored separately in the entity but extracted from the survey JSON on read.
- Per CLAUDE.md payload constraint: "Pre-commitment for NPS and CSAT shares a single check-in response payload" and "Every survey request/response payload < 1KB."

#### Data Flow
```
Client → SurveyController.getSurveysByUserId(user)
       → PreprocessedSurveyRepositoryService.fetchSurveysByUserId(userId)
           → RedisCacheServiceImpl.getAllPreprocessedSurveys(userId)
               ↓ (cache miss)
           → PreprocessedSurveyStorage.findByUserAndStateInAndTtlAfter(userId, [NOT_COMPLETED, DISMISSED], now)
           → RedisCacheServiceImpl.cacheAllPreprocessedSurveys(userId, surveys)
       → Map to PreprocessedSurveyDTO; enrich displayModalType from SurveyBody JSON
       → ResponseEntity<List<PreprocessedSurveyDTO>>
```

#### Error Handling
| Condition | Code | Message | Recovery |
|-----------|------|---------|----------|
| `userId` blank | 400 | "Username is required in authentication token" | Valid JWT required |
| No surveys | 200 | Empty list | Not an error |

---

### API-4: GET /api/surveys/{id} [API-4]
**Controller**: `SurveyController.getSurveyById()` in `module/analytics/controller/SurveyController.java`
**Service**: `PreprocessedSurveyRepositoryService.fetchSurveyById(surveyId)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001

#### Business Rules
- Fetches a single `PreprocessedSurvey` by its id.
- Ownership check: returns 404 if the resolved DTO's `user` field does not match the JWT `userId` (case-insensitive comparison).
- Redis cache (`pps-id:<id>`) is checked first. TTL is verified in-memory against `LocalDateTime.now()` on cache hit.
- `displayModalType` is enriched from `SurveyBody` JSON on return.

#### Data Flow
```
Client → SurveyController.getSurveyById(user, id)
       → PreprocessedSurveyRepositoryService.fetchSurveyById(id)
           → RedisCacheServiceImpl.getPreprocessedSurveyById(id)
               ↓ (cache miss or TTL expired in cache)
           → PreprocessedSurveyStorage.findByIdAndStateInAndTtlAfter(id, [NOT_COMPLETED, DISMISSED], now)
           → RedisCacheServiceImpl.cachePreprocessedSurveyById(...)
       → userId ownership check → 404 if mismatch
       → ResponseEntity<PreprocessedSurveyDTO> or ResponseEntity.notFound()
```

---

### API-5: GET /api/surveys/{surveyId}/history [API-5]
**Controller**: `SurveyController.getSurveyHistory()` in `module/analytics/controller/SurveyController.java`
**Service**: `PreprocessedSurveyRepositoryService.fetchSurveyHistory(userId, surveyId, startDate, endDate)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005

#### Business Rules
- Returns the full history of `PreprocessedSurvey` rows for a user and survey schema, filtered by `lastModifiedOn` within the date range.
- Includes all states (not filtered by active states) — useful for admin and analytics tools to see completed, expired, and abandoned records.
- No caching on this path — direct DB query each time.

#### Data Flow
```
Client → SurveyController.getSurveyHistory(user, surveyId, startDate, endDate)
       → PreprocessedSurveyRepositoryService.fetchSurveyHistory(...)
           → PreprocessedSurveyStorage.findByUserAndSurveyIdAndLastModifiedOnBetween(userId, surveyId, start, end)
       → Map to SurveyHistoryItemDTO (parses additionalData JSON if present)
       → ResponseEntity<SurveyHistoryResponse>
```

---

### API-6: GET /api/surveys/schema/{surveyId} [API-6]
**Controller**: `SurveyController.getSurveySchema()` in `module/analytics/controller/SurveyController.java`
**Service**: `PreprocessedSurveyRepositoryService.fetchSurveySchema(surveyId, userId, userAttributes)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002

#### Business Rules
- Dual-mode resolution:
  1. If a personalised `PreprocessedSurvey` exists for the user+surveyId (state NOT_COMPLETED or DISMISSED, TTL active), return that personalised survey JSON with the `preprocessedSurveyId` reference.
  2. If no personalised record exists, fall back to the raw `survey.survey` template from the `survey` table. If `UserAttributes` are provided in the request AND the template contains `${...}` tokens, substitute user attributes via `StringSubstitutor`.
- BRM image enrichment: if `businessNubanAccountNumber` is present in user attributes, the `brmImage` URL is URL-encoded and prefixed with `${survey.image-location-url}?requestType=BRM_IMAGE`.
- Returns 404 if no matching survey schema is found in either path.
- This endpoint supports the "voluntary survey" flow where users can open a survey schema directly without a pre-committed `PreprocessedSurvey` record.

#### Integration Points
| System | Protocol | Purpose |
|--------|----------|---------|
| MySQL | Spring Data JPA | Read `preprocessed_survey` and `survey` tables |
| Bigtable | gRPC SDK | Fetch user attributes for template variable substitution (only on fallback path if `${}` tokens present) |
| Redis | Spring Data Redis | Read user attributes from cache before Bigtable |

#### Error Handling
| Condition | Code | Message | Recovery |
|-----------|------|---------|----------|
| No survey schema found | 404 | (no body) | Client must verify surveyId |
| `userId` blank | 400 | `NULL_USER_ID_MESSAGE` | Valid JWT required |
| Bigtable unavailable | 200 | Falls back to `requestAttributes` from request body (warns in log) | Graceful degradation — serves template without Bigtable enrichment |

---

### API-7: POST /internal/admin/surveys [API-7]
**Controller**: `AdminSurveyController.createSurvey()` in `module/analytics/controller/AdminSurveyController.java`
**Service**: `SurveyService.createSurvey(request)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001

#### Business Rules
- Creates a new `Survey` record. Sets `priority` default to 10 if not provided.
- Serialises `request.survey` (Map<String, Object>) to JSON string via Jackson. Strips BOM (`﻿`) and zero-width spaces (`​`) from the serialised JSON before saving — emits WARN log if stripping occurs.
- After save, invalidates the `cas-survey-rules` Redis cache key so `SurveyEvaluatorListener` picks up the new rule on next evaluation.
- `category`, `start`, and `duration_days` fields on the `Survey` entity are NOT set by the current `SurveyService.createSurvey()` implementation — they are null unless the caller sets them directly. [AMBIGUOUS: it is unclear whether the admin UI or operator sets these fields via a different path or direct DB manipulation.]

#### Data Flow
```
Operator → AdminSurveyController.createSurvey(request)
         → SurveyService.createSurvey(request)
             → Survey.builder()... (maps fields; serializeSurvey() strips invisible chars)
             → SurveyStorage.save(survey)
             → CacheService.deleteFromCache("cas-survey-rules")
         → ResponseEntity<Long>(survey.id)
```

#### Error Handling
| Condition | Code | Message | Recovery |
|-----------|------|---------|----------|
| Invalid JSON in `survey` field | 400 | "Failed to serialize survey payload" (wrapped as `IllegalArgumentException`) | Fix survey payload |
| Bean validation failure | 400 | Field-level error messages from `@NotBlank`/`@NotNull` | Fix request |

---

### API-8: PUT /internal/admin/surveys [API-8]
**Controller**: `AdminSurveyController.updateSurvey()` in `module/analytics/controller/AdminSurveyController.java`
**Service**: `SurveyService.updateSurvey(request)`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002

#### Business Rules
- Partial update: only non-null / non-blank fields in the request overwrite the existing values. Null `survey`, blank `rule`, blank location fields, and null `priority` are all treated as "no-op" — existing values preserved.
- `id` must be present and > 0, otherwise returns HTTP 400 immediately (no error body).
- If the survey with the given `id` is not found in DB, the update is silently no-op (no exception thrown, no 404 returned). [AMBIGUOUS: this may be a bug — a missing survey ID on update returns HTTP 202 accepted but does nothing.]
- Invalidates `cas-survey-rules` cache after save.

---

### AH-2: SurveyEvaluatorListener (Kafka) [AH-2]
**Handler**: `SurveyEvaluatorListener.handleEvent()` in `module/kafka/listener/SurveyEvaluatorListener.java`
**Service**: `RuleParserHandler.parseRule()` (async, `@Async("appExecutor")`)
**Feeds**: STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003

#### Business Rules
- Iterates over ALL survey rules (every row in `survey` table, cached as `cas-survey-rules`). This means every inbound analytics event is evaluated against every active survey rule — there is no pre-filtering by category.
- **BRM-specific randomized assignment path (`randomizeSurveyAssignment=true`)**: For BRM surveys with `SurveyBody.randomizeSurveyAssignment = true`, `evaluateBRMSurveyEligibilityForUser()` is called first. This flag does **not** apply to NPS surveys. This invokes `RuntimeSurveyScheduler.planNext()` which:
  - Assigns the user to one of 3 time windows (0, 1, 2) deterministically via `Math.floorMod(Objects.hash(userId, surveyId), 3)` — code comment notes "distributing users into every 30 days across 90 days."
  - Window size = `survey.duration_days / 3`. Window 3 gets the remainder.
  - Returns `Plan.evaluateSurvey = true` only if `now` falls within the user's assigned window.
  - If the user's window has elapsed without evaluation, they are reassigned to the next available window recursively.
  - If `Plan.expired = true` (past window 2), user is excluded and the method returns false.
- SpEL rule expression evaluated against `RulesContext(event: VerifiedAnalyticsEventDTO, user: UserAttributes)` with an additional `#data` variable (event data as Map). SpEL evaluation failures are caught and logged as WARN — the survey is skipped, not failed.
- **Survey history check** (when `${survey.check-user-survey-history:true}`): `userEligibleFromSurveyHistory()` applies three gates:
  1. No open surveys for the same survey schema in state NOT_COMPLETED/NOT_READY/DISMISSED with TTL active.
  2. Fewer than `max-response-in-window-individual-survey` completions of this exact survey in the last `response-window-mins-individual-survey` minutes.
  3. Fewer than `max-response-in-window` total completions across all surveys in the last `response-window-mins` minutes.
- If all checks pass, a `PreprocessedSurvey` is created in state NOT_READY and published to the preprocessor topic.
- User attributes are fetched from Bigtable (or Redis cache `pps-user-attributes:<userId>`). If Bigtable returns null, falls back to `validEvent.getUserAttributes()` from the event payload with a WARN log.
- BRM image URL is encoded and prefixed when `businessNubanAccountNumber` is present.

#### [GAP] NPS-specific eligibility gates not implemented:
- Account age ≥ 60 days gate: `UserAttributes.onboardingDate` field exists in the DTO and is populated from Bigtable, but there is no code in `RuleParserHandler` or `SurveyEvaluatorListener` that enforces a minimum account age check. [GAP: not enforced in code — must be added as an NPS-specific pre-condition in `RuleParserHandler.parseRule()` or as a SpEL rule expression in the `survey.rule` field]
- Minimum 2 transactions in 30 days gate: `UserAttributes.lastTxnDate` exists but count is not available. [GAP: no transaction count field in `UserAttributes`; no outbound service call for transaction count exists]
- 90-day global cool-off: no `NpsUserState` table, no `last_nps_triggered_date` check anywhere in the codebase. [GAP: not implemented]
- Weekly sample cap (3,200 Personal / 2,134 Business): no sampling count check in the current codebase. [GAP: not implemented]

---

### AH-3: SurveyPreprocessorListener (Kafka) [AH-3]
**Handler**: `SurveyPreprocessorListener.handleEvent()` / `preprocessSurvey()` in `module/kafka/listener/SurveyPreprocessorListener.java`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002

#### Business Rules
- Receives `EventPreprocessSurveyDTO` containing the partially created `PreprocessedSurvey` (state=NOT_READY), the `Survey` definition, `UserAttributes`, and the originating `VerifiedAnalyticsEventDTO`.
- Performs `StringSubstitutor.replace()` on `survey.getSurvey()` using a context map built from:
  - `user.*` — all non-null fields of `UserAttributes` via reflection
  - `event.*` — all non-null fields of `AnalyticsEventV3DataDTO`
  - `event.device.*` — all non-null fields of device DTO
- Sets `state = NOT_COMPLETED`.
- TTL recalculated: `event.timestamp + preprocessedSurveyTtl minutes`. If `SurveyBody.preprocessedSurveyTTL > 0`, that value overrides the global config default.
- Saves the updated `PreprocessedSurvey` to DB.
- If `SurveyBody.assignBanner = true` AND `bannerId` is set → calls `BannerService.assignBannerToUser(username, bannerId)`.
- Otherwise, if platform is ANDROID or IOS → publishes `NotificationRequest` to push-notification topic.
- Writes to Redis cache: `pps-id:<id>` and appends to `pps-user:<userId>` list (only if the user list already exists in cache).

---

### AH-5: CompletedSurveyListener (Kafka) [AH-5]
**Handler**: `CompletedSurveyListener.handleEvent()` → `SurveyEventCompletionService.processCompletedSurveyEvent()` in `module/analytics/service/impl/SurveyEventCompletionService.java`
**Feeds**: STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003, STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004

#### Business Rules
- Three event names handled: `SURVEY_COMPLETED`, `SURVEY_DISMISSED`, `SURVEY_ABANDONED`.
- **Regular survey path** (surveyId present in `meta`): resolves `PreprocessedSurvey` by `(userId, surveyId)` in states NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED. If not found, creates a placeholder to remove from cache and returns.
- **Voluntary survey path** (surveySchemaId present, surveyId absent): looks up `preprocessed_survey` by `(user, surveySchemaId, states=[NOT_COMPLETED, DISMISSED], ttl > now)`. If no match found, creates a new `PreprocessedSurvey` record directly in the terminal state (`saveUserVoluntarySurvey()`).
- `source` from `meta.source` is appended to `additional_data` on the resolved survey.
- **COMPLETED side-effects**: if `SurveyBody.assignBanner = true` → banner unassigned. If `displayModalType = ALERT` → `survey_alert` rows deleted and cache evicted.
- **DISMISSED side-effects**: if `enableAlertingAfterDismissal = true`:
  1. SpEL `alertingCondition` evaluated against `AlertingContext(user)`.
  2. Resolves user from Bigtable/cache.
  3. `moniepointAgentId` resolved from `UserAttributes.customAttributes["agent_id"]`.
  4. If condition passes → `promoteDismissedSurveyToAlert()`: changes `displayModalType` to `alert`, sets `alertStartTime = now + displayDelayPeriodInSecs`, updates survey in DB and cache, creates `survey_alert` row via `saveSurveyAlert()`.
- **ABANDONED side-effects**: same as COMPLETED for alert cleanup.
- Final state and `completedOn` set: COMPLETED → completedOn = event timestamp; DISMISSED → completedOn NOT set; ABANDONED → completedOn = event timestamp.
- Cache eviction on COMPLETED/ABANDONED: removes from `pps-id:<id>` and `pps-user:<userId>`. On DISMISSED: cache NOT cleared (survey stays available for re-delivery).

---

### AH-6: PreprocessedSurveyExpirationTriggerJob (Quartz) [AH-6]
**Handler**: `PreprocessedSurveyExpirationTriggerJob.execute()` in `module/job/jobs/PreprocessedSurveyExpirationTriggerJob.java`
**Feeds**: — (system-internal; no user-facing story)

#### Business Rules
- Executes native SQL bulk update: `UPDATE preprocessed_survey SET state = 'EXPIRED' WHERE ttl < NOW() AND state IN ('NOT_COMPLETED', 'NOT_READY') ORDER BY id ASC LIMIT :limit`.
- `limit` controlled by `${survey.expiry-fetch-limit:100}`.
- Runs on Quartz cron schedule `${survey.preprocessed-survey-expiry-frequency}` — actual cron value is in the external config server (not available in local application.yml).
- Implemented as `ClusteredJob` — ShedLock prevents concurrent execution across multiple worker pods.
- No cache invalidation performed. Expired surveys remain in Redis cache until their Redis TTL (7 days) expires independently.

---

## 20. Cross-Cutting Concerns

### 20.1 Authentication & Authorization Model

JWT-based stateless OAuth2 resource server. Three JWT issuers supported via `MultiProviderAuthManager`:
1. **Cosmos**: RSA public key (hex-encoded), resource-id scoped, `COSMOS_ROLE_` prefix on authorities.
2. **Moniebook**: RSA public key (Base64-encoded).
3. **Monnify**: RSA public key (Base64-encoded).

Each JWT is decoded by trying all three decoders until one succeeds. The `AuthenticatedUser` principal is extracted from the successful JWT. Authority string is `can_fetch_survey` — used by `@PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")` on all `SurveyController` endpoints.

`/internal/admin/**` is in `PUBLIC_URIS` — no authentication required. This is explicitly marked as temporary in the codebase (`SecurityPropertiesConfig.java:35`).

CSRF disabled (stateless API). Sessions stateless (`SessionCreationPolicy.STATELESS`). CORS configured from `${web-security.cors.allowed-origins}` / `${web-security.cors.allowed-headers}`.

### 20.2 Idempotency Mechanisms

There is no explicit idempotency mechanism for survey creation or completion events. The following implicit safeguards exist:

- **Survey history check in rule evaluation** (`userEligibleFromSurveyHistory()`): prevents duplicate `PreprocessedSurvey` records for the same user+survey within the configured time window — acts as a de-facto idempotency gate for the preprocessing pipeline.
- **State check in completion** (`resolveRegularSurvey()`): only resolves surveys in NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED states — a survey already in COMPLETED state is not found and the completion handler exits without re-processing.
- No outbox pattern, no idempotency key header, no idempotency table.

### 20.3 Error Handling Strategy

Global exception handler: `GenericControllerAdvice` (`@RestControllerAdvice`).

| Exception | HTTP Code | Response Shape |
|-----------|-----------|----------------|
| `BadRequestException` (org.apache.coyote) | 400 | `ErrorResponse.build(400, message)` |
| `HttpMessageNotReadableException` | 400 | `ErrorResponse.build(400, INVALID_DATE_ERROR_MESSAGE)` |
| `MethodArgumentNotValidException` | 400 | Concatenated field error messages |
| `HandlerMethodValidationException` | 400 | Concatenated validation errors with `request[n]:` prefix |
| `NotFoundException` | 404 | `ErrorResponse.build(404, message)` |
| `ServerException` | 500 | `ErrorResponse.build(500, message)` |
| `AuthorizationDeniedException` | 403 | `ErrorResponse.build(403, message)` |
| `MethodArgumentTypeMismatchException` | 400 | `ErrorResponse.build(400, message)` |
| `Exception` (catch-all) | 500 | `ErrorResponse.build(500, message)` |

Kafka consumer error handling: exceptions in all five Kafka consumers are caught at the top level, logged at ERROR, and swallowed — no dead-lettering or retry for survey-specific Kafka errors. The event is silently dropped.

### 20.4 Observability

- **New Relic APM**: `@Trace(dispatcher = true)` on all `SurveyController` methods. `@Trace(async = true)` on `RuleParserHandler.parseRule()`. Custom segments via `NewRelic.getAgent().getTransaction().startSegment()` in `SurveyPreprocessorListener` and `RuleParserHandler`. Named transactions: `Survey/validatedSurveyEventConsume`, `Survey/preprocessSurveyEventConsume`, `Survey/completedSurveyEventConsume`. Custom metrics: `Custom/apiRequest/PayloadBytes`, `Custom/apiRequest/DroppedOversizeEvents`, `Custom/customerAnalyticsTopic/PayloadBytes`.
- **Structured logging**: `@Slf4j` throughout. Logs include `userId`, `surveyId`, `moniepointAgentId`, rule expressions, state transitions at INFO. Kafka events logged at INFO on receipt. DB operations logged at DEBUG.
- **Correlation IDs**: `CorrelationIdFilter` (HTTP layer) and `CorrelationIdProducerInterceptor` / `CorrelationIdRecordInterceptor` (Kafka layer) propagate correlation IDs across service hops.
- **Health**: Spring Actuator `/actuator/health` (public endpoint).
- **PII in logs**: userId and accountNumber are logged at INFO in multiple places (survey fetch, alert fetch, preprocessing). No explicit PII masking. BRM images are URL-encoded before logging but the userId field is logged plainly.

### 20.5 Async Processing Patterns

No outbox pattern. No saga. No compensation logic.

All async survey processing is done via:
1. **Kafka pub-sub chain**: the five-step pipeline (SurveyEventListener → SurveyEvaluatorListener → RuleParserHandler → SurveyPreprocessorListener → SurveyPushNotificationListener / CompletedSurveyListener) is entirely Kafka-mediated. Each step publishes to the next topic.
2. **`@Async("appExecutor")` thread pool**: `RuleParserHandler.parseRule()` and `SurveyEventCompletionService.processCompletedSurveyEvent()` execute in the shared async executor thread pool. No backpressure mechanism.

### 20.6 Workflow & Orchestration Configuration

No Spring State Machine, Spring Integration flows, Temporal/Cadence, BPMN, or Airflow. The survey delivery workflow is choreographed via Kafka topics (not orchestrated). Each Kafka consumer is independent; there is no central orchestrator.

Quartz scheduler: `PreprocessedSurveyExpirationTriggerJob` registered as a `ClusteredJob` (ShedLock distributed lock prevents concurrent execution).

| Workflow | Trigger | Steps | Compensations | Timeout |
|----------|---------|-------|---------------|---------|
| Survey delivery (BRM) | Analytics event matching SpEL rule with `randomizeSurveyAssignment=true` (BRM only) and user in active window | 1. Rule evaluation (AH-2) → 2. Partial save + publish to preprocessor (AH-2) → 3. Full preprocessing + cache write + push notification (AH-3) → 4. Push notification delivery to NOS (AH-4) | None — no compensation if any step fails | Step 3 TTL: not-ready-survey-ttl-mins (3h); final TTL: preprocessed-survey-ttl-mins (7d) |
| Survey completion | SURVEY_COMPLETED/DISMISSED/ABANDONED analytics event | 1. Resolve PreprocessedSurvey → 2. Handle side-effects (banner, alert) → 3. Update state → 4. Evict cache | None | N/A — synchronous within AH-5 |
| Survey expiry | Quartz cron | 1. Bulk-update NOT_COMPLETED/NOT_READY rows to EXPIRED | None | Per-run processes up to `expiry-fetch-limit` rows |

### 20.7 CDC & Event Patterns

No Debezium, no CDC outbox, no `@TransactionalEventListener`, no `ApplicationEventPublisher`.

Domain events are published directly to Kafka via `KafkaTemplate<String, String>` inside service methods. There is no guaranteed atomic write (DB persist + Kafka publish). If Kafka publish fails after DB save, the `PreprocessedSurvey` row exists in NOT_READY state in DB but the preprocessing event is lost — it will be expired by the job after `not-ready-survey-ttl-mins` (3 hours).

| Pattern | Source Table/Class | Target | Config Location |
|---------|-------------------|--------|----------------|
| Direct Kafka publish (not outbox) | `RuleParserHandler.enqueueSurveyForPreprocessing()` | `event-survey-preprocessor` topic | `kafka.topic.event-survey-preprocessor` |
| Direct Kafka publish (not outbox) | `SurveyPreprocessorListener.enqueuePushNotification()` | `event-survey-push-notification` topic | `kafka.topic.event-survey-push-notification` |
| Direct Kafka publish (not outbox) | `AnalyticsServiceImpl.pushResizedEvents()` | `event-completed-survey` topic | `kafka.topic.event-completed-survey` |

### 20.8 External Service Dependencies

| Service | Protocol | SLA | Fallback |
|---------|----------|-----|----------|
| NOS (Notification Orchestration Service) | REST / Feign | Internal SLA [AMBIGUOUS: not documented] | None — exception logged, push notification silently dropped |
| Banner Service | REST / Feign | Internal SLA [AMBIGUOUS] | None — exception logged, banner operation silently dropped |
| Cosmos OAuth2 Server | REST / Feign | Internal SLA [AMBIGUOUS] | None — on failure, `getToken()` returns empty string, downstream NOS/Banner calls use blank Authorization header and fail |
| Google Bigtable | gRPC / Bigtable SDK v2 | Google Cloud SLA | Graceful degradation: falls back to `UserAttributes` from event payload if Bigtable returns null or throws |
| MySQL (primary) | Spring Data JPA / HikariCP | Internal DB SLA | None |
| Redis | Spring Data Redis / Jedis | Internal SLA | None — Redis unavailability causes `SurveyController` read paths and Kafka listeners to throw uncaught exceptions |
| Kafka | Spring Kafka | Internal SLA | None — no dead-letter topic for survey-specific events |

---

## 21. Confidence Scoring

| Capability | Score | Notes |
|------------|-------|-------|
| NPS Survey (NG) — backend | 4/5 | All six REST endpoints are fully documented with code evidence. The complete Kafka pipeline (5 consumers + 3 publishers) is traced. All three MySQL tables are fully documented with migration history. All Redis cache keys and TTLs are documented. All outbound integrations (NOS, Banner, Cosmos, Bigtable) are documented. Two significant [GAP] areas reduce from 5: (1) NPS-specific business rules from CLAUDE.md (90-day cool-off, weekly sample caps 3,200/2,134, account age ≥60d, txn count ≥2) are NOT implemented in any code path — the infrastructure exists but the NPS eligibility guardrails are absent; (2) score/response data model gaps (`nps_score`, `nps_classification`, `nps_user_state` table) mean the full NPS response capture and reporting pipeline is NET-NEW. Core survey delivery infrastructure is complete and well-documented. No frontend code to match against (API-only channel). No failed repos. |

**Score rationale against quantitative thresholds:**
- No FE views to match (API-only channel — thresholds for "FE views matched to APIs" N/A by design).
- >95% of APIs matched to services with code evidence.
- >95% of Kafka topics traced to consumer/producer classes.
- <2 unresolved calls (only `survey.image-location-url` config value is missing from local files — resolved to config server).
- 0 failed repos.
- Score capped at 4/5 (not 5/5) because NPS-specific CLAUDE.md product invariants (cool-off, sampling caps, eligibility gates) are documented as [GAP] — a Phase 4 engineer cannot implement NPS purely from this service without also implementing the missing tables and eligibility logic.
