# Frontend Analysis: NPS Survey (NG)

> **NOTE — API-Only Capability**: The `customer-analytics-service` is a pure backend service. No frontend (mobile, web, or POS) code exists in this repository. The NPS Survey capability is consumed via API by mobile and web clients whose code lives in separate repositories not available in this extraction.
>
> Steps 1 and 2 (View Inventory and View Documentation) are intentionally skipped. This file is a stub to satisfy the pipeline structure.
>
> **Applicable channels**: `API` — The service exposes REST APIs consumed by Mobile (iOS/Android), Web, and potentially POS clients. Channel-specific views are implemented in the respective client repos.
>
> **Impact on Step 4**: All FE-derived fields (Views column in Source, feature flags from client-side, deep link registry, local persistence) will carry `[GAP: FE code not available in this extraction]`. Confidence score is capped at 4/5 for the API contract tracing (BE is fully available).

## 1. View Inventory

*Skipped — no frontend code in this repository.*

**Out of scope (FE lives in separate repos)**:
- Mobile NPS survey overlay / bottom sheet (Flutter/Dart — separate mobile repo)
- Web NPS survey modal (React — separate web repo)
- Mobile NPS push notification handler (Flutter — separate mobile repo)

## 2. View Documentation

*Skipped — no frontend code in this repository.*

## 3. Feature Grouping

Based on the backend API surface discovered in Step 3, the proposed feature grouping for the NPS Survey capability is:

| Feature | Description | BE Components |
|---------|-------------|---------------|
| Eligibility & Sampling | Determines which users are eligible and sampled for NPS in a given week | `SurveyEvaluatorListener`, `PreprocessedSurvey` (NOT_READY state), `RuntimeSurveyScheduler` |
| Survey Delivery | Personalises and delivers the survey to eligible users via push or polling | `SurveyPreprocessorListener`, `SurveyPushNotificationListener`, Redis cache, `PreprocessedSurvey` (NOT_COMPLETED state) |
| Pre-Commitment Check-in | Returns active survey alerts at check-in time so clients can surface the survey | `SurveyController.getDashboardInfo()`, `SurveyAlertStorage` |
| Survey Completion | Records user response (score + qualitative), classifies NPS outcome | `CompletedSurveyListener`, `SurveyEventCompletionService` |
| Survey Expiration | Batch-expires surveys past TTL | `PreprocessedSurveyExpirationTriggerJob` |
| Admin Management | Allows operators to create and update NPS survey definitions | `AdminSurveyController`, `SurveyService` |
