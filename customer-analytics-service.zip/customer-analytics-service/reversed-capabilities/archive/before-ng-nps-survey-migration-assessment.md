# Migration Assessment: NPS Survey (NG)

**Capability**: NPS Survey — Net Promoter Score
**Capability ID**: CAPABILITY-CXAN-NPSS
**Market**: NG (Nigeria)
**Platform**: PLATFORM-CXAN — CX Analytics
**Service**: customer-analytics-service (CAS)
**Assessment date**: 2026-05-19
**Confidence**: 4/5 — all existing components fully traced; GAP items identified in BE analysis

---

## 1. Component Inventory

| Component | Type | Repo / Package | Tech Stack | Test Coverage | Approx. Lines |
|---|---|---|---|---|---|
| `SurveyEventListener` | Kafka Consumer | `module/kafka/listener/` | Spring Kafka, Java 22 | Not measured (excluded pattern: listeners) | ~80 |
| `SurveyEvaluatorListener` | Kafka Consumer | `module/kafka/listener/` | Spring Kafka, SpEL, Java 22 | Not measured | ~200 |
| `RuleParserHandler` | Service / Async Worker | `module/kafka/listener/` | Spring `@Async`, SpEL, Java 22 | Not measured | ~150 |
| `RuntimeSurveyScheduler` | Domain Logic | `module/analytics/service/` | Java 22 | Not measured | ~60 |
| `SurveyPreprocessorListener` | Kafka Consumer | `module/kafka/listener/` | Spring Kafka, Apache Commons Text, Java 22 | Not measured | ~180 |
| `SurveyPushNotificationListener` | Kafka Consumer | `module/kafka/listener/` | Spring Kafka, Feign, Java 22 | Not measured | ~60 |
| `CompletedSurveyListener` | Kafka Consumer | `module/kafka/listener/` | Spring Kafka, Java 22 | Not measured | ~40 |
| `SurveyEventCompletionService` | Service | `module/analytics/service/impl/` | Spring, JPA, Java 22 | Partial (covered via `SurveyEventCompletionServiceTest`) | ~300 |
| `SurveyController` | REST Controller | `module/analytics/controller/` | Spring MVC, JWT, Java 22 | Covered (controller tests) | ~200 |
| `AdminSurveyController` | REST Controller (admin) | `module/analytics/controller/` | Spring MVC, Java 22 | Partial | ~80 |
| `SurveyService` / `SurveyServiceImpl` | Service | `module/analytics/service/` | Spring, JPA, Java 22 | Covered via `SurveyServiceTest` | ~120 |
| `PreprocessedSurveyRepositoryService` | Service | `module/analytics/service/` | Spring, JPA, Redis, Java 22 | Covered via repository tests | ~250 |
| `PreprocessedSurveyExpirationTriggerJob` | Quartz Job | `module/job/jobs/` | Quartz, ShedLock, JPA, Java 22 | Not measured (batch job) | ~60 |
| `SurveyStorage` | Repository | `module/analytics/repository/` | Spring Data JPA, MySQL | TestContainers | ~40 |
| `PreprocessedSurveyStorage` | Repository | `module/analytics/repository/` | Spring Data JPA, MySQL | TestContainers | ~80 |
| `SurveyAlertStorage` | Repository | `module/analytics/repository/` | Spring Data JPA, MySQL | TestContainers | ~30 |
| `RedisCacheServiceImpl` | Cache Service | `module/cache/` | Spring Data Redis, Jedis | Not measured | ~200 |
| `NOSClient` | Feign Client | `outbound/` | Spring Cloud OpenFeign, Java 22 | Mocked in service tests | ~40 |
| `BannerClient` | Feign Client | `outbound/` | Spring Cloud OpenFeign, Java 22 | Mocked in service tests | ~30 |
| `CosmosClient` | Feign Client | `outbound/` | Spring Cloud OpenFeign, Java 22 | Mocked in service tests | ~30 |
| `UserAttributesRepositoryService` | Bigtable Client | `module/analytics/service/` | Bigtable SDK v2, gRPC, Java 22 | Mocked in service tests | ~80 |
| `survey` table | MySQL Table | DB migrations repo (separate) | MySQL, Spring Data JPA | N/A | 12 columns |
| `preprocessed_survey` table | MySQL Table | DB migrations repo (separate) | MySQL, Spring Data JPA | N/A | 15 columns |
| `survey_alert` table | MySQL Table | DB migrations repo (separate) | MySQL, Spring Data JPA | N/A | 14 columns |
| `nps_user_state` table | MySQL Table | [GAP: does not exist] | — | — | — |
| `nps_weekly_sample` table | MySQL Table | [GAP: does not exist] | — | — | — |
| `nps_weekly_score` table | MySQL Table | [GAP: does not exist] | — | — | — |
| `nps_weekly_ai_summary` table | MySQL Table | [GAP: does not exist] | — | — | — |
| Redis keyspace (NPS-relevant keys) | Cache | Infrastructure | Redis / Jedis | N/A | 6 key patterns |
| Kafka topics (5 topics) | Event Bus | Infrastructure | Apache Kafka, Spring Kafka | N/A | 5 topics |
| NOS (Notification Orchestration Service) | Outbound Integration | Internal Moniepoint service | REST / Feign | Mocked | External service |
| Banner Service | Outbound Integration | Internal Moniepoint service | REST / Feign | Mocked | External service |
| Cosmos OAuth2 Server | Outbound Integration | Internal Moniepoint service | REST / Feign | Mocked | External service |
| Google Bigtable | Outbound Integration | GCP Infrastructure | gRPC / Bigtable SDK v2 | Mocked | External service |

---

## 2. Platform Alignment

| Component | Target Pattern | Current Pattern | Alignment | Gap |
|---|---|---|---|---|
| `SurveyEventListener` | Single-responsibility Kafka consumer, idempotent, dead-letter on failure | Fan-out filter; no DLT; at-least-once, not idempotent | Medium | No dead-letter topic; not idempotent |
| `SurveyEvaluatorListener` | Kafka consumer with clear domain boundary; SpEL evaluation extracted to domain service | SpEL evaluation mixed with Kafka consumer logic; Bigtable access inline | Medium | Business logic mixed into consumer; single consumer group for all five consumers creates tight coupling |
| `RuleParserHandler` | Domain service with clearly separated NPS eligibility gates | NPS-specific gates (cool-off, sampling, age, txn count) not implemented; window-based sampling logic is non-standard | Low | Critical NPS eligibility gates missing entirely; business rules from CLAUDE.md not reflected in code |
| `RuntimeSurveyScheduler` | Configurable sampling strategy with per-market caps | Deterministic hash-based window assignment; no weekly cap enforcement | Low | No per-week sample cap; no cool-off integration |
| `SurveyPreprocessorListener` | Consumer with outbox-backed publish | Direct Kafka publish after DB write; no outbox pattern | Low | Dual-write failure risk (DB save succeeds, Kafka publish fails → orphaned NOT_READY row) |
| `SurveyPushNotificationListener` | Resilient client call with circuit breaker, retry, dead-letter | No circuit breaker, no retry on Feign call, silent drop on failure | Low | Push notification is a critical NPS delivery path — no resilience whatsoever |
| `CompletedSurveyListener` / `SurveyEventCompletionService` | Score capture + classification at completion | No score/classification persistence; state machine partially sound | Medium | NPS score and PROMOTER/PASSIVE/DETRACTOR classification not persisted |
| `SurveyController` | REST controller with read-through cache | Redis read-through cache present; payload constraints enforced | High | Well-structured; minor gap: no explicit 1KB payload enforcement in code |
| `AdminSurveyController` | Auth-protected admin API | No auth on admin endpoint (PUBLIC_URIS) | Low | Unauthenticated admin API is a security regression pending network policy |
| `SurveyService` / `SurveyServiceImpl` | Domain service with typed exceptions | Uses typed exception hierarchy (`BadRequestException`, `NotFoundException`); BOM stripping present | High | Aligned; minor: `category`, `start`, `duration_days` not set on create |
| `PreprocessedSurveyRepositoryService` | Cache-aside pattern with invalidation | Cache-aside present; invalidation on write operations present | High | Aligned |
| `PreprocessedSurveyExpirationTriggerJob` | ShedLock-locked batch job with configurable batch size | Clustered ShedLock job; LIMIT-based batch; no cache invalidation | Medium | Cache not invalidated after expiry — expired surveys linger in Redis until natural TTL |
| `SurveyStorage` / `PreprocessedSurveyStorage` / `SurveyAlertStorage` | Spring Data repositories with named-query indexes | Spring Data JPA; compound indexes present on `preprocessed_survey` | High | Aligned; `survey_alert` has no custom indexes |
| `RedisCacheServiceImpl` | Single-layer cache with typed serialisation | Multi-key Redis cache; Jedis; no typed schema | Medium | No schema enforcement on cached objects — deserialization failures are silent |
| `NOSClient` | Resilient Feign client with circuit breaker + retry | Plain Feign client with no FallbackFactory, no Resilience4j | Low | Critical resilience gap on push notification delivery path |
| `BannerClient` | Resilient Feign client | Plain Feign client with no FallbackFactory | Low | Non-critical but same resilience gap |
| `CosmosClient` | Resilient OAuth2 token client with refresh | Plain Feign; token cached in Redis but no refresh retry | Low | On Cosmos failure, all NOS and Banner calls use a blank auth header and fail silently |
| `UserAttributesRepositoryService` | Resilient Bigtable reader with graceful degradation | Partial graceful degradation (fallback to event payload); no circuit breaker | Medium | Partial alignment — fallback exists but is implicit |

---

## 3. Migration Strategy Per Component

| Component | Strategy | Rationale | Risk | Effort |
|---|---|---|---|---|
| `SurveyEventListener` | **Keep + adapt** | Logic is a simple fan-out filter; well-structured; add dead-letter topic | Low | Low |
| `SurveyEvaluatorListener` | **Refactor** | SpEL evaluation logic is reusable but NPS eligibility gates must be extracted and the missing cool-off / cap / age / txn-count gates must be added | High | High |
| `RuleParserHandler` | **Refactor** | The window-based sampling mechanism is domain logic that must be preserved and extended with per-market cap enforcement and cool-off integration | High | High |
| `RuntimeSurveyScheduler` | **Refactor** | Sound approach for time-window partitioning; must be enhanced to integrate with `nps_user_state` for cool-off and `nps_weekly_sample` for cap enforcement | Medium | Medium |
| `SurveyPreprocessorListener` | **Refactor** | Preprocessing logic sound; must adopt outbox pattern to prevent orphaned NOT_READY rows on Kafka publish failure | Medium | Medium |
| `SurveyPushNotificationListener` + `NOSClient` | **Refactor** | Push notification is critical; must add Resilience4j circuit breaker, retry (at least 3 attempts), and dead-letter fallback | High | Medium |
| `CompletedSurveyListener` + `SurveyEventCompletionService` | **Refactor** | Core completion state machine is sound; must add NPS score extraction, classification (Promoter/Passive/Detractor), score persistence, and `nps_user_state` write on COMPLETED | High | High |
| `SurveyController` (API-1 through API-6) | **Keep + adapt** | Well-structured, versioned, auth-protected, cache-integrated; adapt package + payload constraint enforcement | Low | Low |
| `AdminSurveyController` (API-7, API-8) | **Refactor** | Logic is sound but security must be addressed: move from `PUBLIC_URIS` to proper authority-gated auth (`@PreAuthorize`) before Phase 4 deployment | High | Low |
| `SurveyService` / `SurveyServiceImpl` | **Keep + adapt** | Aligned with platform patterns; minor field gap for `category`/`start`/`duration_days` | Low | Low |
| `PreprocessedSurveyRepositoryService` | **Keep + adapt** | Well-structured cache-aside; minor: add payload size guard | Low | Low |
| `PreprocessedSurveyExpirationTriggerJob` | **Keep + adapt** | ShedLock pattern correct; add cache invalidation for expired rows | Low | Low |
| `SurveyStorage` / `PreprocessedSurveyStorage` / `SurveyAlertStorage` | **Keep + adapt** | Spring Data JPA; aligned; add missing index on `survey_alert` | Low | Low |
| `RedisCacheServiceImpl` | **Keep + adapt** | Multi-level caching works; add typed serialisation to prevent silent deserialization failures | Low | Low |
| `BannerClient` | **Keep + adapt** | Non-critical path; add Resilience4j retry and circuit breaker | Low | Low |
| `CosmosClient` | **Keep + adapt** | Token caching works; add retry on token refresh failure | Low | Low |
| `UserAttributesRepositoryService` | **Keep + adapt** | Bigtable read with graceful degradation exists; formalise circuit breaker | Low | Low |
| `nps_user_state` table | **Replace (net-new)** | Does not exist; must be created as a new entity `NpsUserState` keyed by `(userId)` with `last_nps_triggered_date`, `yearly_trigger_count` | High | Medium |
| `nps_weekly_sample` table | **Replace (net-new)** | Does not exist; required for weekly cap enforcement by `(week_start_date, app_domain)` with `sample_count` | High | Medium |
| `nps_weekly_score` table | **Replace (net-new)** | Does not exist; required for RPTG sub capability | Medium | High |
| `nps_weekly_ai_summary` table | **Replace (net-new)** | Does not exist; required for AI summary reporting | Medium | High |
| Kafka pipeline (5 topics) | **Keep + adapt** | Topic structure is sound; add dead-letter topics for each consumer | Medium | Medium |
| NPS Reporting API layer | **Replace (net-new)** | No endpoints exist; must build from scratch per RPTG sub capability spec | Medium | High |
| NPS AI Summarisation job | **Replace (net-new)** | No job exists; must build from scratch; AI provider TBD | Medium | High |

---

## 4. Strangler Fig Candidates

| Component | Approach | Shadow Mode? | Feature Flag | Validation Gate |
|---|---|---|---|---|
| NPS eligibility gate expansion (`RuleParserHandler`) | Strangler fig — add new gates alongside existing SpEL rule evaluation; shadow mode collects gate outcomes without blocking delivery until validated | Yes — log gate decisions without enforcing during ramp | `nps.eligibility-gates-enforced` (new) | Gate hit rates collected for 2 weeks; < 0.1% false positive rate before enforcing |
| NPS push notification resilience (`NOSClient`) | Strangler fig — introduce Resilience4j wrapper around existing Feign call; validate fallback behaviour in shadow mode | Yes — log circuit breaker events without breaking existing flow | `nps.push-notification-resilience-enabled` | No increase in push notification drop rate after circuit breaker introduced |
| NPS score capture (`CompletedSurveyListener`) | Strangler fig — dual-write: extract score from event payload and write to new columns in `preprocessed_survey`; existing completion path untouched | Yes — write score to new columns; existing `state` column write unchanged | `nps.score-capture-enabled` | Score fields populated for 100% of SURVEY_COMPLETED events for 1 week before making mandatory |
| Admin authentication (`AdminSurveyController`) | Strangler fig — add `@PreAuthorize` alongside existing PUBLIC_URI pattern; validate with network-policy enforcement before removing from PUBLIC_URIS | No | `nps.admin-auth-enforced` | Zero 403 errors from legitimate operator tools during shadow period |

---

## 5. Dependency Impact

| If we change... | These depend on it... | Impact |
|---|---|---|
| `SurveyEvaluatorListener` (add eligibility gates) | All downstream Kafka consumers (`SurveyPreprocessorListener`, `SurveyPushNotificationListener`, `CompletedSurveyListener`) — fewer events flow through | Lower preprocessing and push notification volume; lower COMPLETED event volume. Lower is correct but requires capacity validation. |
| `survey` table schema (add `category`, `start`, `duration_days` enforcement) | `AdminSurveyController.createSurvey()`, `SurveyService.createSurvey()`, `SurveyEvaluatorListener` (rule loading) | All three components must handle new required fields; cache invalidation logic unchanged |
| `preprocessed_survey` table schema (add `nps_score`, `nps_classification`) | `CompletedSurveyListener`, `SurveyEventCompletionService`, `PreprocessedSurveyStorage`, `PreprocessedSurveyDTO`, `SurveyHistoryItemDTO` | All five artefacts require migration; DB migration must be coordinated with DBA team via DB migrations repo |
| Kafka consumer group (`survey-evaluator-group-id` shared by all 5 consumers) | All five Kafka consumers share one group ID — offset management is coupled | Kafka partition assignment affects all consumers simultaneously; a stuck consumer in group blocks all other consumers. High operational risk. |
| NOS API contract | `SurveyPushNotificationListener`, `NOSClient`, `NotificationOrchestrationService` | Any NOS API change requires coordinated update across three components; currently no fallback means silent failure |
| `cas-survey-rules` Redis cache key | `SurveyEvaluatorListener` (reader), `SurveyService.createSurvey()` (invalidator), `SurveyService.updateSurvey()` (invalidator) | Cache key rename or TTL change propagates to all three; safest to keep key name stable |
| Cosmos OAuth2 token cache (`cas-access-token`) | `OutboundUtils.getToken()` → `NOSClient`, `BannerClient` | Both outbound services lose auth on token failure; must be addressed before circuit breaker work |
| `nps_user_state` table (net-new) | `RuleParserHandler` (cool-off check), `SurveyEventCompletionService` (write on COMPLETED) | Two code paths must be updated atomically; DB migration must precede code changes |

---

## 6. Migration Sequence

Recommended order (lowest risk first, dependencies respected):

| Order | Component | Strategy | Depends On | Blocks |
|---|---|---|---|---|
| 1 | `nps_user_state` table — DB migration | Replace (net-new) | DB migrations repo; DBA coordination | RuleParserHandler cool-off gate (step 5) |
| 2 | `nps_weekly_sample` table — DB migration | Replace (net-new) | DB migrations repo | RuntimeSurveyScheduler cap enforcement (step 5) |
| 3 | `preprocessed_survey` — add `nps_score`, `nps_classification` columns | Replace (net-new columns) | DB migrations repo | CompletedSurveyListener score capture (step 6) |
| 4 | Admin authentication gap — add `@PreAuthorize` to `AdminSurveyController` | Refactor | Network policy enforcement from infra team | Nothing blocked — can deploy independently |
| 5 | `RuleParserHandler` + `RuntimeSurveyScheduler` — add cool-off, cap, age, txn-count eligibility gates | Refactor | Step 1 (nps_user_state), Step 2 (nps_weekly_sample) | Nothing downstream — gates only reduce event flow |
| 6 | `CompletedSurveyListener` + `SurveyEventCompletionService` — add NPS score extraction, classification, and `nps_user_state` write | Refactor | Step 3 (score columns), Step 1 (nps_user_state) | Step 9 (RPTG reporting tables) |
| 7 | `SurveyPushNotificationListener` + `NOSClient` — add Resilience4j circuit breaker and retry | Refactor | None (independent resilience change) | Nothing blocked |
| 8 | `SurveyPreprocessorListener` — adopt outbox pattern for Kafka publish | Refactor | None (independent reliability change) | Nothing blocked |
| 9 | `nps_weekly_score`, `nps_weekly_ai_summary` tables — DB migration | Replace (net-new) | Step 6 (score data must exist) | RPTG API layer (step 10) |
| 10 | NPS Reporting API layer — new endpoints + weekly score computation job | Replace (net-new) | Step 9 | Nothing |
| 11 | NPS AI Summarisation job | Replace (net-new) | Step 10, AI provider selection | Nothing |
| 12 | `PreprocessedSurveyExpirationTriggerJob` — add cache invalidation for expired rows | Keep + adapt | None | Nothing |
| 13 | `AdminSurveyController` — remove from `PUBLIC_URIS` after network policy confirmed | Keep + adapt | Step 4 (auth in place), infra team confirmation | Nothing |

---

## 7. Tech Debt to Address

| Debt | Location | Impact if Not Addressed | Priority |
|---|---|---|---|
| No circuit breaker or retry on NOS push notification | `NOSClient`, `SurveyPushNotificationListener` | Push notifications permanently dropped on NOS blips; NPS survey delivery silently fails for mobile users | Critical |
| No circuit breaker or retry on Cosmos OAuth2 token | `CosmosClient`, `OutboundUtils.getToken()` | On Cosmos blip, both NOS and Banner Service calls use a blank auth header and fail silently | Critical |
| Shared Kafka consumer group (`survey-evaluator-group-id`) for all five consumers | `SurveyEventListener`, `SurveyEvaluatorListener`, `SurveyPreprocessorListener`, `SurveyPushNotificationListener`, `CompletedSurveyListener` | A stuck or lagging consumer in the group causes Kafka partition rebalancing that affects all other consumers; operational blast radius is service-wide | Critical |
| No outbox pattern — direct Kafka publish after DB save | `RuleParserHandler`, `SurveyPreprocessorListener`, `AnalyticsServiceImpl` | If Kafka is briefly unavailable after DB save, `PreprocessedSurvey` rows are created in NOT_READY state and orphaned — they will expire silently after 3 hours | High |
| Unauthenticated admin API (`/internal/admin/surveys`) | `AdminSurveyController`, `SecurityPropertiesConfig` | NPS survey rule manipulation is unrestricted; any internal network actor can create or modify survey rules | High |
| No dead-letter topic for any survey Kafka consumer | All five Kafka consumers | Failed Kafka events are silently dropped after logging; no replay capability for incidents | High |
| No NPS score / classification persistence | `preprocessed_survey` table, `CompletedSurveyListener` | NPS reporting is impossible without persisted scores; CLAUDE.md invariant (Promoter/Passive/Detractor) cannot be computed | High |
| No 90-day NPS cool-off enforcement | `RuleParserHandler`, `nps_user_state` (missing) | Users can receive NPS surveys more frequently than the 90-day product invariant allows; distorts NPS data quality | High |
| No weekly sample cap enforcement | `RuntimeSurveyScheduler`, `nps_weekly_sample` (missing) | NPS sample may exceed 3,200 (Personal) / 2,134 (Business) per week; distorts statistical validity of NPS score | High |
| Missing eligibility gates (account age, txn count) | `RuleParserHandler`, `UserAttributes` | New accounts and inactive users included in NPS sample; distorts relationship sentiment signal | Medium |
| PII in structured logs (userId, accountNumber) | `SurveyController`, `PreprocessedSurveyRepositoryService`, Kafka listeners | Potential compliance risk — plain userId and accountNumber logged at INFO without masking | Medium |
| No idempotency mechanism for Kafka preprocessing pipeline | `SurveyPreprocessorListener` | Duplicate Kafka delivery can create duplicate `PreprocessedSurvey` rows for the same user+survey | Medium |
| No retry on Banner Service calls | `BannerClient`, `SurveyPreprocessorListener` | Banner assignment or unassignment silently fails on Banner Service blip; banner state becomes inconsistent with survey state | Medium |
| No cache invalidation after expiry job | `PreprocessedSurveyExpirationTriggerJob` | Expired surveys remain in Redis cache for up to 7 days after expiry; clients polling `GET /api/surveys/user` see expired surveys in the response until Redis TTL elapses independently | Low |
| `SurveyCreateRequest` fields `category`, `start`, `duration_days` not set by `createSurvey()` | `SurveyService.createSurvey()` | NPS surveys cannot have their start date or duration configured via the admin API; these must be set via direct DB manipulation or a separate path | Low |
| AMBIGUOUS: `PUT /internal/admin/surveys` returns HTTP 202 on non-existent id | `AdminSurveyController.updateSurvey()`, `SurveyService.updateSurvey()` | Silent no-op on admin survey update with a wrong ID; operator gets no feedback that their update had no effect | Low |

---

## 8. Reuse Candidates

| What | Source | Adaptation Needed |
|---|---|---|
| `SurveyEventListener` (fan-out filter pattern) | `module/kafka/listener/SurveyEventListener.java` | Add dead-letter topic publication; rename consumer group to a survey-listener-specific group |
| `SurveyPreprocessorListener` (StringSubstitutor personalisation pattern) | `module/kafka/listener/SurveyPreprocessorListener.java` | Extract personalisation logic to a domain service; introduce outbox pattern for reliability |
| `SurveyController` (cache-aside read API pattern) | `module/analytics/controller/SurveyController.java` | Keep as-is; adapt package naming for platform conventions |
| Redis multi-key cache pattern (`pps-user:<id>`, `pps-id:<id>`) | `module/cache/RedisCacheServiceImpl.java` | Add typed serialisation schema; retain pattern for CSAT and BRM survey delivery |
| `RuntimeSurveyScheduler` (time-window partitioning for sampling) | `module/analytics/service/RuntimeSurveyScheduler.java` | Extend to accept per-market weekly cap from `nps_weekly_sample`; integrate `nps_user_state` cool-off check |
| `PreprocessedSurveyExpirationTriggerJob` (ShedLock + LIMIT-based batch job) | `module/job/jobs/PreprocessedSurveyExpirationTriggerJob.java` | Reuse pattern for CSAT expiry job; add cache invalidation step |
| SpEL rule evaluation against `RulesContext` | `SurveyEvaluatorListener` + `RuleParserHandler` | Reusable for CSAT and BRM rule evaluation; extract to shared `SurveyRuleEvaluator` domain service |
| `OutboundUtils.getToken()` Redis-backed Cosmos token cache | `outbound/OutboundUtils.java` | Reusable for any service requiring Cosmos OAuth2 client credentials; add retry on token fetch failure |
| NOS integration (push notification delivery) | `outbound/NOSClient.java`, `NotificationOrchestrationService.java` | Reusable for CSAT and any future in-app notification capability; add Resilience4j circuit breaker before reuse |
| `GenericControllerAdvice` (exception-to-HTTP mapping) | `common/advice/GenericControllerAdvice.java` | Shared across all CAS capabilities; carry forward as-is |
| SurveyBody JSON serialisation with BOM stripping | `SurveyService.serializeSurvey()` | Reusable for any admin-authored JSON payload; extract to a utility |

---

### Integration Disposition Summary (Migration Assessment Completeness Rule)

Every outbound integration from the BE analysis is accounted for below:

| Integration | Disposition | Notes |
|---|---|---|
| NOS (Notification Orchestration Service) | **Refactor** — add circuit breaker + retry | Steps 7 in migration sequence; critical delivery path |
| Banner Service | **Keep + adapt** — add Resilience4j retry | Non-critical; step implicit in overall resilience improvement |
| Cosmos OAuth2 Server | **Keep + adapt** — add retry on token failure | Underpins both NOS and Banner auth; low effort |
| Google Bigtable | **Keep + adapt** — formalise circuit breaker | Graceful degradation partially exists; formalise with Resilience4j |
| MySQL (primary datasource) | **Keep + adapt** — add new tables via DB migrations repo | Three net-new tables required; coordinate with DBA |
| Redis | **Keep + adapt** — add typed serialisation | No structural change; operational improvement only |
| Kafka (all 5 topics) | **Keep + adapt** — separate consumer groups + add DLTs | Shared consumer group is the highest operational risk; must resolve before production load increases |
