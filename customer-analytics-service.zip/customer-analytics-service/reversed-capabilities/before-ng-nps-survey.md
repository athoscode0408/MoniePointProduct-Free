﻿---
id: CAPABILITY-CXAN-NPSS
name: NPS Survey
platform: PLATFORM-CXAN — CX Analytics
status: draft
confidence: 4/5
market: ng
personas:
  - user
  - admin
channels:
  - API
  - Mobile (consumed via API)
  - Web (consumed via API)
dependencies:
  - CAPABILITY-CXAN-CHKN — Check-in Pre-Commitment (shared eligibility endpoint)
---

# CX Analytics — NPS Survey

The NPS Survey capability enables Moniepoint to measure relationship-level sentiment from users on a cadence-driven basis. An analytics event triggers eligibility evaluation; eligible users are sampled, personalised surveys are delivered via push notification or app polling, and response data (score + qualitative feedback) is recorded and classified as Promoter, Passive, or Detractor. Admin operators configure survey rule definitions via an internal management API.

The capability is delivered entirely as a backend API service (`customer-analytics-service`). Mobile and Web clients consume the API; no frontend code lives in this repository. Channel-specific views (NPS overlay, push notification handler) reside in separate mobile and web repos not available in this extraction.

> **Note:** Step 4 artifacts include the `market:` field. Phase 2 artifacts drop it (country-agnostic).

---

## Success Metrics

| Metric | Target |
|---|---|
| Survey delivery latency (event trigger → push notification delivered) P95 | < 30 s |
| Survey payload size | < 1 KB per response |

---

## Sub capabilities

### Eligibility & Sampling (SUBCAP-CXAN-NPSS-ELGB)

**Applicable personas**: user
**Applicable channels**: API
**Problem**: Determine which users are eligible for NPS based on survey history gates and SpEL rule evaluation.

**Success metrics**:
- Eligible-but-not-sampled rate: TBD

**Config parameters**:
- `survey.rules-cache-ttl-mins` — Redis TTL in minutes for the full survey rule set (default 1,440)
- `survey.check-user-survey-history` — master switch; if false, skips all survey history eligibility checks
- `survey.response-window-mins` — global lookback window in minutes for cross-survey completion check (default 7)
- `survey.max-response-in-window` — maximum total survey completions within `response-window-mins` (default 2)
- `survey.response-window-mins-individual-survey` — per-survey lookback window in minutes (default 30)
- `survey.max-response-in-window-individual-survey` — max same-survey completions within individual window (default 1)
**design_refs**:
**engineering_refs**: `SurveyEvaluatorListener`, `RuleParserHandler` in `module/kafka/listener/`
**deprecation_reason**:

#### Description

When an analytics event is received on the `verified-analytics-event` Kafka topic, it passes through a two-stage filter pipeline. `SurveyEventListener` strips events without a userId and republishes to `event-validated-survey`. `SurveyEvaluatorListener` then loads all survey rules from a Redis-backed cache, fetches user attributes from Bigtable, and evaluates each rule's SpEL expression against a `RulesContext(event, user)` object. Note: `SurveyBody.randomizeSurveyAssignment = true` and the `RuntimeSurveyScheduler` time-window partitioning apply to **BRM surveys**, not NPS.

#### Competitive Context

(Not available from code analysis — PM to complete.)

#### EPIC-SUBCAP-CXAN-NPSS-ELGB-EP00001 — NPS Eligibility Evaluation

**Persona**: user
**Status**: active

##### Intent

**As a** user
**I want** the system to determine whether I am eligible for an NPS survey
**So that** I only receive a survey when the configured eligibility rules and history gates permit it

The Epic has no events or AC of its own — those belong to stories. The last story in each Epic is the completion story — the story whose success event signals the Epic is done. Order stories so the first initiates the action and the last confirms completion.

---

##### STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001 — Receive and filter analytics event for NPS eligibility

**As a** user
**I want** my analytics activity events to be evaluated against NPS survey rules
**So that** I am considered for NPS survey delivery when I meet the rule criteria

When an analytics event is emitted from the user's mobile or web session, it is published to the `verified-analytics-event` Kafka topic. `SurveyEventListener` acts as the first-stage filter: it discards events without a valid userId (e.g., anonymous sessions) and republishes valid events to the `event-validated-survey` topic for rule evaluation. This ensures only authenticated user events proceed into the NPS pipeline.

###### Fields

This story does not involve data entry — no field spec required.

**Source**: Views [n/a — API only] | APIs [AH-1, AH-2]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001-AC-00001 — Event with valid userId passes filter**
**Path:** success

**Given** an authenticated analytics event with a non-blank userId arrives on the `verified-analytics-event` topic
**When** `SurveyEventListener` processes the event
**Then** the event is republished to `event-validated-survey` for SpEL rule evaluation

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001-AC-00002 — Event without userId is discarded**
**Path:** failed

**Given** an analytics event with a blank or null userId arrives on the `verified-analytics-event` topic
**When** `SurveyEventListener` processes the event
**Then** the system discards the event without republishing
**And** the system displays the message: *"Event discarded: userId is blank — NPS eligibility check skipped"*

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001-AC-00003 — Kafka consumer unavailability**
**Path:** error (retryable)

**Given** the `event-validated-survey` topic is temporarily unreachable
**When** `SurveyEventListener` attempts to republish the event
**Then** the system displays the message: *"Survey eligibility event could not be queued — will retry on next delivery"*
**And** the user may retry — no retry limit applies (Kafka at-least-once delivery handles redelivery)
**And** the inbound analytics event data is not modified and remains on the source topic for reprocessing

---

##### STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002 — Evaluate NPS SpEL rule against user attributes

**As a** user
**I want** the NPS rule expression to be evaluated against my current profile and activity
**So that** I am only selected if I match the configured NPS targeting criteria

After the event passes the userId filter, `SurveyEvaluatorListener` loads all survey rules from the Redis `cas-survey-rules` cache (or DB on cache miss, with a 24-hour cache TTL) and evaluates each rule's SpEL expression against a `RulesContext(event, user)` object. User attributes are fetched from Bigtable (or Redis `pps-user-attributes:<userId>`, TTL 24 hours). The `randomizeSurveyAssignment` flag and `RuntimeSurveyScheduler` window-based sampling apply to BRM surveys only.

###### Fields

This story does not involve data entry — no field spec required.

**Source**: Views [n/a — API only] | APIs [AH-2]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002-AC-00001 — SpEL rule matches and PreprocessedSurvey created**
**Path:** success

**Given** the NPS survey SpEL rule expression evaluates to `true` against the user's attributes and the event payload
**When** `SurveyEvaluatorListener` processes the event
**Then** a `PreprocessedSurvey` is created in state `NOT_READY` and published to the `event-survey-preprocessor` topic

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002-AC-00003 — SpEL expression evaluation error**
**Path:** error (non-retryable)

**Given** the SpEL rule expression on the `survey` row contains a syntax or runtime error
**When** `SurveyEvaluatorListener` attempts to evaluate the expression
**Then** the system displays the message: *"Survey rule evaluation failed — survey skipped for this event"*
**And** the user cannot retry (event is silently dropped; no survey created)
**And** the evaluation exception is logged at WARN and the survey rule is skipped

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002-AC-00004 — Bigtable unavailable — fallback to event payload attributes**
**Path:** error (retryable)

**Given** Bigtable is unavailable when user attributes are requested for rule evaluation
**When** `SurveyEvaluatorListener` calls `UserAttributesRepositoryService`
**Then** the system falls back to `UserAttributes` from the event payload
**And** the system displays the message: *"User attributes unavailable from primary store — using event payload attributes for rule evaluation"*
**And** the user may retry — no retry limit applies (evaluation proceeds with degraded user context)
**And** the partial user attributes from the event payload are used; no user data is lost

---

##### STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003 — Apply survey history eligibility gates before triggering

**As a** user
**I want** the system to verify I have not recently completed or been triggered for this survey
**So that** I am not shown the same NPS survey more frequently than the configured limits allow

Before creating a `PreprocessedSurvey`, `RuleParserHandler.userEligibleFromSurveyHistory()` applies three sequential gates: (1) no open surveys for the same survey schema in an active state (NOT_COMPLETED / NOT_READY / DISMISSED with TTL active), (2) fewer than `max-response-in-window-individual-survey` completions of this exact survey in the last `response-window-mins-individual-survey` minutes, and (3) fewer than `max-response-in-window` total survey completions across all surveys in the last `response-window-mins` minutes.

###### Fields

This story does not involve data entry — no field spec required.

**Source**: Views [n/a — API only] | APIs [AH-2]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003-AC-00001 — User passes all history gates**
**Path:** success

**Given** the user has no open surveys for the same schema, has not completed the survey within the individual window, and has not exceeded the global completion window limit
**When** `userEligibleFromSurveyHistory()` is evaluated
**Then** the user passes eligibility and a `PreprocessedSurvey` is enqueued

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003-AC-00002 — User has open survey for same schema**
**Path:** failed

**Given** the user already has a `PreprocessedSurvey` for the same `survey_id` in state NOT_COMPLETED, NOT_READY, or DISMISSED with TTL active
**When** `userEligibleFromSurveyHistory()` checks gate 1
**Then** the system blocks survey creation for this trigger
**And** the system displays the message: *"NPS survey not triggered — user already has an active survey for this schema"*

**AC-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003-AC-00003 — User exceeds global completion window**
**Path:** failed

**Given** the user has completed `max-response-in-window` or more surveys across all schemas within the last `response-window-mins` minutes (default: 2 completions in 7 minutes)
**When** `userEligibleFromSurveyHistory()` checks gate 3
**Then** the system blocks survey creation
**And** the system displays the message: *"NPS survey not triggered — user has recently completed the maximum number of surveys"*

---

### Delivery & Personalization (SUBCAP-CXAN-NPSS-DLVR)

**Applicable personas**: user
**Applicable channels**: API, Mobile (consumed via API), Web (consumed via API)
**Problem**: Personalise and deliver the NPS survey to sampled users via push notification (mobile) or in-app polling (web/mobile).

**Success metrics**:
- Push notification delivery success rate: TBD
- Survey delivery latency P95: < 30 s from eligibility trigger
- Cache hit rate on `pps-user:<userId>`: TBD

**Config parameters**:
- `survey.not-ready-survey-ttl-mins` — TTL in minutes for a `PreprocessedSurvey` in NOT_READY state before preprocessing completes (default 180 — 3 hours)
- `survey.preprocessed-survey-ttl-mins` — TTL in minutes for a fully preprocessed survey once in NOT_COMPLETED state (default 10,080 — 7 days)
- `survey.preprocessed-survey-cache-by-user-ttl-mins` — Redis cache TTL for `pps-user:<userId>` (default 10,080 — 7 days)
- `survey.preprocessed-survey-cache-by-id-mins` — Redis cache TTL for `pps-id:<surveyId>` (default 10,080 — 7 days)
- Push notification delivery channel: NOS (`integrations.nos.base-url`)
- Check-in eligibility endpoint: GET /api/surveys/dashboard-info

**design_refs**:
**engineering_refs**: `SurveyPreprocessorListener`, `SurveyPushNotificationListener`, `NOSClient` in `outbound/`
**deprecation_reason**:

#### Description

Once eligibility is confirmed and a `PreprocessedSurvey` is created in NOT_READY state, the `SurveyPreprocessorListener` Kafka consumer receives the `EventPreprocessSurveyDTO` and performs full personalisation: a `StringSubstitutor` replaces `${user.*}` and `${event.*}` tokens in the survey JSON template with actual user attribute values fetched from Bigtable (or cache). The state transitions to NOT_COMPLETED, a 7-day TTL is set, and the finalised survey is persisted to MySQL and written to Redis (`pps-id:<id>` and appended to `pps-user:<userId>`). For ANDROID and IOS platforms, a push notification request (`NotificationRequest`) is published to the `event-survey-push-notification` topic. `SurveyPushNotificationListener` consumes this and calls `NotificationOrchestrationService.sendPushNotification()`, which calls NOS `/v2/notification` via Feign. If the survey has `assignBanner=true`, the Banner Service is called instead of push notification. Web and polling-based clients discover the survey via `GET /api/surveys/user` (API-3) or `GET /api/surveys/dashboard-info` (API-1/API-2).

#### Competitive Context

(Not available from code analysis — PM to complete.)

#### EPIC-SUBCAP-CXAN-NPSS-DLVR-EP00001 — Survey Personalisation and Delivery

**Persona**: user
**Status**: active

##### Intent

**As a** user
**I want** to receive a personalised NPS survey at the right time on the right channel
**So that** I can share my sentiment about my experience with Moniepoint

The Epic has no events or AC of its own — those belong to stories. The last story in each Epic is the completion story.

---

##### STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001 — Preprocess and personalise the NPS survey for the user

**As a** user
**I want** the NPS survey content to include my account details and relevant context
**So that** the survey feels relevant to my actual experience

After rule evaluation passes, `SurveyPreprocessorListener` receives the partially created `PreprocessedSurvey` from the `event-survey-preprocessor` topic. It performs string substitution of all `${user.*}` and `${event.*}` tokens in the survey JSON template using the user's attributes from Bigtable. The survey is then saved in NOT_COMPLETED state with a 7-day TTL and written to the Redis cache, making it immediately available for client polling.

###### Fields

This story does not involve data entry — no field spec required.

**Source**: Views [n/a — API only] | APIs [AH-3]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001-AC-00001 — Survey personalised and saved successfully**
**Path:** success

**Given** a `PreprocessedSurvey` in NOT_READY state exists and user attributes are available from Bigtable or the event payload
**When** `SurveyPreprocessorListener.preprocessSurvey()` processes the message
**Then** all `${user.*}` and `${event.*}` tokens in the survey JSON are replaced with actual values
**And** `state` is set to `NOT_COMPLETED` and `ttl` is extended to `event.timestamp + preprocessed-survey-ttl-mins`
**And** the record is persisted to `preprocessed_survey` and written to Redis (`pps-id:<id>` and `pps-user:<userId>`)

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001-AC-00002 — Template has no substitution tokens**
**Path:** success

**Given** the survey JSON template contains no `${}` tokens
**When** `SurveyPreprocessorListener.preprocessSurvey()` processes the message
**Then** the survey JSON is stored as-is without substitution
**And** the state transitions to NOT_COMPLETED with the full TTL

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001-AC-00003 — Database write failure during preprocessing**
**Path:** error (retryable)

**Given** MySQL is temporarily unavailable when `SurveyPreprocessorListener` attempts to persist the `PreprocessedSurvey`
**When** the save operation fails
**Then** the system displays the message: *"Survey personalisation could not be saved — will be retried on next event delivery"*
**And** the user may retry — no retry limit applies (Kafka at-least-once delivery redelivers the message)
**And** the NOT_READY survey row that was created during rule evaluation remains in DB and will expire after `not-ready-survey-ttl-mins` if preprocessing never completes

---

##### STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002 — Deliver NPS survey via push notification to mobile users

**As a** user
**I want** to receive a push notification on my mobile device when an NPS survey is ready for me
**So that** I am prompted at the right moment to share my feedback

After preprocessing completes and the platform is ANDROID or IOS, a `NotificationRequest` is published to the `event-survey-push-notification` Kafka topic. `SurveyPushNotificationListener` consumes this and calls `NotificationOrchestrationService.sendPushNotification()`, which calls NOS via the Feign `NOSClient`. The NOS call uses event name `RENDER_ANALYTICS_SURVEY` and maps the app domain (`CONSUMER` → `PERSONAL`) to the `banking-domain` header. There is no circuit breaker or retry — if NOS fails, the push notification is silently dropped.

###### Fields

This story does not involve data entry — no field spec required.

**Source**: Views [n/a — API only] | APIs [AH-3, AH-4]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002-AC-00001 — Push notification sent successfully**
**Path:** success

**Given** the preprocessed survey has platform = ANDROID or IOS AND NOS is reachable
**When** `SurveyPushNotificationListener` calls `NotificationOrchestrationService.sendPushNotification()`
**Then** NOS returns a success response
**And** the push notification with event name `RENDER_ANALYTICS_SURVEY` is dispatched to the user's device

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002-AC-00002 — Platform is not mobile — push notification skipped**
**Path:** failed

**Given** the preprocessed survey platform is WEB or POS (not ANDROID or IOS)
**When** `SurveyPreprocessorListener` evaluates whether to enqueue a push notification
**Then** no push notification is enqueued — clients discover the survey via the polling API
**And** the system displays the message: *"Push notification skipped — non-mobile platform; survey available via polling endpoint"*

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002-AC-00003 — NOS unavailable — push notification silently dropped**
**Path:** error (non-retryable)

**Given** NOS is unavailable or returns an error response
**When** `SurveyPushNotificationListener` calls NOS
**Then** the exception is logged and `false` is returned
**And** the system displays the message: *"Survey push notification could not be delivered — NOS error; survey remains available via polling"*
**And** the user cannot retry (no retry or dead-letter mechanism for push notification; the survey remains accessible via `GET /api/surveys/user`)
**And** the `PreprocessedSurvey` record in DB is not affected — survey remains in NOT_COMPLETED state

---

##### STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 — Client retrieves active NPS survey via check-in endpoint

**As a** user
**I want** my app to discover my active NPS survey when I open it or navigate to the dashboard
**So that** the survey is surfaced in the app without requiring a manual refresh

Clients call `GET /api/surveys/dashboard-info` (API-1) on app open or screen navigation. This is the shared check-in pre-commitment endpoint per CLAUDE.md: "NPS and CSAT eligibility must be resolved in a single check-in pass — no separate server call." The endpoint returns `SurveyAlert` records (for surveys in alert display mode) with fields for rendering the alert UI. The Redis cache key `survey-alert:<userId>:<agentId>` is checked first (12-hour TTL). Only alerts with `ttl > now` AND `alertStartTime <= now` are returned.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `userId` | String | Yes | Resolved from JWT `@AuthenticationPrincipal`; must be non-blank |
| `moniepointAgentId` | String | Yes | Request header; used to scope `survey_alert` lookup |

**Source**: Views [n/a — API only] | APIs [API-1, API-2]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003-AC-00001 — Active NPS alerts returned**
**Path:** success

**Given** the user has one or more `survey_alert` rows with `ttl > now` AND `alertStartTime <= now`
**When** `GET /api/surveys/dashboard-info` is called with a valid JWT and `moniepointAgentId` header
**Then** the response contains the `SurveyAlertsResponse` with the matching alerts
**And** each alert includes `type`, `icon`, `priority`, `title`, `message`, `action.target` (`/survey/<surveyId>`), and `isDismissible`

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003-AC-00002 — No active alerts — empty list returned**
**Path:** success

**Given** the user has no active survey alerts (all expired or not yet started)
**When** `GET /api/surveys/dashboard-info` is called
**Then** the response contains an empty `alerts` list
**And** HTTP 200 is returned

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003-AC-00003 — Missing userId in JWT**
**Path:** failed

**Given** the JWT does not contain a valid userId claim or the `userId` is blank
**When** `GET /api/surveys/dashboard-info` is called
**Then** the system returns HTTP 400 with the message: *"userId cannot be null or empty"*

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003-AC-00004 — Database unavailable — cache miss path fails**
**Path:** error (retryable)

**Given** the Redis cache has no entry for `survey-alert:<userId>:<agentId>` AND MySQL is unavailable
**When** `GET /api/surveys/dashboard-info` is called
**Then** the system returns HTTP 500 with the message: *"Survey alerts could not be retrieved — please try again"*
**And** the user may retry — no retry limit applies
**And** no survey alert data is modified

---

##### STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004 — Client retrieves active NPS survey list

**As a** user
**I want** my app to show me all active NPS surveys available for me
**So that** I can respond to any pending surveys at my convenience

Clients call `GET /api/surveys/user` (API-3) to retrieve all `PreprocessedSurvey` records in NOT_COMPLETED or DISMISSED state with `ttl > now`. The Redis cache `pps-user:<userId>` (7-day TTL) is checked first. On cache miss, the DB is queried and the result is cached. The `displayModalType` field is enriched from the nested `SurveyBody` JSON on read. Per CLAUDE.md payload constraint: every survey response payload must be < 1 KB.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `userId` | String | Yes | Resolved from JWT; must be non-blank |

**Source**: Views [n/a — API only] | APIs [API-3]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004-AC-00001 — Active surveys returned**
**Path:** success

**Given** the user has one or more `PreprocessedSurvey` rows in NOT_COMPLETED or DISMISSED state with `ttl > now`
**When** `GET /api/surveys/user` is called with a valid JWT
**Then** the response is a list of `PreprocessedSurveyDTO` objects, each with `id`, `surveyId`, `survey` (personalised JSON), `ttl`, `priority`, `location`, `displayModalType`
**And** the total response payload for all surveys is < 1 KB per CLAUDE.md constraint

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004-AC-00002 — No active surveys**
**Path:** success

**Given** the user has no active surveys
**When** `GET /api/surveys/user` is called
**Then** the response is an empty list with HTTP 200

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004-AC-00003 — Username missing in authentication token**
**Path:** failed

**Given** the JWT does not contain a valid username
**When** `GET /api/surveys/user` is called
**Then** the system returns HTTP 400 with the message: *"Username is required in authentication token"*

**AC-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004-AC-00004 — Database unavailable on cache miss**
**Path:** error (retryable)

**Given** the Redis cache has no entry for `pps-user:<userId>` AND MySQL is unavailable
**When** `GET /api/surveys/user` is called
**Then** the system returns HTTP 500 with the message: *"Survey list could not be retrieved — please try again"*
**And** the user may retry — no retry limit applies
**And** no user data is modified

---

### Completion & Classification (SUBCAP-CXAN-NPSS-CMPL)

**Applicable personas**: user
**Applicable channels**: API
**Problem**: Record the user's NPS response event and update the survey state (COMPLETED, DISMISSED, or ABANDONED).

**Success metrics**:
- Response classification accuracy: 100% correct Promoter / Passive / Detractor based on score range
- Survey state accuracy: 0% surveys stuck in intermediate state after outcome event

**Config parameters**:
- `survey.response-window-mins` — global completion window for eligibility checks
- `survey.preprocessed-survey-cache-by-user-ttl-mins` — cache TTL invalidated on completion

**design_refs**:
**engineering_refs**: `CompletedSurveyListener`, `SurveyEventCompletionService` in `module/analytics/service/impl/`
**deprecation_reason**:

#### Description

When a user submits their NPS response (or dismisses or abandons the survey), the mobile or web client emits an analytics event with `eventName` = `SURVEY_COMPLETED`, `SURVEY_DISMISSED`, or `SURVEY_ABANDONED`. This event flows through `AnalyticsServiceImpl.pushResizedEvents()` which publishes it to the `event-completed-survey` Kafka topic. `CompletedSurveyListener` delegates to `SurveyEventCompletionService.processCompletedSurveyEvent()`, which resolves the matching `PreprocessedSurvey` by `(userId, surveyId)` and transitions its state. For COMPLETED surveys, the banner is unassigned (if `assignBanner=true`), `survey_alert` rows are deleted, and the survey is removed from both Redis caches.

#### Competitive Context

(Not available from code analysis — PM to complete.)

#### EPIC-SUBCAP-CXAN-NPSS-CMPL-EP00001 — Survey Response Recording and State Management

**Persona**: user
**Status**: active

##### Intent

**As a** user
**I want** my NPS response to be recorded accurately and my survey state updated immediately
**So that** I am not shown the same survey again once I have completed it

The Epic has no events or AC of its own — those belong to stories. The last story in each Epic is the completion story.

---

##### STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001 — Retrieve individual NPS survey for response

**As a** user
**I want** to open my assigned NPS survey by its identifier
**So that** I can view the full personalised survey content before responding

Clients call `GET /api/surveys/{id}` (API-4) to fetch a single `PreprocessedSurvey` by its id. The service checks Redis `pps-id:<id>` first (7-day TTL). It verifies ownership (the `user` field must match the JWT userId, case-insensitive) and only returns surveys in NOT_COMPLETED or DISMISSED state with TTL active. A 404 is returned if the survey is expired, completed, or belongs to another user.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `id` | Long | Yes | Path variable; `preprocessed_survey.id` |
| `userId` | String | Yes | From JWT; ownership verified against `preprocessed_survey.user` |

**Source**: Views [n/a — API only] | APIs [API-4]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001-AC-00001 — Survey fetched successfully**
**Path:** success

**Given** a `PreprocessedSurvey` exists with the given `id`, in state NOT_COMPLETED or DISMISSED, with `ttl > now`, AND the JWT userId matches `preprocessed_survey.user` (case-insensitive)
**When** `GET /api/surveys/{id}` is called
**Then** the response contains the full `PreprocessedSurveyDTO` with `id`, `surveyId`, personalised `survey` JSON, `ttl`, `priority`, `location`, `displayModalType`

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001-AC-00002 — Survey not found or TTL expired**
**Path:** failed

**Given** no matching `PreprocessedSurvey` exists for the given `id` in an active state, OR the TTL has elapsed
**When** `GET /api/surveys/{id}` is called
**Then** the system returns HTTP 404
**And** the system displays the message: *"Survey not found or has expired"*

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001-AC-00003 — userId mismatch — ownership check fails**
**Path:** failed

**Given** the `PreprocessedSurvey` exists but `preprocessed_survey.user` does not match the JWT userId
**When** `GET /api/surveys/{id}` is called
**Then** the system returns HTTP 404 (ownership failure does not reveal existence)
**And** the system displays the message: *"Survey not found or has expired"*

---

##### STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002 — Retrieve NPS survey schema for voluntary response

**As a** user
**I want** to open a survey directly from a link or menu without a pre-assigned survey record
**So that** I can voluntarily provide NPS feedback outside of the triggered delivery flow

Clients call `GET /api/surveys/schema/{surveyId}` (API-6) to fetch the survey template. If a personalised `PreprocessedSurvey` already exists for the user+surveyId, that is returned. Otherwise, the raw `survey.survey` JSON template from the `survey` table is returned. If the template contains `${}` tokens and user attributes are provided as query parameters, `StringSubstitutor` performs substitution. Bigtable is called for user attributes if needed; if unavailable, the request attributes are used instead.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `surveyId` | Long | Yes | Path variable; FK to `survey.id` |
| User attributes | Various (query params) | No | Optional context for template substitution |

**Source**: Views [n/a — API only] | APIs [API-6]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002-AC-00001 — Personalised survey returned when pre-committed record exists**
**Path:** success

**Given** a `PreprocessedSurvey` exists for the user+surveyId in NOT_COMPLETED or DISMISSED state with TTL active
**When** `GET /api/surveys/schema/{surveyId}` is called
**Then** the response contains the personalised survey JSON with `preprocessedSurveyId` referencing the existing record

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002-AC-00002 — Raw template with substitution returned when no pre-committed record**
**Path:** success

**Given** no personalised `PreprocessedSurvey` exists AND user attributes are provided AND the template contains `${}` tokens
**When** `GET /api/surveys/schema/{surveyId}` is called
**Then** the response contains the survey JSON with substituted user attribute values and `preprocessedSurveyId` = null

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002-AC-00003 — No survey schema found**
**Path:** failed

**Given** no matching `survey` row exists for the given `surveyId`
**When** `GET /api/surveys/schema/{surveyId}` is called
**Then** the system returns HTTP 404
**And** the system displays the message: *"Survey schema not found"*

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002-AC-00004 — Bigtable unavailable — fallback to request attributes**
**Path:** error (retryable)

**Given** Bigtable is unavailable when user attributes are needed for template substitution
**When** `GET /api/surveys/schema/{surveyId}` is called with user attributes in the query
**Then** the system falls back to the request-provided attributes for substitution and returns the schema with HTTP 200
**And** the system displays the message: *"User attributes could not be verified — survey displayed with provided context"*
**And** the user may retry — no retry limit applies
**And** no user data is modified

---

##### STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003 — Submit NPS response and record completion

**As a** user
**I want** to submit my NPS score (and optional qualitative response)
**So that** my feedback is recorded and the survey is closed

When the user submits their NPS response in the client app, the client emits a `SURVEY_COMPLETED` analytics event with `meta.surveyId` and the numeric score. This event is published to the `event-completed-survey` Kafka topic. `CompletedSurveyListener` resolves the `PreprocessedSurvey` by `(userId, surveyId)` and calls `SurveyEventCompletionService.processCompletedSurveyEvent()`. The state transitions to COMPLETED, `completedOn` is set to the event timestamp, the survey is removed from Redis caches, the banner is unassigned if applicable, and `survey_alert` rows are deleted if present.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `meta.surveyId` | String | Yes | ID of the `PreprocessedSurvey` to complete; from analytics event payload |
| `meta.surveySchemaId` | String | Conditional | Required on voluntary survey path when `surveyId` is absent |

**Source**: Views [n/a — API only] | APIs [AH-5]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003-AC-00001 — NPS response recorded successfully**
**Path:** success

**Given** the `PreprocessedSurvey` exists in NOT_COMPLETED or DISMISSED state AND the `SURVEY_COMPLETED` event carries `meta.surveyId`
**When** `CompletedSurveyListener` processes the event
**Then** `state` transitions to COMPLETED, `completedOn` is set to the event timestamp
**And** the survey is removed from `pps-id:<id>` and `pps-user:<userId>` Redis caches
**And** if `assignBanner=true` the banner is unassigned via Banner Service

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003-AC-00002 — No matching survey found for completion event**
**Path:** failed

**Given** no `PreprocessedSurvey` exists for `(userId, surveyId)` in a resolvable state
**When** `CompletedSurveyListener` processes the SURVEY_COMPLETED event
**Then** a placeholder survey is created to clear any stale cache entries and the handler exits without error
**And** the system displays the message: *"No active survey found to complete — cache cleared"*

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003-AC-00003 — Kafka redelivery — survey already COMPLETED**
**Path:** success

**Given** the `PreprocessedSurvey` is already in COMPLETED state (Kafka at-least-once redelivery)
**When** `CompletedSurveyListener` processes the duplicate SURVEY_COMPLETED event
**Then** `resolveRegularSurvey()` returns null (only resolves NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED states)
**And** the completion is silently skipped (idempotent exit)

---

##### STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004 — Handle survey dismissal and optional alert re-promotion

**As a** user
**I want** to dismiss an NPS survey without completing it
**So that** I can respond later if the survey supports re-delivery

When the user dismisses the survey without responding, the client emits a `SURVEY_DISMISSED` analytics event. `SurveyEventCompletionService` transitions the state to DISMISSED without clearing the Redis cache (dismissed surveys remain available for re-delivery). If `enableAlertingAfterDismissal=true`, the SpEL `alertingCondition` is evaluated; if it passes, the survey is promoted to alert mode with `displayModalType = alert`, a delayed start time is set, and a `survey_alert` row is created for the next check-in cycle.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `meta.surveyId` | String | Yes | ID of the `PreprocessedSurvey` to dismiss |

**Source**: Views [n/a — API only] | APIs [AH-5]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004-AC-00001 — Survey dismissed without alert promotion**
**Path:** success

**Given** the user dismisses the survey AND `enableAlertingAfterDismissal=false`
**When** `CompletedSurveyListener` processes the SURVEY_DISMISSED event
**Then** `state` transitions to DISMISSED and the survey remains in the Redis cache
**And** `completedOn` is NOT set (DISMISSED is not a terminal completion)
**And** no `survey_alert` row is created

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004-AC-00002 — Survey dismissed and promoted to alert**
**Path:** success

**Given** `enableAlertingAfterDismissal=true` AND the SpEL `alertingCondition` evaluates to true for the user
**When** `CompletedSurveyListener` processes the SURVEY_DISMISSED event
**Then** `displayModalType` changes to `alert`, `alertStartTime` is set to `now + displayDelayPeriodInSecs`
**And** a `survey_alert` row is created and the survey is updated in the Redis cache

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004-AC-00003 — Alerting condition fails — no alert created**
**Path:** failed

**Given** `enableAlertingAfterDismissal=true` BUT the SpEL `alertingCondition` evaluates to false
**When** dismissal side-effects are processed
**Then** the state transitions to DISMISSED only; no `survey_alert` row is created
**And** the system displays the message: *"NPS dismissal recorded — alerting condition not met; survey will not re-promote"*

---

##### STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005 — Review NPS survey history for a user and schema

**As a** user
**I want** to view the history of my NPS survey interactions for a given survey schema and date range
**So that** I can see when I was triggered, when I responded, and the current state of each interaction

Clients or analytics tools call `GET /api/surveys/{surveyId}/history` (API-5) to retrieve all `PreprocessedSurvey` rows for a user+survey schema filtered by `lastModifiedOn` within a date range. All states are included (COMPLETED, EXPIRED, ABANDONED, DISMISSED, NOT_COMPLETED). No Redis cache is used — the query goes directly to DB each time.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `surveyId` | Long | Yes | Path variable; FK to `survey.id` |
| `startDate` | LocalDate | Yes | ISO format `yyyy-MM-dd` |
| `endDate` | LocalDate | Yes | ISO format `yyyy-MM-dd`; range is inclusive to 23:59:59 |

**Source**: Views [n/a — API only] | APIs [API-5]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005-AC-00001 — History records returned**
**Path:** success

**Given** `PreprocessedSurvey` rows exist for the user+surveyId with `lastModifiedOn` within the specified date range
**When** `GET /api/surveys/{surveyId}/history` is called with valid `startDate` and `endDate`
**Then** the response contains `SurveyHistoryResponse` with a list of `SurveyHistoryItemDTO`, each with `id`, `event`, `ttl`, `state`, `completedOn`, `additionalData`

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005-AC-00002 — No history in date range**
**Path:** success

**Given** no `PreprocessedSurvey` rows match the criteria
**When** `GET /api/surveys/{surveyId}/history` is called
**Then** the response contains an empty `surveys` list with HTTP 200

**AC-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005-AC-00003 — Invalid date format**
**Path:** failed

**Given** `startDate` or `endDate` is provided in a non-ISO format
**When** `GET /api/surveys/{surveyId}/history` is called
**Then** the system returns HTTP 400 with the message: *"Invalid date format — expected yyyy-MM-dd"*

---

### Admin Management (SUBCAP-CXAN-NPSS-ADMN)

**Applicable personas**: admin
**Applicable channels**: API
**Problem**: Allow operators to configure and update NPS survey definitions — including the SpEL rule expression, survey content, and render location — without a deployment.

**Success metrics**:
- Survey rule activation latency (create/update → rule available in evaluator): ≤ `rules-cache-ttl-mins` (default 24 hours; immediate after cache invalidation)
- Admin API error rate: < 1%
- Cache invalidation success rate on create/update: 100%

**Config parameters**:
- `survey.rules-cache-ttl-mins` — Redis cache TTL; invalidated immediately on create/update
- Internal admin endpoint path: `/internal/admin/surveys` (network-policy secured; no JWT required — temporary arrangement)

**design_refs**:
**engineering_refs**: `AdminSurveyController`, `SurveyService`, `SurveyStorage` in `module/analytics/`
**deprecation_reason**:

#### Description

NPS survey definitions are created and updated via the admin API at `/internal/admin/surveys`. The `POST` endpoint creates a new `Survey` entity; the `PUT` endpoint performs a partial update where null/blank fields are preserved from the existing record. Both operations strip BOM characters and zero-width spaces from the survey JSON payload before serialisation (a known data quality issue with some admin tools). After every write, the `cas-survey-rules` Redis cache is invalidated so that `SurveyEvaluatorListener` picks up the new definition on its next evaluation cycle (subject to up to 24-hour lag if the cache is not expired). The admin endpoints are currently unauthenticated — listed in `SecurityPropertiesConfig.PUBLIC_URIS` with a code comment noting this is temporary pending network-policy enforcement [AMBIGUOUS: network policy not yet applied].

#### Competitive Context

(Not available from code analysis — PM to complete.)

#### EPIC-SUBCAP-CXAN-NPSS-ADMN-EP00001 — NPS Survey Definition Management

**Persona**: admin
**Status**: active

##### Intent

**As an** admin
**I want** to create and update NPS survey definitions including their targeting rules and content
**So that** I can control which users receive the NPS survey and what content they see without a code deployment

The Epic has no events or AC of its own — those belong to stories. The last story in each Epic is the completion story.

---

##### STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001 — Create a new NPS survey definition

**As an** admin
**I want** to create a new NPS survey with a targeting rule, content payload, and render location
**So that** the survey is immediately available for evaluation against incoming analytics events

An operator calls `POST /internal/admin/surveys` with a `SurveyCreateRequest` containing the SpEL rule expression, survey JSON content (as a `Map<String, Object>`), priority, web location identifier, and mobile location identifier. The service serialises the survey to JSON, strips any BOM or zero-width characters, saves the `Survey` entity, and invalidates the `cas-survey-rules` Redis cache so the evaluator picks up the new rule within the current cache window.

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `rule` | String | Yes | `@NotBlank`; SpEL expression evaluated against `RulesContext(event, user)` |
| `priority` | Integer | Yes | `@NotNull`; lower value = higher priority; default 10 |
| `survey` | Map<String, Object> | Yes | `@NotNull`; raw survey JSON structure; serialised as `SurveyBody` |
| `locationWeb` | String | Yes | `@NotBlank`; web render location identifier |
| `locationMobile` | String | Yes | `@NotBlank`; mobile render location identifier |

**Source**: Views [n/a — API only] | APIs [API-7]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001-AC-00001 — Survey created successfully**
**Path:** success

**Given** a valid `SurveyCreateRequest` with non-blank `rule`, `locationWeb`, `locationMobile`, and non-null `survey` and `priority`
**When** `POST /internal/admin/surveys` is called
**Then** a new `Survey` row is persisted with the provided fields; BOM and zero-width characters stripped from the survey JSON
**And** the `cas-survey-rules` Redis cache is invalidated
**And** the response body contains the new `survey.id` as a Long

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001-AC-00002 — Required field missing**
**Path:** failed

**Given** the `SurveyCreateRequest` has a blank `rule` or blank `locationWeb` or blank `locationMobile` or null `survey` or null `priority`
**When** `POST /internal/admin/surveys` is called
**Then** the system returns HTTP 400 with the message: *"rule can't be empty."* or *"priority can't be null."* or *"locationWeb can't be empty."* or *"locationMobile can't be empty."* as appropriate
**And** no survey is persisted

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001-AC-00003 — Invalid JSON in survey payload**
**Path:** failed

**Given** the `survey` map contains a value that cannot be serialised to valid JSON by Jackson
**When** `POST /internal/admin/surveys` is called
**Then** the system returns HTTP 400 with the message: *"Failed to serialize survey payload"*
**And** no survey is persisted

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001-AC-00004 — Database write failure**
**Path:** error (retryable)

**Given** MySQL is temporarily unavailable when the survey is being persisted
**When** `POST /internal/admin/surveys` is called
**Then** the system returns HTTP 500 with the message: *"Survey could not be saved — please try again"*
**And** the user may retry — no retry limit applies
**And** no partial data is committed; the Redis cache is not invalidated

---

##### STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002 — Update an existing NPS survey definition

**As an** admin
**I want** to update the rule, content, priority, or location of an existing NPS survey definition
**So that** I can adjust targeting or content without creating a duplicate survey record

An operator calls `PUT /internal/admin/surveys` with a `SurveyCreateRequest` that includes a valid `id` (> 0). The service performs a partial update — only non-null/non-blank fields in the request overwrite existing values. Null `survey`, blank `rule`, blank location fields, and null `priority` are treated as no-ops. After update, the `cas-survey-rules` cache is invalidated. [AMBIGUOUS: if the `id` does not match any existing survey, the update is silently accepted with HTTP 202 but no row is modified — this may be a bug.]

###### Fields

| Label | Type | Required | Constraints |
|---|---|---|---|
| `id` | Long | Yes | Must be > 0; identifies the `Survey` row to update |
| `rule` | String | No | If non-blank, overwrites existing `rule` |
| `priority` | Integer | No | If non-null, overwrites existing `priority` |
| `survey` | Map<String, Object> | No | If non-null, overwrites existing `survey` JSON |
| `locationWeb` | String | No | If non-blank, overwrites existing `locationWeb` |
| `locationMobile` | String | No | If non-blank, overwrites existing `locationMobile` |

**Source**: Views [n/a — API only] | APIs [API-8]

###### Acceptance Criteria

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002-AC-00001 — Survey updated successfully**
**Path:** success

**Given** a valid `SurveyCreateRequest` with `id > 0` matching an existing `Survey` row
**When** `PUT /internal/admin/surveys` is called
**Then** all non-null/non-blank fields in the request overwrite the corresponding columns on the `Survey` entity
**And** the `cas-survey-rules` Redis cache is invalidated
**And** HTTP 202 is returned

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002-AC-00002 — Missing or invalid id**
**Path:** failed

**Given** the `SurveyCreateRequest` has a null `id` or `id <= 0`
**When** `PUT /internal/admin/surveys` is called
**Then** the system returns HTTP 400 with no body
**And** the system displays the message: *"Survey id is required and must be greater than zero"*

**AC-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002-AC-00003 — [AMBIGUOUS] Update with non-existent id silently accepted**
**Path:** error (non-retryable)

**Given** the `id` in the request does not match any existing `Survey` row [AMBIGUOUS: current behaviour]
**When** `PUT /internal/admin/surveys` is called
**Then** the system returns HTTP 202 with no update applied — [AMBIGUOUS: this is likely a bug; expected behaviour is HTTP 404]
**And** the system displays the message: *"Survey update accepted — no matching survey found"*
**And** the user cannot retry (the response implies success; no error is surfaced)

---

### Reporting & Intelligence (SUBCAP-CXAN-NPSS-RPTG)

> **Out of scope for this service.** NPS score computation, weekly aggregation, and reporting are owned by the data team.

---

## User Journeys

### JOURNEY-CXAN-NPSS-HPTH — NPS Happy Path: User Receives and Completes Survey

**Persona**: user

**Entry stories**:
- STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001 — Receive and filter analytics event for NPS eligibility

**Exit stories**:
- STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003 — Submit NPS response and record completion

**Success criteria**:
- Survey delivery latency (trigger → push notification) P95: < 30 s
- Completion rate: TBD
- CSAT: TBD / 5

**Purpose**: Covers the end-to-end flow from the analytics event trigger through eligibility evaluation, survey personalisation, push notification delivery, client retrieval of the survey, and final submission of the NPS response, resulting in a COMPLETED survey record.

---

### JOURNEY-CXAN-NPSS-DSMJ — NPS Dismissal and Re-Promotion Journey

**Persona**: user

**Entry stories**:
- STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 — Client retrieves active NPS survey via check-in endpoint

**Exit stories**:
- STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004 — Handle survey dismissal and optional alert re-promotion

**Success criteria**:
- Alert re-promotion accuracy: 100% of dismissed surveys with `enableAlertingAfterDismissal=true` and passing alerting condition create a `survey_alert`
- CSAT: TBD / 5

**Purpose**: Covers the path where a user dismisses an NPS survey. If the survey has alerting-after-dismissal enabled, the journey continues with the survey being re-promoted as an alert on the next check-in cycle.

---

### JOURNEY-CXAN-NPSS-ADST — Admin Survey Setup Journey

**Persona**: admin

**Entry stories**:
- STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001 — Create a new NPS survey definition

**Exit stories**:
- STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002 — Update an existing NPS survey definition

**Success criteria**:
- Rule activation latency after create/update: ≤ `rules-cache-ttl-mins` (default 24 hours)
- Admin API success rate: > 99%

**Purpose**: Covers the admin operator workflow of creating a new NPS survey definition and subsequently updating it to adjust the SpEL rule, content, or priority — without a code deployment.

---

## Market Configuration Table

| Parameter | NG Value | Notes |
|---|---|---|
| Survey TTL — NOT_COMPLETED (default) | 10,080 minutes (7 days) | Config: `survey.preprocessed-survey-ttl-mins` |
| Survey TTL — NOT_READY (before preprocessing) | 180 minutes (3 hours) | Config: `survey.not-ready-survey-ttl-mins` |
| Survey rules cache TTL | 1,440 minutes (24 hours) | Config: `survey.rules-cache-ttl-mins`; invalidated immediately on admin create/update |
| Survey history response window | 7 minutes | Config: `survey.response-window-mins`; max 2 completions across all surveys |
| Push notification delivery channel | NOS (`/v2/notification`) | `NotificationOrchestrationService`; event name `RENDER_ANALYTICS_SURVEY` |
| Check-in eligibility endpoint | GET /api/surveys/dashboard-info | Shared NPS + CSAT check-in; API-1 (JWT) and API-2 (query params) |
| Admin survey endpoint path | /internal/admin/surveys | POST (create) and PUT (update); unauthenticated — network policy pending [AMBIGUOUS] |
| Survey alert cache TTL | 720 minutes (12 hours) | Config: `survey.survey-alert-cache-ttl-mins` |
| Expiry job batch size | 100 rows per execution | Config: `survey.expiry-fetch-limit` |
| Per-survey individual window | 30 minutes / max 1 completion | Configs: `survey.response-window-mins-individual-survey`, `survey.max-response-in-window-individual-survey` |

---

## Flags

### [GAP] Items

| ID | Location | Description |
|---|---|---|
| GAP-007 | DLVR | No circuit breaker, retry, or dead-letter mechanism for NOS push notification calls. A NOS timeout or outage silently drops the push notification — the survey remains accessible via polling but the user is not notified. |
| GAP-008 | DLVR | No idempotency mechanism for the Kafka preprocessing pipeline. Duplicate delivery of `event-survey-preprocessor` messages can create duplicate `PreprocessedSurvey` rows (guard is only partially in place via `userEligibleFromSurveyHistory()`). |
| GAP-009 | CMPL | Direct Kafka publish (no outbox pattern). If Kafka publish fails after DB save of `PreprocessedSurvey` in NOT_READY state, the preprocessing event is permanently lost. |

### [AMBIGUOUS] Items

| ID | Location | Description |
|---|---|---|
| AMB-001 | ADMN | `category`, `start`, and `duration_days` fields on the `Survey` entity are NOT set by `SurveyService.createSurvey()` — they are null unless set via a different path or direct DB manipulation. |
| AMB-002 | ADMN | `PUT /internal/admin/surveys` silently returns HTTP 202 when the `id` does not match any existing survey. This may be a bug — expected behaviour is HTTP 404. |
| AMB-003 | ADMN | `/internal/admin/**` is in `SecurityPropertiesConfig.PUBLIC_URIS` (no auth required). A code comment marks this as "temporary pending network-policy enforcement" but no completion date is referenced. |
| AMB-004 | DLVR | `survey.preprocessed-survey-expiry-frequency` (Quartz cron expression) is sourced from the external config server. The actual cron value is not in the local application.yml. |
| AMB-005 | DLVR | `survey.image-location-url` is a required config property for BRM image URL construction but is not in the local application.yml — sourced from config server. |

---

## Technical Appendix

### View-to-Story Mapping

| View ID | View Name | Story IDs |
|---|---|---|
| n/a | No frontend views available in this extraction | All stories — FE code lives in separate mobile/web repos |

### API-to-Story Mapping

| API / Async Handler ID | Endpoint / Handler | Story IDs |
|---|---|---|
| API-1 | GET /api/surveys/dashboard-info (JWT variant) | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 |
| API-2 | GET /api/surveys/dashboard-info (query param variant) | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00003 |
| API-3 | GET /api/surveys/user | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00004 |
| API-4 | GET /api/surveys/{id} | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00001 |
| API-5 | GET /api/surveys/{surveyId}/history | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00005 |
| API-6 | GET /api/surveys/schema/{surveyId} | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00002 |
| API-7 | POST /internal/admin/surveys | STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00001 |
| API-8 | PUT /internal/admin/surveys | STORY-SUBCAP-CXAN-NPSS-ADMN-EP00001-00002 |
| AH-1 | SurveyEventListener (verified-analytics-event) | STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001 |
| AH-2 | SurveyEvaluatorListener (event-validated-survey) | STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00002, STORY-SUBCAP-CXAN-NPSS-ELGB-EP00001-00003 |
| AH-3 | SurveyPreprocessorListener (event-survey-preprocessor) | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00001, STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002 |
| AH-4 | SurveyPushNotificationListener (event-survey-push-notification) | STORY-SUBCAP-CXAN-NPSS-DLVR-EP00001-00002 |
| AH-5 | CompletedSurveyListener (event-completed-survey) | STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00003, STORY-SUBCAP-CXAN-NPSS-CMPL-EP00001-00004 |
| AH-6 | PreprocessedSurveyExpirationTriggerJob (Quartz) | No user-facing story — system-internal expiry job; documented in BE analysis only |
