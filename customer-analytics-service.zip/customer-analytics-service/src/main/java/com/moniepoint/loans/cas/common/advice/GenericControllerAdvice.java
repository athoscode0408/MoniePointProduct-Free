package com.moniepoint.loans.cas.common.advice;

import com.moniepoint.loans.cas.common.advice.models.ErrorResponse;
import com.moniepoint.loans.cas.common.exception.NotFoundException;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.ApplicationConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import java.time.ZoneId;
import java.time.ZonedDateTime;


@Slf4j
@RestControllerAdvice
public class GenericControllerAdvice {

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> handleBadRequestException(BadRequestException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        logException("handleBadRequestException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleHttpMessageNotReadableException(HttpMessageNotReadableException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        logException("handleHttpMessageNotReadableException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, ApplicationConstants.INVALID_DATE_ERROR_MESSAGE);
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        StringBuilder errorMessages = new StringBuilder();
        exception.getBindingResult().getAllErrors().forEach(error -> {
            String errorMessage = error.getDefaultMessage();
            errorMessages.append(errorMessage).append("; ");
        });
        logException("handleMethodArgumentNotValidException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, errorMessages.toString());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(HandlerMethodValidationException.class)
    public ResponseEntity<ErrorResponse> handleMethodArgumentNotValidException(HandlerMethodValidationException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        StringBuilder errorMessages = new StringBuilder();
        exception.getAllValidationResults().forEach(error -> {
            var idx = String.format("request[%d]: ", error.getContainerIndex());
            error.getResolvableErrors().forEach(e -> errorMessages.append(idx).append(e.getDefaultMessage()).append("; "));

        });
        logException("handleMethodArgumentNotValidException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, errorMessages.toString());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFoundException(NotFoundException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        logException("handleNotFoundException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(ServerException.class)
    public ResponseEntity<ErrorResponse> handleServerException(ServerException exception) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        logException("handleServerException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(AuthorizationDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAuthorizationDeniedException(AuthorizationDeniedException exception) {
        HttpStatus httpStatus = HttpStatus.FORBIDDEN;
        logException("handleAuthorizationDeniedException", exception);
        ErrorResponse errorResponse = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorResponse, httpStatus);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleTypeMismatch(MethodArgumentTypeMismatchException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorBody, httpStatus);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnknownException(Exception exception) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        logException("handleUnknownException", exception);
        ErrorResponse errorBody = ErrorResponse.build(httpStatus, exception.getMessage());
        return writeErrorResponse(errorBody, httpStatus);
    }

    private ResponseEntity<ErrorResponse> writeErrorResponse(ErrorResponse errorObject, HttpStatus httpStatus) {
        return new ResponseEntity<>(errorObject, httpStatus);
    }

    private static void logException(String handler, Exception e) {
        log.error("Exception occurred in handler: '{}' -- errorMessage: '{}' -- errorTime: '{}' -- exceptionClass: '{}'",
                handler, e.getMessage(), ZonedDateTime.now(ZoneId.systemDefault()), e.getClass().getSimpleName(),
                e
        );
    }
}
