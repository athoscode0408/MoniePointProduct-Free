package com.moniepoint.loans.cas.common.audit;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Optional;

import static com.moniepoint.loans.cas.common.util.ApplicationConstants.CUSTOMER_ANALYTICS_USER;

/**
 * Used from {@link org.springframework.data.jpa.domain.support.AuditingEntityListener}
 * from entities which extend from {@link com.moniepoint.loans.cas.common.entity.BaseEntity} so that we could be able to refer to the person
 * which did the create/delete/update/etc. operation.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AuditorAwareImpl implements AuditorAware<String> {

    private final AuthenticatedUser currentUser;

    @Override
    public Optional<String> getCurrentAuditor() {
        try {
            if (currentUser != null && StringUtils.hasText(currentUser.getUsername())) {
                return Optional.ofNullable(currentUser.getUsername());
            }
        } catch (Exception exception) {
            log.trace("Error in getting username", exception);
        }
        return Optional.of(CUSTOMER_ANALYTICS_USER);
    }
}
