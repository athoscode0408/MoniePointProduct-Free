package com.moniepoint.loans.cas.common.configuration;

import com.google.cloud.bigtable.admin.v2.BigtableTableAdminClient;
import com.google.cloud.bigtable.admin.v2.models.CreateTableRequest;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.BigtableDataSettings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.io.IOException;

@Configuration
@Slf4j
public class BigtableConfig {

    @Value("${bigtable.project-id}")
    private String projectId;

    @Value("${bigtable.instance-id}")
    private String instanceId;

    @Value("${bigtable.emulator-host:}")
    private String emulatorHost;

    @Bean
    public BigtableDataClient bigtableDataClient() throws IOException {
        BigtableDataSettings settings;

        if (!emulatorHost.isEmpty()) {
            // TODO remove emulator condition. For local development only
            settings = BigtableDataSettings.newBuilderForEmulator(emulatorHost.split(":")[0],
                            Integer.parseInt(emulatorHost.split(":")[1]))
                    .setProjectId(projectId)
                    .setInstanceId(instanceId)
                    .build();
//            createTable(projectId, instanceId, "users", "user_attributes");
        } else {
            // For production
            settings = BigtableDataSettings.newBuilder()
                    .setProjectId(projectId)
                    .setInstanceId(instanceId)
                    .build();
        }
        return BigtableDataClient.create(settings);
    }

    public static void createTable(String projectId, String instanceId, String tableId, String family) throws IOException {
        BigtableTableAdminClient adminClient =
                BigtableTableAdminClient.create(projectId, instanceId);

        if (!adminClient.exists(tableId)) {
            CreateTableRequest request = CreateTableRequest.of(tableId)
                    .addFamily(family);

            adminClient.createTable(request);
            log.debug("Table created: {}", tableId);
        } else {
            log.debug("Table already exists: {}", tableId);
        }

        adminClient.close();
    }

}
