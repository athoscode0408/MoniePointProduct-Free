package com.moniepoint.loans.cas.common.configuration;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
@EnableCaching
public class CacheConfig {

    @Value("${cache.max-size:20000}")
    private int maxSize;

    @Value("${cache.expiry-in-mins:180}")
    private int expiry;

    @Value("${cache.survey-rules.expiry-in-mins:5}")
    private int surveyRulesExpiry;

    @Value("${cache.survey-rules.max-size:500}")
    private int surveyRulesMaxSize;

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager manager = new CaffeineCacheManager();

        manager.setCaffeine(
                Caffeine.newBuilder()
                        .maximumSize(maxSize)
                        .expireAfterWrite(Duration.ofMinutes(expiry))
                        .recordStats()
        );

        manager.registerCustomCache("surveyRules",
                Caffeine.newBuilder()
                        .maximumSize(surveyRulesMaxSize)
                        .expireAfterWrite(Duration.ofMinutes(surveyRulesExpiry))
                        .recordStats()
                        .build()
        );

        return manager;
    }

}

