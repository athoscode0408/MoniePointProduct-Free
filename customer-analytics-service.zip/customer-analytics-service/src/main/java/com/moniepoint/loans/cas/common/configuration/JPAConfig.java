package com.moniepoint.loans.cas.common.configuration;

import com.moniepoint.loans.cas.module.analytics.entity.*;
import com.moniepoint.loans.cas.module.analytics.repository.*;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
@EnableJpaAuditing
@EnableJpaRepositories(
        basePackageClasses = {AnalyticsEventProviderRepository.class, BrazeApiKeyStorage.class,
                PreprocessedSurveyStorage.class, SupportedEventRepository.class, SupportedUserAttributesRepository.class,
        SurveyStorage.class, UnsupportedEventRepository.class, MixpanelApiKeyStorage.class},
        excludeFilters = @ComponentScan.Filter(
                type = FilterType.ASSIGNABLE_TYPE,
                classes = { EventRetryRepository.class, EventDeadLetterRepository.class }
        ),
        entityManagerFactoryRef = "primaryEmf",
        transactionManagerRef = "primaryTx"
)
public class JPAConfig {

    @Primary
    @Bean(name = "primaryDataSource")
    @ConfigurationProperties("spring.datasource")
    public DataSource primaryDataSource() {
        return new com.zaxxer.hikari.HikariDataSource();
    }

    @Primary
    @Bean(name = "primaryEmf")
    public LocalContainerEntityManagerFactoryBean primaryEmf(
            EntityManagerFactoryBuilder builder,
            @Qualifier("primaryDataSource") DataSource ds) {
        return builder
                .dataSource(ds)
                .packages(AnalyticsEventProvider.class, BrazeApiKey.class,
                        PreprocessedSurvey.class, SupportedEvent.class,SupportedUserAttributes.class, Survey.class,
                        UnsupportedEvent.class, MixpanelApiKey.class)
                .persistenceUnit("primaryPU")
                .build();
    }

    @Primary
    @Bean(name = "primaryTx")
    public PlatformTransactionManager primaryTx(
            @Qualifier("primaryEmf") EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }


}
