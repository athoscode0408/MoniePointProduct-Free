package com.moniepoint.loans.cas.common.configuration;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ObjectMapperConfiguration {

    private static final ObjectMapper mapper;
    private static final ObjectWriter prettyMapper;

    static {
        mapper = constructObjectMapper();

        prettyMapper = constructObjectMapper()
                .writerWithDefaultPrettyPrinter();
    }

    public static ObjectMapper constructObjectMapper() {
        return new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .findAndRegisterModules();
    }

    @Bean
    public ObjectMapper objectMapper() {
        return mapper;
    }

    public static ObjectWriter getPrettyMapper() {
        return prettyMapper;
    }
}
