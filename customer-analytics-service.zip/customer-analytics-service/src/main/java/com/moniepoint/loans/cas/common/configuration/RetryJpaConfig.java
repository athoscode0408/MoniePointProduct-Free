package com.moniepoint.loans.cas.common.configuration;

import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.repository.*;
import com.moniepoint.loans.cas.module.analytics.repository.CohortStorage;
import com.moniepoint.loans.cas.module.analytics.repository.EligibilityRuleStorage;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
@EnableJpaRepositories(
        basePackageClasses = { EventRetryRepository.class, EventDeadLetterRepository.class },
        excludeFilters = @ComponentScan.Filter(
                type = FilterType.ASSIGNABLE_TYPE,
                classes = { AnalyticsEventProviderRepository.class, BrazeApiKeyStorage.class,
                        PreprocessedSurveyStorage.class, SupportedEventRepository.class, SupportedUserAttributesRepository.class,
                        SurveyStorage.class, UnsupportedEventRepository.class, MixpanelApiKeyStorage.class, SurveyAlertStorage.class,
                        CohortStorage.class, EligibilityRuleStorage.class, NpsWeeklySampleStorage.class, NpsUserStateStorage.class }
        ),
        entityManagerFactoryRef = "retryEmf",
        transactionManagerRef = "retryTx"
)
public class RetryJpaConfig {

    @Bean(name = "retryDataSource")
    @ConfigurationProperties("retry.datasource.hikari")
    public DataSource retryDataSource() {
        return new com.zaxxer.hikari.HikariDataSource();
    }

    @Bean(name = "retryEmf")
    public LocalContainerEntityManagerFactoryBean retryEmf(
            EntityManagerFactoryBuilder builder,
            @Qualifier("retryDataSource") DataSource ds) {
        return builder
                .dataSource(ds)
                .packages(EventRetry.class, EventDeadLetter.class)
                .persistenceUnit("retryPU")
                .build();
    }

    @Bean(name = "retryTx")
    public PlatformTransactionManager retryTx(
            @Qualifier("retryEmf") EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }
}
