package com.moniepoint.loans.cas.common.exception;


import lombok.Getter;
import org.springframework.http.HttpStatus;


@Getter
public abstract class BaseRuntimeException extends RuntimeException {

    private final HttpStatus responseCode;

    protected BaseRuntimeException(HttpStatus httpStatus) {
        this.responseCode = httpStatus;
    }
    protected BaseRuntimeException(String message, Throwable cause, HttpStatus httpStatus) {
        super(message, cause);
        this.responseCode = httpStatus;
    }

    protected BaseRuntimeException(String message, HttpStatus httpStatus) {
        super(message);
        this.responseCode = httpStatus;
    }

}
