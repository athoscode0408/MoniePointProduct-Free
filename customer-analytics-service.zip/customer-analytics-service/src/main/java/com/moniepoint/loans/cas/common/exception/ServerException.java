package com.moniepoint.loans.cas.common.exception;

import org.springframework.http.HttpStatus;

public final class ServerException extends BaseRuntimeException {

    public ServerException() {
        super(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ServerException(String message) {
        super(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ServerException(String message, Throwable cause) {
        super(message, cause, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ServerException(Exception e) {
        super(e.getMessage(), e.getCause(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
