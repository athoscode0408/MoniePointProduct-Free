package com.moniepoint.loans.cas.common.security;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Component("Authorities")
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Authorities {

    public static final String CAN_PUSH_ANALYTICS_EVENT = "can_push_analytics_event";
    public static final String CAN_FETCH_SURVEY = "can_fetch_survey";
    public static final String CAN_FETCH_CAMPAIGN = "can_fetch_campaign";


}
