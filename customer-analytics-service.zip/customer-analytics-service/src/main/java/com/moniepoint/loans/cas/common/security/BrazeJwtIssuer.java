package com.moniepoint.loans.cas.common.security;

import com.moniepoint.loans.cas.common.util.HashUtil;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.*;
import com.nimbusds.jwt.*;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.*;
import java.security.interfaces.*;
import java.security.spec.*;
import java.time.Instant;
import java.util.*;

@Slf4j
@Service
public class BrazeJwtIssuer {

    @Value("${braze.auth-private-key}")
    private String privKey;

    RSAPrivateKey privateKey;

    @PostConstruct
    public void loadPrivateKey() throws Exception {
       try
       {
           privateKey = loadPrivateKeyPKCS8();
           log.info("Successfully loaded private key");
       } catch (Exception e) {
           log.error("Exception loading private key ",e);
       }

    }

    public  String issueBearerToken(String userId,
                                          long ttlSeconds) throws JOSEException {

        var now = Instant.now();
        var exp = now.plusSeconds(ttlSeconds);

        var header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                .type(JOSEObjectType.JWT)
                .build();

        var claims = new JWTClaimsSet.Builder()
                .subject(HashUtil.sha256Hex(userId))
                .expirationTime(Date.from(exp))
                .build();

        var jwt = new SignedJWT(header, claims);
        jwt.sign(new RSASSASigner(privateKey));
        return jwt.serialize();
    }

    public RSAPrivateKey loadPrivateKeyPKCS8() throws Exception {

        byte[] der = Base64.getDecoder().decode(privKey);
        var keySpec = new PKCS8EncodedKeySpec(der);
        var kf = KeyFactory.getInstance("RSA");
        return (RSAPrivateKey) kf.generatePrivate(keySpec);
    }

}
