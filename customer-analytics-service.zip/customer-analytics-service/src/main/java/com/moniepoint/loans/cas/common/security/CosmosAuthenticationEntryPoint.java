package com.moniepoint.loans.cas.common.security;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.moniepoint.loans.cas.common.advice.models.ErrorResponse;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;


@Slf4j
public class CosmosAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private static final ObjectWriter objectWriter = ObjectMapperConfiguration.getPrettyMapper();


    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException {
        log.debug("Authentication error", authException);
        processException(response, authException);
    }


    public void processException(HttpServletResponse response,
                                 AuthenticationException authenticationException) throws IOException {

        try (PrintWriter writer = response.getWriter()) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            ErrorResponse errorResponse;
            if (authenticationException instanceof OAuth2AuthenticationException auth2AuthenticationException) {
                errorResponse = ErrorResponse.build(HttpStatus.UNAUTHORIZED, auth2AuthenticationException.getError().getErrorCode());
            } else {
                errorResponse = ErrorResponse.build(HttpStatus.UNAUTHORIZED, authenticationException.getMessage());
            }
            writer.print(objectWriter.writeValueAsString(errorResponse));
            writer.flush();
        }
    }

}
