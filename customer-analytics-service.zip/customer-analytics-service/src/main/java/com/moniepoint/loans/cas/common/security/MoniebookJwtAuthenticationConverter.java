package com.moniepoint.loans.cas.common.security;

import com.moniepoint.loans.cas.common.security.model.CosmosPrincipalFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthentication;
import org.springframework.util.Assert;

@Slf4j
public class MoniebookJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    @Override
    public final AbstractAuthenticationToken convert(@NonNull Jwt jwt) {
        Assert.notNull(jwt, "jwt cannot be null");

        var principal = CosmosPrincipalFactory.createPrincipal(jwt);
        var authorities = principal.getAuthorities();
        // Moniebook does not emit authorities, so we implicitly add it
        authorities.add(new SimpleGrantedAuthority(Authorities.CAN_PUSH_ANALYTICS_EVENT));
        authorities.add(new SimpleGrantedAuthority(Authorities.CAN_FETCH_SURVEY));
        authorities.add(new SimpleGrantedAuthority(Authorities.CAN_FETCH_CAMPAIGN));



        var oAuth2AccessToken = new OAuth2AccessToken(OAuth2AccessToken.TokenType.BEARER, jwt.getTokenValue(), jwt.getIssuedAt(), jwt.getExpiresAt());
        return new BearerTokenAuthentication(principal, oAuth2AccessToken, authorities);
    }
}