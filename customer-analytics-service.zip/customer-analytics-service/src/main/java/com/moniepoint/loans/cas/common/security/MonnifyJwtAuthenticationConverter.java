package com.moniepoint.loans.cas.common.security;

import com.moniepoint.loans.cas.common.security.model.CosmosPrincipalFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthentication;
import org.springframework.util.Assert;

import java.util.List;

@Slf4j
public class MonnifyJwtAuthenticationConverter implements Converter<Jwt, AbstractAuthenticationToken> {

    private final String resourceId;

    public MonnifyJwtAuthenticationConverter(String resourceId) {
        this.resourceId = resourceId;
    }

    @Override
    public final AbstractAuthenticationToken convert(@NonNull Jwt jwt) {
        Assert.notNull(jwt, "jwt cannot be null");

        validateResourceId(jwt);

        var principal = CosmosPrincipalFactory.createPrincipal(jwt);

        var oAuth2AccessToken = new OAuth2AccessToken(OAuth2AccessToken.TokenType.BEARER, jwt.getTokenValue(), jwt.getIssuedAt(), jwt.getExpiresAt());
        return new BearerTokenAuthentication(principal, oAuth2AccessToken, principal.getAuthorities());
    }

    private void validateResourceId(Jwt jwt) {
        List<String> resourceIds = jwt.getAudience();
        if (resourceId != null && (resourceIds == null || !resourceIds.contains(resourceId))) {
            throw new OAuth2AuthenticationException("Invalid token does not contain resource id (" + resourceId + ")");
        }
    }
}
