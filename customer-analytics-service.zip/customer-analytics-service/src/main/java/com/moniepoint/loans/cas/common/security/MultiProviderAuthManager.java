package com.moniepoint.loans.cas.common.security;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MultiProviderAuthManager implements AuthenticationManagerResolver<HttpServletRequest> {

    private final SecurityPropertiesConfig securityPropertiesConfig;
    private final JwtDecoder cosmosJwtDecoder;
    private final JwtDecoder moniebookJwtDecoder;
    private final JwtDecoder monnifyJwtDecoder;
    private AuthenticationManager authenticationManager;


    @PostConstruct
    void initiateAuthProviders()
    {
        JwtAuthenticationProvider cosmosAuthProvider = new JwtAuthenticationProvider(cosmosJwtDecoder);
        cosmosAuthProvider.setJwtAuthenticationConverter(new CosmosJwtAuthenticationConverter(securityPropertiesConfig.getResourceId()));

        JwtAuthenticationProvider moniebookAuthProvider = new JwtAuthenticationProvider(moniebookJwtDecoder);
        moniebookAuthProvider.setJwtAuthenticationConverter(new MoniebookJwtAuthenticationConverter());

        JwtAuthenticationProvider monnifyAuthProvider = new JwtAuthenticationProvider(monnifyJwtDecoder);
        monnifyAuthProvider.setJwtAuthenticationConverter(new MonnifyJwtAuthenticationConverter(securityPropertiesConfig.getResourceId()));

        this.authenticationManager = new ProviderManager(
                cosmosAuthProvider,
                moniebookAuthProvider,
                monnifyAuthProvider
        );

    }


    @Override
    public AuthenticationManager resolve(HttpServletRequest context) {
        return authenticationManager;
    }
}
