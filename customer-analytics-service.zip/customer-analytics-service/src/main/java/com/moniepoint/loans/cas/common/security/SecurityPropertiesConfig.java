package com.moniepoint.loans.cas.common.security;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.codec.Hex;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.util.StringUtils;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.List;

@Getter
@Configuration
@RequiredArgsConstructor
public class SecurityPropertiesConfig {

    protected static final String[] PUBLIC_URIS = {
            "/actuator/health",
            "/actuator/refresh",
            "/api/v3/events",
            "/api/v3/event",
            "/api/v3/user-info",
            "/api/v1/white-listed-events",
            "/api/webhook/**",
                // // Temporary: allow unauthenticated access to internal admin survey creation
                // // NOTE: remove or restrict this in production once admin API is protected
            "/internal/admin/**"
    };

    public static final String COSMOS_ROLE_PREFIX = "COSMOS_ROLE_";

    @Value(value = "#{'${web-security.cors.allowed-origins}'.split(',')}")
    private List<String> allowedOrigins;

    @Value(value = "#{'${web-security.cors.allowed-headers}'.split(',')}")
    private List<String> allowedHeaders;

    @Value("${web-security.cosmos.public-key}")
    private String cosmosPublicKey;

    @Value("${web-security.moniebook.public-key}")
    private String moniebookPublicKey;

    @Value("${web-security.monnify.public-key}")
    private String monnifyPublicKey;

    @Value("${web-security.cosmos.resource-id}")
    private String resourceId;


    public List<String> getAllowedOrigins() {
        allowedOrigins.removeIf(origin -> !StringUtils.hasText(origin));
        return allowedOrigins;
    }


    public List<String> getAllowedHeaders() {
        allowedHeaders.removeIf(origin -> !StringUtils.hasText(origin));
        return allowedHeaders;
    }

    @Bean(name = "cosmosJwtDecoder")
    protected JwtDecoder cosmosJwtDecoder() throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(Hex.decode(cosmosPublicKey));
        PublicKey pubKey = keyFactory.generatePublic(pubKeySpec);

        return NimbusJwtDecoder
                .withPublicKey((RSAPublicKey) pubKey)
                .build();
    }

    @Bean(name = "moniebookJwtDecoder")
    protected JwtDecoder moniebookJwtDecoder() throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(moniebookPublicKey));
        PublicKey pubKey = keyFactory.generatePublic(pubKeySpec);

        return NimbusJwtDecoder
                .withPublicKey((RSAPublicKey) pubKey)
                .build();
    }

    @Bean(name = "monnifyJwtDecoder")
    protected JwtDecoder monnifyJwtDecoder() throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(monnifyPublicKey));
        PublicKey pubKey = keyFactory.generatePublic(pubKeySpec);

        return NimbusJwtDecoder
                .withPublicKey((RSAPublicKey) pubKey)
                .build();
    }

}