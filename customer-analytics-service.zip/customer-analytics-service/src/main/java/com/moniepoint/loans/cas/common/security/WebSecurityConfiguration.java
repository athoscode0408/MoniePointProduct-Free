package com.moniepoint.loans.cas.common.security;


import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.core.GrantedAuthorityDefaults;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.security.web.savedrequest.NullRequestCache;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.cors.CorsConfiguration;

import static com.moniepoint.loans.cas.common.security.SecurityPropertiesConfig.COSMOS_ROLE_PREFIX;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class WebSecurityConfiguration {


    private final SecurityPropertiesConfig securityPropertiesConfig;


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, MultiProviderAuthManager authManager) throws Exception {

        return http

                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers(SecurityPropertiesConfig.PUBLIC_URIS).permitAll()

                        .anyRequest().fullyAuthenticated())

                .csrf(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .formLogin(AbstractHttpConfigurer::disable)
                .logout(AbstractHttpConfigurer::disable)
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .requestCache(cache -> cache.requestCache(new NullRequestCache()))

                .cors(cors -> cors
                        .configurationSource(request -> {
                            var configuration = new CorsConfiguration();
                            configuration.setAllowedOrigins(securityPropertiesConfig.getAllowedOrigins());
                            configuration.setAllowedHeaders(securityPropertiesConfig.getAllowedHeaders());
                            configuration.addAllowedMethod(CorsConfiguration.ALL);
                            return configuration;
                        }))

                .oauth2ResourceServer(resourceServer -> resourceServer
                        .authenticationManagerResolver(authManager)
                        .authenticationEntryPoint(new CosmosAuthenticationEntryPoint()))
                .build();
    }


    @Bean
    static GrantedAuthorityDefaults grantedAuthorityDefaults() {
        return new GrantedAuthorityDefaults(COSMOS_ROLE_PREFIX);
    }


    /**
     * KrakenD's GeoIP plugin injects the MaxMind city lookup as a JSON blob in the
     * {@code x-geoip} header. That payload commonly contains non-ASCII characters
     * (localised city/country names), which Spring Security's {@link StrictHttpFirewall}
     * rejects by default with a 500 "header value not allowed" error.
     * <p>
     * We keep the default strict ASCII-only validation for every other header, and only
     * relax it for values that look like the GeoIP JSON payload.
     *
     * @see <a href="https://teamapt.atlassian.net/wiki/spaces/MAE/pages/2953838679">Geo IP Header in API gateway And Solution for Springboot Applications</a>
     */
    @Bean
    public HttpFirewall geoIpAwareHttpFirewall() {
        StrictHttpFirewall firewall = new StrictHttpFirewall();

        firewall.setAllowedHeaderValues(headerValue -> isGeoIpJson(headerValue) || isValidAsciiHeader(headerValue));

        return firewall;
    }


    private boolean isGeoIpJson(String value) {
        return value != null && value.contains("\"GeoNameID\"");
    }


    private boolean isValidAsciiHeader(String value) {
        if (value == null) {
            return true;
        }

        for (char c : value.toCharArray()) {
            if (c < 0x20 || c > 0x7E) {
                return false;
            }
        }
        return true;
    }


    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.httpFirewall(geoIpAwareHttpFirewall());
    }


    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public AuthenticatedUser currentUser() {
        return (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

}
