package com.moniepoint.loans.cas.common.security.model;

import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.core.OAuth2AuthenticatedPrincipal;

import java.util.List;
import java.util.Map;
import java.util.Set;


@Getter
@ToString
@Builder(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class AuthenticatedUser implements OAuth2AuthenticatedPrincipal {

	private Map<String, Object> attributes;
	private Set<GrantedAuthority> authorities;
	private String name;
	private String username;
	private String firstName;
	private String email;
	private String phone;
	private String lastName;
	private String resetPassword;
	private String authenticationDomain;
	private String branch;
	private List<String> roles;
	private List<String> authoritiesList;
	private String clientId;
	private String deviceStatus;
	private String panicMode;
	private Set<String> scope;
	private List<String> aud;
	private String userType;

}
