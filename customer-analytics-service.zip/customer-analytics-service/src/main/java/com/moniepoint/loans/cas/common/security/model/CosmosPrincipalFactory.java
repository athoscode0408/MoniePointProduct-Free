package com.moniepoint.loans.cas.common.security.model;

import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.Assert;

import java.util.*;

import static com.moniepoint.loans.cas.common.security.SecurityPropertiesConfig.COSMOS_ROLE_PREFIX;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class CosmosPrincipalFactory {

    private static final String SCOPE_CLAIM_NAME = "scope";
    private static final String AUTHORITIES_CLAIM_NAME = "authorities";
    private static final String ROLES_CLAIM_NAME = "roles";
    private static final String[] USERNAME_CLAIM_NAMES = {"username", "user_name", "client_id"};
    private static final String[] CLIENT_ID_CLAIM_NAMES = {"client_id", "clientId"};


    public static AuthenticatedUser createPrincipal(Jwt jwt) {
        Assert.notNull(jwt, "jwt cannot be null");

        AuthenticatedUser.AuthenticatedUserBuilder cosmosAuthenticatedUserBuilder = buildClientDetails(jwt);

        if(clientOnly(jwt)) {
            return cosmosAuthenticatedUserBuilder.build();
        }

        return buildUserDetails(cosmosAuthenticatedUserBuilder, jwt);
    }


    private static AuthenticatedUser.AuthenticatedUserBuilder buildClientDetails(Jwt jwt) {
        return AuthenticatedUser.builder()
                .authorities(getGrantedAuthorities(jwt))
                .authoritiesList(jwt.getClaimAsStringList(AUTHORITIES_CLAIM_NAME))
                .attributes(jwt.getClaims())
                .name(getUsername(jwt))
                .username(getUsername(jwt))
                .clientId(getClientId(jwt))
                .scope(getScopes(jwt))
                .aud(jwt.getAudience());
    }


    private static AuthenticatedUser buildUserDetails(
            AuthenticatedUser.AuthenticatedUserBuilder cosmosAuthenticatedUserBuilder, Jwt jwt) {

        return cosmosAuthenticatedUserBuilder
                .firstName(jwt.getClaimAsString("firstName"))
                .lastName(jwt.getClaimAsString("lastName"))
                .email(jwt.getClaimAsString("email"))
                .phone(jwt.getClaimAsString("phone_number"))
                .resetPassword(jwt.getClaimAsString("resetPassword"))
                .authenticationDomain(jwt.getClaimAsString("authenticationDomain"))
                .branch(jwt.getClaimAsString("branch"))
                .roles(jwt.getClaimAsStringList(ROLES_CLAIM_NAME))
                .userType(jwt.getClaimAsString("userType"))
                .deviceStatus(jwt.getClaimAsString("deviceStatus"))
                .panicMode(jwt.getClaimAsString("panicMode"))
                .build();
    }




    private static boolean clientOnly(Jwt jwt) {
        return !jwt.hasClaim("userType") && !jwt.hasClaim("firstName") && !jwt.hasClaim("lastName");
    }



    private static HashSet<String> getScopes(Jwt jwt) {
        return new HashSet<>(getClaimsAsCollection(jwt, SCOPE_CLAIM_NAME));
    }



    private static String getUsername(Jwt jwt) {
        for (String claimName : USERNAME_CLAIM_NAMES) {
            if(jwt.hasClaim(claimName)) {
                return jwt.getClaimAsString(claimName);
            }
        }
        return null;
    }



    private static String getClientId(Jwt jwt) {
        for (String claimName : CLIENT_ID_CLAIM_NAMES) {
            if(jwt.hasClaim(claimName)) {
                return jwt.getClaimAsString(claimName);
            }
        }
        return null;
    }




    private static Set<GrantedAuthority> getGrantedAuthorities(Jwt jwt) {

        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();

        List<String> authorities = getClaimsAsCollection(jwt, AUTHORITIES_CLAIM_NAME);
        authorities.forEach(authority -> grantedAuthorities.add(new SimpleGrantedAuthority(authority.trim())));

        List<String> roles = getClaimsAsCollection(jwt, ROLES_CLAIM_NAME);
        roles.forEach(role -> grantedAuthorities.add(new SimpleGrantedAuthority(COSMOS_ROLE_PREFIX.concat(role).trim())));

        return grantedAuthorities;
    }


    private static List<String> getClaimsAsCollection(Jwt jwt, String claimName) {
        return Optional.ofNullable(jwt.getClaimAsStringList(claimName)).orElse(Collections.emptyList());
    }
}
