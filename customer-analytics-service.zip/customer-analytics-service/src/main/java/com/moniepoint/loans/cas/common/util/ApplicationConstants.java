package com.moniepoint.loans.cas.common.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ApplicationConstants {

    public static final String INVALID_DATE_ERROR_MESSAGE = "Invalid data.";
    public static final String INVALID_EVENT_ENVIRONMENT_ERROR_MESSAGE = "Event environment is not valid.";
    public static final String INVALID_EVENT_PLATFORM_ERROR_MESSAGE = "Event platform is not valid.";

    public static final String CUSTOMER_ANALYTICS_USER = "SYSTEM";

    public static final String NULL_USER_ID_MESSAGE = "Username is not present in access token";




}
