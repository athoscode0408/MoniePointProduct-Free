package com.moniepoint.loans.cas.common.util;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Value("${survey.async_core_pool_size_multiplier:200}")
    private Integer corePoolSizeMultiplier;

    @Value("${survey.async_max_pool_size_multiplier:300}")
    private Integer maxPoolSizeMultiplier;

    @Value("${survey.async_queue_capacity:2000}")
    private Integer queueCapacity;

    @Value("${survey.async_thread_keepalive_seconds:120}")
    private Integer threadKeepAliveSec;

    @Value("${survey.async_await_termination_seconds:30}")
    private Integer awaitTerminationSec;

    @Bean(name = "appExecutor")
    public Executor appExecutor() {
        int cores = Runtime.getRuntime().availableProcessors();

        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(cores * corePoolSizeMultiplier);
        exec.setMaxPoolSize(cores * maxPoolSizeMultiplier);
        exec.setQueueCapacity(queueCapacity);
        exec.setKeepAliveSeconds(threadKeepAliveSec);
        exec.setThreadNamePrefix("app-async-");
        exec.setAllowCoreThreadTimeOut(true);
        exec.setWaitForTasksToCompleteOnShutdown(true);
        exec.setAwaitTerminationSeconds(awaitTerminationSec);
        exec.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        exec.setTaskDecorator(mdcTaskDecorator());
        exec.initialize();
        return exec;
    }

    @Bean
    public TaskDecorator mdcTaskDecorator() {
        return runnable -> {
            Map<String, String> contextMap = MDC.getCopyOfContextMap(); // capture from caller thread
            return () -> {
                Map<String, String> previous = MDC.getCopyOfContextMap();
                if (contextMap != null) MDC.setContextMap(contextMap); else MDC.clear();
                try {
                    runnable.run();
                } finally {
                    if (previous != null) MDC.setContextMap(previous); else MDC.clear(); // restore
                }
            };
        };
    }
}
