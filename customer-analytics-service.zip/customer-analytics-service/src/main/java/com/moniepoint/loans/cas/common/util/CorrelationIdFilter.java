package com.moniepoint.loans.cas.common.util;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        try {
            String incoming = req.getHeader(CorrelationIds.HEADER);
            if (incoming != null && !incoming.isBlank()) {
                CorrelationIds.set(incoming);
            } else {
                CorrelationIds.getOrCreate();
            }
            // Echo back so downstream callers can join the trace
            res.setHeader(CorrelationIds.HEADER, CorrelationIds.get());
            chain.doFilter(req, res);
        } finally {
            CorrelationIds.clear();
        }
    }
}