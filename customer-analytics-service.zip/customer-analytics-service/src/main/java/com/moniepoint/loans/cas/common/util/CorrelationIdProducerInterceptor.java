package com.moniepoint.loans.cas.common.util;

import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.header.internals.RecordHeader;

import java.nio.charset.StandardCharsets;
import java.util.Map;

public class CorrelationIdProducerInterceptor implements ProducerInterceptor<Object, Object> {
    @Override
    public ProducerRecord<Object,Object> onSend(ProducerRecord<Object,Object> record) {
        var headers = record.headers();
        var existing = headers.lastHeader(CorrelationIds.HEADER);
        if (existing == null) {
            var id = CorrelationIds.getOrCreate();
            headers.add(new RecordHeader(CorrelationIds.HEADER, id.getBytes(StandardCharsets.UTF_8)));
        }
        return record;
    }
    @Override public void onAcknowledgement(RecordMetadata m, Exception e) {}
    @Override public void close() {}
    @Override public void configure(Map<String, ?> configs) {}
}