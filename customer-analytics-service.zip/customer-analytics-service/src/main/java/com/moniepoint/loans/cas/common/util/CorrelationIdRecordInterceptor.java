package com.moniepoint.loans.cas.common.util;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Component
public class CorrelationIdRecordInterceptor implements RecordInterceptor<Object, Object> {

    @Override
    public void afterRecord(ConsumerRecord<Object, Object> record, Consumer<Object, Object> consumer) {
        CorrelationIds.clear();
    }

    @Override
    public ConsumerRecord<Object, Object> intercept(ConsumerRecord<Object, Object> record, Consumer<Object, Object> consumer) {
        var h = record.headers().lastHeader(CorrelationIds.HEADER);
        if (h != null) {
            CorrelationIds.set(new String(h.value(), StandardCharsets.UTF_8));
        } else {
            CorrelationIds.getOrCreate();
        }
        return record;
    }
}

