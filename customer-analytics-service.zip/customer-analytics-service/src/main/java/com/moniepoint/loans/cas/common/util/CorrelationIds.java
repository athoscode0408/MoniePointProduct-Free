package com.moniepoint.loans.cas.common.util;

import datadog.trace.api.CorrelationIdentifier;
import org.slf4j.MDC;

import java.util.UUID;
import java.util.function.Supplier;

public final class CorrelationIds {
    public static final String MDC_KEY = "correlationId";
    public static final String HEADER = "X-Correlation-Id";

    private CorrelationIds() {}

    public static String get() {
        return MDC.get(MDC_KEY);
    }

    public static String getOrCreate() {
        var id = get();
        if (id == null || id.isBlank()) {
            id = UUID.randomUUID().toString();
            MDC.put(MDC_KEY, id);
            MDC.put("trace.id", CorrelationIdentifier.getTraceId());
            MDC.put("span.id", CorrelationIdentifier.getSpanId());
        }
        return id;
    }

    public static void set(String id) {
        if (id == null || id.isBlank()) {
            id = UUID.randomUUID().toString();
        }
        MDC.put(MDC_KEY, id);
        MDC.put("trace.id", CorrelationIdentifier.getTraceId());
        MDC.put("span.id", CorrelationIdentifier.getSpanId());
    }

    public static void clear() {
        MDC.remove(MDC_KEY);
    }

    /** Run a block with a correlationId set, always clearing afterwards. */
    public static void runWith(String correlationId, Runnable r) {
        var prev = get();
        try {
            set(correlationId != null ? correlationId : prev);
            if (get() == null) getOrCreate();
            r.run();
        } finally {
            if (prev != null)
            {
                MDC.put(MDC_KEY, prev);
                MDC.put("trace.id", CorrelationIdentifier.getTraceId());
                MDC.put("span.id", CorrelationIdentifier.getSpanId());
            }
            else clear();
        }
    }

    public static <T> T callWith(String correlationId, Supplier<T> s) {
        var prev = get();
        try {
            set(correlationId != null ? correlationId : prev);
            if (get() == null) getOrCreate();
            return s.get();
        } finally {
            if (prev != null) MDC.put(MDC_KEY, prev); else clear();
        }
    }
}