package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

public class EpochTimestampDeserializer extends StdDeserializer<Timestamp> {

    public EpochTimestampDeserializer() {
        super(Timestamp.class);
    }

    @Override
    public Timestamp deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        if (p.currentToken() == JsonToken.VALUE_STRING) {
            String text = p.getText().trim();

            try {
                return epochToTimestamp(Long.parseLong(text));
            } catch (NumberFormatException ignored) {
            }

            try {
                return Timestamp.from(OffsetDateTime.parse(text).toInstant());
            } catch (Exception ignored) {
            }

            try {
                return Timestamp.from(Instant.parse(text));
            } catch (Exception ignored) {
            }

            return Timestamp.valueOf(LocalDateTime.parse(text));
        }

        return epochToTimestamp(p.getLongValue());
    }

    private static Timestamp epochToTimestamp(long value) {
        // 13+ digits = milliseconds, 10 digits = seconds
        Instant instant = String.valueOf(value).length() >= 13
                ? Instant.ofEpochMilli(value)
                : Instant.ofEpochSecond(value);
        return Timestamp.from(instant);
    }
}
