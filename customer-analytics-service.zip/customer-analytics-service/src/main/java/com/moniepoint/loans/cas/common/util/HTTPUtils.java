package com.moniepoint.loans.cas.common.util;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.util.IPAddress;

import java.net.URI;
import java.net.URISyntaxException;

@Slf4j
public class HTTPUtils {
    private HTTPUtils() {
    }

    public static String getIPAddress(HttpServletRequest request) {
        String xForwardedForHeader = request.getHeader("X-Forwarded-For");
        if (StringUtils.isBlank(xForwardedForHeader) || "unknown".equalsIgnoreCase(xForwardedForHeader)) {
            return request.getRemoteAddr();
        }

        for(String ip: xForwardedForHeader.split(",")) {
            if (IPAddress.isValid(ip.trim())) {
                return ip.trim();
            } else {
                log.warn("Received invalid ip address: {}, in X-Forwarded-For header {}", ip.trim(), xForwardedForHeader);
            }
        }

        return request.getRemoteAddr();
    }

    public static String getDomainFromURL(String url) {
        if (StringUtils.isBlank(url)) {
            return null;
        }

        try {
            URI uri = new URI(url);
            return uri.getHost();
        } catch (URISyntaxException _) {
            return null;
        }
    }
}
