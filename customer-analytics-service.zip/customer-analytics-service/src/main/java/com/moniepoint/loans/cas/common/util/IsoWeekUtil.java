package com.moniepoint.loans.cas.common.util;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.WeekFields;

public final class IsoWeekUtil {

    private IsoWeekUtil() {}

    public static String current(ZoneId zone) {
        LocalDate today = LocalDate.now(zone);
        WeekFields iso = WeekFields.ISO;
        int year = today.get(iso.weekBasedYear());
        int week = today.get(iso.weekOfWeekBasedYear());
        return String.format("%d-W%02d", year, week);
    }
}
