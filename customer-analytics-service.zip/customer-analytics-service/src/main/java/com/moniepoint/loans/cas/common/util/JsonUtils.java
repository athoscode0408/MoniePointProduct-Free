package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Iterator;
import java.util.Map;

public class JsonUtils {
    private JsonUtils() {}

    public static String normalizeJsonToArray(String json){
        if (!json.trim().startsWith("[")) {
            return "[" + json.trim() + "]";
        }
        return json;
    }

    public static ObjectNode flattenObjectNode(ObjectNode source) {
        ObjectNode result = JsonNodeFactory.instance.objectNode();
        flattenInto(result, source, "");
        return result;
    }

    private static void flattenInto(ObjectNode result, JsonNode node, String prefix) {
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String key = prefix.isEmpty() ? entry.getKey() : prefix + "_" + entry.getKey();
                flattenInto(result, entry.getValue(), key);
            }
        } else if (node.isArray()) {
            for (int i = 0; i < node.size(); i++) {
                flattenInto(result, node.get(i), prefix + "_" + i);
            }
        } else {
            result.set(prefix, node);
        }
    }

}
