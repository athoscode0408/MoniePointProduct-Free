package com.moniepoint.loans.cas.common.util;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.kafka.ConcurrentKafkaListenerContainerFactoryConfigurer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;

import java.util.Map;

@Configuration
public class KafkaTracingConfig {

    // Add the ProducerInterceptor so every send() carries the header
    @Bean
    public ProducerFactory<?,?> producerFactory(KafkaProperties props) {
        Map<String, Object> cfg = props.buildProducerProperties(null);
        cfg.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG,
                CorrelationIdProducerInterceptor.class.getName());
        return new DefaultKafkaProducerFactory<>(cfg);
    }

    @Bean
    public KafkaTemplate<?,?> kafkaTemplate(ProducerFactory<?,?> pf) {
        return new KafkaTemplate<>(pf);
    }

    // Attach RecordInterceptor to consumers so MDC is set for each record
    @Bean
    public ConcurrentKafkaListenerContainerFactory<Object, Object> kafkaListenerContainerFactory(
            ConcurrentKafkaListenerContainerFactoryConfigurer configurer,
            ConsumerFactory<Object, Object> cf,
            CorrelationIdRecordInterceptor recordInterceptor) {

        var factory = new ConcurrentKafkaListenerContainerFactory<Object, Object>();
        configurer.configure(factory, cf);
        factory.setRecordInterceptor(recordInterceptor);
        return factory;
    }
}