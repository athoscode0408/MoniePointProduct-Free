package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.moniepoint.loans.cas.common.exception.ServerException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class ObjectMapperHelper {

    private final ObjectMapper mapper;
    private final Telemetry telemetry;

    @Autowired
    public ObjectMapperHelper(ObjectMapper mapper, Telemetry telemetry) {
        this.mapper = mapper;
        this.telemetry = telemetry;
        mapper.registerModule(new JavaTimeModule());
        mapper.enable(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL);
    }

    public String serializeToString(Object object) {
        if (object == null) return "{}";

        long startTime = System.nanoTime();

        try {
            String json = mapper.writeValueAsString(object);
            long durationNs = System.nanoTime() - startTime;
            long durationMs = durationNs / 1_000_000;
            int payloadBytes = json.getBytes(StandardCharsets.UTF_8).length;

            telemetry.recordMetric("Custom/Serialization/PayloadBytes", payloadBytes);

            telemetry.recordMetric("Custom/Serialization/TimeMs", durationMs);
            log.debug("Serialization time for payload of size {} was {} ms", payloadBytes, durationMs);
            return json;
        } catch (IOException e) {
            log.error("An exception occurred while writing object as string.", e);
            throw new ServerException("serializeToString error occurred", e);
        }
    }

    public <T> T deserializeStringToObject(String content, TypeReference<T> valueTypeRef) {
        long startTime = System.nanoTime();

        try {
            return mapper.readValue(content, valueTypeRef);
        } catch (IOException e) {
            log.error("An exception occurred while reading object to class. {}", valueTypeRef, e);
            throw new ServerException("deserializeStringToObject error occurred", e);
        } finally {
            long duration = System.nanoTime() - startTime;
            long durationMs = duration / 1_000_000;
            int payloadSizeBytes = content.getBytes(StandardCharsets.UTF_8).length;

            telemetry.recordMetric("Custom/Deserialization/Time", durationMs);
            telemetry.recordMetric("Custom/Deserialization/PayloadSize", payloadSizeBytes);
            log.debug("Deserialization time for payload of size {} was {} ms", payloadSizeBytes, durationMs);
        }
    }

    public <T> T convertObjectToType(Object object, TypeReference<T> type) {
        return mapper.convertValue(object, type);
    }

    public <T> T mapRowToPojo(Row row, Class<T> clazz, String businessAccountNumber) {
        try {
            Map<String, String> columnMap = new HashMap<>();

            for (RowCell cell : row.getCells()) {
                String qualifier = cell.getQualifier().toStringUtf8();
                String value = cell.getValue().toStringUtf8();
                try {
                    if (!StringUtils.isBlank(value) && value.startsWith("{"))
                    {
                        value = mapper.readTree(value).traverse(mapper).readValueAs(ObjectNode.class).path(businessAccountNumber).asText(null);
                    }
                } catch (Exception _) {
                }
                columnMap.put(qualifier, value);
            }
            return convertValue(columnMap, clazz);
        } catch (Exception e) {
            throw new RuntimeException("Failed to map row to POJO", e);
        }
    }

    public <T> T mapCachedMapToPojo(Map<String, String> row, Class<T> clazz, String businessAccountNumber) {
        try {
            Map<String, String> columnMap = new HashMap<>();
            for (Map.Entry<String, String> e : row.entrySet()) {
                String qualifier = e.getKey();
                String value = e.getValue();
                try {
                    if (!StringUtils.isBlank(value) && value.startsWith("{"))
                    {
                        value = mapper.readTree(value).traverse(mapper).readValueAs(ObjectNode.class).path(businessAccountNumber).asText(null);
                    }
                } catch (Exception _) {
                }
                columnMap.put(qualifier, value);
            }
            return convertValue(columnMap, clazz);
        } catch (Exception e) {
            throw new RuntimeException("Failed to map row to POJO", e);
        }
    }

    public ObjectNode mapPojoToObjectNode(Object pojo) {
        return mapper.valueToTree(pojo);
    }

    public <T> T mapObjectNodeToPojo(ObjectNode obj, Class<T> clazz) {
        try {
            return mapper.treeToValue(obj, clazz);
        } catch (Exception e) {
            log.error("Failed to map objectNode to POJO", e);
            return null;
        }
    }

    public <T> T convertValue(Object fromObject, Class<T> clazz) {
        return mapper.convertValue(fromObject, clazz);
    }

}
