package com.moniepoint.loans.cas.common.util;

import io.micrometer.core.instrument.MeterRegistry;
import io.opentracing.Scope;
import io.opentracing.Span;
import io.opentracing.log.Fields;
import io.opentracing.tag.Tags;
import io.opentracing.util.GlobalTracer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Supplier;

@Slf4j
@Component
@RequiredArgsConstructor
public class Telemetry {

    private final MeterRegistry meterRegistry;

    public void recordMetric(String name, double value) {
        meterRegistry.summary(name).record(value);
    }

    public void onStageDone(String stage, String cid, boolean ok, long durationMs) {
        log.info("Stage {} done for correlationId {}. success={}, durationMs={}", stage, cid, ok, durationMs);
    }

    public static void runInSpan(String name, Runnable work) {
        runInSpan(name, () -> {
            work.run();
            return null;
        });
    }

    public static <T> T runInSpan(String name, Supplier<T> work) {
        Span span = GlobalTracer.get().buildSpan(name).start();
        try (Scope _ = GlobalTracer.get().activateSpan(span)) {
            return work.get();
        } catch (RuntimeException e) {
            Tags.ERROR.set(span, true);
            span.log(Map.of(
                    Fields.EVENT, "error",
                    Fields.ERROR_OBJECT, e,
                    Fields.MESSAGE, String.valueOf(e.getMessage())
            ));
            throw e;
        } finally {
            span.finish();
        }
    }
}
