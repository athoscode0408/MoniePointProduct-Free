package com.moniepoint.loans.cas.integrations;

import feign.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class FeignConfig {

    @Value("${feign.connect-timeout:2000}")
    private int connectTimeout;

    @Value("${feign.read-timeout:10000}")
    private int readTimeout;


    @Bean
    Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }

    @Bean
    public feign.Request.Options feignOptions() {
        return new feign.Request.Options(connectTimeout, readTimeout);
    }
}
