package com.moniepoint.loans.cas.integrations.braze;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.braze.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "braze-service", url = "${integrations.braze.base-url}", fallbackFactory = BrazeClientFallbackFactory.class, configuration = FeignConfig.class)
public interface BrazeClient {

    /**
     * @see <a href="https://www.braze.com/docs/api/endpoints/user_data/post_user_track">Braze docs</a>
     */
    @PostMapping("/users/track")
    ResponseEntity<BrazeTrackResponse> trackEvent(@RequestBody BrazeTrackRequest request, @RequestHeader("Authorization") String authorizationToken);

    /**
     * @see <a href="https://www.braze.com/docs/api/endpoints/user_data/post_user_identify">Braze docs</a>
     */
    @PostMapping("/users/identify")
    ResponseEntity<BrazeIdentifyResponse> identify(@RequestBody BrazeIdentifyRequest request, @RequestHeader("Authorization") String authorizationToken);

    /**
     * @see <a href="https://www.braze.com/docs/api/endpoints/export/canvas/get_canvas_details">Braze docs</a>
     */
    @GetMapping("/canvas/details")
    ResponseEntity<BrazeCanvasResponse> fetchCanvasDetails(@RequestParam String canvas_id, @RequestHeader("Authorization") String authorizationToken);


}
