package com.moniepoint.loans.cas.integrations.braze;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.dto.*;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class BrazeClientFallbackFactory implements FallbackFactory<BrazeClient> {

    private final EventRetryService eventRetryService;
    private final ObjectMapperHelper objectMapperHelper;

    @Override
    public BrazeClient create(Throwable cause) {
        return new BrazeClient() {
            @Override
            public ResponseEntity<BrazeTrackResponse> trackEvent(BrazeTrackRequest request, String authorizationToken) {
                log.error("{} braze events can't be pushed due to : {}", request.getEvents().size(), cause.getMessage());

                Optional<BrazeEvent> events = request.getEvents().stream().findFirst();
                if (events.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                }

                String eventID = String.valueOf(events.get().getProperties().get("event_id"));
                BrazeTrackResponse response = new BrazeTrackResponse(0, 0, cause.getMessage());

                EventRetryDataDTO eventRetryDataDTO = EventRetryDataDTO.builder()
                        .eventId(eventID)
                        .eventProvider(EventProvider.BRAZE)
                        .eventData(objectMapperHelper.serializeToString(request))
                        .failureReason(cause.getMessage())
                        .build();

                if (cause instanceof FeignException fe && fe.status() == HttpStatus.BAD_REQUEST.value()) {
                    log.warn("{} braze events rejected with 400 Bad Request — not retrying: {}",
                            request.getEvents().size(), cause.getMessage());
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
                }
                eventRetryService.processFailedEventData(eventRetryDataDTO);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(response);
            }

            @Override
            public ResponseEntity<BrazeIdentifyResponse> identify(BrazeIdentifyRequest request, String authorizationToken) {
                log.error("{} braze user alias could not be identified due to : {}. Will not be retried", request.getAliases().size(), cause.getMessage());
                Optional<BrazeAliasesToIdentify> events = request.getAliases().stream().findFirst();
                if (events.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                }

                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new BrazeIdentifyResponse(0, 0, 0, cause.getMessage()));
            }

            @Override
            public ResponseEntity<BrazeCanvasResponse> fetchCanvasDetails(String id,String authorizationToken) {
                log.error("Could not fetch canvas details from Braze", cause);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new BrazeCanvasResponse(null, null, cause.getMessage() ) );
            }
        };
    }
}
