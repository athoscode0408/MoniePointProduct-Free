package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.moniepoint.loans.cas.common.util.HashUtil;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.Serial;
import java.io.Serializable;

@AllArgsConstructor
@Getter
public class BrazeAliasesToIdentify implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Unique user identifier, external to braze
     *
     * @see <a href="https://www.braze.com/docs/api/basics/#user-ids">Braze user IDs</a>
     */
    @JsonProperty("external_id")
    private String externalID;
    @JsonProperty("user_alias")
    private BrazeUserAlias userAlias;

    public BrazeAliasesToIdentify(UserEventIdentifier user) {
        externalID = HashUtil.sha256Hex(user.getUserID());
        userAlias = new BrazeUserAlias(user.getSessionID(), BrazeUserAlias.SESSION_ID_LABEL);
    }
}
