package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeCanvasResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private Boolean enabled;

    private String name;

    private String message;
}
