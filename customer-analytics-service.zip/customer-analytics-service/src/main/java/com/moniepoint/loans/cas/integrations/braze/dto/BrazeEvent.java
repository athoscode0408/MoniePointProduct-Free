package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.HashUtil;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;


/**
 * In Braze, an event object is an object that gets passed through the API when a specific event occurs.
 * Events objects are housed in an events array. Each event object in the events array represents a single occurrence
 * of a custom event by a particular user at the designated time value.
 * The event object has many different fields that allow you to customize by setting and using event properties in messages,
 * data collection, and personalization.
 *
 * @see <a href="https://www.braze.com/docs/api/objects_filters/event_object/#what-is-an-event-object">Braze event specification</a>
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrazeEvent implements Serializable {

    @JsonIgnore
    final ObjectMapper objectMapper = new ObjectMapper();

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Unique user identifier, external to braze
     *
     * @see <a href="https://www.braze.com/docs/api/basics/#user-ids">Braze user IDs</a>
     */
    @JsonProperty("external_id")
    private String externalID;

    @JsonProperty("user_alias")
    private BrazeUserAlias userAlias;

    @JsonProperty("braze_id")
    private String brazeID;

    @JsonProperty("email")
    private String email;

    @JsonProperty("phone")
    private String phone;

    /**
     * Identifies the app that created the event
     * Can be retrieved from the braze project settings
     *
     * @see <a href="https://www.braze.com/docs/api/identifier_types">API Identifier</a>
     */
    @JsonProperty("app_id")
    private String appID;

    /**
     * Name of the event
     */
    @JsonProperty("name")
    private String name;

    /**
     * Time when the event happened
     * Accepted formats: ISO 8601 or `yyyy-MM-dd'T'HH:mm:ss:SSSZ`
     */
    @JsonProperty("time")
    private String time;

    @JsonProperty("properties")
    private JsonNode properties;

    @JsonProperty("_update_existing_only")
    private Boolean updateExistingOnly = false;


    public BrazeEvent(VerifiedAnalyticsEventDTO event) {
        var user = event.getUserIdentifiers();
        if (StringUtils.isAllBlank(user.getUserID(), user.getEmail(), user.getPhone())) {
            this.userAlias = new BrazeUserAlias(user.getSessionID(), BrazeUserAlias.SESSION_ID_LABEL);
        } else {
            this.externalID = HashUtil.sha256Hex(user.getUserID());
            this.email = user.getEmail();
            this.phone = user.getPhone();
        }

        this.time = event.getTimestamp().toInstant().toString();
        ObjectNode data = (ObjectNode) event.getData();
        // including eventType as fallback where eventName is not sent in payload
        // This is a backward compatibility update for clients integrating to v1/v2 endpoints
        this.name = data.path("eventName").asText(event.getEventType());
        HashMap<String, Object> eventData = objectMapper.convertValue(event.getData(), HashMap.class);
        HashMap<String, Object> properties = (HashMap<String, Object>) eventData.get("properties");
        HashMap<String, Object> meta = (HashMap<String, Object>) eventData.get("meta");
        HashMap<String, Object> device = (HashMap<String, Object>) eventData.get("device");
        eventData.remove("properties");
        eventData.remove("meta");
        eventData.remove("device");
        HashMap<String, Object> mergedEventData = new HashMap<>(eventData);
        mergedEventData.put("userID", user.getUserID());
        mergedEventData.putAll(Objects.requireNonNullElse(properties, mergedEventData));
        mergedEventData.putAll(Objects.requireNonNullElse(meta, mergedEventData));
        mergedEventData.putAll(Objects.requireNonNullElse(device, mergedEventData));
        mergedEventData.put("analytics_source", "CAS");
        this.properties= objectMapper.convertValue(mergedEventData, ObjectNode.class);
    }
}