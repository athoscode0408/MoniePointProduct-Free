package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.Getter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Allows to merge aliases, emails, phone numbers and external ids
 *
 * @see <a href="https://www.braze.com/docs/api/endpoints/user_data/post_user_identify">Braze docs</a>
 */
@Getter
public class BrazeIdentifyRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty("aliases_to_identify")
    private final Collection<BrazeAliasesToIdentify> aliases;
    @JsonProperty("merge_behavior")
    private final String mergeBehavior;

    public BrazeIdentifyRequest(Collection<VerifiedAnalyticsEventDTO> events) {
        this.mergeBehavior = "merge";
        this.aliases = new ArrayList<>();
        events.forEach(e -> {
            if (e.getUserIdentifiers() != null && e.getUserIdentifiers().getUserID() != null) {
                this.aliases.add(new BrazeAliasesToIdentify(e.getUserIdentifiers()));
            }
        });
    }
}
