package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class BrazeIdentifyResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty("aliases_processed")
    private int aliasesProcessed;

    @JsonProperty("emails_processed")
    private int emailsProcessed;

    @JsonProperty("phone_numbers_processed")
    private int phoneNumbersProcessed;

    @JsonProperty("message")
    private String message;
}
