package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serial;
import java.io.Serializable;

public record BrazeLocation(@JsonProperty("longitude") Double longitude,
                            @JsonProperty("latitude") Double latitude) implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

}
