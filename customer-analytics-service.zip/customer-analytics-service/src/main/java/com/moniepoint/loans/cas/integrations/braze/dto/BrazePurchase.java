package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;


/**
 * A purchase object is an object that gets passed through the API when a purchase has been made.
 * Each purchase object is located within a purchase array, with each object being a single purchase by a particular user
 * at a particular time. The purchase object has many different fields that allow the Braze backend to store and use
 * this information for customization, data collection, and personalization.
 *
 * @see <a href="https://www.braze.com/docs/api/objects_filters/purchase_object/#what-is-a-purchase-object">Braze purchase object specification</a>
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrazePurchase implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Unique user identifier, external to braze
     *
     * @see <a href="https://www.braze.com/docs/api/basics/#user-ids">Braze user IDs</a>
     */
    @JsonProperty("external_id")
    private String externalID;

    @JsonProperty("user_alias")
    private BrazeUserAlias userAlias;

    @JsonProperty("braze_id")
    private String brazeID;

    @JsonProperty("email")
    private String email;

    @JsonProperty("phone")
    private String phone;

    /**
     * Identifies the app that created the event
     * Can be retrieved from the braze project settings
     *
     * @see <a href="https://www.braze.com/docs/api/identifier_types">API Identifier</a>
     */
    @JsonProperty("app_id")
    private String appID;

    /**
     * Identifier for the purchase (such as Product Name or Product Category)
     *
     * @see <a href="https://www.braze.com/docs/api/objects_filters/purchase_object/#purchase-product-id">Product ID docs</a>
     */
    @JsonProperty("product_id")
    private String productID;

    /**
     * ISO 4217 Alphabetic Currency Code
     */
    @JsonProperty("currency")
    private String currency;

    @JsonProperty("price")
    private String price;

    /**
     * the quantity purchased (defaults to 1, must be <= 100 -- currently,
     * Braze treats a quantity _X_ as _X_ separate purchases with quantity 1)
     */
    @JsonProperty("quantity")
    private String quantity;

    /**
     * Time when the event happened
     * Accepted formats: ISO 8601 or `yyyy-MM-dd'T'HH:mm:ss:SSSZ`
     */
    @JsonProperty("time")
    private String time;

    /**
     * Purchase properties can be used to trigger messages and for personalization using Liquid, also allowing you to segment based on these properties.
     *
     * @see <a href="https://www.braze.com/docs/api/objects_filters/purchase_object/#purchase-properties-object">Purchase Properties api docs</a>
     * @see <a href="https://www.braze.com/docs/user_guide/data/custom_data/purchase_events?redirected=1#purchase-properties">Purchase Properties user guide</a>
     */
    @JsonProperty("properties")
    private JsonNode properties;

    @JsonProperty("_update_existing_only")
    private Boolean updateExistingOnly = false;
}