package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.databind.node.NullNode;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

@RequiredArgsConstructor
@Getter
@Slf4j
public class BrazeTrackRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private final Collection<BrazeUserAttributes> attributes;
    private final Collection<BrazeEvent> events;
    private final Collection<BrazePurchase> purchases;

    public BrazeTrackRequest(Collection<VerifiedAnalyticsEventDTO> events, Map<String, String> appIDs) {
        this.events = new ArrayList<>();
        this.purchases = new ArrayList<>();
        this.attributes = new ArrayList<>();
        events.forEach(e -> {
            try{
                this.attributes.add(new BrazeUserAttributes(e));
                if (e.getData() != null && !(e.getData() instanceof NullNode)) {
                    BrazeEvent brazeEvent = new BrazeEvent(e);
                    brazeEvent.setAppID(StringUtils.isBlank(e.getPlatform()) ? null :  appIDs.get(e.getPlatform().toLowerCase()));
                    this.events.add(brazeEvent);
                }
            } catch (Exception ex) {
                log.warn("Error populating event in BrazeTrackRequest : {}", ex.getMessage());
            }


        });
    }
}
