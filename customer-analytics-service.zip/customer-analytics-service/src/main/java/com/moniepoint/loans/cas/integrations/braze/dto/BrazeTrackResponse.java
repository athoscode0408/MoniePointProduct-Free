package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class BrazeTrackResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty("attributes_processed")
    private int attributesProcessed;

    @JsonProperty("events_processed")
    private int eventsProcessed;

    @JsonProperty("message")
    private String message;
}
