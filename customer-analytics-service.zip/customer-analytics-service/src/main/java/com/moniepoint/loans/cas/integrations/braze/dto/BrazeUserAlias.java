package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serial;
import java.io.Serializable;

/**
 * Each alias functions as a key-value pair that consists of two parts:
 * an alias_label, which defines the key of the alias,
 * and an alias_name, which defines the value.
 * An alias_name for any single label must be unique across your user base (just like with external_id).
 *
 * @param value
 * @param label
 * @see <a href="https://www.braze.com/docs/user_guide/data/user_data_collection/user_profile_lifecycle?redirected=1#user-aliases">User Aliases docs</a>
 */
public record BrazeUserAlias(@JsonProperty("alias_name") String value,
                             @JsonProperty("alias_label") String label) implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    public static final String SESSION_ID_LABEL = "session_id";
}
