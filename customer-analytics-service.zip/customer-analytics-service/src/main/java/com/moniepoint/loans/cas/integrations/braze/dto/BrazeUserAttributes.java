package com.moniepoint.loans.cas.integrations.braze.dto;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.HashUtil;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * In Braze, an attributes object allows one to update those special values on the user profile in the dashboard
 * or add your own custom attribute data to the user
 *
 * @see <a href="https://www.braze.com/docs/api/objects_filters/user_attributes_object">Braze user attributes specification</a>
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BrazeUserAttributes implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonIgnore
    ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Unique user identifier, external to braze
     *
     * @see <a href="https://www.braze.com/docs/api/basics/#user-ids">Braze user IDs</a>
     */
    @JsonProperty("external_id")
    private String externalID;

    @JsonProperty("user_alias")
    private BrazeUserAlias userAlias;

    @JsonProperty("braze_id")
    private String brazeID;

    @JsonProperty("email")
    private String email;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("_update_existing_only")
    private Boolean updateExistingOnly = false;

    @JsonProperty("push_token_import")
    private Boolean pushTokenImport;

    @JsonProperty("first_name")
    private String firstName;

    @JsonProperty("last_name")
    private String lastName;

    private String country;

    @JsonProperty("current_location")
    private BrazeLocation currentLocation;

    private String dob;

    @JsonProperty("home_city")
    private String homeCity;

    @JsonIgnore
    private transient Map<String, Object> customProperties;

    @JsonAnySetter
    public void addCustomProps(String name, Object value) {
        if (customProperties == null) {
            customProperties = new HashMap<>();
        }
        customProperties.put(name, value);
    }

    @JsonAnyGetter
    public Map<String, Object> getCustomProps() {
        return customProperties;
    }

    public BrazeUserAttributes(VerifiedAnalyticsEventDTO event) {
        this.externalID = HashUtil.sha256Hex(event.getUserIdentifiers().getUserID());
        this.email = event.getUserIdentifiers().getEmail();
        this.phone = event.getUserIdentifiers().getPhone();
        this.firstName = event.getUserIdentifiers().getName();

        UserAttributes attributes= event.getUserAttributes();

        if (attributes != null) {
            this.email = attributes.getEmail();
            this.phone = attributes.getPhone();
            this.firstName = attributes.getFirstName();
            Timestamp dobTs = attributes.getDateOfBirth();
            this.dob = dobTs != null ? dobTs.toLocalDateTime().toLocalDate().toString() : null;
            this.homeCity = attributes.getCity();
            this.lastName = attributes.getLastName();
            this.customProperties = attributes.getCustomAttributes();
            attributes.setEmail(null);
            attributes.setPhone(null);
            attributes.setFirstName(null);
            attributes.setCustomAttributes(null);
            attributes.setDateOfBirth(null);
            attributes.setCity(null);
            attributes.setLastName(null);
            HashMap<String, Object> attributesMap = objectMapper.convertValue(attributes, HashMap.class);
            for (Map.Entry<String, Object> e : attributesMap.entrySet()) {
                String qualifier = e.getKey();
                Object value = e.getValue();
                if ((value instanceof String && StringUtils.isNotBlank((String) value)) || value != null)
                {
                    addCustomProps(qualifier, value);
                }
            }
        }
    }
}