package com.moniepoint.loans.cas.integrations.customerio.config;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;

@Slf4j
@Getter
@Configuration
@EnableRetry
public class CustomerIOConfig {

    @Value("${integrations.customerio.api-key}")
    private String apiKey;

    @Value("${integrations.customerio.site-id}")
    private String siteId;

    @Value("${integrations.customerio.enable}")
    private boolean enable;

    @Value("${integrations.customerio.update-customer-profile:false}")
    private boolean updateCustomerProfile;
}
