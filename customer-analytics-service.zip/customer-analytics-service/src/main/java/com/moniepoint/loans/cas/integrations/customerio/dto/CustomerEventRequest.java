package com.moniepoint.loans.cas.integrations.customerio.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Timestamp;

@Data
@SuperBuilder
@RequiredArgsConstructor
public class CustomerEventRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Event name can't be empty.")
    private String name;

    @NotBlank(message = "Event id can't be empty.")
    private String id;

    @NotNull(message = "Event type can't be null.")
    private CustomerIOEventType type;

    @NotNull(message = "Event timestamp can't be null")
    private Timestamp timestamp;

    @NotNull(message = "Event data can't be null.")
    private JsonNode data;

    private String customerIdentifier;

    public String getType() {
        return type.getValue();
    }

    public void setType(String type) {
        this.type = CustomerIOEventType.fromValue(type);
    }
}
