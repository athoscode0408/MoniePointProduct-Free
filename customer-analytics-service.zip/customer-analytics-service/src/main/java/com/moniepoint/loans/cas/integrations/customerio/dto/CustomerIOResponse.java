package com.moniepoint.loans.cas.integrations.customerio.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder
public class CustomerIOResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private boolean success;
}
