package com.moniepoint.loans.cas.integrations.customerio.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serial;
import java.io.Serializable;

@Data
@SuperBuilder
@RequiredArgsConstructor
public class CustomerProfileUpdateRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private JsonNode data;
}