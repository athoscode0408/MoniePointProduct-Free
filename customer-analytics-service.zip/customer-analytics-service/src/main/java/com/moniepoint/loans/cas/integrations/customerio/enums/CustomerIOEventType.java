package com.moniepoint.loans.cas.integrations.customerio.enums;

public enum CustomerIOEventType {

    EVENT("event"), PAGE("page"), SCREEN("screen");

    private final String value;

    CustomerIOEventType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static CustomerIOEventType fromValue(String value) {
        for (CustomerIOEventType eventType : CustomerIOEventType.values()) {
            if (eventType.getValue().equals(value)) {
                return eventType;
            }
        }
        throw new IllegalArgumentException("Unknown customerio event type value : " + value);
    }
}
