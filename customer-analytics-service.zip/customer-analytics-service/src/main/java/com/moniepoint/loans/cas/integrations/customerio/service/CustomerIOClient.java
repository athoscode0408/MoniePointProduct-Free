package com.moniepoint.loans.cas.integrations.customerio.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.service.impl.CustomerIOClientFallbackFactory;
import jakarta.validation.constraints.NotNull;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@FeignClient(name = "customerio-service", url = "${integrations.customerio.base-url}",configuration = FeignConfig.class, fallbackFactory = CustomerIOClientFallbackFactory.class)
public interface CustomerIOClient {

    @PostMapping("${integrations.customerio.customer-event-endpoint}")
    ResponseEntity<Void> sendCustomerEvent(@PathVariable("identifier") String identifier, @RequestBody CustomerEventRequest customerEventRequest, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("${integrations.customerio.anonymous-event-endpoint}")
    ResponseEntity<Void> sendAnonymousEvent(@RequestBody AnonymousEventRequest anonymousEventRequest, @RequestHeader("Authorization") String authorizationToken);

    @PutMapping("${integrations.customerio.update-customer-profile-endpoint}")
    ResponseEntity<Void> updateCustomerProfile(@PathVariable("identifier") String identifier, @RequestBody @NotNull JsonNode data, @RequestHeader("Authorization") String authorizationToken);

}
