package com.moniepoint.loans.cas.integrations.customerio.service;

import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerIOResponse;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerProfileUpdateRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

@Validated
public interface CustomerIOIntegrationService {

    CustomerIOResponse sendCustomerEventToCustomerIO(@Valid @NotBlank String username, @Valid @NotNull CustomerEventRequest customerEventRequest);
    CustomerIOResponse sendAnonymousEventToCustomerIO(@Valid @NotNull AnonymousEventRequest anonymousEventRequest);
    CustomerIOResponse updateCustomerProfile(@Valid @NotBlank String identifier,@Valid @NotNull  CustomerProfileUpdateRequest customerProfileUpdateRequest);
    void failureHandler(@Valid @NotBlank String failureReason, @Valid @NotNull CustomerEventRequest request);

}
