package com.moniepoint.loans.cas.integrations.googleanalytics.config;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Getter
@Configuration
public class GoogleAnalyticsConfig {

    @Value("${integrations.googleanalytics.enable}")
    private boolean enable;

    @Value("${integrations.googleanalytics.android.personal.api-secret}")
    private String androidPersonalApiSecret;

    @Value("${integrations.googleanalytics.android.personal.firebase-app-id}")
    private String androidPersonalFirebaseAppId;

    @Value("${integrations.googleanalytics.android.business.api-secret}")
    private String androidBusinessApiSecret;

    @Value("${integrations.googleanalytics.android.business.firebase-app-id}")
    private String androidBusinessFirebaseAppId;

    @Value("${integrations.googleanalytics.ios.personal.api-secret}")
    private String iosPersonalApiSecret;

    @Value("${integrations.googleanalytics.ios.personal.firebase-app-id}")
    private String iosPersonalFirebaseAppId;

    @Value("${integrations.googleanalytics.ios.business.api-secret}")
    private String iosBusinessApiSecret;

    @Value("${integrations.googleanalytics.ios.business.firebase-app-id}")
    private String iosBusinessFirebaseAppId;

    @Value("${integrations.googleanalytics.web.personal.api-secret}")
    private String webPersonalApiSecret;

    @Value("${integrations.googleanalytics.web.personal.measurement-id}")
    private String webPersonalMeasurementId;

    @Value("${integrations.googleanalytics.web.business.api-secret}")
    private String webBusinessApiSecret;

    @Value("${integrations.googleanalytics.web.business.measurement-id}")
    private String webBusinessMeasurementId;

}
