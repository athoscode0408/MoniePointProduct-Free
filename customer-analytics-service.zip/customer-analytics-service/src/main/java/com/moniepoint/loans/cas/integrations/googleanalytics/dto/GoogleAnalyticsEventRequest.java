package com.moniepoint.loans.cas.integrations.googleanalytics.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GoogleAnalyticsEventRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty("app_instance_id")
    private String appInstanceId;

    @JsonProperty("client_id")
    private String clientId;

    private JsonNode events;

    @JsonProperty("user_id")
    private String userId;

}
