package com.moniepoint.loans.cas.integrations.googleanalytics.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.impl.GoogleAnalyticsClientFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "googleanalytics-service", url = "${integrations.googleanalytics.base-url}", configuration = FeignConfig.class, fallbackFactory = GoogleAnalyticsClientFallbackFactory.class)
public interface GoogleAnalyticsClient {

    @PostMapping("${integrations.googleanalytics.validate-event-endpoint}")
    ResponseEntity<JsonNode> validateEvent(@RequestParam Map<String, String> queryParams, @RequestBody GoogleAnalyticsEventRequest request);

    @PostMapping("${integrations.googleanalytics.event-endpoint}")
    ResponseEntity<Void> sendEvent(@RequestParam Map<String, String> queryParams, @RequestBody GoogleAnalyticsEventRequest request);

}
