package com.moniepoint.loans.cas.integrations.googleanalytics.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.integrations.googleanalytics.config.GoogleAnalyticsConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Validated
public interface GoogleAnalyticsIntegrationService {

    GoogleAnalyticsResponse sendEventToGoogleAnalytics(@Valid @NotNull GoogleAnalyticsEventRequest request);

    void failureHandler(@Valid @NotBlank String failureReason, @Valid @NotNull GoogleAnalyticsEventRequest request);

    default String getEventIdFromJsonNode(JsonNode jsonNode) {
        return Optional.ofNullable(jsonNode)
                .filter(JsonNode::isArray)
                .filter(node -> node.size() > 0)
                .map(node -> node.get(0))
                .map(node -> node.get("params"))
                .map(node -> node.get("eventId"))
                .map(JsonNode::asText)
                .orElse(null);
    }

    default Map<String, String> prepareQueryParams(JsonNode jsonNode, GoogleAnalyticsConfig config) {
        Optional<JsonNode> params = Optional.ofNullable(jsonNode).filter(JsonNode::isArray)
                .filter(node -> node.size() > 0).map(node -> node.get(0)).map(node -> node.get("params"));
        String deviceType = params.map(node -> node.get("device_type")).map(JsonNode::asText).orElse(null);
        String appDomain = params.map(node -> node.get("app_domain")).map(JsonNode::asText).orElse(null);

        Map<String, String> queryParams = new HashMap<>();
        if ("WEB".equals(deviceType)) {
            if ("PERSONAL".equals(appDomain)) {
                queryParams.put("api_secret", config.getWebPersonalApiSecret());
                queryParams.put("measurement_id", config.getWebPersonalMeasurementId());
            } else if ("BUSINESS".equals(appDomain)) {
                queryParams.put("api_secret", config.getWebBusinessApiSecret());
                queryParams.put("measurement_id", config.getWebBusinessMeasurementId());
            }
        } else if ("ANDROID".equals(deviceType)) {
            if ("PERSONAL".equals(appDomain)) {
                queryParams.put("api_secret", config.getAndroidPersonalApiSecret());
                queryParams.put("firebase_app_id", config.getAndroidPersonalFirebaseAppId());
            } else if ("BUSINESS".equals(appDomain)) {
                queryParams.put("api_secret", config.getAndroidBusinessApiSecret());
                queryParams.put("firebase_app_id", config.getAndroidBusinessFirebaseAppId());
            }
        } else if ("IOS".equals(deviceType)) {
            if ("PERSONAL".equals(appDomain)) {
                queryParams.put("api_secret", config.getIosPersonalApiSecret());
                queryParams.put("firebase_app_id", config.getIosPersonalFirebaseAppId());
            } else if ("BUSINESS".equals(appDomain)) {
                queryParams.put("api_secret", config.getIosBusinessApiSecret());
                queryParams.put("firebase_app_id", config.getIosBusinessFirebaseAppId());
            }
        }

        return queryParams;
    }

}
