package com.moniepoint.loans.cas.integrations.mixpanel.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class MixpanelEventResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private int code;
    private String error;
    @JsonProperty("num_records_imported")
    private int numRecordsImported;
    private String status;

    @JsonProperty("failed_records")
    private List<FailedRecord> failedRecords;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FailedRecord implements Serializable {

        @Serial
        private static final long serialVersionUID = 1L;

        private int index;
        @JsonProperty("$insert_id")
        private String insertId;
        private String field;
        private String message;
    }

}
