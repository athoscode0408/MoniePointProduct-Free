package com.moniepoint.loans.cas.integrations.mixpanel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.io.Serializable;

/**
 * Sets user profile properties
 * These properties will be added to all user events
 *
 * @see <a href="https://developer.mixpanel.com/reference/profile-set">Mixpanel docs</a>
 */
@RequiredArgsConstructor
@Getter
public class MixpanelProfilePropertiesRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Moniepoint internal user identifier, used in Mixpanel to uniquely identify a user
     *
     * @see <a href="https://docs.mixpanel.com/docs/tracking-methods/id-management/identifying-users-simplified#user_id">Identifying Users (Simplified)</a>
     */
    @JsonProperty("$distinct_id")
    private String userID;

    /**
     * Project auth token
     */
    @JsonProperty("$token")
    private String token;

    /**
     * IP address of the user sending the event.
     * Will be used by mixpanel to calculate location data
     */
    @JsonProperty("$ip")
    private String ip;

    /**
     * User profile properties to set
     */
    @JsonProperty("$set")
    private MixpanelEventProperties properties;

    public MixpanelProfilePropertiesRequest(VerifiedAnalyticsEventDTO event, String authorizationToken, ObjectMapper objectMapper) {
        String deviceId = "";
        if (event.getData() != null && !(event.getData() instanceof NullNode))
        {
            ObjectNode objectNode = (ObjectNode) event.getData();
            AnalyticsEventV3DeviceInfoDTO device = objectMapper.convertValue(objectNode.path("device"), AnalyticsEventV3DeviceInfoDTO.class);
            deviceId= device == null ? "" : device.getId();
        }

        this.userID = StringUtils.isBlank(event.getUserIdentifiers().getUserID()) ? (StringUtils.isBlank(deviceId) ? event.getUserIdentifiers().getSessionID() : deviceId ) : event.getUserIdentifiers().getUserID();
        this.token = authorizationToken;
        this.ip = event.getIp();
        this.properties = new MixpanelEventProperties(event);
    }
}
