package com.moniepoint.loans.cas.integrations.mixpanel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@AllArgsConstructor
public class MixpanelQueryUser implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Moniepoint internal user identifier, used in Mixpanel to uniquely identify a user
     *
     * @see <a href="https://docs.mixpanel.com/docs/tracking-methods/id-management/identifying-users-simplified#user_id">Identifying Users (Simplified)</a>
     */
    @JsonProperty("$distinct_id")
    private String userID;
    @JsonProperty("$properties")
    private MixpanelEventProperties properties;
}
