package com.moniepoint.loans.cas.integrations.mixpanel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;

@Data
@AllArgsConstructor
public class MixpanelQueryUserRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private String where;
    @JsonProperty("output_properties")
    @feign.form.FormProperty("output_properties")
    private String properties = "[\"$phone\", \"$email\", \"$device_id\"]";

    public MixpanelQueryUserRequest(Iterable<MixpanelEventRequest> requests) {
        var sb = new ArrayList<String>();
        for (var r : requests) {
            if (StringUtils.isNotBlank(r.getProperties().getEmail())) {
                sb.add(String.format("user[\"$email\"] == \"%s\"", r.getProperties().getEmail()));
            } else if (StringUtils.isNotBlank(r.getProperties().getPhone())) {
                sb.add(String.format("user[\"$phone\"] == \"%s\"", r.getProperties().getPhone()));
            }
            else if (StringUtils.isNotBlank(r.getProperties().getDeviceID())) {
                sb.add(String.format("user[\"$device_id\"] == \"%s\"", r.getProperties().getDeviceID()));
            }
        }
        this.where = String.join(" or ", sb);
    }
}
