package com.moniepoint.loans.cas.integrations.mixpanel.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.Collection;

/**
 * Mixpanel Query Request payload for the engage api
 *
 * @see <a href="https://developer.mixpanel.com/reference/engage-query">Mixpanel docs</a>
 */
@Data
@AllArgsConstructor
public class MixpanelQueryUserResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private Collection<MixpanelQueryUser> results;
    @JsonProperty
    private int page;
    @JsonProperty("page_size")
    private int pageSize;
    @JsonProperty
    private int total;
    @JsonProperty
    private String status;
}
