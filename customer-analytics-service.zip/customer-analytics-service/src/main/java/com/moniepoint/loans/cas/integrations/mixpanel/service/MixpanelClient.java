package com.moniepoint.loans.cas.integrations.mixpanel.service;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelProfilePropertiesRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.service.impl.MixpanelClientFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

@FeignClient(name = "mixpanel-service", url = "${integrations.mixpanel.base-url:https://api.mixpanel.com/}", configuration = FeignConfig.class,  fallbackFactory = MixpanelClientFallbackFactory.class)
public interface MixpanelClient {

    @PostMapping("/import?strict=1")
    ResponseEntity<MixpanelEventResponse> sendImportEventRequest(@RequestBody List<MixpanelEventRequest> mixpanelEventRequests, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/engage?ip=0")
    ResponseEntity<Void> setProfileProperties(@RequestBody List<MixpanelProfilePropertiesRequest> requests);
}
