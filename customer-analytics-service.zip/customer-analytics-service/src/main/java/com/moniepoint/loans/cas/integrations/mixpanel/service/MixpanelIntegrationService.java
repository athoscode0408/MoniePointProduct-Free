package com.moniepoint.loans.cas.integrations.mixpanel.service;

import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelProfilePropertiesRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelResponse;
import com.moniepoint.loans.cas.module.analytics.entity.MixpanelApiKey;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Validated
public interface MixpanelIntegrationService {

    MixpanelResponse sendEventsToMixpanel(@Valid @NotNull List<MixpanelEventRequest> mixpanelEventRequests, String token);

    void updateProfileAttributes(@Valid @NotNull List<MixpanelProfilePropertiesRequest> requests);

    void failureHandler(@Valid @NotBlank String failureReason, @Valid @NotNull MixpanelEventRequest request);

    List<MixpanelEventRequest> identifyUnknownUsersByProfileProperties(List<MixpanelEventRequest> requests, MixpanelApiKey mixpanelApiKey);



}
