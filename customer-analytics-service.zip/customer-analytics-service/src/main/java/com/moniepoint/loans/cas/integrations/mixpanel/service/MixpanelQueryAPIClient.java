package com.moniepoint.loans.cas.integrations.mixpanel.service;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelQueryUserRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelQueryUserResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "mixpanel-query-api", configuration = FeignConfig.class, url = "${integrations.mixpanel.query-api-url:https://mixpanel.com/api/}")
public interface MixpanelQueryAPIClient {

    @PostMapping(value = "/query/engage", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    ResponseEntity<MixpanelQueryUserResponse> queryUserProfile(@RequestParam("project_id") String projectID, @RequestBody MixpanelQueryUserRequest request, @RequestHeader("Authorization") String authorizationToken);
}
