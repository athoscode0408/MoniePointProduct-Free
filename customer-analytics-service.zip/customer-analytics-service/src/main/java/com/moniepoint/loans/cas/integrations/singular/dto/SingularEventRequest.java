package com.moniepoint.loans.cas.integrations.singular.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

/**
 * Represents the payload for a server-to-server event sent to the Singular API.
 *
 * @see <a href="https://support.singular.net/hc/en-us/articles/31496864868635-Server-to-Server-EVENT-Endpoint-API-Reference">Singular S2S Event API Reference</a>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SingularEventRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String eventID;

    // --- Mandatory Fields ---

    private String idfv;

    private String aifa;

    private String sdid;

//    @JsonProperty("a")
//    private String apiKey;
    private String a;

//    @JsonProperty("p")
//    private String platform; // "android", "ios", or "web"
    private String p; // "android", "ios", or "web"


//    @JsonProperty("ip")
//    private String ipAddress;
    private String ip;


//    @JsonProperty("ve")
//    private String osVersion;
    private String ve;


//    @JsonProperty("ma")
//    private String deviceMake;
    private String ma;


//    @JsonProperty("mo")
//    private String deviceModel;
    private String mo;


//    @JsonProperty("lc")
//    private String deviceLocale;
    private String lc;


//    @JsonProperty("bd")
//    private String deviceBuild;
    private String bd;


//    @JsonProperty("i")
//    private String appIdentifier;
    private String i; // e.g., com.moniepoint.app


    private int att_authorization_status;

//    @JsonProperty("n")
//    private String eventName;
    private String n;


//    @JsonProperty("e")
//    private JsonNode eventAttributes;
    private String e;

    private String custom_user_id;

    @JsonProperty("is_revenue_event")
    private Boolean is_revenue_event;

    private Double amt;

    private String cur;

    private Boolean use_ip;

}
