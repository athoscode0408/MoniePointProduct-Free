package com.moniepoint.loans.cas.integrations.singular.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SingularResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String status; // "ok" or "error"
    private String reason;

    private List<String> results;

    @JsonProperty("unrecognized_params")
    private List<String> unrecognizedParams;
}