package com.moniepoint.loans.cas.integrations.singular.service;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularEventRequest;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularResponse;
import datadog.trace.api.Trace;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "singular-service", url = "${integrations.singular.base-url:https://s2s.singular.net/}", configuration = FeignConfig.class)
public interface SingularClient {

    /**
     * Sends a server-to-server event to Singular.
     */
    @GetMapping("/api/v1/evt")
    @Trace
    ResponseEntity<SingularResponse> sendEvent(@SpringQueryMap SingularEventRequest eventRequest);
}
