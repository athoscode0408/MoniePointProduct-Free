package com.moniepoint.loans.cas.integrations.singular.service;

import com.moniepoint.loans.cas.integrations.singular.dto.SingularEventRequest;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

@Validated
public interface SingularIntegrationService {
    boolean sendEvent(@Valid @NotNull SingularEventRequest eventRequest);

    void failureHandler(@Valid @NotBlank String failureReason, @Valid @NotNull SingularEventRequest request);
}
