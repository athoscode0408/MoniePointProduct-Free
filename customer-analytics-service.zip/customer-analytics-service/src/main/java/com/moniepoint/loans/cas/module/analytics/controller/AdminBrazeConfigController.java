package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.BrazeApiKeyRequest;
import com.moniepoint.loans.cas.module.analytics.service.impl.BrazeConfigService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/admin/braze-api-key-config")
@RequiredArgsConstructor
@Slf4j
public class AdminBrazeConfigController {

    private final BrazeConfigService brazeConfigService;

    @PostMapping
    public ResponseEntity<Long> createBrazeApiKeyMapping(@RequestBody List<BrazeApiKeyRequest> requests) {
        log.info("Creating {} braze api key configs", requests.size());
        brazeConfigService.createBrazeApiKeys(requests);
        return ResponseEntity.ok().build();
    }

    @PutMapping
    public ResponseEntity<Long> updateBrazeApiKeys(@RequestBody BrazeApiKeyRequest request) throws BadRequestException {
        if ( request.getId() == null || request.getId() <= 0L)
        {
            return ResponseEntity.badRequest().build();
        }
        log.info("Updating braze api key config with id {} ", request.getId());
        brazeConfigService.updateBrazeApiKeys(request);
        return ResponseEntity.accepted().build();
    }
}
