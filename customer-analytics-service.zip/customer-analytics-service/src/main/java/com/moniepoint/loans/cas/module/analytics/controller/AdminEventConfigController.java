package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.EventConfigDTO;
import com.moniepoint.loans.cas.module.analytics.service.impl.EventConfigService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/internal/admin/event")
@RequiredArgsConstructor
@Slf4j
@Validated
public class AdminEventConfigController {

    private static final String NULL_EVENTS_MESSAGE = "Events list must not be null";

    private final EventConfigService eventConfigService;

    @PostMapping
    public ResponseEntity<Long> createEvent(@RequestBody @Valid List<EventConfigDTO> events) throws BadRequestException {
        validateEvents(events);
        log.info("Creating {} events configurations", events.size());
        eventConfigService.createEventConfig(events);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> blacklistEvent(@RequestBody @Valid List<EventConfigDTO> events) throws BadRequestException {
        validateEvents(events);
        log.info("Blacklisting {} event configurations", events.size());
        eventConfigService.removeEventConfig(events);
        return ResponseEntity.ok().build();
    }

    private void validateEvents(List<EventConfigDTO> events) throws BadRequestException {
        if (events == null) {
            throw new BadRequestException(NULL_EVENTS_MESSAGE);
        }
    }

}
