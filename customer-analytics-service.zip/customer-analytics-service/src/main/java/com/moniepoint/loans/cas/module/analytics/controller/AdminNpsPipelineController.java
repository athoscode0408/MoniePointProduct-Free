package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.NpsPipelineTriggerRequest;
import com.moniepoint.loans.cas.outbound.airflow.AirflowDagTriggerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/admin/nps/pipeline")
@RequiredArgsConstructor
@Slf4j
@Profile({"cloud_dev", "dev", "staging"})
public class AdminNpsPipelineController {

    private final AirflowDagTriggerService airflowDagTriggerService;

    @PostMapping("/trigger")
    public ResponseEntity<Void> triggerPipeline(@RequestBody(required = false) NpsPipelineTriggerRequest request) {
        String isoWeek = request != null ? request.getIsoWeek() : null;
        log.info("Admin trigger received for NPS pipeline isoWeek={}", isoWeek);
        airflowDagTriggerService.triggerNpsPipeline(isoWeek);
        return ResponseEntity.accepted().build();
    }
}