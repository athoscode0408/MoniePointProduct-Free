package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.SurveyCreateRequest;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.service.SurveyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// for survey setup

@RestController
@RequestMapping("/internal/admin/surveys")
@RequiredArgsConstructor
@Slf4j
@Profile({"cloud_dev", "dev", "staging", "test"})
public class AdminSurveyController {

    private final SurveyService surveyService;

    @PostMapping
    public ResponseEntity<Long> createSurvey(@RequestBody SurveyCreateRequest request) {
        log.info("Creating survey with priority {} and locationWeb={}", request.getPriority(), request.getLocationWeb());
        Survey saved = surveyService.createSurvey(request);
        return ResponseEntity.ok(saved.getId());
    }

    @PutMapping
    public ResponseEntity<Long> updateSurvey(@RequestBody SurveyCreateRequest request) {
        if ( request.getId() == null || request.getId() <= 0L)
        {
            return ResponseEntity.badRequest().build();
        }
        log.info("Updating survey with id {} ", request.getId());
        surveyService.updateSurvey(request);
        return ResponseEntity.accepted().build();
    }
}
