package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/push-event")
    @PreAuthorize("hasAuthority(@Authorities.CAN_PUSH_ANALYTICS_EVENT)")
    public AnalyticsEventResponseDTO pushEvent(@RequestBody @Valid AnalyticsEventV1RequestDTO analyticsEventRequest) {
        return analyticsService.pushEvent(analyticsEventRequest);
    }
}
