package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeCanvasResponse;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeAuthResponse;
import com.moniepoint.loans.cas.module.analytics.service.impl.BrazeAuthHandler;
import com.moniepoint.loans.cas.module.analytics.service.impl.BrazeCampaignsHandler;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
@Slf4j
public class BrazeController {

    private final BrazeCampaignsHandler brazeCampaignsHandler;
    private final BrazeAuthHandler brazeAuthHandler;


    @GetMapping("/campaign")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_CAMPAIGN)")
    public ResponseEntity<BrazeCanvasResponse> fetchCanvasDetails(@RequestParam @NotBlank String id ) {
        log.info("Received fetch canvas details request with id {} ",id);
        return brazeCampaignsHandler.fetchCanvas(id);
    }

    @GetMapping("/braze/auth")
    public ResponseEntity<BrazeAuthResponse> getBrazeAuth(@AuthenticationPrincipal AuthenticatedUser user) {
        log.info("Received getBrazeAuth request for user {} ",user.getUsername());
        return brazeAuthHandler.generateAuth(user.getUsername());
    }
}
