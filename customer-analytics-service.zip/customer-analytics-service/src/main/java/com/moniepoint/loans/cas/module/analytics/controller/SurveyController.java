package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyAlertsResponse;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyHistoryResponse;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveySchemaDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.repository.service.PreprocessedSurveyRepositoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.coyote.BadRequestException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

import static com.moniepoint.loans.cas.common.util.ApplicationConstants.NULL_USER_ID_MESSAGE;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/surveys")
@Slf4j
public class SurveyController {

    private final PreprocessedSurveyRepositoryService preprocessedSurveyRepositoryService;

    @GetMapping("/dashboard-info")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<SurveyAlertsResponse> getDashboardInfo(@AuthenticationPrincipal AuthenticatedUser user, @RequestHeader(value = "moniepointAgentId") String moniepointAgentId) throws BadRequestException {
        String userId = user != null ? user.getUsername() : null;
        if (StringUtils.isBlank(userId)) {
            throw new BadRequestException(NULL_USER_ID_MESSAGE);
        }
        log.info("Received request to fetch dashboard info for user {} and agent id {}", userId, moniepointAgentId);
        return ResponseEntity.ok(preprocessedSurveyRepositoryService.fetchSurveyAlerts(userId, moniepointAgentId));
    }

    @GetMapping(value = "/dashboard-info", params = {"username", "moniepointAgentId"})
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<SurveyAlertsResponse> getDashboardInfoByParams(
            @RequestParam String username,
            @RequestParam String moniepointAgentId) throws BadRequestException {
        if (StringUtils.isBlank(username)) {
            throw new BadRequestException(NULL_USER_ID_MESSAGE);
        }
        log.info("Received request to fetch dashboard info for user {} and agent id {}", username, moniepointAgentId);
        return ResponseEntity.ok(preprocessedSurveyRepositoryService.fetchSurveyAlerts(username, moniepointAgentId));
    }

    @GetMapping("/user")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<List<PreprocessedSurveyDTO>> getSurveysByUserId(@AuthenticationPrincipal AuthenticatedUser user) throws BadRequestException {
        String username = user != null ? user.getUsername() : null;
        if (StringUtils.isBlank(username))
        {
            throw new BadRequestException("Username is required in authentication token");
        }
        log.info("Received api request to fetch survey for user {}",username);
        List<PreprocessedSurveyDTO> preprocessedSurveyDTOS = preprocessedSurveyRepositoryService.fetchSurveysByUserId(username);
        log.info("Returning response {} to api request for user {}",preprocessedSurveyDTOS.size(),username);
        return ResponseEntity.ok(preprocessedSurveyDTOS);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<PreprocessedSurveyDTO> getSurveyById(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id) throws BadRequestException {
        String userId = user != null ? user.getUsername() : null;
        if (StringUtils.isBlank(userId))
        {
            throw new BadRequestException(NULL_USER_ID_MESSAGE);
        }
        log.info("Received api request to fetch survey by id {} for user {}",id, userId);
        PreprocessedSurveyDTO preprocessedSurveyDTO = preprocessedSurveyRepositoryService.fetchSurveyById(id);
        log.debug("Returning response {} to api request for user {}",preprocessedSurveyDTO ,userId);
        return preprocessedSurveyDTO == null || !(preprocessedSurveyDTO.getUser().equalsIgnoreCase(userId)) ? ResponseEntity.notFound().build() : ResponseEntity.ok(preprocessedSurveyDTO);
    }

    @GetMapping("/{surveyId}/history")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<SurveyHistoryResponse> getSurveyHistory(
            @AuthenticationPrincipal AuthenticatedUser user,
            @PathVariable Long surveyId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) throws BadRequestException {
        String userId = user != null ? user.getUsername() : null;
        if (StringUtils.isBlank(userId)) {
            throw new BadRequestException(NULL_USER_ID_MESSAGE);
        }
        log.info("Received request to fetch survey history for user {} surveyId {} between {} and {}", userId, surveyId, startDate, endDate);
        return ResponseEntity.ok(preprocessedSurveyRepositoryService.fetchSurveyHistory(userId, surveyId, startDate, endDate));
    }

    @GetMapping("/schema/{surveyId}")
    @PreAuthorize("hasAuthority(@Authorities.CAN_FETCH_SURVEY)")
    public ResponseEntity<SurveySchemaDTO> getSurveySchema(
            @AuthenticationPrincipal AuthenticatedUser user,
            @PathVariable Long surveyId,
            @ModelAttribute UserAttributes userAttributes) throws BadRequestException {
        String userId = user != null ? user.getUsername() : null;
        if (StringUtils.isBlank(userId)) {
            throw new BadRequestException(NULL_USER_ID_MESSAGE);
        }
        log.info("Received request to fetch survey schema for surveyId {} from user {}",
                surveyId, userId);
        if (!new UserAttributes().equals(userAttributes)) {
            log.info("Request user attributes: {}", userAttributes);
        }
        SurveySchemaDTO schema = preprocessedSurveyRepositoryService.fetchSurveySchema(surveyId, userId, userAttributes);
        return schema == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(schema);
    }

}
