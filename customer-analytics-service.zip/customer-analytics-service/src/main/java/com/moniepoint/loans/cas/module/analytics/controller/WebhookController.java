package com.moniepoint.loans.cas.module.analytics.controller;

import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateGoalDTO;
import com.moniepoint.loans.cas.outbound.rewards.RewardsCampaignResponse;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalMarkerDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalDeactivationDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignByDomainDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserRewardEventDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeCloseCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.service.impl.WebhookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/webhook")
@Slf4j
public class WebhookController {

    private final WebhookService webhookService;

    @PostMapping("/braze/assign-campaign")
    public ResponseEntity<RewardsCampaignResponse> assignUserToCampaign(@RequestBody @Valid BrazeUserCampaignDTO brazeUserCampaignDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received assign-campaign webhook from braze for user {}", brazeUserCampaignDTO.getCustomerIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.processRewardAssignCampaign(brazeUserCampaignDTO, secret);
        log.info("Response returned to client on assign-campaign {}", response);
        return response;
    }

    @PostMapping("/braze/stop-campaign")
    public ResponseEntity<RewardsCampaignResponse> removeUserFromCampaign(@RequestBody @Valid BrazeUserCampaignDTO brazeUserCampaignDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received stop-campaign webhook from braze for user {}", brazeUserCampaignDTO.getCustomerIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.processRewardStopCampaign(brazeUserCampaignDTO, secret);
        log.info("Response returned to client on stop-campaign {}", response);
        return response;
    }

    @PostMapping("/braze/campaigns")
    public ResponseEntity<RewardsCampaignResponse> createCampaign(@RequestBody @Valid BrazeUserCreateCampaignDTO brazeUserCreateCampaignDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received create campaign webhook from braze for user {}", brazeUserCreateCampaignDTO.getCampaignIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.createRewardCampaign(brazeUserCreateCampaignDTO, secret);
        log.info("Response returned to client on create campaign {}", response);
        return response;
    }

    @PostMapping("/braze/goals")
    public ResponseEntity<RewardsCampaignResponse> createGoal(@RequestBody @Valid BrazeUserCreateGoalDTO brazeUserCreateGoalDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received create goal webhook from braze for user {}", brazeUserCreateGoalDTO.getCampaignIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.createRewardGoal(brazeUserCreateGoalDTO, secret);
        log.info("Response returned to client on create goal {}", response);
        return response;
    }

    @PostMapping("/braze/mark-goal")
    public ResponseEntity<RewardsCampaignResponse> markGoal(@RequestBody @Valid BrazeUserGoalMarkerDTO brazeUserGoalMarkerDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received mark goal webhook from braze for goal identifier {}", brazeUserGoalMarkerDTO.getGoalIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.markRewardGoal(brazeUserGoalMarkerDTO, secret);
        log.info("Response returned to client on mark goal {}", response);
        return response;
    }

    @PostMapping("/braze/deactivate-goal")
    public ResponseEntity<RewardsCampaignResponse> deactivateGoal(@RequestBody @Valid BrazeUserGoalDeactivationDTO brazeUserGoalDeactivationDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received deactivate goal webhook from braze for customer identifier {}", brazeUserGoalDeactivationDTO.getCustomerIdentifier());
        ResponseEntity<RewardsCampaignResponse> response = webhookService.deactivateRewardGoal(brazeUserGoalDeactivationDTO, secret);
        log.info("Response returned to client on deactivate goal {}", response);
        return response;
    }

    @PostMapping("/braze/assign-by-domain")
    public ResponseEntity<RewardsCampaignResponse> assignCampaignByDomain(@RequestBody @Valid BrazeUserCampaignByDomainDTO brazeUserCampaignByDomainDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received assign campaign by domain webhook from braze for campaign identifier {}",brazeUserCampaignByDomainDTO.getCampaignIdentifier());
        ResponseEntity<RewardsCampaignResponse>  response = webhookService.assignRewardCampaignByDomain(brazeUserCampaignByDomainDTO, secret);
        log.info("Response returned to client on assign campaign by domain {}", response);
        return response;
    }

    @PostMapping("/braze/event-reward")
    public ResponseEntity<RewardsCampaignResponse> rewardUserByEvent(@RequestBody @Valid BrazeUserRewardEventDTO brazeUserRewardEventDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received reward-event webhook from braze for user {}",brazeUserRewardEventDTO.getEventUserId());
        ResponseEntity<RewardsCampaignResponse>  response = webhookService.rewardEvent(brazeUserRewardEventDTO, secret);
        log.info("Response returned to client on reward-event {}", response);
        return response;
    }

    @PostMapping("/braze/close-campaign")
    public ResponseEntity<RewardsCampaignResponse> closeCampaign(@RequestBody @Valid BrazeCloseCampaignDTO brazeCloseCampaignDTO, @RequestHeader("X-Secret-Key") String secret) {
        log.info("Received close campaign webhook from braze for campaign identifier {}",brazeCloseCampaignDTO.getCampaignIdentifier());
        ResponseEntity<RewardsCampaignResponse>  response = webhookService.closeRewardCampaign(brazeCloseCampaignDTO, secret);
        log.info("Response returned to client on close campaign {}", response);
        return response;
    }

}
