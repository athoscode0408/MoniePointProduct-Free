package com.moniepoint.loans.cas.module.analytics.controller.v1;

import com.moniepoint.loans.cas.module.analytics.dto.v1.BrazeAllowedEventsResponse;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class WhitelistedEventsController {

    private final AnalyticsService analyticsService;

    @ResponseStatus(HttpStatus.OK)
    @GetMapping("/white-listed-events")
    public BrazeAllowedEventsResponse getWhitelistedBrazeEvents() {
        return analyticsService.getPubliclyAllowedBrazeEvents();
    }

}
