package com.moniepoint.loans.cas.module.analytics.controller.v2;

import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v2")
public class AnalyticsControllerV2 {

    private final AnalyticsService analyticsService;
    private final ModelMapper modelMapper;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/push-event")
    @PreAuthorize("hasAuthority(@Authorities.CAN_PUSH_ANALYTICS_EVENT)")
    public AnalyticsEventResponseDTO pushEvent(@RequestBody @Valid AnalyticsEventV2RequestDTO analyticsEventV2Request) {
        analyticsService.pushEvents(List.of(analyticsEventV2Request));
        return AnalyticsEventResponseDTO.builder().success(true).build();

    }

}
