package com.moniepoint.loans.cas.module.analytics.controller.v3;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.common.util.HTTPUtils;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import datadog.trace.api.Trace;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v3")
@Slf4j
public class AnalyticsControllerV3 {

    private final AnalyticsService analyticsService;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/event")
    @PreAuthorize("!isAuthenticated() || hasAuthority(@Authorities.CAN_PUSH_ANALYTICS_EVENT)")
    public AnalyticsEventResponseDTO pushEvent(
            @AuthenticationPrincipal AuthenticatedUser user,
            @RequestBody @Valid BaseAnalyticsEventRequestDTO<?> request,
            HttpServletRequest httpServletRequest) {
        return pushEvents(user, List.of(request), httpServletRequest);
    }

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/events")
    @PreAuthorize("!isAuthenticated() || hasAuthority(@Authorities.CAN_PUSH_ANALYTICS_EVENT)")
    public AnalyticsEventResponseDTO pushEvents(
            @AuthenticationPrincipal AuthenticatedUser user,
            @RequestBody @Valid List<BaseAnalyticsEventRequestDTO<?>> request,
            HttpServletRequest httpServletRequest
    ) {
        log.debug("Received customer analytics event from api with id of first request {}",request.getFirst().getId());
        String defaultIp = HTTPUtils.getIPAddress(httpServletRequest);
        request.forEach(r -> {
            if (StringUtils.isBlank(r.getIp())) {
                r.setIp(defaultIp);
            }
            r.setUserIdentifiers(getUserEventIdentifier(r,user));
        });
        long t0 = System.nanoTime();
        analyticsService.pushEvents(request);
        long t1 = System.nanoTime();
        log.debug("timings ns:submit={}", (t1-t0));
        return AnalyticsEventResponseDTO.builder().success(true).build();

    }


    @Trace
    private UserEventIdentifier getUserEventIdentifier(BaseAnalyticsEventRequestDTO<?> request, AuthenticatedUser user) {
        String userID = user != null ? user.getUsername() : null;
        String email = user != null ? user.getEmail() : null;
        String phone = user != null ? user.getPhone() : null;
        String name = user != null ? String.format("%s %s", user.getFirstName(), user.getLastName()) : null;
        if (StringUtils.isBlank(userID) && request.getUserIdentifiers() != null)
        {
            userID = request.getUserIdentifiers().getUserID();
            email = request.getUserIdentifiers().getEmail();
            phone = request.getUserIdentifiers().getPhone();
            name = request.getUserIdentifiers().getName();
        }
        return new UserEventIdentifier(null, userID, email, phone, name);
    }
}
