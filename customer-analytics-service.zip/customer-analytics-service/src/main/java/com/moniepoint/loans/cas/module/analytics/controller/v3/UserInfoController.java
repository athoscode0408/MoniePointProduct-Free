package com.moniepoint.loans.cas.module.analytics.controller.v3;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.module.analytics.dto.UserInfoResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.analytics.service.SessionService;
import com.moniepoint.loans.cas.module.analytics.service.impl.SessionServiceImpl;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v3")
@Slf4j
public class UserInfoController {

    private final SessionService sessionService;

    @ResponseStatus(HttpStatus.OK)
    @PostMapping("/user-info")
    @PreAuthorize("!isAuthenticated() || hasAuthority(@Authorities.CAN_PUSH_ANALYTICS_EVENT)")
    public UserInfoResponseDTO userInfo(@AuthenticationPrincipal AuthenticatedUser user, @RequestBody @Valid AnalyticsEventV3DeviceInfoDTO request) {
        String userID = user != null ? user.getUsername() : null;
        String sessionID = StringUtils.isBlank(request.getId()) ? SessionServiceImpl.generateSessionID() : sessionService.generateSessionID(request.getId(), userID);
        return new UserInfoResponseDTO(userID, sessionID);
    }
}
