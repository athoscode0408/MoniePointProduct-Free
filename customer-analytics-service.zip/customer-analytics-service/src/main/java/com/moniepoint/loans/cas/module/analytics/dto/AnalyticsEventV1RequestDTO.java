package com.moniepoint.loans.cas.module.analytics.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventEnvironment;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventPlatform;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Timestamp;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsEventV1RequestDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Event id can't be empty")
    private String id;

    @NotBlank(message = "Event type can't be empty")
    private String eventType;

    @NotNull(message = "Event timestamp can't be null")
    private Timestamp timestamp;

    @ValidEventEnvironment
    private String appEnv;

    @ValidEventPlatform
    private String platform;

    @NotNull(message = "Event data can't be null")
    private JsonNode data;

}
