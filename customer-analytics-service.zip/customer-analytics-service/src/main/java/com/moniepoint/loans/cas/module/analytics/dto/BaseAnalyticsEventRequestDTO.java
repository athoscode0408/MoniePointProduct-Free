package com.moniepoint.loans.cas.module.analytics.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.moniepoint.loans.cas.common.util.EpochTimestampDeserializer;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventEnvironment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.sql.Timestamp;
import java.util.List;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "dtoVersion",
        visible = true,
        defaultImpl = AnalyticsEventV2RequestDTO.class
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = AnalyticsEventV2RequestDTO.class, name = "v2"),
        @JsonSubTypes.Type(value = AnalyticsEventV3RequestDTO.class, name = "v3")
})
@Data
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public abstract class BaseAnalyticsEventRequestDTO<T> {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Pattern(regexp = "^(v2|v3)$", message = "Invalid dtoVersion. Accepted values: v2, v3")
    private String dtoVersion;

    @NotBlank(message = "Event id can't be empty")
    private String id;

    @NotBlank(message = "Event type can't be empty")
    private String eventType;

    @ValidEventEnvironment
    private String appEnv;

    @NotNull(message = "Event timestamp can't be null")
    @JsonDeserialize(using = EpochTimestampDeserializer.class)
    private Timestamp timestamp;

    private String customerIdentifier;

    private UserEventIdentifier userIdentifiers;

    /**
     * Optional field to override IP address from the header
     * This allows backend services to push events from multiple users/devices using the API
     */
    private String ip;

    private Double longitude;

    private Double latitude;

    private T data;

    private UserAttributes userAttributes;

    private List<EventProvider> excludeProviders;

    private String platform;

    private String appDomain;

    private String applicationID;

}
