package com.moniepoint.loans.cas.module.analytics.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrazeApiKeyRequest {

    private Long id;

    @NotBlank(message = "app id can't be empty.")
    private String applicationID;

    @NotNull(message = "app domain can't be empty.")
    private String appDomain;

    @NotNull(message = "api key can't be empty.")
    private String apiKey;

}
