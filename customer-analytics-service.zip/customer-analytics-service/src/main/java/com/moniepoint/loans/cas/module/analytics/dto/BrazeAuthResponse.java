package com.moniepoint.loans.cas.module.analytics.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeAuthResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private String message;

    private String access_token;

    private String token_type;

    private int expires_in;
}
