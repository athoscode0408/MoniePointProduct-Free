package com.moniepoint.loans.cas.module.analytics.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeUserCampaignDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Campaign identifier can't be empty")
    private String campaignIdentifier;

    @NotBlank(message = "Customer identifier can't be empty")
    private String customerIdentifier;

    @NotBlank(message = "Webhook reference can't be empty")
    private String webhookReference;

}
