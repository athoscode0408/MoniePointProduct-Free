package com.moniepoint.loans.cas.module.analytics.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeUserCreateCampaignDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Campaign identifier is required")
    private String campaignIdentifier;

    @NotBlank(message = "Campaign external identifier is required")
    private String campaignExternalIdentifier;

    @NotBlank(message = "Base64String Campaign image is required")
    private String campaignImage;

    @NotBlank(message = "Base64String Campaign details image is required")
    private String campaignDetailsImage;

    @NotBlank(message = "Campaign description is required")
    private String campaignDescription;

    @NotBlank(message = "Campaign title is required")
    private String campaignTitle;

    @NotBlank(message = "Banner Id is required")
    private String bannerId;

    private String domain;

    @JsonIgnore
    @Builder.Default
    private LocalDateTime campaignStatDate = LocalDateTime.now();

    @NotNull(message = "Campaign end date is required")
    private LocalDateTime campaignEndDate;

    @NotNull(message = "Campaign priority is required")
    @Min(value = 0, message = "Campaign priority must range between 0 and 5")
    @Max(value = 5, message = "Campaign priority must range between 0 and 5")
    private Integer priority;
}
