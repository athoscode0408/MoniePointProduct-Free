package com.moniepoint.loans.cas.module.analytics.dto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeUserCreateGoalDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Campaign identifier can not be empty")
    private String campaignIdentifier;
    @NotEmpty
    private List<@Valid Goal> goals;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Goal {
        @NotBlank(message = "Reward code can not be empty")
        private String rewardCode;

        @NotBlank(message = "Goal type is required")
        private String goalType;

        @NotBlank(message = "Goal identifier can not be empty")
        private String code;

        @NotBlank(message = "Goal title can not be empty")
        private String title;

        @NotBlank(message = "Goal description can not be empty")
        private String description;

        @NotNull(message = "Expected occurrences is required")
        @Positive(message = "Expected occurrence should only be positive number")
        private Integer expectedOccurrences;

        private String deepLink;

        @NotBlank(message = "Goal frequency is required")
        private String goalFrequency;

        @NotBlank(message = "Reward mode is required")
        private String rewardMode;

        @NotBlank(message = "Reward manager  is required")
        private String goalManager;

        @NotNull(message = "Days Till Expiry is required")
        @Positive(message = "Days Till Expiry for goal should only be positive number")
        private Integer daysTillExpiry;

        private List<Long> businessIds;
    }
}
