package com.moniepoint.loans.cas.module.analytics.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeUserGoalMarkerDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "goal identifier is required")
    private String goalIdentifier;

    @NotBlank(message = "Customer identifier is required")
    private String customerIdentifier;

    @NotBlank(message = "Event source domain is required")
    private String eventSourceDomain;

    private BigDecimal amount;

    private Long businessId;

    private Long eventPerformedAtSecs;
}
