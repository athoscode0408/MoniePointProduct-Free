package com.moniepoint.loans.cas.module.analytics.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class BrazeUserRewardEventDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Event name can't be empty")
    private String eventName;

    @Builder.Default
    private String eventSource = "BRAZE"; // CUSTOMER_IO/BRAZE

    @NotBlank(message = "Customer identifier can't be empty")
    private String eventUserId;

    @Builder.Default
    private String eventUserIdType = "USERNAME";

    @NotBlank(message = "Event reference can't be empty")
    private String eventReferenceId;

    @NotNull(message = "Reward Event metadata can't be empty")
    @Valid
    private RewardEventMetadataDTO metadata;

}
