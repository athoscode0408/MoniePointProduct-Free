package com.moniepoint.loans.cas.module.analytics.dto;

import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder(toBuilder = true)
public class EventRetryDataDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Event id can't be empty.")
    private String eventId;

    @NotNull(message = "Event provider can't be null.")
    private EventProvider eventProvider;

    @NotBlank(message = "Failure reason can't be empty.")
    private String failureReason;

    @NotBlank(message = "Event data can't be empty.")
    private String eventData;
}
