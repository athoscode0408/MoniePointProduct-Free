package com.moniepoint.loans.cas.module.analytics.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder
public class EventRetryIDRangeDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotNull(message = "Start can't be null.")
    @Min(value = 1, message = "Start can't be less than 1.")
    private Long start;

    @NotNull(message = "End can't be null.")
    @Min(value = 1, message = "End can't be less than 1.")
    private Long end;
}
