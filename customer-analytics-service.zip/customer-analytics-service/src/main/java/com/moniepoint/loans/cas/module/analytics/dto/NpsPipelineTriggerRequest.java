package com.moniepoint.loans.cas.module.analytics.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class NpsPipelineTriggerRequest {

    @JsonProperty("iso_week")
    private String isoWeek;
}