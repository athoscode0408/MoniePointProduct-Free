package com.moniepoint.loans.cas.module.analytics.dto;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serial;
import java.io.Serializable;

import jakarta.validation.constraints.NotBlank;




@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class RewardEventMetadataDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "domain can't be empty")
    private String domain; // consumer/business
}
