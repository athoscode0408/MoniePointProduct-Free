package com.moniepoint.loans.cas.module.analytics.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SurveyCreateRequest {

    private Long id;

    @NotBlank(message = "rule can't be empty.")
    private String rule;

    @NotNull(message = "priority can't be null.")
    private Integer priority;

    /**
     * The raw survey JSON structure. It will be stored as text in the DB.
     */
    @NotNull
    private Map<String, Object> survey;

    @NotBlank(message = "locationWeb can't be empty.")
    private String locationWeb;

    @NotBlank(message = "locationMobile can't be empty.")
    private String locationMobile;
}
