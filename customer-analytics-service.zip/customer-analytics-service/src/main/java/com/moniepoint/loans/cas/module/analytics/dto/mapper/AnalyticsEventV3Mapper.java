package com.moniepoint.loans.cas.module.analytics.dto.mapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class AnalyticsEventV3Mapper {
    private final ObjectMapper objectMapper;

    public AnalyticsEventRequestDTO mapToAnalyticsEventRequestDTO(AnalyticsEventV3RequestDTO v3RequestDTO) {
        try {

            JsonNode data = objectMapper.convertValue(v3RequestDTO.getData(), JsonNode.class);
            JsonNode properties = data == null ? null : objectMapper.convertValue(data.path("properties"), JsonNode.class);

            String appDomain = extractAppDomain(v3RequestDTO,data,properties);

            String phone = extractPhone(v3RequestDTO,properties);
            if (v3RequestDTO.getUserAttributes() != null) {
                v3RequestDTO.getUserAttributes().setPhone(phone);
            }
            else
            {
                UserAttributes userAttributes = UserAttributes.builder()
                        .phone(phone).build();
                v3RequestDTO.setUserAttributes(userAttributes);
            }

            return AnalyticsEventRequestDTO.builder()
                    .id(v3RequestDTO.getId())
                    .eventType(v3RequestDTO.getEventType())
                    .timestamp(v3RequestDTO.getTimestamp())
                    .appEnv(v3RequestDTO.getAppEnv())
                    .ip(v3RequestDTO.getIp())
                    .platform(Optional.ofNullable(v3RequestDTO.getData())
                            .map(platformData -> platformData.getDevice() == null ? null : platformData.getDevice().getType()).orElse(null))
                    .platformv2(v3RequestDTO.getPlatform())
                    .data(data)
                    .customerIdentifier(v3RequestDTO.getCustomerIdentifier())
                    .userIdentifiers(v3RequestDTO.getUserIdentifiers())
                    .userAttributes(v3RequestDTO.getUserAttributes())
                    .applicationID(v3RequestDTO.getApplicationID())
                    .longitude(v3RequestDTO.getLongitude())
                    .latitude(v3RequestDTO.getLatitude())
                    .excludeProviders(v3RequestDTO.getExcludeProviders())
                    .appDomain(appDomain)
                    .build();
        } catch (Exception e) {
            log.error("Error mapping AnalyticsEventV3RequestDTO to AnalyticsEventRequestDTO: {}", e.getMessage());
            throw new IllegalArgumentException("Error in mapping analytics event");
        }
    }

    private String extractAppDomain(AnalyticsEventV3RequestDTO v3RequestDTO, JsonNode data, JsonNode properties) {
        if (StringUtils.isNotBlank(v3RequestDTO.getAppDomain())) {
            return v3RequestDTO.getAppDomain();
        }

        if (properties != null) {
            String propertiesAppDomain = properties.path("app_domain").asText(null);
            if (StringUtils.isNotBlank(propertiesAppDomain)) {
                return propertiesAppDomain;
            }
        }

        if (data != null) {
            return data.path("app_domain").asText(null);
        }

        return null;
    }

    private String extractPhone(AnalyticsEventV3RequestDTO v3RequestDTO, JsonNode properties) {
        if (v3RequestDTO.getUserAttributes() != null && StringUtils.isNotBlank(v3RequestDTO.getUserAttributes().getPhone())) {
            return v3RequestDTO.getUserAttributes().getPhone();
        }

        if (properties != null) {
            return properties.path("phone_number").asText(null);
        }
        return null;
    }

}
