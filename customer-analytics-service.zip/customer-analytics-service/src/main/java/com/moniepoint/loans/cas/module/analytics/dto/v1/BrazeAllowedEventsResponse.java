package com.moniepoint.loans.cas.module.analytics.dto.v1;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BrazeAllowedEventsResponse implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @JsonProperty("expires_at")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant expiresAt;

    @JsonProperty("allowed_events")
    private List<String> allowedEvents;

}
