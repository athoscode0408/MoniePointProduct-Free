package com.moniepoint.loans.cas.module.analytics.dto.v2;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventPlatform;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serial;
import java.io.Serializable;

@Data
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsEventV2RequestDTO extends BaseAnalyticsEventRequestDTO<JsonNode> implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @ValidEventPlatform
    private String platform;
}
