package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.Map;


@Data
@SuperBuilder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsEventV3DataDTO implements Serializable {
    @NotBlank(message = "Event name can't be empty")
    private String eventName;
    @NotBlank(message = "Event properties can't be empty")
    private Map<String, Object> properties;
    private Map<String, Object> meta;
    @NotBlank(message = "Device information can't be empty")
    private AnalyticsEventV3DeviceInfoDTO device;
}
