package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventPlatform;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

@Data
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsEventV3DeviceInfoDTO implements Serializable {
    @NotBlank(message = "Device id can't be empty")
    private String id;
    @ValidEventPlatform
    private String type;
    private String os;
    private String osVersion;
    private Integer dpi;
    private Integer height;
    private Integer width;
    private String manufacturer;
    private String model;
    private String locale;
    private String idfv;
    private String aifa;

    /**
     * Specific browser details
     */
    private String agent;
    private String agentVersion;
    private String url;
    private String referrer;

    /**
     * Specific app details
     */
    private String buildNumber;
    private String version;

    private Map<String, String> additionalInfo;
}
