package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class AnalyticsEventV3RequestDTO extends BaseAnalyticsEventRequestDTO<AnalyticsEventV3DataDTO> {
    private String applicationID;
    private String version;
    private String appDomain;
}
