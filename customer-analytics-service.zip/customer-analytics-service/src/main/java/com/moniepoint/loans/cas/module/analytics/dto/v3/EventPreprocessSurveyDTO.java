package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EventPreprocessSurveyDTO implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    private Survey survey;
    private UserAttributes userAttributes;
    private VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO;
    private PreprocessedSurvey preprocessedSurvey;
    private Long cohortId;

}
