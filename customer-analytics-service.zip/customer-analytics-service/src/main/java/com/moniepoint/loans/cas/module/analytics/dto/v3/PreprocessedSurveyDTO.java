package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.util.StdConverter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PreprocessedSurveyDTO implements Serializable {
    private Long id;
    private String user;
    private Long surveyId;
    private String survey;
    private String event;
    @JsonDeserialize(converter = TsToLdt.class)
    private LocalDateTime ttl;
    private int priority = 10;
    private String location;
    private String locationWeb;
    private String locationMobile;
    private String displayModalType;

    public static class TsToLdt extends StdConverter<Object, LocalDateTime> {
        @Override
        public java.time.LocalDateTime convert(Object value) {
            switch (value) {
                case null -> {
                    return null;
                }
                case java.sql.Timestamp ts -> {
                    return ts.toLocalDateTime().truncatedTo(ChronoUnit.SECONDS);
                }
                case Long l -> {
                    return java.time.Instant.ofEpochMilli(l)
                            .atZone(ZoneOffset.UTC)
                            .toLocalDateTime().truncatedTo(ChronoUnit.SECONDS);
                }
                case String s -> {
                    return LocalDateTime.parse(s, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                            .truncatedTo(ChronoUnit.SECONDS);
                }
                case List<?> arr -> {
                    int year   = ((Number) arr.get(0)).intValue();
                    int month  = ((Number) arr.get(1)).intValue();
                    int day    = ((Number) arr.get(2)).intValue();
                    int hour   = ((Number) arr.get(3)).intValue();
                    int minute = ((Number) arr.get(4)).intValue();
                    int second = arr.size() > 5 ? ((Number) arr.get(5)).intValue() : 0;
                    return LocalDateTime.of(year, month, day, hour, minute, second)
                            .truncatedTo(ChronoUnit.SECONDS);
                }
                default -> throw new IllegalArgumentException("Unsupported type for LocalDateTime: " + value.getClass());
            }
        }
    }

}
