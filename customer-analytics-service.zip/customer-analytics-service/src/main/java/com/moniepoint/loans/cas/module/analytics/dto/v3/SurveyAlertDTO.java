package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveyAlertDTO {
    private String id;
    private String type;
    private String icon;
    private int priority;
    private String title;
    private String message;
    private Action action;
    @JsonProperty("isDismissible")
    private boolean dismissible;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Action {
        private String label;
        private String target;
    }
}
