package com.moniepoint.loans.cas.module.analytics.dto.v3;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class SurveyAlertsResponse {
    private List<SurveyAlertDTO> alerts;
}
