package com.moniepoint.loans.cas.module.analytics.dto.v3;


import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveyBody {

    private boolean assignBanner;

    private String bannerId;

    private Long responseWindowUniqueSurveyMins;

    private int maxCountUniqueSurveyInResponseWindow;

    private int preprocessedSurveyTTL;

    private boolean randomizeSurveyAssignment;

    private boolean generateUniqueSurveyPerBRM;

    private boolean enableAlertingAfterDismissal;

    private String alertingCondition;

    private String alertType;

    private String alertIcon;

    private int alertPriority;

    private String alertTitle;

    private String alertMessage;

    private String alertActionLabel;

    private boolean alertDismissible;

    private String displayModalType;

    private Timestamp alertStartTime;

    private Long displayDelayPeriodInSecs;

    private int reminderMinIntervalHours;

    private Q2CopyByBand q2CopyByBand;

    private Map<String, Object> customAttributes;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Q2CopyByBand {
        private String detractor;
        private String passive;
        private String promoter;
    }

    @JsonAnySetter
    public void addCustomAttributes(String name, Object value) {
        if (customAttributes == null) {
            customAttributes = new HashMap<>();
        }
        customAttributes.put(name, value);
    }

    @JsonAnyGetter
    public Map<String, Object> getCustomAttributes() {
        return customAttributes;
    }

}
