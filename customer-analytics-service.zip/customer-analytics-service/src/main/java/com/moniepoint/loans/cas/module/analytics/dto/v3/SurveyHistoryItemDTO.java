package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class SurveyHistoryItemDTO {
    private Long id;
    private String event;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime ttl;
    private PreprocessedSurveyState state;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime completedOn;
    private Object additionalData;
}
