package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.JsonRawValue;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SurveySchemaDTO {
    private Long id;
    @JsonRawValue
    private String survey;
    private Long preprocessedSurveyId;
}
