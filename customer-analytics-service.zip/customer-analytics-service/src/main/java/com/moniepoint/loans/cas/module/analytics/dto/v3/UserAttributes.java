package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserAttributes implements Serializable {
    private String email;
    @JsonAlias({"phone_number", "phone"})
    private String phone;
    private String name;
    private String type;
    @JsonAlias("first_name")
    private String firstName;
    @JsonAlias("last_name")
    private String lastName;
    @JsonAlias("date_of_birth")
    private Timestamp dateOfBirth;
    @JsonAlias("kyc_level")
    private String kycLevel;
    @JsonAlias("user_name")
    private String userName;
    private String city;
    private String state;
    private String lga;
    @JsonAlias("nuban_account_number")
    private String nubanAccountNumber;
    private String religion;
    @JsonAlias("employment_status")
    private String employmentStatus;
    @JsonAlias("marital_status")
    private String maritalStatus;
    @JsonAlias("onboarding_mode")
    private String onboardingMode;
    @JsonAlias("onboarding_type")
    private String onboardingType;
    @JsonAlias("prm_name")
    private String prmName;
    @JsonAlias("prm_phone_number")
    private String prmPhoneNumber;
    @JsonAlias("sc_name")
    private String scName;
    @JsonAlias("sc_phone_number")
    private String scPhoneNumber;
    @JsonAlias("rm_name")
    private String rmName;
    @JsonAlias("rm_phone_number")
    private String rmPhoneNumber;
    @JsonAlias("device_id")
    private String deviceId;
    @JsonAlias("device_type")
    private String deviceType;
    @JsonAlias("app_version")
    private String appVersion;
    @JsonAlias("app_domain")
    private String appDomain;
    private String platform;
    @JsonAlias("onboarding_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime onboardingDate;
    @JsonAlias("business_name")
    private String businessName;
    @JsonAlias("business_nuban_account_number")
    private String businessNubanAccountNumber;
    @JsonAlias("business_classification")
    private String businessClassification;
    @JsonAlias("business_type")
    private String businessType;
    @JsonAlias("business_category")
    private String businessCategory;
    @JsonAlias("brm_name")
    private String brmName;
    @JsonAlias("brm_id")
    private String brmId;
    @JsonAlias("brm_phone_number")
    private String brmPhoneNumber;
    @JsonAlias("terminal_id")
    private String terminalId;
    @JsonAlias("last_txn_date")
    private LocalDate lastTxnDate;
    @JsonAlias("brm_image")
    private String brmImage;

    @JsonIgnore
    private Map<String, Object> customAttributes;

    @JsonAnySetter
    public void addCustomAttributes(String name, Object value) {
        if (customAttributes == null) {
            customAttributes = new HashMap<>();
        }
        customAttributes.put(name, value);
    }

    @JsonAnyGetter
    public Map<String, Object> getCustomAttributes() {
        return customAttributes;
    }

    public void update(UserAttributes attributes) {
        if (attributes == null) {
            return;
        }
        for (Field field : UserAttributes.class.getDeclaredFields()) {
            field.setAccessible(true);
            try {
                Object newValue = field.get(attributes);
                if (newValue instanceof String) {
                    if (StringUtils.isBlank((String) field.get(this))  &&  StringUtils.isNotBlank((String) newValue)) {
                        field.set(this, newValue);
                    }
                } else if (newValue instanceof Map) {
                    Map in = (Map) newValue;
                    if (in.isEmpty()) continue;
                    Map merged;
                    Object current = field.get(this);
                    if ( current instanceof Map) {
                        merged = new java.util.LinkedHashMap((Map) current);
                        merged.putAll(in);
                    } else {
                        merged = new java.util.LinkedHashMap(in);
                    }
                    field.set(this, merged);
                } else if (field.get(this) == null && newValue != null) {
                    field.set(this, newValue);
                }
            } catch (IllegalAccessException e) {
                // do nothing
            }
        }
    }

}
