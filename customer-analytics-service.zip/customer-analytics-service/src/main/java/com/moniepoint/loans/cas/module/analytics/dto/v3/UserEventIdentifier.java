package com.moniepoint.loans.cas.module.analytics.dto.v3;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;
import java.util.UUID;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(toBuilder = true)
public class UserEventIdentifier implements Serializable {
    private final String sessionID;

    private String userID;
    private String email;
    private String phone;
    private String name;

    public UserEventIdentifier() {
        this.sessionID = UUID.randomUUID().toString();
    }
}
