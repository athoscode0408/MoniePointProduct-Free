package com.moniepoint.loans.cas.module.analytics.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "analytics_event_providers")
public class AnalyticsEventProvider extends BaseEntity {

    @Column(name = "provider_name", nullable = false, length = 50)
    private String providerName;

    @Enumerated(EnumType.STRING)
    @Column(name = "provider_key", nullable = false, unique = true)
    private EventProvider providerKey;

    @ManyToMany(mappedBy = "providers")
    @Builder.Default
    @JsonIgnore
    private Set<SupportedEvent> events = new HashSet<>();

    @Override
    public boolean equals(Object o) {
        return super.equals(o);

    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

}
