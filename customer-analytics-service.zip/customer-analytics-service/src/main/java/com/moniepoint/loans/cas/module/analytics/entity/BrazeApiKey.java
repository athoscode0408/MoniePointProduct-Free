package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "braze_api_keys")
public class BrazeApiKey extends BaseEntity {


    @Column(name = "api_key", nullable = false, length = 50)
    private String apiKey;

    @Column(name = "application_id", nullable = false)
    private String applicationID;

    @Column(name = "app_domain")
    private String appDomain;


}
