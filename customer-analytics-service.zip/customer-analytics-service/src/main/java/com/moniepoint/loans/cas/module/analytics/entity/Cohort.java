package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyPlatform;
import com.moniepoint.loans.cas.module.analytics.enums.SurveySegment;
import com.moniepoint.loans.cas.module.analytics.enums.converter.SurveyCategoryConverter;
import com.moniepoint.loans.cas.module.analytics.enums.converter.SurveyPlatformConverter;
import com.moniepoint.loans.cas.module.analytics.enums.converter.SurveySegmentConverter;
import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Table(name = "cohort")
public class Cohort extends BaseEntity {

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "survey_id", nullable = false)
    private Long surveyId;

    @Column(name = "rule_definition", columnDefinition = "JSON")
    private String ruleDefinition;

    @Column(name = "compiled_clickhouse_sql", columnDefinition = "TEXT")
    private String compiledClickhouseSql;

    @Column(name = "sampling_config", columnDefinition = "JSON")
    private String samplingConfig;

    @Column(name = "survey_category", nullable = false)
    @Convert(converter = SurveyCategoryConverter.class)
    @Builder.Default
    private SurveyCategory surveyCategory = SurveyCategory.NPS;

    @Column(name = "segment", nullable = false)
    @Convert(converter = SurveySegmentConverter.class)
    private SurveySegment segment;

    @Column(name = "platform", nullable = false)
    @Convert(converter = SurveyPlatformConverter.class)
    private SurveyPlatform platform;

    @Column(nullable = false)
    private boolean active;
}
