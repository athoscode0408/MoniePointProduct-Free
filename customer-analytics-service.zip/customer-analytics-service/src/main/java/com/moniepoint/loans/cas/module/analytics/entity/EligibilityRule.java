package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.module.analytics.enums.EligibilityRuleType;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "eligibility_rule")
public class EligibilityRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cohort_id", nullable = false)
    private Long cohortId;

    @Column(name = "rule_order", nullable = false)
    private int ruleOrder;

    @Enumerated(EnumType.STRING)
    @Column(name = "rule_type", nullable = false, length = 50)
    private EligibilityRuleType ruleType;

    @Column(name = "rule_config", nullable = false, columnDefinition = "JSON")
    private String ruleConfig;

    @Column(nullable = false)
    private boolean active = true;

    @Column(name = "created_on", nullable = false)
    private LocalDateTime createdOn;
}
