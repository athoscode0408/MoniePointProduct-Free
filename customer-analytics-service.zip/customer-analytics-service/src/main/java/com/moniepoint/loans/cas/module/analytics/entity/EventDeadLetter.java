package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "event_dead_letter")
public class EventDeadLetter extends BaseEntity {

    @Column(name = "event_id", unique = true, nullable = false, length = 50)
    private String eventId;

    @Column(name = "event_data", nullable = false)
    private String eventData;

    @Column(name = "provider_key", nullable = false)
    @Enumerated(EnumType.STRING)
    private EventProvider eventProvider;

    @Column(name = "last_retry_time", nullable = false)
    private LocalDateTime lastRetryTime;

    @Column(name = "last_failure_reason", nullable = false)
    private String lastFailureReason;

    @Override
    public boolean equals(Object o) {
        return super.equals(o);

    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

}
