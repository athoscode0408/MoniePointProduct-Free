package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "mixpanel_api_keys")
public class MixpanelApiKey extends BaseEntity {


    @Column(name = "api_secret", nullable = false, length = 100)
    private String apiSecret;

    @Column(name = "project_id", nullable = false, length = 50)
    private String projectID;

    @Column(name = "project_token", nullable = false, length = 50)
    private String projectToken;

    @Column(name = "application_id", nullable = false)
    private String applicationID;

}
