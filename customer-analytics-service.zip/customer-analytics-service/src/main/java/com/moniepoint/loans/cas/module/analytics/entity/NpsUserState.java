package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Table(
        name = "nps_user_state",
        uniqueConstraints = @UniqueConstraint(name = "uq_nus_user_id", columnNames = {"user_id"})
)
public class NpsUserState extends BaseEntity {

    @Column(name = "user_id", nullable = false, length = 50)
    private String userId;

    @Column(name = "user_name", nullable = false, length = 50)
    private String userName;

    @Column(name = "last_nps_triggered_date")
    private LocalDate lastNpsTriggeredDate;

    @Column(name = "trigger_year")
    private Integer triggerYear;

    @Column(name = "trigger_count_year", nullable = false)
    @Builder.Default
    private int triggerCountYear = 0;

    @Column(name = "last_nps_response_classification", length = 20)
    private String lastNpsResponseClassification;
}
