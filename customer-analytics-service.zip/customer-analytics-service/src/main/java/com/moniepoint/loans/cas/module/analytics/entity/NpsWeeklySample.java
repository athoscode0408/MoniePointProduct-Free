package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.enums.converter.NpsSampleStatusConverter;
import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Table(
        name = "nps_weekly_sample",
        uniqueConstraints = @UniqueConstraint(
                name = "uq_nws_user_cohort_week",
                columnNames = {"user_id", "cohort_id", "iso_week"}
        ),
        indexes = @Index(
                name = "idx_nws_cohort_week_status",
                columnList = "cohort_id, iso_week, status"
        )
)
public class NpsWeeklySample extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "user_name", nullable = false)
    private String userName;

    @Column(name = "cohort_id", nullable = false)
    private Long cohortId;

    @Column(name = "iso_week", nullable = false, length = 8)
    private String isoWeek;

    @Column(name = "status", nullable = false)
    @Convert(converter = NpsSampleStatusConverter.class)
    @Builder.Default
    private NpsSampleStatus status = NpsSampleStatus.PENDING;

    @Column(name = "served_at")
    private Timestamp servedAt;

    @Column(name = "dismissed_at")
    private Timestamp dismissedAt;

    @Column(name = "reminder_served_at")
    private Timestamp reminderServedAt;

    @Column(name = "responded_at")
    private Timestamp respondedAt;
}
