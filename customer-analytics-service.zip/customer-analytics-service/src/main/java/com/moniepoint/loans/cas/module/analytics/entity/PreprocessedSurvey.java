package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import jakarta.persistence.*;
import lombok.*;
import org.apache.commons.lang3.StringUtils;

import java.sql.Timestamp;
import java.time.Instant;
@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "preprocessed_survey")
public class PreprocessedSurvey extends BaseEntity {


    @Column(name = "user", nullable = false, length = 50)
    private String user;

    @Column(name = "event", nullable = false)
    private String event;

    @Column(name = "priority", nullable = false)
    private int priority = 10;

    @Column(name = "survey_id", nullable = false, length = 50)
    private Long surveyId;

    @Column(name = "survey", nullable = false)
    private String survey;

    @Column(name = "ttl", nullable = false)
    private Timestamp ttl;

    @Column(name = "location", nullable = false)
    private String location;

     @Column(name = "state", length = 50)
     @Enumerated(EnumType.STRING)
     private PreprocessedSurveyState state;

     @Column(name = "completed_on")
     private Timestamp completedOn;

    @Column(name = "additional_data")
    private String additionalData;

    @Column(name = "cohort_id")
    private Long cohortId;

    @Column(name = "iso_week", length = 8)
    private String isoWeek;

    public Instant getTTLAsInstant() {
        return ttl.toInstant();
    }

    public boolean isSampledNPSSurvey() {
        return StringUtils.isNotBlank(isoWeek);
    }
}
