package com.moniepoint.loans.cas.module.analytics.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.moniepoint.loans.cas.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Getter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "supported_events")
public class SupportedEvent extends BaseEntity {

    @Column(name = "event_type", unique = true, nullable = false, length = 100)
    private String eventType;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(
            name = "providers_event_types",
            joinColumns = @JoinColumn(name = "event_type_id"),
            inverseJoinColumns = @JoinColumn(name = "provider_id")
    )
    @Builder.Default
    private Set<AnalyticsEventProvider> providers = new HashSet<>();

    @ManyToMany(mappedBy = "supportedEvents")
    @Builder.Default
    @JsonIgnore
    private Set<SupportedUserAttributes> eventUserAttributes = new HashSet<>();

    @Override
    public boolean equals(Object o) {
        return super.equals(o);

    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

}
