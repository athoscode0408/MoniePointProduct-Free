package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "survey")
public class Survey extends BaseEntity {
    @Column(name = "rule", nullable = false)
    private String rule;

    @Column(name = "priority", nullable = false)
    private int priority = 10;

    @Column(name = "survey", nullable = false)
    private String survey;

    @Column(name = "location_web",nullable = false)
    private String webLocation;

    @Column(name = "location_mobile",nullable = false)
    private String mobileLocation;


    @Column(name = "category")
    @Enumerated(EnumType.STRING)
    private SurveyCategory category;

    @Column(name = "start")
    private Timestamp start;

    @Column(name = "duration_days")
    private Integer durationInDays ;
}
