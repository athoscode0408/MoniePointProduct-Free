package com.moniepoint.loans.cas.module.analytics.entity;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Data
@Entity
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "survey_alert")
public class SurveyAlert extends BaseEntity {

    @Column(name = "user", nullable = false, length = 50)
    private String user;

    @Column(name = "preprocessed_survey_id", nullable = false)
    private Long preprocessedSurveyId;

    @Column(name = "survey_id")
    private Long surveyId;

    @Column(name = "account_number", nullable = false, length = 50)
    private String accountNumber;

    @Column(name = "moniepoint_agent_id", nullable = false, length = 50)
    private String moniepointAgentId;

    @Column(name = "ttl", nullable = false)
    private Timestamp ttl;

    @Column(name = "event", nullable = false)
    private String event;

    @Column(name = "alert_type")
    private String alertType;

    @Column(name = "alert_icon")
    private String alertIcon;

    @Column(name = "alert_priority")
    private int alertPriority;

    @Column(name = "alert_title")
    private String alertTitle;

    @Column(name = "alert_message")
    private String alertMessage;

    @Column(name = "alert_action_label")
    private String alertActionLabel;

    @Column(name = "alert_dismissible")
    private boolean alertDismissible;

    @Column(name = "alert_start_time")
    private Timestamp alertStartTime;
}
