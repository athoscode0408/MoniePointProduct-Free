package com.moniepoint.loans.cas.module.analytics.enums;

public enum EligibilityRuleType {
    COOL_OFF,
    ANNUAL_CAP,
    CROSS_PROGRAMME_CAP
}