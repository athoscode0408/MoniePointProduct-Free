package com.moniepoint.loans.cas.module.analytics.enums;

public enum EventProvider {

    MIX, CIO, GA, BRAZE, SIN

}
