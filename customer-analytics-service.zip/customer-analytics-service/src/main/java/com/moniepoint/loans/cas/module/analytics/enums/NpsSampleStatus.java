package com.moniepoint.loans.cas.module.analytics.enums;

public enum NpsSampleStatus {
    PENDING,
    GENERATED,
    SERVED,
    DISMISSED,
    REMINDER_SERVED,
    RESPONDED,
    CHECKPOINT,
    EXPIRED,
    ABANDONED
}
