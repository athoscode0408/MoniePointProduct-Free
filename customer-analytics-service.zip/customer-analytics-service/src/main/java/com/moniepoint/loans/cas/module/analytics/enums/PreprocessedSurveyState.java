package com.moniepoint.loans.cas.module.analytics.enums;

public enum PreprocessedSurveyState {
    NOT_READY, NOT_COMPLETED, COMPLETED, EXPIRED, ABANDONED, DISMISSED
}
