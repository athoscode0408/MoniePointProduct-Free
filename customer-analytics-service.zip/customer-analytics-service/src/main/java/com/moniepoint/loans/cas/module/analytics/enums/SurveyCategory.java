package com.moniepoint.loans.cas.module.analytics.enums;

public enum SurveyCategory {

    BRM, CSAT, NPS

}
