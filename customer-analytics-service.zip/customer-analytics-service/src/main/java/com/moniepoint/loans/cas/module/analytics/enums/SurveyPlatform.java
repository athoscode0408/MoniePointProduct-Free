package com.moniepoint.loans.cas.module.analytics.enums;

public enum SurveyPlatform {
    MOBILE,
    WEB,
    POS
}