package com.moniepoint.loans.cas.module.analytics.enums;

public enum SurveySegment {
    PERSONAL,
    BUSINESS
}