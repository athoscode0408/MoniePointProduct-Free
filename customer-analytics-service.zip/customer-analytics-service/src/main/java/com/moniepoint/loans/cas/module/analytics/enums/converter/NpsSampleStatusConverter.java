package com.moniepoint.loans.cas.module.analytics.enums.converter;

import com.moniepoint.loans.cas.common.entity.converter.StringEnumConverter;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import jakarta.persistence.Converter;

@Converter
public class NpsSampleStatusConverter extends StringEnumConverter<NpsSampleStatus> {
    protected NpsSampleStatusConverter() {super(NpsSampleStatus.class);}
}
