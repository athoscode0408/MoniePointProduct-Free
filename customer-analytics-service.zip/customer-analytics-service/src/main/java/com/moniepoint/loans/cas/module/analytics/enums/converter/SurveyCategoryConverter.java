package com.moniepoint.loans.cas.module.analytics.enums.converter;

import com.moniepoint.loans.cas.common.entity.converter.StringEnumConverter;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import jakarta.persistence.Converter;

@Converter
public class SurveyCategoryConverter extends StringEnumConverter<SurveyCategory> {
    protected SurveyCategoryConverter() { super(SurveyCategory.class); }
}
