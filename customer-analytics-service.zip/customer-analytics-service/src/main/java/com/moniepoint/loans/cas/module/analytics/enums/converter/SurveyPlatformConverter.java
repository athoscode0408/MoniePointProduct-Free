package com.moniepoint.loans.cas.module.analytics.enums.converter;

import com.moniepoint.loans.cas.common.entity.converter.StringEnumConverter;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyPlatform;
import jakarta.persistence.Converter;

@Converter
public class SurveyPlatformConverter extends StringEnumConverter<SurveyPlatform> {
    protected SurveyPlatformConverter() { super(SurveyPlatform.class); }
}