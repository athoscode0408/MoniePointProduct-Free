package com.moniepoint.loans.cas.module.analytics.enums.converter;

import com.moniepoint.loans.cas.common.entity.converter.StringEnumConverter;
import com.moniepoint.loans.cas.module.analytics.enums.SurveySegment;
import jakarta.persistence.Converter;

@Converter
public class SurveySegmentConverter extends StringEnumConverter<SurveySegment> {
    protected SurveySegmentConverter() { super(SurveySegment.class); }
}