package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AnalyticsEventProviderRepository  extends JpaRepository<AnalyticsEventProvider, Long> {
    @Query("SELECT p FROM AnalyticsEventProvider p LEFT JOIN FETCH p.events")
    List<AnalyticsEventProvider> findAllWithEvents();
    Optional<AnalyticsEventProvider> findByProviderKey(EventProvider providerKey);

}
