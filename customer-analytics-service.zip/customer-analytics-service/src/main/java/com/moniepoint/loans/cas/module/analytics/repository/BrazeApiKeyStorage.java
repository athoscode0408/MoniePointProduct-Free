package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.BrazeApiKey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrazeApiKeyStorage extends JpaRepository<BrazeApiKey, Long> {
}

