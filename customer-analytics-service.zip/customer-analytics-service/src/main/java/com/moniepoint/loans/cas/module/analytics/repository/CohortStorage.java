package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.Cohort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CohortStorage extends JpaRepository<Cohort, Long> {

    List<Cohort> findByActiveTrue();
}
