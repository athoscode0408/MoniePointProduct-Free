package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EligibilityRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EligibilityRuleStorage extends JpaRepository<EligibilityRule, Long> {

    @Query("SELECT r FROM EligibilityRule r WHERE r.cohortId = :cohortId AND r.active = true ORDER BY r.ruleOrder")
    List<EligibilityRule> findActiveByCohortId(@Param("cohortId") Long cohortId);
}
