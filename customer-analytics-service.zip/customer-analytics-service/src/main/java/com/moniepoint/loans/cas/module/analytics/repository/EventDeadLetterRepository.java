package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EventDeadLetterRepository extends JpaRepository<EventDeadLetter, Long> {
    Optional<EventDeadLetter> findByEventIdAndEventProvider(String eventId, EventProvider eventProvider);
}

