package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EventRetryRepository extends JpaRepository<EventRetry, Long> {
    Optional<EventRetry> findByEventIdAndEventProvider(String eventId, EventProvider eventProvider);

    @Query("SELECT MIN(er.id) FROM EventRetry er")
    Long findMinId();

    @Query(value = """
      SELECT MAX(t.id)
      FROM (
          SELECT er.id
          FROM event_retries er
          WHERE er.id >= :startId
          ORDER BY er.id ASC
          LIMIT :limit
      ) AS t
      """, nativeQuery = true)
    Long findMaxId(Long startId, Long limit);

    @Query("SELECT e.id FROM EventRetry e WHERE e.id BETWEEN :startId AND :endId")
    Page<Long> findIdsInRange(@Param("startId") Long startId, @Param("endId") Long endId, Pageable pageable);

    @Query("SELECT e.id as id, e.createdOn as createdOn FROM EventRetry e WHERE e.id > :cursor ORDER BY e.id ASC")
    List<EventRetryView> findBatchAfter(@Param("cursor") Long cursor, Pageable pageable);
}

