package com.moniepoint.loans.cas.module.analytics.repository;

import java.sql.Timestamp;

public interface EventRetryView {
    Long getId();
    Timestamp getCreatedOn();
}
