package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.MixpanelApiKey;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MixpanelApiKeyStorage extends JpaRepository<MixpanelApiKey, Long> {
    Optional<MixpanelApiKey> findByApplicationID(String applicationId);

}

