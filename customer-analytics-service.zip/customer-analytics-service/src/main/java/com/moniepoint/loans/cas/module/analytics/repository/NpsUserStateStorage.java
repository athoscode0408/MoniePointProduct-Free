package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface NpsUserStateStorage extends JpaRepository<NpsUserState, Long> {

    Optional<NpsUserState> findByUserName(String userName);
}
