package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface NpsWeeklySampleStorage extends JpaRepository<NpsWeeklySample, Long> {

    Optional<NpsWeeklySample> findByUserIdAndIsoWeek(Long userId, String isoWeek);

    Optional<NpsWeeklySample> findByUserNameAndIsoWeek(String userName, String isoWeek);

    @Query("SELECT s FROM NpsWeeklySample s WHERE s.isoWeek = :isoWeek AND s.status = :status")
    List<NpsWeeklySample> findPendingByIsoWeek(
            @Param("isoWeek") String isoWeek,
            @Param("status") NpsSampleStatus status
    );

    @Modifying
    @Query("UPDATE NpsWeeklySample s SET s.status = :newStatus WHERE s.isoWeek <= :isoWeek AND s.status = :currentStatus")
    int updateStatusByIsoWeekLessThanEqualAndCurrentStatus(
            @Param("isoWeek") String isoWeek,
            @Param("currentStatus") NpsSampleStatus currentStatus,
            @Param("newStatus") NpsSampleStatus newStatus
    );

    @Modifying
    @Query("UPDATE NpsWeeklySample s SET s.status = :newStatus WHERE s.id IN :ids AND s.status = :currentStatus")
    int updateStatusByIds(
            @Param("ids") List<Long> ids,
            @Param("currentStatus") NpsSampleStatus currentStatus,
            @Param("newStatus") NpsSampleStatus newStatus
    );
}
