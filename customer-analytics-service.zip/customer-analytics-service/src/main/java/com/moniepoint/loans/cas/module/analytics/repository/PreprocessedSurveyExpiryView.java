package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;

import java.sql.Timestamp;

public interface PreprocessedSurveyExpiryView {
    Long getId();
    PreprocessedSurveyState getState();
    Timestamp getTtl();
}
