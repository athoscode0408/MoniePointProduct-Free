package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface PreprocessedSurveyStorage extends JpaRepository<PreprocessedSurvey, Long> {
    Optional<PreprocessedSurvey> findPreprocessedSurveyByUserAndIdAndStateIn(String userId, Long id, List<PreprocessedSurveyState> preprocessedSurveyStates);
    List<PreprocessedSurvey> findByUserAndStateInAndTtlAfter(String user, List<PreprocessedSurveyState> state, Timestamp now);
    Optional<PreprocessedSurvey> findByIdAndStateInAndTtlAfter(Long id, List<PreprocessedSurveyState> state, Timestamp now);
    List<PreprocessedSurvey>  findByUserAndStateInOrUserAndCompletedOnAfter(String user,List<PreprocessedSurveyState> preprocessedSurveyStates, String user2, Timestamp cutoff);
    List<PreprocessedSurvey> findByUserAndSurveyIdAndLastModifiedOnBetween(String user, Long surveyId, Timestamp startDate, Timestamp endDate);
    List<PreprocessedSurvey> findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(String user, Long surveyId, List<PreprocessedSurveyState> states, Timestamp now);
    Optional<PreprocessedSurvey> findFirstByUserAndSurveyIdAndStateInAndTtlAfter(String user, Long surveyId, List<PreprocessedSurveyState> states, Timestamp now);

    Optional<PreprocessedSurvey> findFirstByUserAndIsoWeekAndStateIn(String user, String isoWeek, List<PreprocessedSurveyState> states);


    @Modifying
    @Transactional
    @Query(value = """
      UPDATE preprocessed_survey
      SET state = 'EXPIRED'
      WHERE ttl < NOW()
      AND state in ('NOT_COMPLETED', 'NOT_READY')
      ORDER BY id ASC
      LIMIT :limit
      """, nativeQuery = true)
    int expirePreprocessedSurveys(@Param("limit") Long limit);

    @Query("""
            SELECT p.id as id, p.state as state, p.ttl as ttl
            FROM PreprocessedSurvey p
            WHERE p.id > :startId AND p.state IN :eligibleStates
            ORDER BY p.id ASC
            """)
    List<PreprocessedSurveyExpiryView> findBatchStartingAfter(
            @Param("startId") Long startId,
            @Param("eligibleStates") Collection<PreprocessedSurveyState> eligibleStates,
            Pageable pageable);

    @Modifying
    @Transactional
    @Query("UPDATE PreprocessedSurvey p SET p.state = 'EXPIRED' WHERE p.id IN :ids")
    int expireByIds(@Param("ids") Collection<Long> ids);
}

