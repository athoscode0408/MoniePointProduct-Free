package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SupportedEventRepository extends JpaRepository<SupportedEvent, Long> {
    Optional<SupportedEvent> findByEventType(String eventType);
}

