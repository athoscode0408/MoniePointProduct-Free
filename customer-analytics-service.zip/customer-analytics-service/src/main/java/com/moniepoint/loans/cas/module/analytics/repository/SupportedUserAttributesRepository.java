package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.SupportedUserAttributes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SupportedUserAttributesRepository extends JpaRepository<SupportedUserAttributes, Long> {
    @Query("SELECT sua.attribute from SupportedUserAttributes sua join sua.supportedEvents se where se.eventType = :event")
    List<String> findAllByEvent(String event);
    Optional<SupportedUserAttributes> findByAttribute(String userAttribute);

}

