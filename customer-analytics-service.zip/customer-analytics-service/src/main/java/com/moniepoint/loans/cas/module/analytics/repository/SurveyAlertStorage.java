package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.SurveyAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;

public interface SurveyAlertStorage extends JpaRepository<SurveyAlert, Long> {
    List<SurveyAlert> findByUserAndMoniepointAgentIdAndTtlAfter(String user, String moniepointAgentId, Timestamp now);
    List<SurveyAlert> findByPreprocessedSurveyId(Long preprocessedSurveyId);
    @Transactional("primaryTx")
    @Modifying
    void deleteByPreprocessedSurveyId(Long preprocessedSurveyId);
}
