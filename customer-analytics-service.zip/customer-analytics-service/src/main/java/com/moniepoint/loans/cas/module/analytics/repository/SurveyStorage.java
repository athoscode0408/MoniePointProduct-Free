package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SurveyStorage extends JpaRepository<Survey, Long> {
}
