package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.UnsupportedEvent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnsupportedEventRepository extends JpaRepository<UnsupportedEvent, Long> {

}

