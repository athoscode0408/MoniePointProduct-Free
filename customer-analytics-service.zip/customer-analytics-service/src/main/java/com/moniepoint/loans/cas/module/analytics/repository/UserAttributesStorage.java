package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;

public interface UserAttributesStorage {

    UserAttributes findUser(String userId, String businessNubanAccountNumber);

//    UserAttributes findUser(String userId);


}
