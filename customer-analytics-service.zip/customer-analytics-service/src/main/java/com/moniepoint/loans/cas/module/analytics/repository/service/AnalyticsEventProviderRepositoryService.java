package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.AnalyticsEventProviderRepository;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AnalyticsEventProviderRepositoryService {

    private final AnalyticsEventProviderRepository analyticsEventProviderRepository;
    private final CacheService cacheService;
    private final ObjectMapperHelper objectMapperHelper;


    public Set<AnalyticsEventProvider> getAllAnalyticsEventProviders() {
        Set<AnalyticsEventProvider> analyticsProviders = getAllAnalyticsEventProvidersFromCache();
        if (analyticsProviders.isEmpty()){
            analyticsProviders = getAllAnalyticsEventProvidersFromDb();
            saveToCache(analyticsProviders);
        }
        return analyticsProviders;
    }

    public List<String> getAllowListedEventTypes(EventProvider provider) {
        return getAllowLists().getOrDefault(provider, List.of());
    }

    public Map<String, Collection<EventProvider>> getSupportedEventProviders(Collection<String> eventTypes) {
        var allowLists = getAllowLists();

        return eventTypes.stream().collect(Collectors.toMap(
                event -> event,
                event -> allowLists.entrySet().stream()
                        .filter(p ->
                                CollectionUtils.isEmpty(p.getValue()) || p.getValue().contains(event)
                        ).map(Map.Entry::getKey).collect(Collectors.toSet()),
                (eventType1, eventType2) -> eventType1
        ));
    }

    @Trace
    private Map<EventProvider, List<String>> getAllowLists() {
        String cachedString = cacheService.getCachedString(CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY);
        if (StringUtils.isBlank(cachedString)) {
            var allow = analyticsEventProviderRepository.findAllWithEvents().stream().collect(Collectors.toMap(
                    AnalyticsEventProvider::getProviderKey,
                    p -> p.getEvents().stream().map(SupportedEvent::getEventType).toList(),
                    (v1, v2) -> v1
            ));
            log.info("AllowList returned from db {}", allow);
            cacheService.cacheString(CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY, objectMapperHelper.serializeToString(allow));
            return allow;
        }
        log.info("AllowList returned from cache {}", cachedString);
        return objectMapperHelper.deserializeStringToObject(cachedString, new TypeReference<>() {
        });
    }

    private Set<AnalyticsEventProvider> getAllAnalyticsEventProvidersFromCache() {
        String cachedString = cacheService.getCachedString(CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY);
        if (Objects.isNull(cachedString)) {
            return Collections.emptySet();
        } else {
            return objectMapperHelper.deserializeStringToObject(cachedString, new TypeReference<>() {});
        }
    }

    private Set<AnalyticsEventProvider> getAllAnalyticsEventProvidersFromDb() {
        return new HashSet<>(analyticsEventProviderRepository.findAll());
    }

    private void saveToCache(Set<AnalyticsEventProvider> providers) {
        String serialized = objectMapperHelper.serializeToString(providers);
        cacheService.cacheString(CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY, serialized);
    }

}
