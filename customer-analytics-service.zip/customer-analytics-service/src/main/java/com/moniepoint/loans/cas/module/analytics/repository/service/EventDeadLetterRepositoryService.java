package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.EventDeadLetterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EventDeadLetterRepositoryService {

    private final EventDeadLetterRepository eventDeadLetterRepository;

    @Transactional("retryTx")
    public Optional<EventDeadLetter> findByEventIdAndEventProvider(String eventId, EventProvider eventProvider) {
        return eventDeadLetterRepository.findByEventIdAndEventProvider(eventId, eventProvider);
    }

    @Transactional("retryTx")
    public EventDeadLetter save(EventDeadLetter eventDeadLetter) {
        return eventDeadLetterRepository.save(eventDeadLetter);
    }

    @Transactional("retryTx")
    public void deleteAllEventDeadLetter(){
        eventDeadLetterRepository.deleteAll();
    }

}
