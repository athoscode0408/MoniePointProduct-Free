package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryRepository;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryView;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EventRetryRepositoryService {

    private final EventRetryRepository eventRetryRepository;

    @Transactional("retryTx")
    public Optional<EventRetry> findByEventIdAndEventProvider(String eventId, EventProvider eventProvider) {
        return eventRetryRepository.findByEventIdAndEventProvider(eventId, eventProvider);
    }

    @Transactional("retryTx")
    public EventRetry save(EventRetry eventRetry) {
        return eventRetryRepository.save(eventRetry);
    }

    @Transactional("retryTx")
    public Long findMinEventRetryId(){
        return eventRetryRepository.findMinId();
    }

    @Transactional("retryTx")
    public Long findMaxEventRetryId(Long startId, Long limit){
        return eventRetryRepository.findMaxId(startId, limit);
    }

    @Transactional("retryTx")
    public Page<Long> fetchPaginatedIdsInRange(Long start, Long end, int currentPage, int pageSize){
        Pageable pageable = PageRequest.of(currentPage, pageSize, Sort.by("id").ascending());
        return eventRetryRepository.findIdsInRange(start, end, pageable);
    }

    @Transactional("retryTx")
    public void deleteById(Long id) {
        eventRetryRepository.deleteById(id);
    }

    @Transactional("retryTx")
    public Optional<EventRetry> findEventRetryById(Long eventRetryId) {
        return eventRetryRepository.findById(eventRetryId);
    }

    @Transactional("retryTx")
    public List<EventRetryView> findBatchAfter(Long cursor, int batchSize) {
        return eventRetryRepository.findBatchAfter(cursor, PageRequest.of(0, batchSize));
    }

    @Transactional("retryTx")
    public void deleteAllByIds(Collection<Long> ids) {
        eventRetryRepository.deleteAllByIdInBatch(ids);
    }
}
