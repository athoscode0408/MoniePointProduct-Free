package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.IsoWeekUtil;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.*;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.SurveyAlert;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyAlertStorage;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySampleService;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState.DISMISSED;
import static com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState.NOT_COMPLETED;

@Service
@Slf4j
@RequiredArgsConstructor
public class PreprocessedSurveyRepositoryService {

    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    private final PreprocessedSurveyStorage preprocessedSurveyRepository;
    private final ObjectMapperHelper objectMapperHelper;
    private final RedisCacheServiceImpl cache;
    private final SurveyRepositoryService surveyRepositoryService;
    private final UserAttributesStorage userStorage;
    private final SurveyAlertStorage surveyAlertStorage;
    private final NpsWeeklySampleService npsWeeklySampleService;

    @Value("${survey.image-location-url}")
    private String imageLocationUrl;

    @Trace
    public List<PreprocessedSurveyDTO> fetchSurveysByUserId(String username) {
        List<PreprocessedSurveyDTO> cached = cache.getAllPreprocessedSurveys(username);
        if (!cached.isEmpty()) {
            return cached;
        }

        log.debug("Surveys for user {} not available in cache. Fetching from database", username);
        Timestamp now = Timestamp.from(Instant.now());
        List<PreprocessedSurvey> entities = preprocessedSurveyRepository
                .findByUserAndStateInAndTtlAfter(username, List.of(NOT_COMPLETED, DISMISSED), now);

        serveNpsSurveyIfDue(username, entities);

        List<PreprocessedSurveyDTO> dtos = entities.stream()
                .map(survey -> {
                    try {
                        PreprocessedSurveyDTO dto = objectMapperHelper.convertObjectToType(survey, new TypeReference<>() {});
                        SurveyBody surveyBody = objectMapperHelper.deserializeStringToObject(survey.getSurvey(), new TypeReference<>() {});
                        dto.setDisplayModalType(surveyBody.getDisplayModalType());
                        enrichWithSurveyLocations(dto);
                        return dto;
                    } catch (ServerException e) {
                        log.error("Failed to deserialize survey body for preprocessed survey id {} for user {}. Expiring survey. Reason: {}",
                                survey.getId(),
                                username,
                                e.getMessage(),
                                e);
                        // MK: this is done to reduce the error rate we are seeing in survey endpoints.
                        // but ideally GET APIs shouldn't modify the server state, we need to identify all
                        // generated surveys and expire them either with a job or using a manual db migration script
                        // then remove this logic; PO-349 tracks this work
                        expireSurvey(survey.getId());
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        cache.cacheAllPreprocessedSurveys(username, dtos);
        return dtos;
    }

    private void serveNpsSurveyIfDue(String username, List<PreprocessedSurvey> entities) {
        String currentIsoWeek = IsoWeekUtil.current(LAGOS);
        boolean hasCurrentWeekNpsSurvey = entities.stream()
                .anyMatch(survey -> currentIsoWeek.equals(survey.getIsoWeek()));
        if (hasCurrentWeekNpsSurvey) {
            log.debug("NPS survey present for user {} in iso week {}. Serving sample", username, currentIsoWeek);
            npsWeeklySampleService.serveNpsSurvey(username, currentIsoWeek);
        }
    }

    @Trace
    public SurveyHistoryResponse fetchSurveyHistory(String userId, Long surveyId, LocalDate startDate, LocalDate endDate) {
        Timestamp start = Timestamp.valueOf(startDate.atStartOfDay());
        Timestamp end = Timestamp.valueOf(endDate.atTime(23, 59, 59));
        List<PreprocessedSurvey> surveys = preprocessedSurveyRepository
                .findByUserAndSurveyIdAndLastModifiedOnBetween(userId, surveyId, start, end);
        List<SurveyHistoryItemDTO> items = surveys.stream().map(this::toHistoryItem).toList();
        return new SurveyHistoryResponse(items);
    }

    @Trace
    public SurveyAlertsResponse fetchSurveyAlerts(String userId, String moniepointAgentId) {
        Timestamp now = Timestamp.from(Instant.now());
        List<SurveyAlert> cachedAlerts = cache.getCachedSurveyAlerts(userId, moniepointAgentId);
        if (cachedAlerts != null) {
            log.debug("Survey alerts for user {} and agent {} found in cache", userId, moniepointAgentId);
            return new SurveyAlertsResponse(cachedAlerts.stream()
                    .filter(a -> a.getTtl() != null && a.getTtl().after(now))
                    .filter(a -> a.getAlertStartTime() != null && !a.getAlertStartTime().after(now))
                    .map(this::toAlertDTO)
                    .toList());
        }
        List<SurveyAlert> alerts = surveyAlertStorage
                .findByUserAndMoniepointAgentIdAndTtlAfter(userId, moniepointAgentId, now);
        cache.cacheSurveyAlerts(userId, moniepointAgentId, alerts);
        return new SurveyAlertsResponse(alerts.stream()
                .filter(a -> a.getAlertStartTime() != null && !a.getAlertStartTime().after(now))
                .map(this::toAlertDTO)
                .toList());
    }

    private SurveyAlertDTO toAlertDTO(SurveyAlert alert) {
        return SurveyAlertDTO.builder()
                .id(alert.getEvent())
                .type(alert.getAlertType())
                .icon(alert.getAlertIcon())
                .priority(alert.getAlertPriority())
                .title(alert.getAlertTitle())
                .message(alert.getAlertMessage())
                .action(SurveyAlertDTO.Action.builder()
                        .label(alert.getAlertActionLabel())
                        .target("/survey/" + alert.getSurveyId())
                        .build())
                .dismissible(alert.isAlertDismissible())
                .build();
    }

    private SurveyHistoryItemDTO toHistoryItem(PreprocessedSurvey survey) {
        Object additionalData = null;
        if (survey.getAdditionalData() != null) {
            try {
                additionalData = objectMapperHelper.deserializeStringToObject(survey.getAdditionalData(), new TypeReference<Object>() {});
            } catch (Exception e) {
                additionalData = survey.getAdditionalData();
            }
        }
        return SurveyHistoryItemDTO.builder()
                .id(survey.getId())
                .event(survey.getEvent())
                .ttl(survey.getTtl() != null ? survey.getTtl().toLocalDateTime() : null)
                .state(survey.getState())
                .completedOn(survey.getCompletedOn() != null ? survey.getCompletedOn().toLocalDateTime() : null)
                .additionalData(additionalData)
                .build();
    }

    @Trace
    public SurveySchemaDTO fetchSurveySchema(Long surveyId, String userId, UserAttributes requestAttributes) {
        Timestamp now = Timestamp.from(Instant.now());
        Optional<PreprocessedSurvey> preprocessedSurvey = preprocessedSurveyRepository
                .findFirstByUserAndSurveyIdAndStateInAndTtlAfter(userId, surveyId, List.of(NOT_COMPLETED, DISMISSED), now);

        if (preprocessedSurvey.isPresent()) {
            PreprocessedSurvey ps = preprocessedSurvey.get();
            return SurveySchemaDTO.builder()
                    .id(surveyId)
                    .survey(ps.getSurvey())
                    .preprocessedSurveyId(ps.getId())
                    .build();
        }

        return surveyRepositoryService.findById(surveyId)
                .map(survey -> {
                    String surveyJson = survey.getSurvey();
                    boolean hasRequestAttributes = !new UserAttributes().equals(requestAttributes);
                    if (hasRequestAttributes && surveyJson.contains("${")) {
                        surveyJson = enrichSurveyWithUserAttributes(surveyJson, userId, requestAttributes);
                    }
                    return SurveySchemaDTO.builder()
                            .id(survey.getId())
                            .survey(surveyJson)
                            .build();
                })
                .orElse(null);
    }

    private String enrichSurveyWithUserAttributes(String surveyJson, String userId, UserAttributes requestAttributes) {
        String businessAccountNumber = requestAttributes.getBusinessNubanAccountNumber();
        String personalAccountNumber = requestAttributes.getNubanAccountNumber();
        String accountNumber = StringUtils.isBlank(businessAccountNumber) ? personalAccountNumber : businessAccountNumber;

        UserAttributes user = StringUtils.isBlank(accountNumber) ? null : userStorage.findUser(userId, accountNumber);
        log.info("User data returned for user {} and account {} from bigtable is {}", userId, accountNumber, user);

        if (user == null) {
            log.warn("User data not found in bigtable, using request attributes");
            user = requestAttributes;
        } else {
            user.update(requestAttributes);
        }

        if (StringUtils.isNotBlank(businessAccountNumber)) {
            String brmImage = user.getBrmImage();
            String encodedImage = StringUtils.isBlank(brmImage) ? null : URLEncoder.encode(brmImage, StandardCharsets.UTF_8);
            user.setBrmImage(StringUtils.isBlank(encodedImage) ? null : imageLocationUrl + encodedImage + "?requestType=BRM_IMAGE");
        }

        Map<String, Object> valueMap = new HashMap<>();
        populateContextValuesMap(valueMap, "user", user);
        return StringSubstitutor.replace(surveyJson, valueMap);
    }

    private void populateContextValuesMap(Map<String, Object> values, String prefix, Object object) {
        if (object == null) return;
        for (Field field : object.getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                Object value = field.get(object);
                if (value != null) {
                    values.put(String.format("%s.%s", prefix, StringUtils.capitalize(field.getName())), value);
                }
            } catch (IllegalAccessException e) {
                log.warn("Could not access field {} on {} via reflection", field.getName(), object.getClass(), e);
            }
        }
    }

    @Trace
    public PreprocessedSurveyDTO fetchSurveyById(Long surveyId) {
        String surveyString = cache.getPreprocessedSurveyById(String.valueOf(surveyId));
        if (!StringUtils.isBlank(surveyString)) {
            log.debug("Survey with id {} available in cache", surveyId);
            try {
                PreprocessedSurveyDTO dto = objectMapperHelper.deserializeStringToObject(surveyString, new TypeReference<PreprocessedSurveyDTO>() {});
                return dto.getTtl().isAfter(LocalDateTime.now()) ? dto : null;
            } catch (Exception e) {
                log.error("Failed to deserialize cached preprocessed survey id {}. Expiring survey. Reason: {}", surveyId, e.getMessage());
                expireSurvey(surveyId);
                return null;
            }
        }

        Timestamp now = Timestamp.from(Instant.now());
        Optional<PreprocessedSurvey> preprocessedSurvey = preprocessedSurveyRepository
                .findByIdAndStateInAndTtlAfter(surveyId, List.of(NOT_COMPLETED, DISMISSED), now);

        return preprocessedSurvey.map(survey -> {
            PreprocessedSurveyDTO dto = objectMapperHelper.convertObjectToType(survey, new TypeReference<>() {});
            try {
                SurveyBody surveyBody = objectMapperHelper.deserializeStringToObject(survey.getSurvey(), new TypeReference<>() {});
                dto.setDisplayModalType(surveyBody.getDisplayModalType());
            } catch (Exception e) {
                log.error("Failed to deserialize survey body for preprocessed survey id {}. Expiring survey. Reason: {}", surveyId, e.getMessage());
                expireSurvey(surveyId);
                return null;
            }
            enrichWithSurveyLocations(dto);
            cache.cachePreprocessedSurveyById(String.valueOf(surveyId), objectMapperHelper.serializeToString(dto));
            return dto;
        }).orElse(null);
    }

    private void expireSurvey(Long surveyId) {
        preprocessedSurveyRepository.expireByIds(List.of(surveyId));
        cache.removePreprocessedSurveyBySurveyId(String.valueOf(surveyId));
    }

    private void enrichWithSurveyLocations(PreprocessedSurveyDTO dto) {
        if (dto.getSurveyId() == null) return;
        surveyRepositoryService.findById(dto.getSurveyId()).ifPresent(s -> {
            dto.setLocationWeb(s.getWebLocation());
            dto.setLocationMobile(s.getMobileLocation());
        });
    }
}
