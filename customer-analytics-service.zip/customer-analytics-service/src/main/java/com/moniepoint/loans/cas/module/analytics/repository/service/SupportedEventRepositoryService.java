package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedEventRepository;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class SupportedEventRepositoryService {

    @Value("${cache.supported-event.expiry}")
    private long supportedEventExpiry;

    private final SupportedEventRepository supportedEventRepository;
    private final CacheService cacheService;
    private final ObjectMapperHelper objectMapperHelper;


    public Optional<SupportedEvent> findByEventType(String eventType) {
        Optional<SupportedEvent> cachedSupportedEventOptional = findByEventTypeFromCache(eventType);
        if (cachedSupportedEventOptional.isEmpty()) {
            Optional<SupportedEvent> optionalSupportedEvent = findByEventTypeFromDB(eventType);
            optionalSupportedEvent.ifPresent(this::saveEventTypeToCache);
            return optionalSupportedEvent;
        } else {
            return cachedSupportedEventOptional;
        }
    }

    public Optional<SupportedEvent> findByEventTypeFromDB(String eventType) {
        return supportedEventRepository.findByEventType(eventType);
    }

    public Optional<SupportedEvent> findByEventTypeFromCache(String eventType) {
        String cachedEventString = cacheService.getCachedString(Strings.concat(CacheKeys.SUPPORTED_EVENT_CACHE_KEY_PREFIX, eventType));
        if (Objects.isNull(cachedEventString)) {
            return Optional.empty();
        } else {
            SupportedEvent supportedEvent = objectMapperHelper.deserializeStringToObject(cachedEventString, new TypeReference<SupportedEvent>() {
            });
            return Optional.of(supportedEvent);
        }
    }

    public void saveEventTypeToCache(SupportedEvent supportedEvent) {
        String eventString = objectMapperHelper.serializeToString(supportedEvent);
        cacheService.cacheString(Strings.concat(CacheKeys.SUPPORTED_EVENT_CACHE_KEY_PREFIX, supportedEvent.getEventType()), eventString, supportedEventExpiry);
    }

    @PostConstruct
    public void loadSupportedEventsToCache() {
        log.info("Start loading supported events to cache.");
        Collection<SupportedEvent> supportedEvents = supportedEventRepository.findAll();
        supportedEvents.forEach(supportedEvent -> {
            String eventString = objectMapperHelper.serializeToString(supportedEvent);
            cacheService.cacheString(Strings.concat(CacheKeys.SUPPORTED_EVENT_CACHE_KEY_PREFIX, supportedEvent.getEventType()), eventString, supportedEventExpiry);
        });
        log.info("End loading supported events to cache.");
    }

}
