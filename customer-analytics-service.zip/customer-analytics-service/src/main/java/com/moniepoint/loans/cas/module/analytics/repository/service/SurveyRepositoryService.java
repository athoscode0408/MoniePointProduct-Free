package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class SurveyRepositoryService {

    private final SurveyStorage surveyStorage;
    private final RedisCacheServiceImpl cache;
    private final ObjectMapperHelper objectMapperHelper;

    public Optional<Survey> findById(Long surveyId) {
        String cachedRules = cache.getCachedString(CacheKeys.CAS_SURVEY_RULES_KEY);
        if (StringUtils.isNotBlank(cachedRules)) {
            log.debug("Looking up survey {} from rules cache", surveyId);
            return objectMapperHelper.<List<Survey>>deserializeStringToObject(cachedRules, new TypeReference<>() {})
                    .stream()
                    .filter(s -> surveyId.equals(s.getId()))
                    .findFirst();
        }
        log.debug("Rules cache empty, fetching survey {} from database", surveyId);
        return surveyStorage.findById(surveyId);
    }
}
