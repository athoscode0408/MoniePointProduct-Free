package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.UnsupportedEvent;
import com.moniepoint.loans.cas.module.analytics.repository.UnsupportedEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UnsupportedEventRepositoryService {

    private final UnsupportedEventRepository unsupportedEventRepository;

    public UnsupportedEvent save(UnsupportedEvent unsupportedEvent) {
        return unsupportedEventRepository.save(unsupportedEvent);
    }

    public void deleteAllUnsupportedEvents(){
        unsupportedEventRepository.deleteAll();
    }

}
