package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserAttributesRepositoryService implements UserAttributesStorage {

    @Value("${bigtable.users-attributes-table}")
    private String USER_ATTRIBUTES_TABLE;

    @Value("${survey.preprocessed-survey-cache-by-id-mins:1440}")
    public Integer USER_ATTRIBUTES_CACHE_TTL;

    private final BigtableDataClient dataClient;
    private final ObjectMapperHelper objectMapperHelper;
    private final CacheService cacheService;

    @Trace
    public UserAttributes findUser(String userId, String businessAccountNumber) {
        UserAttributes user ;
        try{
            String rowString = cacheService.getCachedString("pps-user-attributes:%s".formatted(userId));
            if (!StringUtils.isBlank(rowString))
            {
                log.debug("User attributes found in cache");
                user = objectMapperHelper.mapCachedMapToPojo(objectMapperHelper.deserializeStringToObject(rowString, new TypeReference<>() {
                }),UserAttributes.class, businessAccountNumber);
            }
            else {
                log.debug("Now going to fetch user attributes from bigtable");
                user = Telemetry.runInSpan("BigTableRead", () -> {
                    Row row = dataClient.readRow(USER_ATTRIBUTES_TABLE, userId,Filters.FILTERS.limit().cellsPerColumn(1));
                    if (row == null)
                    {
                        return null;
                    }
                    Map<String, String> cachedMap = new HashMap<>();
                    for (RowCell cell : row.getCells())
                    {
                        String qualifier = cell.getQualifier().toStringUtf8();
                        String value = cell.getValue().toStringUtf8();
                        cachedMap.put(qualifier, value);
                    }
                    cacheService.cacheString("pps-user-attributes:%s".formatted(userId),objectMapperHelper.serializeToString(cachedMap), USER_ATTRIBUTES_CACHE_TTL*60);
                    return objectMapperHelper.mapRowToPojo(row,UserAttributes.class, businessAccountNumber);
                });
            }
            return user;
        }
        catch (Exception e)
        {
            log.error("Error getting user attributes from cache/bigtable", e);
            return null;
        }
    }

//    @Trace
//    public UserAttributes findUser(String userId) {
//        UserAttributes user ;
//        try{
//            String rowString = cacheService.getCachedString("pps-user-attributes:%s".formatted(userId));
//            if (!StringUtils.isBlank(rowString))
//            {
//                log.debug("User attributes found in cache");
//                Map<String, String> row= objectMapperHelper.deserializeStringToObject(rowString, new TypeReference<>() {
//                });
//                user = objectMapperHelper.convertValue(row, UserAttributes.class);
//            }
//            else {
//                log.debug("Now going to fetch user attributes from bigtable");
//                Segment seg = NewRelic.getAgent().getTransaction()
//                        .startSegment("BigTableRead");
//                try {
//                    Row row = dataClient.readRow(USER_ATTRIBUTES_TABLE, userId,Filters.FILTERS.limit().cellsPerColumn(1));
//                    if (row == null)
//                    {
//                        return null;
//                    }
//                    Map<String, String> cachedMap = new HashMap<>();
//                    for (RowCell cell : row.getCells())
//                    {
//                        String qualifier = cell.getQualifier().toStringUtf8();
//                        String value = cell.getValue().toStringUtf8();
//                        cachedMap.put(qualifier, value);
//                    }
//                    cacheService.cacheString("pps-user-attributes:%s".formatted(userId),objectMapperHelper.serializeToString(cachedMap), USER_ATTRIBUTES_CACHE_TTL*60);
//                    user = objectMapperHelper.convertValue(cachedMap, UserAttributes.class);
//                }
//                finally {
//                    if (seg != null) {
//                        seg.end();
//                    }
//                }
//            }
//            return user;
//        }
//        catch (Exception e)
//        {
//            log.error("Error getting user attributes from cache/bigtable", e);
//            return null;
//        }
//    }

    @PreDestroy
    public void close() {
        dataClient.close();
        log.debug("Closed Bigtable connection");
    }

}



