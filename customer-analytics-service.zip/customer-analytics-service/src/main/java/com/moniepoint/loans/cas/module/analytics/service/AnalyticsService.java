package com.moniepoint.loans.cas.module.analytics.service;

import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v1.BrazeAllowedEventsResponse;

import java.util.List;

public interface AnalyticsService {

    AnalyticsEventResponseDTO pushEvent(AnalyticsEventV1RequestDTO analyticsEventRequestDTO);
    void pushEvents(List<BaseAnalyticsEventRequestDTO<?>> analyticsEvents);

    void handleRawAnalyticsEvent(AnalyticsEventRequestDTO analyticsEventRequestDTO);
    void handleRawAnalyticsEvents(List<AnalyticsEventRequestDTO> analyticsEventsRequestDTO);

    BrazeAllowedEventsResponse getPubliclyAllowedBrazeEvents();

}
