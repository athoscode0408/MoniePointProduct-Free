package com.moniepoint.loans.cas.module.analytics.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.scheduling.annotation.Async;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public interface EventProviderHandler {

    boolean support(EventProvider provider);


    void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent);

    @Async("appExecutor")
    default void processEvents(List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents){
        verifiedAnalyticsEvents.forEach(this::processEvent);
    }

    boolean processEvent(String eventJsonString);


    default Optional<String> getUserName(JsonNode jsonNode) {
        if (Objects.nonNull(jsonNode)
                && jsonNode.has("username")
                && !jsonNode.get("username").isNull()
                && Strings.isNotBlank(jsonNode.get("username").asText())) {
            return Optional.of(jsonNode.get("username").asText());
        }
        return Optional.empty();
    }

    default Optional<String> getIdentifier(JsonNode jsonNode, String customerIdentifier) {
        if(!StringUtils.isEmpty(customerIdentifier)){
            return Optional.of(customerIdentifier);
        }

        return this.getUserName(jsonNode);
    }

}
