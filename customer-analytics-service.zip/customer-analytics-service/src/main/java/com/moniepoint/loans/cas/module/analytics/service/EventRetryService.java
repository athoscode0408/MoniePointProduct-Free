package com.moniepoint.loans.cas.module.analytics.service;

import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;

public interface EventRetryService {

    void processFailedEventData(EventRetryDataDTO eventRetryDataDTO);
    void retryFailedEvents();
    void handleEventRetryIDRange(EventRetryIDRangeDTO eventRetryIDRangeDTO);

}
