package com.moniepoint.loans.cas.module.analytics.service;

import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;

public interface NpsUserStateService {

    boolean isInCoolOff(String username, int coolOffDays, int yearlyTriggerCap);

    NpsUserState writeTriggered(String username);
}
