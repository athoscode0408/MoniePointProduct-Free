package com.moniepoint.loans.cas.module.analytics.service;

public interface NpsWeeklySampleExpiryService {

    void expireWeeklySamples(String isoWeek);
}
