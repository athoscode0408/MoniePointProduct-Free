package com.moniepoint.loans.cas.module.analytics.service;

public interface NpsWeeklySamplePreparationService {

    void prepareWeeklySample(String isoWeek);
}
