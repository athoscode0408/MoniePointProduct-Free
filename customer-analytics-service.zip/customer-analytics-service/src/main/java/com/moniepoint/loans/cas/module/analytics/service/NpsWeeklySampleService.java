package com.moniepoint.loans.cas.module.analytics.service;

import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;

import java.util.Optional;

public interface NpsWeeklySampleService {

    Optional<PreprocessedSurvey> serveNpsSurvey(String username, String isoWeek);
}
