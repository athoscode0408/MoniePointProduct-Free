package com.moniepoint.loans.cas.module.analytics.service;

public interface PreprocessedSurveyExpiryService {

    void expirePreprocessedSurveys();

    void expirePreprocessedSurveysV2();
}
