package com.moniepoint.loans.cas.module.analytics.service;

public interface SessionService {
    String generateSessionID(String deviceID, String userID);
}
