package com.moniepoint.loans.cas.module.analytics.service;

import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyRulesCache {

    private final SurveyStorage surveyStorage;

    @Cacheable(cacheNames = "surveyRules", key = "'all'")
    public Collection<Survey> getRules() {
        log.debug("Fetched survey rules from db");
        return surveyStorage.findAll();
    }

    @CacheEvict(cacheNames = "surveyRules", allEntries = true)
    public void evict() {
        log.info("Survey rules cache evicted");
    }
}
