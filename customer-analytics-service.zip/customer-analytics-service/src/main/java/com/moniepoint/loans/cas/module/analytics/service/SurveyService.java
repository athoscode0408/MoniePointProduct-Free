package com.moniepoint.loans.cas.module.analytics.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.module.analytics.dto.SurveyCreateRequest;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SurveyService {

    private final SurveyStorage surveyStorage;
    private final ObjectMapper mapper;
    private final CacheService cacheService;

    @Transactional
    public Survey createSurvey(SurveyCreateRequest request) {
        Survey survey = Survey.builder()
                .rule(request.getRule())
                .priority(request.getPriority() != null ? request.getPriority() : 10)
                .survey(serializeSurvey(request))
                .webLocation(request.getLocationWeb())
                .mobileLocation(request.getLocationMobile())
                .build();

        Survey savedSurvey = surveyStorage.save(survey);
        cacheService.deleteFromCache(CacheKeys.CAS_SURVEY_RULES_KEY);
        return savedSurvey;
    }

    @Transactional
    public void  updateSurvey(SurveyCreateRequest request) {
        Optional<Survey> optionalSurvey = surveyStorage.findById(request.getId());
        if (optionalSurvey.isPresent())
        {
            Survey updatedSurvey = optionalSurvey.get();
            updatedSurvey.setSurvey(request.getSurvey() == null ? updatedSurvey.getSurvey() :serializeSurvey(request));
            updatedSurvey.setRule(StringUtils.isBlank(request.getRule()) ? updatedSurvey.getRule() : request.getRule());
            updatedSurvey.setPriority(request.getPriority() == null ? updatedSurvey.getPriority() : request.getPriority());
            updatedSurvey.setMobileLocation(StringUtils.isBlank(request.getLocationMobile()) ? updatedSurvey.getMobileLocation() : request.getLocationMobile());
            updatedSurvey.setWebLocation(StringUtils.isBlank(request.getLocationWeb()) ? updatedSurvey.getWebLocation() : request.getLocationWeb());
            surveyStorage.save(updatedSurvey);
            cacheService.deleteFromCache(CacheKeys.CAS_SURVEY_RULES_KEY);
        }

    }

    private String serializeSurvey(SurveyCreateRequest request) {
        try {
            String json = mapper.writeValueAsString(request.getSurvey());
            // Remove leading UTF-8 BOM (U+FEFF) or other invisible zero-width characters that
            // can cause MySQL 'Incorrect string value' errors when column charset doesn't
            // accept them. Also defensively strip ZERO WIDTH SPACE (U+200B).
            if (json.indexOf('\uFEFF') >= 0 || json.indexOf('\u200B') >= 0) {
                String cleaned = json.replace("\uFEFF", "").replace("\u200B", "");
                // keep a log entry to help debug problematic payloads in future
                // (do not log entire payload in production if it contains PII)
                // Use warn level so operators see it during investigation.
                org.slf4j.LoggerFactory.getLogger(SurveyService.class)
                        .warn("serializeSurvey: removed invisible characters from payload (len before={}, after={})", json.length(), cleaned.length());
                json = cleaned;
            }
            // Escape surrogate pairs (emoji and other supplementary characters beyond the BMP) as
            // JSON Unicode escape sequences. MySQL utf8 columns reject 4-byte UTF-8 sequences;
            // JSON unicode escapes are ASCII-only and safe to store.
            return escapeSupplementaryCharacters(json);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to serialize survey payload", e);
        }
    }

    private static String escapeSupplementaryCharacters(String s) {
        StringBuilder sb = null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isHighSurrogate(c) && i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1))) {
                if (sb == null) sb = new StringBuilder(s.substring(0, i));
                sb.append(String.format("\\u%04x\\u%04x", (int) c, (int) s.charAt(i + 1)));
                i++;
            } else if (sb != null) {
                sb.append(c);
            }
        }
        return sb != null ? sb.toString() : s;
    }
}
