package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import com.moniepoint.loans.cas.outbound.banner.BannerClient;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerDTO;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerResponse;
import com.moniepoint.loans.cas.outbound.banner.dto.UnassignBannerDTO;
import datadog.trace.api.Trace;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Slf4j
public class BannerService {

    @Value("${survey.preprocessed-survey-ttl-mins:10080}")
    private int preprocessedSurveyTtl;

    private final BannerClient bannerClient;
    private final OutboundUtils outboundUtils;
    private final ObjectMapperHelper objectMapperHelper;

    public BannerService(BannerClient bannerClient, OutboundUtils outboundUtils, ObjectMapperHelper objectMapperHelper) {
        this.bannerClient = bannerClient;
        this.outboundUtils = outboundUtils;
        this.objectMapperHelper = objectMapperHelper;
    }

    @Trace
    public ResponseEntity<AssignBannerResponse> assignBannerToUser(String ownerIdentifier, String bannerId) {
        try {
            String token = outboundUtils.getToken();

            LocalDateTime expiryDate = LocalDateTime.now().plusMinutes(preprocessedSurveyTtl);


            AssignBannerDTO assignBannerDTO = AssignBannerDTO.builder()
                    .bannerId(bannerId)
                    .ownerIdentifier(ownerIdentifier)
                    .ownerIdentifierType("USERNAME")
                    .expiryDate(expiryDate)
                    .build();

            ResponseEntity<AssignBannerResponse> response = bannerClient.assignBanner(assignBannerDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for banner service assign-banner with reason : {} and data : {}", response.getStatusCode(), assignBannerDTO);
            }
            return response;
        } catch (FeignException exception) {
            log.error("Assign banner request for user {} to banner service could not be processed: {}",ownerIdentifier, exception.getMessage(), exception);
            AssignBannerResponse assignBannerResponse;
            try{
                assignBannerResponse= objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            }
            catch (Exception e)
            {
                assignBannerResponse = new AssignBannerResponse(false, "500", exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(assignBannerResponse);
        }catch (Exception exception) {
            log.error("Assign banner request for user {} to banner service could not be processed: {}", ownerIdentifier,exception.getMessage(), exception);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new AssignBannerResponse(false, "500", exception.getMessage(),null));
        }
    }

    @Trace
    public boolean unAssignBannerToUser(String bannerOwnerIdentifier, String bannerId) {

        try {
            String token = outboundUtils.getToken();

            UnassignBannerDTO unassignBannerDTO = new UnassignBannerDTO(bannerOwnerIdentifier, bannerId);

            ResponseEntity<Void> response = bannerClient.unAssignBanner(unassignBannerDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for banner service unassign banner request with reason : {} and data : {}", response.getStatusCode(), unassignBannerDTO);
                return false;
            }
            return true;
        } catch (FeignException exception) {
            log.error("Unassign banner request for user {} to banner service could not be processed: {}", bannerOwnerIdentifier, exception.getMessage());
            return false;
        }catch (Exception exception) {
            log.error("Unassign banner request for user {} to banner service could not be processed: {}", bannerOwnerIdentifier,exception.getMessage());
            return false;
        }
    }

}
