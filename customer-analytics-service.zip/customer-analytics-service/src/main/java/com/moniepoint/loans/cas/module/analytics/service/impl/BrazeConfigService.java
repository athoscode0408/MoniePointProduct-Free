package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.dto.BrazeApiKeyRequest;
import com.moniepoint.loans.cas.module.analytics.entity.BrazeApiKey;
import com.moniepoint.loans.cas.module.analytics.repository.BrazeApiKeyStorage;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BrazeConfigService {

    private final BrazeApiKeyStorage brazeApiKeyStorage;
    private final CacheService cacheService;

    @Transactional
    public void createBrazeApiKeys(List<BrazeApiKeyRequest> requests) {
        for (BrazeApiKeyRequest request : requests)
        {
            String encodedApiKey = Base64.getEncoder()
                    .encodeToString(request.getApiKey().getBytes(StandardCharsets.UTF_8));
            BrazeApiKey brazeApiKey = BrazeApiKey.builder()
                    .appDomain(request.getAppDomain())
                    .applicationID(request.getApplicationID())
                    .apiKey(encodedApiKey)
                    .build();

            brazeApiKeyStorage.save(brazeApiKey);
        }

        cacheService.deleteFromCache("braze_api_key_mapping");

    }

    @Transactional
    public void  updateBrazeApiKeys(BrazeApiKeyRequest request) {
        Optional<BrazeApiKey> optionalBrazeApiKey = brazeApiKeyStorage.findById(request.getId());
        if (optionalBrazeApiKey.isPresent())
        {
            BrazeApiKey brazeApiKey = optionalBrazeApiKey.get();
            brazeApiKey.setApiKey(StringUtils.isBlank(request.getApiKey()) ? brazeApiKey.getApiKey() : Base64.getEncoder()
                    .encodeToString(request.getApiKey().getBytes(StandardCharsets.UTF_8)));
            brazeApiKey.setApplicationID(StringUtils.isBlank(request.getApplicationID()) ? brazeApiKey.getApplicationID() : request.getApplicationID());
            brazeApiKey.setAppDomain(StringUtils.isBlank(request.getAppDomain()) ?  brazeApiKey.getAppDomain() : request.getAppDomain());
            brazeApiKeyStorage.save(brazeApiKey);
            cacheService.deleteFromCache("braze_api_key_mapping");
        }

    }

}
