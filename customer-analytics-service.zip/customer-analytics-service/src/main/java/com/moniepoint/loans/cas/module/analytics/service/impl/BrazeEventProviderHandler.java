package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.BrazeClient;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeIdentifyRequest;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeIdentifyResponse;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackRequest;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackResponse;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.BrazeApiKey;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.BrazeApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedUserAttributesRepository;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.StreamSupport;

@Service
@Slf4j
public class BrazeEventProviderHandler implements EventProviderHandler {

    @Value("${integrations.braze.enable}")
    private final boolean enabled;
    @Value("${integrations.braze.enable-workspace-targeting:true}")
    private boolean enableWorkspaceTargeting;
    @Value("${integrations.braze.enable-attributes-filtering:true}")
    private boolean enableAttributesFiltering;
    private final String defaultApiKey;

    private final Map<String, String> clientIDs;

    private final BrazeClient brazeClient;
    private final ObjectMapperHelper objectMapperHelper;
    private final EventRetryService eventRetryService;

    private final BrazeApiKeyStorage brazeApiKeyStorage;

    private final CacheService cacheService;

    private final SupportedUserAttributesRepository supportedUserAttributesRepository;

    public BrazeEventProviderHandler(
            @Value("${integrations.braze.enable}") boolean enabled,
            @Value("${integrations.braze.api-key}") String defaultApiKey,
            @Value("${integrations.braze.android-id}") String androidID,
            @Value("${integrations.braze.web-id}") String webID,
            @Value("${integrations.braze.ios-id}") String iosID,
            BrazeClient brazeClient,
            ObjectMapperHelper objectMapperHelper,
            EventRetryService eventRetryService,
            BrazeApiKeyStorage brazeApiKeyStorage,
            CacheService cacheService,
            SupportedUserAttributesRepository supportedUserAttributesRepository
    ) {
        this.enabled = enabled;
        this.defaultApiKey = defaultApiKey;
        this.brazeClient = brazeClient;
        this.objectMapperHelper = objectMapperHelper;
        this.eventRetryService = eventRetryService;
        this.brazeApiKeyStorage = brazeApiKeyStorage;
        this.cacheService = cacheService;
        this.supportedUserAttributesRepository = supportedUserAttributesRepository;
        this.clientIDs = Map.of(
                "android", StringUtils.defaultIfBlank(androidID, ""),
                "web", StringUtils.defaultIfBlank(webID, ""),
                "ios", StringUtils.defaultIfBlank(iosID, "")
        );
    }

    @Override
    public boolean support(EventProvider provider) {
        return EventProvider.BRAZE.equals(provider);
    }

    @Override
    public void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        processEvents(List.of(verifiedAnalyticsEvent));
    }

    @Override
    public boolean processEvent(String eventJsonString) {
        VerifiedAnalyticsEventDTO request = objectMapperHelper.deserializeStringToObject(eventJsonString, new TypeReference<>() {
        });
        return processBrazeEvents(List.of(request));
    }


    @Override
    @Async("appExecutor")
    public void processEvents(List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents) {
        processBrazeEvents(verifiedAnalyticsEvents);
    }

    private boolean processBrazeEvents(List<VerifiedAnalyticsEventDTO> events) {
        if (!enabled) {
            return true;
        }

        String apiKey = !enableWorkspaceTargeting ? defaultApiKey : getApiKey(events.getFirst().getApplicationID(), events.getFirst().getAppDomain());
        if (StringUtils.isBlank(apiKey))
        {
            log.error("No configured api key for app id {} and app domain {}", events.getFirst().getApplicationID(), events.getFirst().getAppDomain());
            return false;
        }

        List<VerifiedAnalyticsEventDTO> filteredEvents = new ArrayList<>();
        events.forEach(event->
        {
                VerifiedAnalyticsEventDTO filteredEvent = filterUserAttributes(event);
                if (filteredEvent != null)
                {
                    filteredEvents.add(filteredEvent);
                }
        });
        BrazeTrackRequest brazeTrackRequest = new BrazeTrackRequest(filteredEvents, this.clientIDs);
        if (!brazeTrackRequest.getEvents().isEmpty() || !brazeTrackRequest.getAttributes().isEmpty() )
        {
            log.info("Braze request to remote {}", objectMapperHelper.serializeToString(brazeTrackRequest));

            try {
                ResponseEntity<BrazeTrackResponse> response = brazeClient.trackEvent(
                        brazeTrackRequest,
                        String.format("Bearer %s", apiKey)
                );
                if (response.getStatusCode() == HttpStatus.CREATED) {
                    log.info("{} events successfully pushed to braze", filteredEvents.size());
                    var identifyRequests = new BrazeIdentifyRequest(events);
                    if (identifyRequests.getAliases().isEmpty()) {
                        return true;
                    }

                    log.debug("Identifying {} braze users", identifyRequests.getAliases().size());
                    log.debug("Identifying braze users request {}", identifyRequests);

                    try{
                        ResponseEntity<BrazeIdentifyResponse> identifyResponse = brazeClient.identify(
                                identifyRequests,
                                String.format("Bearer %s", apiKey)
                        );

                        if (identifyResponse.getStatusCode() == HttpStatus.CREATED) {
                            log.debug("{} users successfully identified", identifyRequests.getAliases().size());
                        } else {
                            log.debug(
                                    "Failure identifying {} braze users with reason: {} and data: {}",
                                    identifyRequests.getAliases().size(),
                                    identifyResponse.getStatusCode(), identifyRequests
                            );
                        }
                    } catch (Exception e) {
                        log.warn(
                                "Failure identifying {} braze users with reason: {} ",
                                identifyRequests.getAliases().size(),
                                e.getMessage()
                        );                }
                    return true;
                }
                log.info("Handling failure for braze with reason : {} and data : {}", response.getStatusCode(), events);
                if (response.getStatusCode() == HttpStatus.BAD_REQUEST) {
                    log.warn("Braze rejected {} events with 400 Bad Request — not retrying",
                            filteredEvents.size());
                    return false;
                }
                submitForRetry(events, response.getStatusCode().toString());
                return false;
            } catch (Exception exception) {
                log.error("Braze events could not be processed: {}", exception.getMessage());
                if (exception instanceof FeignException fe && fe.status() == HttpStatus.BAD_REQUEST.value()) {
                    log.warn("Braze rejected events with 400 Bad Request — not retrying: {}",
                            exception.getMessage());
                    return false;
                }
                submitForRetry(events, exception.getMessage());
                return false;
            }
        }
        return true;
    }

    private void submitForRetry(List<VerifiedAnalyticsEventDTO> events, String error) {
        events.forEach(e -> {
            EventRetryDataDTO eventRetryDataDTO = EventRetryDataDTO.builder()
                    .eventId(e.getId())
                    .eventProvider(EventProvider.BRAZE)
                    .eventData(objectMapperHelper.serializeToString(e))
                    .failureReason(error)
                    .build();
            eventRetryService.processFailedEventData(eventRetryDataDTO);
        });
    }

    private String getApiKey(String applicationId, String appDomain) {
        log.info("Fetching api key for application id {} and app domain {}", applicationId, appDomain);
        String apiKey = "";
        String apiKeys = cacheService.getCachedString( "braze_api_key_mapping");
        if (StringUtils.isBlank(apiKeys)) {
            try {
                List<BrazeApiKey> apiKeyList= brazeApiKeyStorage.findAll();
                Optional<BrazeApiKey> brazeApiKey = apiKeyList.stream()
                        .filter(key -> key.getApplicationID().equalsIgnoreCase(applicationId))
                        .findFirst();
                if (brazeApiKey.isPresent())
                {
                    String encryptedApiKey = brazeApiKey.get().getApiKey();
                    byte[] cipherBytes = Base64.getDecoder().decode(encryptedApiKey);
                    apiKey = new String(cipherBytes, StandardCharsets.UTF_8);
                }
                cacheService.cacheString("braze_api_key_mapping", objectMapperHelper.serializeToString(apiKeyList));
                return apiKey;
            } catch (Exception e) {
                log.error("Error while decrypting api key ", e);
                return "";
            }
        }
        List<BrazeApiKey> apiKeyList = objectMapperHelper.deserializeStringToObject(apiKeys,new TypeReference<>() {
        });
        Optional<BrazeApiKey> brazeApiKey = apiKeyList.stream()
                .filter(key -> key.getApplicationID().equalsIgnoreCase(applicationId))
                .filter(key -> key.getAppDomain().equalsIgnoreCase(appDomain))
                .findFirst();
        if (brazeApiKey.isPresent())
        {
            String encryptedApiKey = brazeApiKey.get().getApiKey();
            byte[] cipherBytes = Base64.getDecoder().decode(encryptedApiKey);
            apiKey = new String(cipherBytes, StandardCharsets.UTF_8);
        }
        return apiKey;
    }

    VerifiedAnalyticsEventDTO filterUserAttributes (VerifiedAnalyticsEventDTO event)  {
        if (!enableAttributesFiltering)
        {
            return event;
        }
        if (event.getData() != null && !(event.getData() instanceof NullNode) && !(StringUtils.isBlank(event.getData().path("eventName").asText()))) {
            String eventName = event.getData().path("eventName").asText();
            List<String> allow;
            var cachedAllow = cacheService.getCachedString(eventName+"_allowed_attributes");
            if (StringUtils.isNotBlank(cachedAllow))
            {
                allow = objectMapperHelper.deserializeStringToObject(cachedAllow, new TypeReference<>() {
                });
            }
            else {
                allow = supportedUserAttributesRepository.findAllByEvent(eventName);
                if (allow.isEmpty())
                    return emptyAttributesAndIdentifierData(event);
                cacheService.cacheString(eventName+"_allowed_attributes", objectMapperHelper.serializeToString(allow));
            }
            List<String> defaultAllow = List.of("userID", "sessionID");
            UserAttributes filteredUserAttributes = objectMapperHelper.mapObjectNodeToPojo(filterObjectProperties(objectMapperHelper.mapPojoToObjectNode(event.getUserAttributes()), allow, defaultAllow), UserAttributes.class);
            UserEventIdentifier filteredUserIdentifier=event.getUserAttributes() == null? null : objectMapperHelper.mapObjectNodeToPojo(filterObjectProperties(objectMapperHelper.mapPojoToObjectNode(event.getUserIdentifiers()), allow, defaultAllow), UserEventIdentifier.class);
            Map<String, Object> filteredCustomAttributes = (event.getUserAttributes() == null || event.getUserAttributes().getCustomAttributes() == null) ? null : objectMapperHelper.mapObjectNodeToPojo(filterObjectProperties(objectMapperHelper.mapPojoToObjectNode(event.getUserAttributes().getCustomAttributes()), allow, defaultAllow), Map.class);
            filteredUserAttributes.setCustomAttributes(filteredCustomAttributes);
            event.setUserAttributes(filteredUserAttributes);
            event.setUserIdentifiers(filteredUserIdentifier);
            return event;
        }
        return emptyAttributesAndIdentifierData(event);
    }

    private static VerifiedAnalyticsEventDTO emptyAttributesAndIdentifierData(VerifiedAnalyticsEventDTO event) {
        String userID = event.getUserIdentifiers().getUserID();
        String sessionId = event.getUserIdentifiers().getSessionID();
        UserEventIdentifier filteredUserIdentifier = new UserEventIdentifier(sessionId, userID, null, null, null);
        event.setUserAttributes(null);
        event.setUserIdentifiers(filteredUserIdentifier);
        return event;
    }

    ObjectNode filterObjectProperties(ObjectNode eventData, List<String> allow, List<String> defaultAllow) {
        // build a local allowed set — avoids mutating the caller's list and gives O(1) lookups
        Set<String> allowed = new HashSet<>(allow);
        allowed.addAll(defaultAllow);
        // allow braze standard attributes through in both snake_case and camelCase
        if (allowed.contains("first_name")) allowed.add("firstName");
        if (allowed.contains("last_name")) allowed.add("lastName");
        if (allowed.contains("date_of_birth")) allowed.add("dateOfBirth");
        if (allowed.contains("phone_number")) allowed.add("phoneNumber");
        List<String> toRemove = StreamSupport
                .stream(Spliterators.spliteratorUnknownSize(eventData.fieldNames(), Spliterator.ORDERED), false)
                .filter(name -> !allowed.contains(name))
                .toList();

        eventData.remove(toRemove);
        return eventData;
    }


}
