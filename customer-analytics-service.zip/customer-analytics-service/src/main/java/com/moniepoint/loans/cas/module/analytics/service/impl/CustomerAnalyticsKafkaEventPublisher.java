package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.kafka.service.impl.AbstractKafkaEventPublisher;
import datadog.trace.api.Trace;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class CustomerAnalyticsKafkaEventPublisher extends AbstractKafkaEventPublisher<BaseAnalyticsEventRequestDTO<?>> {

    private final String topic;

    public CustomerAnalyticsKafkaEventPublisher(@Value("${kafka.topic.customer-analytics-event}") String topic,
                                                KafkaTemplate<String, String> kafkaTemplate,
                                                ObjectMapperHelper objectMapperHelper, Telemetry telemetry) {
        super(kafkaTemplate, objectMapperHelper, telemetry);
        this.topic = topic;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    public void publishEvent(BaseAnalyticsEventRequestDTO<?> analyticsEventRequest) {
        if (Objects.isNull(analyticsEventRequest)) {
            log.error("Failed to send customer analytics event due to missing event data.");
            return;
        }
        String key = getCustomerAnalyticEventKey(analyticsEventRequest);
        if (Strings.isBlank(key)) {
            log.error("Failed to send customer analytics event due missing key.");
            return;
        }
        publishEvent(key, analyticsEventRequest);
        log.info("Customer analytics event '{}' has successfully published with key '{}'.", analyticsEventRequest, key);
    }

    @Trace
    public void publishEvents(List<BaseAnalyticsEventRequestDTO<?>> analyticsEventsRequest) {
        if (Objects.isNull(analyticsEventsRequest) || analyticsEventsRequest.isEmpty()) {
            log.error("Failed to send customer analytics events due to missing event data.");
            return;
        }

        String key = getCustomerAnalyticEventKey(analyticsEventsRequest.getFirst());
        if (Strings.isBlank(key)) {
            log.error("Failed to send customer analytics event due missing key.");
            return;
        }
        log.info("Now sending events to kafka topic {}", topic);

        publishEventsAsync(key, analyticsEventsRequest);
    }

    String getCustomerAnalyticEventKey(BaseAnalyticsEventRequestDTO<?> analyticsEventRequest) {
        return analyticsEventRequest.getId();
    }
}
