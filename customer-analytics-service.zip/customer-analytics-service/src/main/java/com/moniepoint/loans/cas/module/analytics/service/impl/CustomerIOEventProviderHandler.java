package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerIOEventProviderHandler implements EventProviderHandler {

    private final CustomerIOIntegrationService customerIOIntegrationService;
    private final CustomerIOConfig customerIOConfig;
    private final ObjectMapperHelper objectMapperHelper;

    @Override
    public boolean support(EventProvider provider) {
        return EventProvider.CIO.equals(provider);
    }

    @Override
    public void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        if (!customerIOConfig.isEnable()) {
            return;
        }
        JsonNode jsonNode = verifiedAnalyticsEvent.getData();

        ObjectNode objectNode = (ObjectNode) verifiedAnalyticsEvent.getData();
        objectNode.put("app_env", verifiedAnalyticsEvent.getAppEnv());
        objectNode.put("platform", verifiedAnalyticsEvent.getPlatform());

        Optional<String> usernameOptional = getIdentifier(jsonNode, verifiedAnalyticsEvent.getCustomerIdentifier());
        if (usernameOptional.isPresent()) {
            verifiedAnalyticsEvent.setCustomerIdentifier(usernameOptional.get());
            processCustomerEvent(usernameOptional.get(), verifiedAnalyticsEvent);
        } else {
            processAnonymousEvent(verifiedAnalyticsEvent);
        }
    }

    @Override
    public boolean processEvent(String eventJsonString) {
        //return true if customer IO is not enabled, so that events in retry are deleted
        if (!customerIOConfig.isEnable()) {
            return true;
        }
        CustomerEventRequest eventRequest = objectMapperHelper.deserializeStringToObject(eventJsonString, new TypeReference<>() {
        });
        Optional<String> usernameOptional = getIdentifier(eventRequest.getData(), eventRequest.getCustomerIdentifier());
        if (usernameOptional.isPresent()) {
            return customerIOIntegrationService.sendCustomerEventToCustomerIO(usernameOptional.get(), eventRequest).isSuccess();
        } else {
            AnonymousEventRequest anonymousEventRequest = objectMapperHelper.deserializeStringToObject(eventJsonString, new TypeReference<AnonymousEventRequest>() {
            });
            return customerIOIntegrationService.sendAnonymousEventToCustomerIO(anonymousEventRequest).isSuccess();
        }
    }

    private void processCustomerEvent(String identifier, VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        log.debug("Processing request for user : {} with event : {}", identifier, verifiedAnalyticsEvent);
        String eventName = verifiedAnalyticsEvent.getEventType();
        if (verifiedAnalyticsEvent.getData() != null && !(verifiedAnalyticsEvent.getData() instanceof NullNode) && !(StringUtils.isBlank(verifiedAnalyticsEvent.getData().path("eventName").asText()))) {
            eventName = verifiedAnalyticsEvent.getData().path("eventName").asText(eventName);
        }

        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .id(verifiedAnalyticsEvent.getId())
                .name(eventName)
                .type(CustomerIOEventType.EVENT)
                .timestamp(verifiedAnalyticsEvent.getTimestamp())
                .data(verifiedAnalyticsEvent.getData())
                .customerIdentifier(verifiedAnalyticsEvent.getCustomerIdentifier())
                .build();

        customerIOIntegrationService.sendCustomerEventToCustomerIO(identifier, customerEventRequest);
    }

    private void processAnonymousEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        String eventName = verifiedAnalyticsEvent.getEventType();
        if (verifiedAnalyticsEvent.getData() != null && !(verifiedAnalyticsEvent.getData() instanceof NullNode) && !(StringUtils.isBlank(verifiedAnalyticsEvent.getData().path("eventName").asText()))) {
            eventName = verifiedAnalyticsEvent.getData().path("eventName").asText(eventName);
        }
        AnonymousEventRequest anonymousEventRequest = AnonymousEventRequest.builder()
                .id(verifiedAnalyticsEvent.getId())
                .name(eventName)
                .type(CustomerIOEventType.EVENT)
                .timestamp(verifiedAnalyticsEvent.getTimestamp())
                .anonymousId(UUID.randomUUID().toString())
                .data(verifiedAnalyticsEvent.getData())
                .build();

        log.info("Processing request for anonymous event : {}", anonymousEventRequest);
        customerIOIntegrationService.sendAnonymousEventToCustomerIO(anonymousEventRequest);
    }
}
