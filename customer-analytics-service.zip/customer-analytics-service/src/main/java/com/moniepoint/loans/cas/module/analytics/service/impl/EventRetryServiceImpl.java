package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDTO;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;
import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventDeadLetterRepositoryService;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class EventRetryServiceImpl implements EventRetryService {

    private final EventRetryRepositoryService eventRetryRepositoryService;
    private final EventDeadLetterRepositoryService eventDeadLetterRepositoryService;
    private final Clock clock;
    private final KafkaEventPublisher<EventRetryIDRangeDTO> eventRetryIdRangeKafkaEventPublisher;
    private final KafkaEventPublisher<EventRetryDTO> eventRetryIdKafkaEventPublisher;

    @Value("${integrations.retry.max-attempts}")
    private int maxAttempts;

    @Value("${integrations.retry.next-interval-in-seconds}")
    private int nextIntervalInSeconds;

    @Value("${event-retry.partition-size}")
    private int partitionSize;

    @Value("${event-retry.page-size}")
    private int pageSize;

    @Value("${event-retry.fetch-limit:500000}")
    private Long retryLimit;

    @Override
    public void processFailedEventData(EventRetryDataDTO eventRetryDataDTO) {
        EventProvider provider = eventRetryDataDTO.getEventProvider();
        String eventId = eventRetryDataDTO.getEventId();

        LocalDateTime currentDateTime = LocalDateTime.now(clock);
        LocalDateTime nextRetryDateTime = currentDateTime.plusSeconds(nextIntervalInSeconds);

        Optional<EventRetry> eventRetryOptional = eventRetryRepositoryService.findByEventIdAndEventProvider(eventId, provider);
        if (eventRetryOptional.isPresent()) {
            EventRetry eventRetry = eventRetryOptional.get();
            int attemptCount = eventRetry.getAttemptCount();
            if (attemptCount == maxAttempts) {
                processMaxAttemptFailure(eventRetryDataDTO, eventRetry);
            } else {
                eventRetry.setAttemptCount(eventRetry.getAttemptCount() + 1);
                eventRetry.setLastRetryTime(currentDateTime);
                eventRetry.setNextRetryTime(nextRetryDateTime);
                try {
                    eventRetryRepositoryService.save(eventRetry);
                } catch (DataIntegrityViolationException e) {
                    log.warn("Error writing record {} in eventRetry table", eventRetry.getEventId(), e);
                }
                catch (Exception e) {
                    log.error("Unable to update record {} in eventRetry table", eventRetry.getEventId(), e);
                }
            }
        } else {
            processFirstEventRetry(eventRetryDataDTO, currentDateTime, nextRetryDateTime);
        }
    }

    @Override
    public void retryFailedEvents() {
        Long minId = eventRetryRepositoryService.findMinEventRetryId();
        Long maxId = eventRetryRepositoryService.findMaxEventRetryId(minId, retryLimit);

        if (Objects.nonNull(minId) && Objects.nonNull(maxId)) {
            long start = minId;
            while (start <= maxId) {
                long end = Math.min(start + partitionSize - 1, maxId);
                EventRetryIDRangeDTO eventRetryIDRangeDTO = EventRetryIDRangeDTO.builder().start(start).end(end).build();
                String key = String.format("%s-%s", start, end);
                eventRetryIdRangeKafkaEventPublisher.publishEvent(key, eventRetryIDRangeDTO);
                start += partitionSize;
            }
        }
    }

    @Override
    public void handleEventRetryIDRange(EventRetryIDRangeDTO eventRetryIDRangeDTO) {
        Long start = eventRetryIDRangeDTO.getStart();
        Long end = eventRetryIDRangeDTO.getEnd();
        int currentPage = 0;
        boolean hasNextPage = true;

        while (hasNextPage) {
            Page<Long> paginatedEventRetryIds = eventRetryRepositoryService.fetchPaginatedIdsInRange(start, end, currentPage, pageSize);
            List<Long> eventRetryIds = paginatedEventRetryIds.getContent();
            processEventRetryIds(eventRetryIds);
            hasNextPage = paginatedEventRetryIds.hasNext();
            currentPage++;
        }
    }

    private void processEventRetryIds(List<Long> eventRetryIds) {
        eventRetryIds.stream().map(id -> EventRetryDTO.builder().id(id).build()).forEach(eventRetryDTO -> 
            eventRetryIdKafkaEventPublisher.publishEvent(eventRetryDTO.getId().toString(), eventRetryDTO));
    }

    private void processMaxAttemptFailure(EventRetryDataDTO eventRetryDataDTO, EventRetry eventRetry) {
        EventDeadLetter eventDeadLetter = EventDeadLetter.builder()
                .eventId(eventRetryDataDTO.getEventId())
                .eventProvider(eventRetryDataDTO.getEventProvider())
                .eventData(eventRetryDataDTO.getEventData())
                .lastFailureReason(eventRetryDataDTO.getFailureReason())
                .lastRetryTime(eventRetry.getLastRetryTime())
                .build();

        try {
            eventDeadLetterRepositoryService.save(eventDeadLetter);
        } catch (DataIntegrityViolationException e) {
            log.warn("Error writing record {} in eventDeadLetter table", eventDeadLetter.getEventId(), e);
        }
        catch (Exception e) {
            log.error("Unable to save record {} in eventDeadLetter table", eventDeadLetter.getEventId(), e);
        }

        try{
            eventRetryRepositoryService.deleteById(eventRetry.getId());
        } catch (Exception e) {
           log.error("Unable to delete retry for record {} in the database",eventRetryDataDTO.getEventId(), e);
        }
    }

    private void processFirstEventRetry(EventRetryDataDTO eventRetryDataDTO, LocalDateTime currentDateTime, LocalDateTime nextRetryDateTime) {
        EventRetry eventRetry = EventRetry.builder()
                .eventId(eventRetryDataDTO.getEventId())
                .eventProvider(eventRetryDataDTO.getEventProvider())
                .eventData(eventRetryDataDTO.getEventData())
                .attemptCount(1)
                .lastFailureReason(eventRetryDataDTO.getFailureReason())
                .lastRetryTime(currentDateTime)
                .nextRetryTime(nextRetryDateTime)
                .build();
        try {
            eventRetryRepositoryService.save(eventRetry);
        } catch (DataIntegrityViolationException e) {
            log.warn("Error writing record {} in eventRetry table", eventRetry.getEventId(), e);
        }
        catch (Exception e) {
            log.error("Unable to create entry of record {} in eventRetry table", eventRetry.getEventId(), e);
        }
    }
}
