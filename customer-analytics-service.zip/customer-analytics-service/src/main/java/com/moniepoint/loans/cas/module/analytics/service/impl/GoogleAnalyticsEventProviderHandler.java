package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.googleanalytics.config.GoogleAnalyticsConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsIntegrationService;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.moniepoint.loans.cas.common.util.JsonUtils.flattenObjectNode;

@Service
@RequiredArgsConstructor
@Slf4j
public class GoogleAnalyticsEventProviderHandler implements EventProviderHandler {

    private final GoogleAnalyticsIntegrationService googleAnalyticsIntegrationService;
    private final GoogleAnalyticsConfig googleAnalyticsConfig;
    private final ObjectMapperHelper objectMapperHelper;

    @Override
    public boolean support(EventProvider provider) {
        return EventProvider.GA.equals(provider);
    }

    @Override
    public void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        if (!googleAnalyticsConfig.isEnable()) {
            return;
        }
        processGoogleAnalyticsEventRequest(verifiedAnalyticsEvent);
    }

    @Override
    public boolean processEvent(String eventJsonString) {
        GoogleAnalyticsEventRequest request = objectMapperHelper.deserializeStringToObject(eventJsonString, new TypeReference<>() {
        });
        return googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(request).isSuccess();
    }

    private void processGoogleAnalyticsEventRequest(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        log.info("Processing request with event : {}", verifiedAnalyticsEvent);

        JsonNodeFactory jsonNodeFactory = JsonNodeFactory.instance;
        ArrayNode arrayNode = jsonNodeFactory.arrayNode();
        ObjectNode objectNode = jsonNodeFactory.objectNode();

        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .events(arrayNode)
                .userId(verifiedAnalyticsEvent.getCustomerIdentifier())
                .build();

        ObjectNode data = (ObjectNode) verifiedAnalyticsEvent.getData();
        String deviceType = Optional.ofNullable(data.get("device_type")).map(JsonNode::asText).orElse(null);

        if ("WEB".equals(deviceType)) {
            String clientId = Optional.ofNullable(data.get("clientId")).map(JsonNode::asText).orElse(null);
            data.remove("clientId");
            request.setClientId(clientId);
        } else {
            String appInstanceId = Optional.ofNullable(data.get("appInstanceId")).map(JsonNode::asText).orElse(null);
            data.remove("appInstanceId");
            request.setAppInstanceId(appInstanceId);
        }

        data.put("eventId", verifiedAnalyticsEvent.getId());
        var value = data.path("amount").asDouble(0.0);
        data.put("value", value);
        data.put("currency", "NGN");



        objectNode.put("name", verifiedAnalyticsEvent.getEventType());
        objectNode.set("params", flattenObjectNode(data));

        arrayNode.add(objectNode);

        googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(request);
    }

}
