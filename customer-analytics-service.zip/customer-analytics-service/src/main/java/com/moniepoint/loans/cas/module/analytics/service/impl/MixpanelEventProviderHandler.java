package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.HTTPUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventProperties;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelProfilePropertiesRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.service.impl.MixpanelIntegrationServiceImpl;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.analytics.entity.MixpanelApiKey;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Stream;

@Service
@Slf4j
public class MixpanelEventProviderHandler implements EventProviderHandler {
    private final boolean enable;
    private final String projectToken;

    private final MixpanelIntegrationServiceImpl mixpanelIntegrationService;
    private final ObjectMapperHelper objectMapperHelper;
    private final ObjectMapper objectMapper;

    @Value("${integrations.mixpanel.enable-workspace-targeting:true}")
    private boolean enableWorkspaceTargeting;


    public MixpanelEventProviderHandler(
            @Value("${integrations.mixpanel.enable}") boolean enable,
            @Value("${integrations.mixpanel.project-token}") String projectToken,
            MixpanelIntegrationServiceImpl mixpanelIntegrationService,
            ObjectMapperHelper objectMapperHelper,
            ObjectMapper objectMapper
    ) {
        this.enable = enable;
        this.projectToken = projectToken;
        this.mixpanelIntegrationService = mixpanelIntegrationService;
        this.objectMapperHelper = objectMapperHelper;
        this.objectMapper = objectMapper;
    }


    @Override
    public boolean support(EventProvider provider) {
        return EventProvider.MIX.equals(provider);
    }

    @Override
    public void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        processEvents(List.of(verifiedAnalyticsEvent));
    }

    // Used in a retry mechanism
    @Override
    public boolean processEvent(String eventJsonString) {
        MixpanelEventRequest mixpanelEventRequest = objectMapperHelper.deserializeStringToObject(eventJsonString, new TypeReference<>() {
        });
        String appID = (!enableWorkspaceTargeting || mixpanelEventRequest.getProperties().getCustomProperties().get("application_id") == null) ? "" : mixpanelEventRequest.getProperties().getCustomProperties().get("application_id").toString();
        MixpanelApiKey mixpanelApiKey = mixpanelIntegrationService.getClientProjectData(appID);
        String token = mixpanelApiKey == null ? projectToken : mixpanelApiKey.getProjectToken();
        return mixpanelIntegrationService.sendEventsToMixpanel(List.of(mixpanelEventRequest), getAuthorizationToken(token)).isSuccess();
    }


    @Override
    @Async("appExecutor")
    public void processEvents(List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents) {
        if (!enable) {
            return;
        }
        log.info("Processing request with {} events", verifiedAnalyticsEvents.size());

        var eventRequests = verifiedAnalyticsEvents.stream()
                .map(this::createMixpanelEventRequest)
                .toList();

        List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEventDTOUpdated = new ArrayList<VerifiedAnalyticsEventDTO>();

        String appID = !enableWorkspaceTargeting ? "" : verifiedAnalyticsEvents.getFirst().getApplicationID();
        MixpanelApiKey mixpanelApiKey = mixpanelIntegrationService.getClientProjectData(appID);
        String token = mixpanelApiKey == null ? projectToken : mixpanelApiKey.getProjectToken();
        if (!eventRequests.isEmpty()) {
            var requests =mixpanelIntegrationService.identifyUnknownUsersByProfileProperties(eventRequests, mixpanelApiKey);

            mixpanelIntegrationService.sendEventsToMixpanel(requests, getAuthorizationToken(token));

            verifiedAnalyticsEventDTOUpdated =
                    verifiedAnalyticsEvents.stream()
                            .filter(e -> e.getUserAttributes() != null)
                            .flatMap(ef -> {
                                List<VerifiedAnalyticsEventDTO> sub = new ArrayList<>();

                                requests.stream()
                                        .filter(r -> Objects.equals(r.getProperties().getInsertID(), ef.getId()))
                                        .map(r -> r.getProperties().getUserID())
                                        .filter(StringUtils::isNotBlank)
                                        .forEach(userId -> {
                                            VerifiedAnalyticsEventDTO copy = ef.toBuilder()
                                                    .userIdentifiers(ef.getUserIdentifiers().toBuilder().build())
                                                    .userAttributes(ef.getUserAttributes().toBuilder().build())
                                                    .build();
                                            copy.getUserIdentifiers().setUserID(userId);
                                            sub.add(copy);
                                        });
                                return sub.isEmpty() ? Stream.of(ef) : sub.stream();
                            })
                            .toList();
        }

        var userUpdateRequests = verifiedAnalyticsEventDTOUpdated.stream()
                .map(e -> new MixpanelProfilePropertiesRequest(e, token, objectMapper))
                .toList();
        if (!userUpdateRequests.isEmpty()) {
            mixpanelIntegrationService.updateProfileAttributes(userUpdateRequests);
        }
    }

    private MixpanelEventRequest createMixpanelEventRequest(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
        MixpanelEventProperties mixpanelProps = new MixpanelEventProperties();
        if (verifiedAnalyticsEvent.getData() != null && ! (verifiedAnalyticsEvent.getData() instanceof  NullNode))
        {
            ObjectNode objectNode = (ObjectNode)verifiedAnalyticsEvent.getData();
            mixpanelProps = objectMapper.convertValue(objectNode, MixpanelEventProperties.class);
            if (mixpanelProps.getCustomProperties() != null)
            {
                mixpanelProps.getCustomProperties().remove("properties");
            }
            var properties = objectMapper.convertValue(objectNode.get("properties"), Map.class);
            if (properties != null) {
                if (mixpanelProps.getCustomProperties() == null)
                {
                    mixpanelProps.setCustomProperties(new HashMap<>());
                }
                mixpanelProps.getCustomProperties().putAll(properties);
            }
            AnalyticsEventV3DeviceInfoDTO device = objectMapper.convertValue(objectNode.get("device"), AnalyticsEventV3DeviceInfoDTO.class);
            if (device != null && device.getId() != null) {
                mixpanelProps.setDeviceID(device.getId());
                mixpanelProps.setOs(device.getOs());
                mixpanelProps.setOsVersion(device.getOsVersion());
                mixpanelProps.setBrowser(device.getAgent());
                mixpanelProps.setBrowserVersion(device.getAgentVersion());
                mixpanelProps.setCurrentURL(device.getUrl());
                mixpanelProps.setInitialReferrer(device.getReferrer());
                mixpanelProps.setInitialReferringDomain(HTTPUtils.getDomainFromURL(device.getReferrer()));
                mixpanelProps.setScreenDPI(device.getDpi());
                mixpanelProps.setScreenWidth(device.getWidth());
                mixpanelProps.setScreenHeight(device.getHeight());

                mixpanelProps.setAppBuildNumber(device.getBuildNumber());
                mixpanelProps.setAppVersionString(device.getVersion());
                if (device.getType().equalsIgnoreCase("ios")) {
                    mixpanelProps.setIOSAppVersion(device.getVersion());
                    mixpanelProps.setIOSAppRelease(device.getBuildNumber());
                } else if (device.getType().equalsIgnoreCase("android")) {
                    mixpanelProps.setAndroidAppVersion(device.getVersion());
                }
            }
        }
        var userAttributes = objectMapper.convertValue(verifiedAnalyticsEvent.getUserAttributes(), Map.class);
        if (userAttributes != null) {
            if (mixpanelProps.getCustomProperties() == null)
            {
                mixpanelProps.setCustomProperties(new HashMap<>());
            }
            mixpanelProps.getCustomProperties().putAll(userAttributes);
        }
        mixpanelProps.addCustomProperty("app_env", verifiedAnalyticsEvent.getAppEnv());
        mixpanelProps.addCustomProperty("platform", verifiedAnalyticsEvent.getPlatformv2());
        mixpanelProps.addCustomProperty("application_id", verifiedAnalyticsEvent.getApplicationID());
        mixpanelProps.addCustomProperty("analytics_source", "CAS");
        mixpanelProps.setInsertID(verifiedAnalyticsEvent.getId());
        mixpanelProps.setTime(verifiedAnalyticsEvent.getTimestamp().getTime());
        mixpanelProps.setIp(verifiedAnalyticsEvent.getIp());
        mixpanelProps.setEmail(StringUtils.isBlank(verifiedAnalyticsEvent.getUserIdentifiers().getEmail()) ? (verifiedAnalyticsEvent.getUserAttributes() == null ? null : verifiedAnalyticsEvent.getUserAttributes() .getEmail()) :  verifiedAnalyticsEvent.getUserIdentifiers().getEmail());
        mixpanelProps.setPhone(StringUtils.isBlank(verifiedAnalyticsEvent.getUserIdentifiers().getPhone()) ? (verifiedAnalyticsEvent.getUserAttributes() == null ? null : verifiedAnalyticsEvent.getUserAttributes().getPhone()) : verifiedAnalyticsEvent.getUserIdentifiers().getPhone());
        mixpanelProps.setLongitude(verifiedAnalyticsEvent.getLongitude());
        mixpanelProps.setLatitude(verifiedAnalyticsEvent.getLatitude());

        if (verifiedAnalyticsEvent.getUserIdentifiers() != null) {
            mixpanelProps.setUserID(verifiedAnalyticsEvent.getUserIdentifiers().getUserID());
            if (StringUtils.isBlank(mixpanelProps.getDeviceID()))
            {
                mixpanelProps.setDeviceID(verifiedAnalyticsEvent.getUserIdentifiers().getSessionID());
            }
        }
        String distinctId = StringUtils.isBlank(mixpanelProps.getUserID()) ? mixpanelProps.getDeviceID() : mixpanelProps.getUserID() ;
        mixpanelProps.setDistinctID(distinctId);

        return MixpanelEventRequest.builder()
                .event(StringUtils.isBlank(verifiedAnalyticsEvent.getData().path("eventName").asText()) ? verifiedAnalyticsEvent.getEventType() : verifiedAnalyticsEvent.getData().path("eventName").asText() )
                .properties(mixpanelProps)
                .build();
    }

    private String getAuthorizationToken(String token) {
        String auth = String.format("%s:", token);
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
        return String.format("Basic %s", new String(encodedAuth));
    }

}
