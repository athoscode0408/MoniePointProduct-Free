package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;
import com.moniepoint.loans.cas.module.analytics.repository.NpsUserStateStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsUserStateService;
import jakarta.persistence.OptimisticLockException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.ZoneId;

@Slf4j
@Service
@RequiredArgsConstructor
public class NpsUserStateServiceImpl implements NpsUserStateService {

    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    private final NpsUserStateStorage npsUserStateStorage;

    @Override
    @Transactional(readOnly = true)
    public boolean isInCoolOff(String username, int coolOffDays, int yearlyTriggerCap) {
        return npsUserStateStorage.findByUserName(username)
                .map(state -> isStateCoolingOff(state, coolOffDays, yearlyTriggerCap))
                .orElse(false);
    }

    @Override
    @Transactional
    public NpsUserState writeTriggered(String username) {
        NpsUserState state = npsUserStateStorage.findByUserName(username)
                .map(existing -> applyTrigger(existing))
                .orElseGet(() -> buildFirstTrigger(username));

        try {
            return npsUserStateStorage.save(state);
        } catch (OptimisticLockException e) {
            log.debug("OptimisticLockException writing NPS trigger for username={}, returning committed state", username);
            return npsUserStateStorage.findByUserName(username)
                    .orElseThrow(() -> new IllegalStateException("NpsUserState missing after OptimisticLockException for username=" + username));
        }
    }

    private boolean isStateCoolingOff(NpsUserState state, int coolOffDays, int yearlyTriggerCap) {
        LocalDate today = LocalDate.now(LAGOS);
        int thisYear = today.getYear();

        if (state.getLastNpsTriggeredDate() != null) {
            long daysSinceTrigger = today.toEpochDay() - state.getLastNpsTriggeredDate().toEpochDay();
            if (daysSinceTrigger < coolOffDays) {
                return true;
            }
        }

        if (thisYear == safeYear(state.getTriggerYear()) && state.getTriggerCountYear() >= yearlyTriggerCap) {
            return true;
        }

        return false;
    }

    private NpsUserState applyTrigger(NpsUserState existing) {
        LocalDate today = LocalDate.now(LAGOS);
        int thisYear = today.getYear();

        if (safeYear(existing.getTriggerYear()) != thisYear) {
            existing.setTriggerYear(thisYear);
            existing.setTriggerCountYear(1);
        } else {
            existing.setTriggerCountYear(existing.getTriggerCountYear() + 1);
        }
        existing.setLastNpsTriggeredDate(today);
        return existing;
    }

    private NpsUserState buildFirstTrigger(String username) {
        LocalDate today = LocalDate.now(LAGOS);
        return NpsUserState.builder()
                .userId(username) // backward compatibility: user_id column keeps storing the username value
                .userName(username) // now correctly populated; used as the lookup key going forward
                .lastNpsTriggeredDate(today)
                .triggerYear(today.getYear())
                .triggerCountYear(1)
                .build();
    }

    private int safeYear(Integer year) {
        return year != null ? year : -1;
    }
}
