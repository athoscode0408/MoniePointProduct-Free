package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.repository.NpsWeeklySampleStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySampleExpiryService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class NpsWeeklySampleExpiryServiceImpl implements NpsWeeklySampleExpiryService {

    private final NpsWeeklySampleStorage npsWeeklySampleStorage;

    @Override
    @Transactional
    public void expireWeeklySamples(String isoWeek) {
        int expired = npsWeeklySampleStorage.updateStatusByIsoWeekLessThanEqualAndCurrentStatus(
                isoWeek, NpsSampleStatus.PENDING, NpsSampleStatus.EXPIRED);

        int generatedExpired = npsWeeklySampleStorage.updateStatusByIsoWeekLessThanEqualAndCurrentStatus(
                isoWeek, NpsSampleStatus.GENERATED, NpsSampleStatus.EXPIRED);

        int abandoned = npsWeeklySampleStorage.updateStatusByIsoWeekLessThanEqualAndCurrentStatus(
                isoWeek, NpsSampleStatus.SERVED, NpsSampleStatus.ABANDONED);

        log.info("NPS expiry: week={}, expired={}, generatedExpired={}, abandoned={}",
                isoWeek, expired, generatedExpired, abandoned);
    }
}
