package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.NpsWeeklySampleStorage;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsUserStateService;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySampleService;
import jakarta.persistence.OptimisticLockException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class NpsWeeklySampleServiceImpl implements NpsWeeklySampleService {

    private final NpsWeeklySampleStorage npsWeeklySampleStorage;
    private final PreprocessedSurveyStorage preprocessedSurveyStorage;
    private final NpsUserStateService npsUserStateService;

    @Override
    @Transactional
    public Optional<PreprocessedSurvey> serveNpsSurvey(String username, String isoWeek) {
        Optional<NpsWeeklySample> sampleOpt = npsWeeklySampleStorage.findByUserNameAndIsoWeek(username, isoWeek);

        if (sampleOpt.isEmpty()) {
            return Optional.empty();
        }

        NpsWeeklySample sample = sampleOpt.get();

        if (sample.getStatus() == NpsSampleStatus.SERVED) {
            log.debug("NPS sample already SERVED for username={} isoWeek={}, returning existing survey", username, isoWeek);
            return findPreprocessedSurvey(username, isoWeek);
        }

        if (sample.getStatus() != NpsSampleStatus.PENDING && sample.getStatus() != NpsSampleStatus.GENERATED) {
            return Optional.empty();
        }

        try {
            sample.setStatus(NpsSampleStatus.SERVED);
            sample.setServedAt(Timestamp.from(Instant.now()));
            npsWeeklySampleStorage.save(sample);
            npsUserStateService.writeTriggered(username);
        } catch (OptimisticLockException e) {
            log.debug("OptimisticLockException on double-serve for username={} isoWeek={}, returning already-served survey", username, isoWeek);
        }

        return findPreprocessedSurvey(username, isoWeek);
    }

    private Optional<PreprocessedSurvey> findPreprocessedSurvey(String username, String isoWeek) {
        return preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(
                username,
                isoWeek,
                List.of(PreprocessedSurveyState.NOT_COMPLETED, PreprocessedSurveyState.NOT_READY)
        );
    }
}
