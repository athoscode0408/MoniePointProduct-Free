package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyExpiryView;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.service.PreprocessedSurveyExpiryService;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class PreprocessedSurveyExpiryServiceImpl implements PreprocessedSurveyExpiryService {

    private final PreprocessedSurveyStorage preprocessedSurveyStorage;
    private final RedisCacheServiceImpl cache;

    @Value("${survey.expiry-batch-size:50}")
    private long batchSize;

    @Value("${survey.expiry-max-duration-mins:45}")
    private long maxDurationMins;

    @Value("${survey.expiry-v2.batch-size:500}")
    private int v2BatchSize;

    // Comma-separated states eligible to be expired (e.g. NOT_COMPLETED,NOT_READY)
    @Value("${survey.expiry-v2.eligible-states:NOT_COMPLETED,NOT_READY}")
    private String eligibleStatesConfig;

    @Override
    public void expirePreprocessedSurveys() {
        Instant deadline = Instant.now().plus(maxDurationMins, ChronoUnit.MINUTES);
        int totalExpired = 0;
        int batchCount = 0;
        boolean timedOut = false;

        while (true) {
            if (Instant.now().isAfter(deadline)) {
                timedOut = true;
                break;
            }

            try {
                int updated = preprocessedSurveyStorage.expirePreprocessedSurveys(batchSize);
                totalExpired += updated;
                batchCount++;
                log.info("Expired {} surveys in batch {}, total expired so far: {}", updated, batchCount, totalExpired);

                if (updated < batchSize) {
                    break;
                }
            } catch (Exception e) {
                log.error("Unable to expire surveys in batch {}, stopping early", batchCount + 1, e);
                break;
            }
        }

        log.info("Completed survey expiry. Total expired: {}, batches processed: {}, timed out: {}",
                totalExpired, batchCount, timedOut);
    }

    @Override
    public void expirePreprocessedSurveysV2() {
        Set<PreprocessedSurveyState> eligibleStates = parseEligibleStates();
        if (eligibleStates.isEmpty()) {
            log.error("expirePreprocessedSurveysV2: no eligible states configured, aborting.");
            return;
        }

        Instant deadline = Instant.now().plus(maxDurationMins, ChronoUnit.MINUTES);
        Timestamp now = Timestamp.from(Instant.now());

        long cursor = cache.getExpiryCursor();
        int totalScanned = 0;
        int totalExpired = 0;
        int batchCount = 0;
        boolean timedOut = false;

        log.info("expirePreprocessedSurveysV2: starting from cursor id={}, eligible states={}", cursor, eligibleStates);

        while (true) {
            if (Instant.now().isAfter(deadline)) {
                timedOut = true;
                break;
            }

            List<PreprocessedSurveyExpiryView> batch = preprocessedSurveyStorage
                    .findBatchStartingAfter(cursor, eligibleStates, PageRequest.of(0, v2BatchSize));

            if (batch.isEmpty()) {
                log.info("expirePreprocessedSurveysV2: reached end of table at cursor id={}, resetting cursor.", cursor);
                cache.setExpiryCursor(0L);
                break;
            }

            long lastIdInBatch = batch.getLast().getId();
            totalScanned += batch.size();

            List<Long> toExpire = batch.stream()
                    .filter(ps -> eligibleStates.contains(ps.getState())
                            && ps.getTtl() != null
                            && ps.getTtl().before(now))
                    .map(PreprocessedSurveyExpiryView::getId)
                    .toList();

            if (toExpire.isEmpty()) {
                cursor = lastIdInBatch;
                cache.setExpiryCursor(cursor);
                log.info("expirePreprocessedSurveysV2: no expired rows in batch ending at id={}, stopping early.", cursor);
                break;
            }

            try {
                int expired = preprocessedSurveyStorage.expireByIds(toExpire);
                totalExpired += expired;
            } catch (Exception e) {
                log.error("expirePreprocessedSurveysV2: failed to expire batch at cursor id={}, skipping batch.", cursor, e);
            }

            batchCount++;
            cursor = lastIdInBatch;
            cache.setExpiryCursor(cursor);

            log.info("expirePreprocessedSurveysV2: batch={}, scanned={}, expired={} of {}, cursor advanced to id={}",
                    batchCount, batch.size(), toExpire.size(), batch.size(), cursor);
        }

        log.info("expirePreprocessedSurveysV2: done. totalScanned={}, totalExpired={}, batches={}, timedOut={}, cursor={}",
                totalScanned, totalExpired, batchCount, timedOut, cursor);
    }

    private Set<PreprocessedSurveyState> parseEligibleStates() {
        return Arrays.stream(eligibleStatesConfig.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(s -> {
                    try {
                        return PreprocessedSurveyState.valueOf(s);
                    } catch (IllegalArgumentException e) {
                        log.error("expirePreprocessedSurveysV2: unknown eligible state '{}', ignoring.", s);
                        return null;
                    }
                })
                .filter(s -> s != null)
                .collect(Collectors.toSet());
    }
}
