package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.kafka.service.impl.AbstractKafkaEventPublisher;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
public class RawAnalyticsEventKafkaEventPublisher extends AbstractKafkaEventPublisher<AnalyticsEventV1RequestDTO> {

    private final String topic;

    public RawAnalyticsEventKafkaEventPublisher(@Value("${kafka.topic.raw-analytics-event}") String topic,
                                                KafkaTemplate<String, String> kafkaTemplate,
                                                ObjectMapperHelper objectMapperHelper, Telemetry telemetry) {
        super(kafkaTemplate, objectMapperHelper, telemetry);
        this.topic = topic;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    public void publishEvent(AnalyticsEventV1RequestDTO analyticsEventRequest) {
        if (Objects.isNull(analyticsEventRequest)) {
            log.error("Failed to send raw analytics event due to missing event data.");
            return;
        }
        String key = getRawAnalyticEventKey(analyticsEventRequest);
        if (Strings.isBlank(key)) {
            log.error("Failed to send raw analytics event due missing key.");
            return;
        }
        publishEvent(key, analyticsEventRequest);
        log.info("Raw analytics event '{}' has successfully published with key '{}'.", analyticsEventRequest, key);
    }

    private String getRawAnalyticEventKey(AnalyticsEventV1RequestDTO analyticsEventRequest){
        return analyticsEventRequest.getId();
    }

}
