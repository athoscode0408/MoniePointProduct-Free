package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.analytics.dto.v3.EventPreprocessSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class RuleParserHandler {

    private record RulesContext(VerifiedAnalyticsEventDTO event, UserAttributes user) {
    }
    private final KafkaEventPublisher<EventPreprocessSurveyDTO> surveyPreprocessorKafkaEventPublisher;
    private final PreprocessedSurveyStorage preprocessedSurveyStorage;
    private final ExpressionParser expressionParser = new SpelExpressionParser();
    private final ObjectMapperHelper objectMapperHelper;
    private final RuntimeSurveyScheduler runtimeSurveyScheduler;
    private final SurveyBodyLoader surveyBodyLoader;

    @Value("${survey.response-window-mins:7}")
    private Long responseWindowMins;
    @Value("${survey.max-response-in-window:2}")
    private int responseCount;
    @Value("${survey.response-window-mins-individual-survey:30}")
    private Long responseWindowMinsIndividualsurvey;
    @Value("${survey.max-response-in-window-individual-survey:1}")
    private int responseCountIndividualsurvey;
    @Value("${survey.check-user-survey-history:true}")
    private Boolean useUserSurveyHistory;
    @Value("${survey.not-ready-survey-ttl-mins:180}")
    private int notReadySurveyTtl;

    @Async("appExecutor")
    @Trace
    @Transactional
    public void parseRule(Survey surveyRule, VerifiedAnalyticsEventDTO event, UserAttributes user) {
        Telemetry.runInSpan("RuleParser", () -> {
            var userId=event.getUserIdentifiers().getUserID();

            SurveyBody surveyBody = deserializeSurveyBody(surveyRule);
            boolean randomizeSurveyAssignment = surveyBody != null && surveyBody.isRandomizeSurveyAssignment();

            if (randomizeSurveyAssignment)
            {
                try{
                    boolean evaluateBRMSurvey = evaluateBRMSurveyEligibilityForUser(surveyRule,userId);
                    if (!evaluateBRMSurvey)
                        return;
                }
                catch (Exception e)
                {
                    log.error("An exception occurred while trying to evaluate BRM survey {} ", surveyRule.getId(), e);
                    return;
                }
            }

            log.info("Starting evaluation of survey rule {} for user {}.", surveyRule.getRule(), userId);

            try {
                var context = new StandardEvaluationContext(new RulesContext(event, user));
                context.addPropertyAccessor(new MapAccessor());

                var dataMap = objectMapperHelper.convertObjectToType(event.getData(), new com.fasterxml.jackson.core.type.TypeReference<>() {});
                context.setVariable("data", dataMap);

                var expression = expressionParser.parseExpression(surveyRule.getRule());

                if (Boolean.TRUE.equals(expression.getValue(context, Boolean.class))) {
                    log.info("survey rule {} evaluated to TRUE for user {}.", surveyRule.getRule(), userId);

                    boolean generateSurveyPerBRM = surveyBody != null && (surveyBody.isGenerateUniqueSurveyPerBRM());

                    if (useUserSurveyHistory && !userEligibleFromSurveyHistory(surveyRule, userId, user, generateSurveyPerBRM))
                    {
                        return;
                    }

                    var eventLocation = Optional.ofNullable(event.getPlatform()).orElse(null);
                    var location = "web".equalsIgnoreCase(eventLocation) ? surveyRule.getWebLocation() : surveyRule.getMobileLocation();
                    var preprocessedSurvey = PreprocessedSurvey.builder()
                            .user(userId)
                            .event(event.getId())
                            .priority(surveyRule.getPriority())
                            .surveyId(surveyRule.getId())
                            .ttl(Timestamp.from(event.getTimestamp().toInstant().plus(Duration.of(notReadySurveyTtl, ChronoUnit.MINUTES))))
                            .location(location)
                            .state(PreprocessedSurveyState.NOT_READY)
                            .build();
                    ObjectNode additionalData = JsonNodeFactory.instance.objectNode();
                    UserAttributes requestAttributes = event.getUserAttributes();
                    String businessAccount = requestAttributes == null ? null : requestAttributes.getBusinessNubanAccountNumber();
                    String personalAccount = requestAttributes == null ? null : requestAttributes.getNubanAccountNumber();
                    String accountNumber = StringUtils.isBlank(businessAccount) ? personalAccount : businessAccount;
                    if (StringUtils.isNotBlank(accountNumber))
                    {
                        additionalData.put("accountNumber", accountNumber);
                    }
                    if (generateSurveyPerBRM && StringUtils.isNotBlank(user.getBrmId()))
                    {
                        additionalData.put("brmId", user.getBrmId());
                    }
                    preprocessedSurvey.setAdditionalData(additionalData.toString());
                    preprocessedSurveyStorage.save(preprocessedSurvey);
                    log.debug("Saved partially preprocessed survey for  rule {} and user {}.", surveyRule.getRule(), event.getUserIdentifiers().getUserID());
                    enqueueSurveyForPreprocessing(surveyRule, user, event, preprocessedSurvey);
                }
                else {
                    log.info("survey rule {} evaluated to FALSE for user {}.", surveyRule.getRule(), event.getUserIdentifiers().getUserID());
                }
            } catch (Exception ex) {
                log.warn("Expression {} failed to be evaluated. Skipping. Reason: {}", surveyRule.getRule(), ex.getMessage());
            }
        });
    }

    private void enqueueSurveyForPreprocessing(Survey survey, UserAttributes user, VerifiedAnalyticsEventDTO event, PreprocessedSurvey preprocessedSurvey) {
        EventPreprocessSurveyDTO eventPreprocessSurveyDTO= EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(user)
                .verifiedAnalyticsEventDTO(event)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        log.debug("Now publishing partially preprocessed survey to kafka for processing completion");
        surveyPreprocessorKafkaEventPublisher.publishEvent("survey-preprocessor-"+event.getId(), eventPreprocessSurveyDTO);
    }

    private SurveyBody deserializeSurveyBody(Survey surveyRule) {
        return surveyBodyLoader.load(surveyRule);
    }

    public boolean evaluateBRMSurveyEligibilityForUser(Survey survey, String userId) {
        RuntimeSurveyScheduler.Plan plan =runtimeSurveyScheduler.planNext(survey.getId(),userId,survey.getStart().toInstant(), survey.getDurationInDays());
        return plan.evaluateSurvey;
    }

    @Trace
    private boolean userEligibleFromSurveyHistory(Survey survey, String userId,UserAttributes user, boolean generateSurveyPerBRM) {
        Timestamp now = Timestamp.from(Instant.now());

        SurveyBody surveyBody = deserializeSurveyBody(survey);
        long effectiveWindowMinsIndividual = surveyBody != null
                && surveyBody.getResponseWindowUniqueSurveyMins() != null
                && surveyBody.getResponseWindowUniqueSurveyMins() > 0L
                ? surveyBody.getResponseWindowUniqueSurveyMins()
                : responseWindowMinsIndividualsurvey;
        int effectiveCountIndividual = surveyBody != null && surveyBody.getMaxCountUniqueSurveyInResponseWindow() > 0
                ? surveyBody.getMaxCountUniqueSurveyInResponseWindow()
                : responseCountIndividualsurvey;
        long maxMins = Math.max(effectiveWindowMinsIndividual, responseWindowMins);
        Timestamp period = Timestamp.from(now.toInstant().minus(responseWindowMins, ChronoUnit.MINUTES));
        Timestamp periodUniqueSurvey = Timestamp.from(now.toInstant().minus(effectiveWindowMinsIndividual, ChronoUnit.MINUTES));
        Timestamp periodMaxMins = Timestamp.from(now.toInstant().minus(maxMins, ChronoUnit.MINUTES));

        List<PreprocessedSurvey> userPreprocessedSurveys=preprocessedSurveyStorage.findByUserAndStateInOrUserAndCompletedOnAfter(userId, List.of(PreprocessedSurveyState.NOT_COMPLETED, PreprocessedSurveyState.NOT_READY, PreprocessedSurveyState.DISMISSED), userId, periodMaxMins);

        List<PreprocessedSurvey> openPreprocessedSurveys=userPreprocessedSurveys.stream()
                .filter(ps ->
            ps.getSurveyId().equals(survey.getId()) && (ps.getState().equals(PreprocessedSurveyState.NOT_COMPLETED) || ps.getState().equals(PreprocessedSurveyState.NOT_READY) || ps.getState().equals(PreprocessedSurveyState.DISMISSED)) && ps.getTtl().after(now)
        ).collect(Collectors.toList());

        if (generateSurveyPerBRM && StringUtils.isNotBlank(user.getBrmId()))
        {
            openPreprocessedSurveys= openPreprocessedSurveys.stream().filter(ps ->{
                try {
                    JsonNode jsonNode= new ObjectMapper().readTree(ps.getAdditionalData());
                    String brmId = jsonNode.path("brmId").asText(null);
                    return StringUtils.isBlank(brmId) || brmId.equals(user.getBrmId());
                } catch (Exception e) {
                    log.warn("BRM preprocessed survey does not contain BRM data");
                    return false;
                }
            }).collect(Collectors.toList());
        }

        log.info("User has {} OPEN survey(s) with id {}",openPreprocessedSurveys.size(), survey.getId());

        if (!openPreprocessedSurveys.isEmpty())
            return false;

        List<PreprocessedSurvey> allUniqueRecentlyCompletedSurveys= userPreprocessedSurveys.stream()
                .filter(ps ->
                        ps.getSurveyId().equals(survey.getId()) && (ps.getState().equals(PreprocessedSurveyState.ABANDONED) || ps.getState().equals(PreprocessedSurveyState.COMPLETED)) && ps.getCompletedOn().after(periodUniqueSurvey)
                ).collect(Collectors.toList());

        if ( generateSurveyPerBRM && !StringUtils.isBlank(user.getBrmId()))
        {
            allUniqueRecentlyCompletedSurveys= allUniqueRecentlyCompletedSurveys.stream().filter(ps ->{
                try {
                    JsonNode jsonNode= new ObjectMapper().readTree(ps.getAdditionalData());
                    String brmId = jsonNode.path("brmId").asText(null);
                    return StringUtils.isBlank(brmId) || brmId.equals(user.getBrmId());
                } catch (Exception e) {
                    log.warn("BRM preprocessed survey does not contain BRM data");
                    return false;
                }
            }).collect(Collectors.toList());
        }

        log.info("Number of user completed surveys for survey id {} in the last {} mins is {}", survey.getId(), effectiveWindowMinsIndividual, allUniqueRecentlyCompletedSurveys.size());

        if (effectiveCountIndividual > 0 && allUniqueRecentlyCompletedSurveys.size() >= effectiveCountIndividual)
            return false;


        List<PreprocessedSurvey> allRecentlyCompletedSurveys=  userPreprocessedSurveys.stream()
                .filter(ps ->
                        (ps.getState().equals(PreprocessedSurveyState.ABANDONED) || ps.getState().equals(PreprocessedSurveyState.COMPLETED)) && ps.getCompletedOn().after(period)
                ).collect(Collectors.toList());

        if (generateSurveyPerBRM  && !StringUtils.isBlank(user.getBrmId()))
        {
            allRecentlyCompletedSurveys= allRecentlyCompletedSurveys.stream().filter(ps ->{
                if (!ps.getSurveyId().equals(survey.getId()))
                    return true;
                try {
                    JsonNode jsonNode= new ObjectMapper().readTree(ps.getAdditionalData());
                    String brmId = jsonNode.path("brmId").asText(null);
                    return StringUtils.isBlank(brmId) || brmId.equals(user.getBrmId());
                } catch (Exception e) {
                    log.warn("BRM preprocessed survey does not contain BRM data");
                    return false;
                }
            }).collect(Collectors.toList());
        }

        log.info("Number of all user completed surveys in the last {} mins is {}",responseWindowMins,allRecentlyCompletedSurveys.size());

        return responseCount == 0 || allRecentlyCompletedSurveys.size() < responseCount;
    }

}
