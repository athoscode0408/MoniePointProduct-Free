package com.moniepoint.loans.cas.module.analytics.service.impl;

import datadog.trace.api.Trace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Objects;

@Slf4j
@Service
public class RuntimeSurveyScheduler {

    record Range(ZonedDateTime start, ZonedDateTime end) {}


    public static final class Plan {
        public final int windowIndex;       // 0,1,2  (for reporting)
        public final boolean expired;
        public final boolean evaluateSurvey;

        public Plan( int windowIndex, boolean expired, Boolean evaluateSurvey) {
            this.windowIndex = windowIndex;
            this.expired = expired;
            this.evaluateSurvey = evaluateSurvey;
        }
    }

    public Plan planNext(
            long surveyId,
            String userId,
            Instant startTime,
            int surveyDurationInDays
    ) {
        // place user in 1 of 3 windows (0,1,2) (assuming we're distributing users into every 30 days across 90 days)
        int initialWindow = Math.floorMod(Objects.hash(userId, surveyId), 3);

        Instant nowUtc = Instant.now();

        ZoneId userZone = ZoneId.of("UTC");

        ZonedDateTime surveyStartLocal = startTime.atZone(userZone);

        return getPlan(surveyId, userId, userZone, surveyStartLocal, nowUtc, initialWindow,surveyDurationInDays);
    }

    @Trace
    private static Plan getPlan(long surveyId, String userId, ZoneId userZone, ZonedDateTime surveyStartLocal, Instant nowUtc,  int initialWindow, int surveyDurationDays) {
        int noOfWindows = 3;
        int windowSize = surveyDurationDays/noOfWindows;
        int lastWindowSize = windowSize+(surveyDurationDays%noOfWindows);

        var w1Start = surveyStartLocal.plusDays(windowSize);

        var w2Start = w1Start.plusDays(windowSize);

        var w3Start = w2Start.plusDays(lastWindowSize);

        var nowLocal = nowUtc.atZone(userZone);

        Range range = getStartAndEnd(w1Start, w2Start, w3Start, surveyStartLocal, initialWindow);

        ZonedDateTime start = range.start;
        ZonedDateTime end = range.end;
        log.info("RuntimeSurveyScheduler :: User: {} window for survey with id {} is {} and between {} and {}", userId, surveyId,initialWindow, start, end);

        if (nowLocal.isBefore(start))
        {
            log.debug("RuntimeSurveyScheduler :: User: {} schedule for survey is after current window.", userId);
            return new Plan( initialWindow, false, false);
        }

        else if (nowLocal.isAfter(w3Start))
        {
            log.debug("RuntimeSurveyScheduler :: This survey window was closed at {}. Creating new survey window from then ", w3Start );
            return getPlan(surveyId,userId,userZone,w3Start,nowUtc,initialWindow,surveyDurationDays);

        }

        else if (nowLocal.isBefore(end)) {
            log.debug("RuntimeSurveyScheduler :: User: {}  scheduled for survey in this window. ", userId);
            return new Plan(initialWindow, false, true);
        }

        else
        {
            log.debug("RuntimeSurveyScheduler :: User: {} window for survey has elapsed. ", userId);
            // Window elapsed without completion -> reschedule per rules.
            if (initialWindow == 2)
            {
                log.warn("RuntimeSurveyScheduler :: User: {} schedule for survey cannot be rescheduled further as survey has probably ended. ", userId);
                return new Plan(initialWindow, true, false);
            }
            else if (initialWindow == 0) {
                initialWindow = Math.floorMod(Objects.hash(userId, surveyId), 2) + 1;
                Range newRange = getStartAndEnd(w1Start, w2Start, w3Start, surveyStartLocal, initialWindow);

                ZonedDateTime newStart = newRange.start;
                ZonedDateTime newEnd = newRange.end;
                log.info("RuntimeSurveyScheduler :: User: {} new window for survey with id {} is {}. User's window is now between {} and {}", userId, surveyId, initialWindow, newStart, newEnd);
                return getPlan(surveyId,userId,userZone,surveyStartLocal,nowUtc,initialWindow,surveyDurationDays);
            }
            else {
                initialWindow = 2;
                Range newRange = getStartAndEnd(w1Start, w2Start, w3Start, surveyStartLocal, initialWindow);

                ZonedDateTime newStart = newRange.start;
                ZonedDateTime newEnd = newRange.end;
                log.info("RuntimeSurveyScheduler :: User: {} new window for survey with id {} is {}. User's window is now between {} and {}", userId, surveyId, initialWindow, newStart, newEnd  );
                return getPlan(surveyId,userId,userZone,surveyStartLocal,nowUtc,initialWindow,surveyDurationDays);
            }
        }
    }

    private static Range getStartAndEnd(ZonedDateTime w1Start, ZonedDateTime w2Start, ZonedDateTime w3Start, ZonedDateTime surveyStartLocal, int window) {
        ZonedDateTime start = switch (window) {
            case 0 -> surveyStartLocal;
            case 1 -> w1Start;
            default -> w2Start;
        };
        ZonedDateTime end = switch (window) {
            case 0 -> w1Start;
            case 1 -> w2Start;
            default -> w3Start;
        };
        return new Range(start, end);
    }

}
