package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.service.SessionService;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.bouncycastle.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
@Slf4j
@RequiredArgsConstructor
public class SessionServiceImpl implements SessionService {

    private final CacheService cacheService;

    @Value("${redis.session-ttl-in-seconds:21600}")
    private long SESSION_TTL;

    @Override
    @Trace
    @Cacheable(cacheNames = "sessionIdCache", key = "'sessionId'")
    public String generateSessionID(String deviceID, String userID) {
        String rawIdentifiers = cacheService.getCachedString(deviceID);
        var identifiers = parseIdentifier(rawIdentifiers);
        String sessionID = identifiers.getRight();
        String storedUserID = identifiers.getLeft();
        if (storedUserID != null && !storedUserID.equals(userID)) {
            sessionID = generateSessionID();
            cacheService.cacheString(deviceID, generateRawIdentifier(sessionID, userID), SESSION_TTL);
        }
        else if (StringUtils.isBlank(rawIdentifiers))
        {
            cacheService.cacheString(deviceID, generateRawIdentifier(sessionID, userID), SESSION_TTL);
        }
        return sessionID;
    }

    private static String generateRawIdentifier(String sessionID, String userID) {
        return userID == null ? sessionID : sessionID + ";" + userID;
    }

    private static Pair<String, String> parseIdentifier(String identifier) {
        if (StringUtils.isBlank(identifier)) {
            return Pair.of(null, generateSessionID());
        }
        var ids = Strings.split(identifier, ';');
        return Pair.of(ids.length > 1 ? ids[1] : null, ids[0]);
    }

    public static String generateSessionID() {
        return UUID.randomUUID().toString();
    }
}
