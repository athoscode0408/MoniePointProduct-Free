package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyBodyLoader {

    private static final Map<Long, String> FALLBACK_SURVEY_RESOURCES = Map.of(
            4L, "/survey_4_fixed.json",
            5L, "/survey_5_fixed.json"
    );

    private final ObjectMapperHelper objectMapperHelper;

    @Value("${survey.resource-load.enabled:false}")
    private boolean resourceLoadEnabled;

    /**
     * When resource-load is enabled and the rule ID has a configured classpath resource,
     * loads from that resource first, falling back to the DB value if the resource is null.
     * When disabled, always deserializes from survey.getSurvey().
     */
    public SurveyBody load(Survey survey) {
        Long ruleId = survey.getId();
        if (resourceLoadEnabled && FALLBACK_SURVEY_RESOURCES.containsKey(ruleId)) {
            SurveyBody fromResource = loadFromResource(ruleId);
            if (fromResource != null) {
                return fromResource;
            }
            log.warn("Resource fallback returned null for rule id={}, falling back to DB value", ruleId);
        }
        try {
            return objectMapperHelper.deserializeStringToObject(survey.getSurvey(), new TypeReference<>() {});
        } catch (Exception e) {
            log.error("Failed to deserialize survey body for rule id={}. Reason: {}", ruleId, e.getMessage());
            return null;
        }
    }

    private SurveyBody loadFromResource(Long surveyId) {
        String resourcePath = FALLBACK_SURVEY_RESOURCES.get(surveyId);
        try (InputStream is = SurveyBodyLoader.class.getResourceAsStream(resourcePath)) {
            if (is == null) {
                log.error("Fallback resource not found on classpath: {}", resourcePath);
                return null;
            }
            String json = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            return objectMapperHelper.deserializeStringToObject(json, new TypeReference<>() {});
        } catch (IOException e) {
            log.error("Failed to load fallback survey body for rule id={} from {}", surveyId, resourcePath, e);
            return null;
        }
    }
}
