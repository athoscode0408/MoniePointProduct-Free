package com.moniepoint.loans.cas.module.analytics.service.impl;


import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.impl.AbstractKafkaEventPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SurveyEvaluatorKafkaEventPublisher extends AbstractKafkaEventPublisher<VerifiedAnalyticsEventDTO>  {

    private final String topic;

    public SurveyEvaluatorKafkaEventPublisher(@Value("${kafka.topic.event-validated-survey}") String topic,
                                                 KafkaTemplate<String, String> kafkaTemplate,
                                                 ObjectMapperHelper objectMapperHelper, Telemetry telemetry) {
        super(kafkaTemplate, objectMapperHelper, telemetry);
        this.topic = topic;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    @Async("appExecutor")
    public void publishEvents(String key, List<VerifiedAnalyticsEventDTO> events) {
        log.debug("Now sending {} events to kafka topic {}", events.size(), topic);
        for (VerifiedAnalyticsEventDTO event : events)
        {
            publishEvent(event.getId(), event);
        }
    }
}
