package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.SurveyAlert;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyAlertStorage;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.analytics.repository.service.SurveyRepositoryService;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState.*;
@Service
@Slf4j
@RequiredArgsConstructor
public class SurveyEventCompletionService{

    private final PreprocessedSurveyStorage preprocessedSurveyStorage;

    private final RedisCacheServiceImpl cacheService;

    private final ObjectMapperHelper objectMapperHelper;

    private final BannerService bannerService;

    private final UserAttributesStorage userStorage;

    private final SurveyAlertStorage surveyAlertStorage;

    private final SurveyRepositoryService surveyRepositoryService;



    private final ExpressionParser expressionParser = new SpelExpressionParser();

    private record AlertingContext(UserAttributes user) {}

    private static final String SURVEY_COMPLETED_EVENT = "SURVEY_COMPLETED";
    private static final String SURVEY_DISMISSED_EVENT = "SURVEY_DISMISSED";
    private static final String SURVEY_ABANDONED_EVENT = "SURVEY_ABANDONED";
    private static final String ALERT_DISPLAY_TYPE = "alert";


    @Async("appExecutor")
    @Trace
    public void processCompletedSurveyEvent(AnalyticsEventRequestDTO dto) {
        try {
            String eventName = dto.getData().get("eventName").asText();
            log.info("Received survey completion event {}", eventName);

            if (!dto.getData().has("meta")) {
                log.warn("Survey completion event has no meta property");
                return;
            }

            String userId = resolveUserId(dto);
            PreprocessedSurvey survey = resolvePreprocessedSurvey(userId, dto);
            if (survey == null) return;
            appendSourceToAdditionalData(survey, dto);

            SurveyBody surveyBody = objectMapperHelper.deserializeStringToObject(survey.getSurvey(), new TypeReference<>() {});
            handleCompletionSideEffects(survey, surveyBody, eventName, userId, dto);
            finalizeAndSave(survey, eventName, dto);

        } catch (Exception e) {
            log.error("Error thrown while processing completed survey {} ", dto.getId(), e);
            throw e;
        }
    }

    private String resolveUserId(AnalyticsEventRequestDTO dto) {
        String userId = dto.getUserIdentifiers().getUserID();
        return userId != null ? userId : dto.getCustomerIdentifier();
    }

    private PreprocessedSurvey resolvePreprocessedSurvey(String userId, AnalyticsEventRequestDTO dto) {
        long surveyId = dto.getData().get("meta").path("surveyId").asLong(0L);
        long surveySchemaId = dto.getData().get("meta").path("surveySchemaId").asLong(0L);
        return surveyId == 0L
                ? resolveVoluntarySurvey(userId, surveySchemaId, dto)
                : resolveRegularSurvey(userId, surveyId);
    }

    private PreprocessedSurvey resolveVoluntarySurvey(String userId, long surveySchemaId, AnalyticsEventRequestDTO dto) {
        if (surveySchemaId == 0L) {
            log.warn("surveySchemaId not found in meta for voluntary survey, userId: {}", userId);
            return null;
        }
        Optional<PreprocessedSurvey> survey = preprocessedSurveyStorage
                .findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(userId, surveySchemaId, List.of(NOT_COMPLETED, DISMISSED), Timestamp.from(Instant.now()))
                .stream()
                .filter(s -> brmIdMatchesAdditionalData(dto, s))
                .findFirst();
        if (survey.isEmpty()) {
            saveUserVoluntarySurvey(dto);
            return null;
        }
        return survey.get();
    }

    private void appendSourceToAdditionalData(PreprocessedSurvey survey, AnalyticsEventRequestDTO dto) {
        String source = dto.getData().get("meta").path("source").asText(null);
        if (StringUtils.isBlank(source)) return;
        Map<String, Object> data = new java.util.LinkedHashMap<>();
        if (StringUtils.isNotBlank(survey.getAdditionalData())) {
            try {
                Map<String, Object> existing = objectMapperHelper.deserializeStringToObject(survey.getAdditionalData(), new TypeReference<>() {});
                data.putAll(existing);
            } catch (Exception e) {
                log.warn("Could not parse additionalData for survey {} when appending source", survey.getId());
            }
        }
        data.put("source", source);
        survey.setAdditionalData(objectMapperHelper.serializeToString(data));
    }

    private boolean brmIdMatchesAdditionalData(AnalyticsEventRequestDTO dto, PreprocessedSurvey survey) {
        String requestBrmId = dto.getUserAttributes() == null ? null : dto.getUserAttributes().getBrmId();

        if (StringUtils.isBlank(requestBrmId)) {
            String accountNumber = resolveAccountNumber(dto);
            if (StringUtils.isNotBlank(accountNumber)) {
                UserAttributes fetched = userStorage.findUser(resolveUserId(dto), accountNumber);
                if (fetched != null) {
                    requestBrmId = fetched.getBrmId();
                }
            }
        }

        String storedBrmId = null;
        if (StringUtils.isNotBlank(survey.getAdditionalData())) {
            try {
                Map<String, Object> additionalData = objectMapperHelper.deserializeStringToObject(
                        survey.getAdditionalData(), new TypeReference<>() {});
                Object raw = additionalData.get("brmId");
                storedBrmId = raw == null ? null : String.valueOf(raw);
            } catch (Exception e) {
                log.warn("Could not parse additionalData for survey {} when checking brmId", survey.getId());
                return false;
            }
        }
        return Objects.equals(StringUtils.trimToNull(requestBrmId), StringUtils.trimToNull(storedBrmId));
    }

    private static String resolveAccountNumber(AnalyticsEventRequestDTO dto) {
        UserAttributes userAttrs = dto.getUserAttributes();
        String businessAccount = userAttrs == null ? null : userAttrs.getBusinessNubanAccountNumber();
        String personalAccount = userAttrs == null ? null : userAttrs.getNubanAccountNumber();
        return StringUtils.isBlank(businessAccount) ? personalAccount : businessAccount;
    }


    private PreprocessedSurvey resolveRegularSurvey(String userId, long surveyId) {
        PreprocessedSurvey survey = preprocessedSurveyStorage
                .findPreprocessedSurveyByUserAndIdAndStateIn(userId, surveyId, List.of(NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED))
                .orElse(null);
        if (survey == null) {
            log.warn("Uncompleted preprocessed survey with id {} not found for user {}", surveyId, userId);
            PreprocessedSurvey placeholder = new PreprocessedSurvey();
            placeholder.setId(surveyId);
            placeholder.setUser(userId);
            removeSurveyFromCache(placeholder);
            return null;
        }
        return survey;
    }

    private void handleCompletionSideEffects(PreprocessedSurvey survey, SurveyBody surveyBody, String eventName, String userId, AnalyticsEventRequestDTO dto) {
        if (SURVEY_COMPLETED_EVENT.equalsIgnoreCase(eventName)) {
            if (surveyBody != null && surveyBody.isAssignBanner()) {
                bannerService.unAssignBannerToUser(survey.getUser(), surveyBody.getBannerId());
            }
        } else if (surveyBody != null && SURVEY_DISMISSED_EVENT.equalsIgnoreCase(eventName) && surveyBody.isEnableAlertingAfterDismissal()) {
            handleAlertingOnDismissal(survey, surveyBody, userId, dto);
        }
        if (SURVEY_COMPLETED_EVENT.equalsIgnoreCase(eventName) || SURVEY_ABANDONED_EVENT.equalsIgnoreCase(eventName)) {
            if (surveyBody != null && "ALERT".equalsIgnoreCase(surveyBody.getDisplayModalType())) {
                surveyAlertStorage.findByPreprocessedSurveyId(survey.getId())
                        .forEach(alert -> cacheService.evictSurveyAlerts(alert.getUser(), alert.getMoniepointAgentId()));
                surveyAlertStorage.deleteByPreprocessedSurveyId(survey.getId());
            }
        }
    }

    private void handleAlertingOnDismissal(PreprocessedSurvey survey, SurveyBody surveyBody, String userId, AnalyticsEventRequestDTO dto) {
        String condition = surveyBody.getAlertingCondition();
        if (StringUtils.isBlank(condition)) {
            log.warn("Alerting after dismissal is enabled but no alertingCondition is defined for survey {}", survey.getSurveyId());
            return;
        }
        UserAttributes user = resolveUserForAlerting(userId, dto);
        if (evaluateAlertingCondition(user, condition)) {
            String accountNumber = resolveAccountNumber(dto);
            String moniepointAgentId = user.getCustomAttributes().get("agent_id") != null ? String.valueOf(user.getCustomAttributes().get("agent_id")) : null;
           if (StringUtils.isBlank(moniepointAgentId))
            {
                log.warn("Alerting after dismissal is enabled but no moniepointAgentId is found for user {} and account number {}", userId, accountNumber);
                return;
            }
            promoteDismissedSurveyToAlert(survey, surveyBody, accountNumber, moniepointAgentId);

        }
    }

    private UserAttributes resolveUserForAlerting(String userId, AnalyticsEventRequestDTO dto) {
        UserAttributes userAttributes = dto.getUserAttributes();
        String accountNumber = resolveAccountNumber(dto);
        UserAttributes user = StringUtils.isBlank(accountNumber) ? null : userStorage.findUser(userId, accountNumber);
        log.info("User data returned for user {} and account {} from bigtable is {}", userId, accountNumber, user);
        if (user == null) {
            log.warn("User data not found in bigtable");
            user = userAttributes;
        } else {
            log.debug("User data found in bigtable");
            user.update(userAttributes);
        }
        return user;
    }

    private boolean evaluateAlertingCondition(UserAttributes user, String condition) {
        try {
            var context = new StandardEvaluationContext(new AlertingContext(user));
            context.addPropertyAccessor(new MapAccessor());
            return Boolean.TRUE.equals(expressionParser.parseExpression(condition).getValue(context, Boolean.class));
        } catch (Exception e) {
            log.warn("Alerting condition '{}' failed to evaluate, skipping alert promotion. Reason: {}", condition, e.getMessage());
            return false;
        }
    }

    private void promoteDismissedSurveyToAlert(PreprocessedSurvey survey, SurveyBody surveyBody, String accountNumber, String moniepointAgentId) {
        surveyBody.setDisplayModalType(ALERT_DISPLAY_TYPE);
        Timestamp alertStart = Timestamp.from(
                Instant.now().plusSeconds(surveyBody.getDisplayDelayPeriodInSecs())
        );
        surveyBody.setAlertStartTime(alertStart);
        survey.setSurvey(objectMapperHelper.serializeToString(surveyBody));
        removeSurveyFromCache(survey);
        PreprocessedSurveyDTO dto = objectMapperHelper.convertObjectToType(survey, new TypeReference<>() {});
        surveyRepositoryService.findById(survey.getSurveyId()).ifPresent(s -> {
            dto.setLocationWeb(s.getWebLocation());
            dto.setLocationMobile(s.getMobileLocation());
        });
        cacheService.cachePreprocessedSurveyById(String.valueOf(survey.getId()), objectMapperHelper.serializeToString(dto));
        List<PreprocessedSurveyDTO> cachedSurveys = cacheService.getAllPreprocessedSurveys(survey.getUser());
        if (!cachedSurveys.isEmpty()) {
            cacheService.appendPreprocessedSurvey(survey.getUser(), dto);
        }
        try
        {
            saveSurveyAlert(survey, accountNumber, surveyBody, moniepointAgentId);
        } catch (Exception e) {
            log.error("Error saving survey alert: {} ",e.getMessage(), e);
        }
    }

    private void saveSurveyAlert(PreprocessedSurvey survey, String accountNumber, SurveyBody surveyBody, String moniepointAgentId) {
        if (StringUtils.isBlank(accountNumber)) {
            log.warn("No accountNumber available for survey {} — skipping SurveyAlert persist", survey.getId());
            return;
        }
        if (survey.getTtl() == null) {
            log.warn("No TTL on survey {} — skipping SurveyAlert persist", survey.getId());
            return;
        }
        surveyAlertStorage.save(SurveyAlert.builder()
                .user(survey.getUser())
                .preprocessedSurveyId(survey.getId())
                .surveyId(survey.getSurveyId())
                .accountNumber(accountNumber)
                .moniepointAgentId(moniepointAgentId)
                .ttl(survey.getTtl())
                .event(survey.getEvent())
                .alertType(surveyBody.getAlertType())
                .alertIcon(surveyBody.getAlertIcon())
                .alertPriority(surveyBody.getAlertPriority())
                .alertTitle(surveyBody.getAlertTitle())
                .alertMessage(surveyBody.getAlertMessage())
                .alertActionLabel(surveyBody.getAlertActionLabel())
                .alertDismissible(surveyBody.isAlertDismissible())
                .alertStartTime(surveyBody.getAlertStartTime())
                .build());
        cacheService.evictSurveyAlerts(survey.getUser(), moniepointAgentId);
    }

    private void finalizeAndSave(PreprocessedSurvey survey, String eventName, AnalyticsEventRequestDTO dto) {
        survey.setState(SURVEY_COMPLETED_EVENT.equalsIgnoreCase(eventName) ? COMPLETED
                : SURVEY_DISMISSED_EVENT.equalsIgnoreCase(eventName) ? DISMISSED
                : ABANDONED);
        if (!SURVEY_DISMISSED_EVENT.equalsIgnoreCase(eventName)) {
            survey.setCompletedOn(dto.getTimestamp());
        }
        PreprocessedSurvey saved = preprocessedSurveyStorage.save(survey);
        if (!SURVEY_DISMISSED_EVENT.equalsIgnoreCase(eventName)) {
            removeSurveyFromCache(saved);
        }
    }

    private void saveUserVoluntarySurvey(AnalyticsEventRequestDTO analyticsEventRequestDTO)
    {
        String userId= analyticsEventRequestDTO.getUserIdentifiers().getUserID() != null ? analyticsEventRequestDTO.getUserIdentifiers().getUserID()  : analyticsEventRequestDTO.getCustomerIdentifier();
        String completionEvent = analyticsEventRequestDTO.getData().get("eventName").asText();
        Long surveySchemaId = analyticsEventRequestDTO.getData().get("meta").path("surveySchemaId").asLong(0L);
        String location = resolveVoluntarySurveyLocation(surveySchemaId, analyticsEventRequestDTO.getPlatform());
        String userAccountNumber = resolveAccountNumber(analyticsEventRequestDTO);
        PreprocessedSurvey preprocessedSurvey = PreprocessedSurvey.builder()
                .user(userId)
                .completedOn(analyticsEventRequestDTO.getTimestamp())
                .event(analyticsEventRequestDTO.getId())
                .state(SURVEY_COMPLETED_EVENT.equalsIgnoreCase(completionEvent) ? COMPLETED : (SURVEY_DISMISSED_EVENT.equalsIgnoreCase(completionEvent) ? DISMISSED : ABANDONED))
                .surveyId(surveySchemaId)
                .location(location)
                .build();
        String brmId = analyticsEventRequestDTO.getUserAttributes() == null ? null : analyticsEventRequestDTO.getUserAttributes().getBrmId();
        String source = analyticsEventRequestDTO.getData().get("meta").path("source").asText(null);
        if (StringUtils.isNotBlank(brmId) || StringUtils.isNotBlank(source) || StringUtils.isNotBlank(userAccountNumber)) {
            ObjectNode additionalData = JsonNodeFactory.instance.objectNode();
            if (StringUtils.isNotBlank(brmId)) additionalData.put("brmId", brmId);
            if (StringUtils.isNotBlank(source)) additionalData.put("source", source);
            if (StringUtils.isNotBlank(userAccountNumber)) additionalData.put("accountNumber", userAccountNumber);
            preprocessedSurvey.setAdditionalData(additionalData.toString());
        }
        preprocessedSurveyStorage.save(preprocessedSurvey);
    }

    private String resolveVoluntarySurveyLocation(Long surveySchemaId, String platform) {
        return surveyRepositoryService.findById(surveySchemaId)
                .map(survey -> "web".equalsIgnoreCase(platform) ? survey.getWebLocation() : survey.getMobileLocation())
                .orElse(null);
    }

    private void removeSurveyFromCache(PreprocessedSurvey userPreprocessedSurvey) {
        cacheService.removePreprocessedSurveyBySurveyId(String.valueOf(userPreprocessedSurvey.getId()));
        cacheService.removePreprocessedSurveyByUserId(userPreprocessedSurvey.getUser(), String.valueOf(userPreprocessedSurvey.getId()));
    }
}
