package com.moniepoint.loans.cas.module.analytics.service.impl;


import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import com.moniepoint.loans.cas.module.kafka.service.impl.AbstractKafkaEventPublisher;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SurveyPushNotificationKafkaEventPublisher extends AbstractKafkaEventPublisher<NotificationRequest> {

    private final String topic;

    public SurveyPushNotificationKafkaEventPublisher(@Value("${kafka.topic.event-survey-push-notification}") String topic,
                                              KafkaTemplate<String, String> kafkaTemplate,
                                              ObjectMapperHelper objectMapperHelper, Telemetry telemetry) {
        super(kafkaTemplate, objectMapperHelper, telemetry);
        this.topic = topic;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    public void publishEvents(String key, List<NotificationRequest> notificationRequests) {
        throw new UnsupportedOperationException("Publishing a batch of events is not yet implemented.");
    }


}
