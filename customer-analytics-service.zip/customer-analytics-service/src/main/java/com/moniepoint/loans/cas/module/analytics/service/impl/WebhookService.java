package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalMarkerDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalDeactivationDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignByDomainDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserRewardEventDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateGoalDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeCloseCampaignDTO;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import com.moniepoint.loans.cas.outbound.rewards.RewardsClient;
import com.moniepoint.loans.cas.outbound.rewards.RewardsCampaignResponse;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class WebhookService {

    private final RewardsClient rewardsClient;
    private final OutboundUtils outboundUtils;
    private final ObjectMapperHelper objectMapperHelper;
    @Value("${integrations.rewards.secret-key}")
    private String rewardsSecretKey;

    public WebhookService(RewardsClient rewardsClient, OutboundUtils outboundUtils, ObjectMapperHelper objectMapperHelper) {
        this.rewardsClient = rewardsClient;
        this.outboundUtils = outboundUtils;
        this.objectMapperHelper = objectMapperHelper;
    }

    public ResponseEntity<RewardsCampaignResponse> processRewardAssignCampaign(BrazeUserCampaignDTO brazeUserCampaignDTO, String secret) {

        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.assignCampaign(brazeUserCampaignDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service assign-campaign with reason : {} and data : {}", response.getStatusCode(), brazeUserCampaignDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("Assign campaign webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Assign campaign webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> processRewardStopCampaign(BrazeUserCampaignDTO brazeUserCampaignDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.stopCampaign(brazeUserCampaignDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service stop-campaign with reason : {} and data : {}", response.getStatusCode(), brazeUserCampaignDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("Stop campaign webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Stop campaign webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }


    public ResponseEntity<RewardsCampaignResponse> createRewardCampaign(BrazeUserCreateCampaignDTO brazeUserCreateCampaignDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.createCampaign(brazeUserCreateCampaignDTO, String.format("Bearer %s", token), "CREATE");
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service create campaign with reason : {} and data : {}", response.getStatusCode(), brazeUserCreateCampaignDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("create campaign webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Create campaign webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> createRewardGoal(BrazeUserCreateGoalDTO brazeUserCreateGoalDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.createGoal(brazeUserCreateGoalDTO, String.format("Bearer %s", token), "CREATE");
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service create goal with reason : {} and data : {}", response.getStatusCode(), brazeUserCreateGoalDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("create goal webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Create goal webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> markRewardGoal(BrazeUserGoalMarkerDTO brazeUserGoalMarkerDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.markGoal(brazeUserGoalMarkerDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service mark goal with reason : {} and data : {}", response.getStatusCode(), brazeUserGoalMarkerDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("mark goal webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("mark goal webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }


    public ResponseEntity<RewardsCampaignResponse> deactivateRewardGoal(BrazeUserGoalDeactivationDTO brazeUserGoalDeactivationDTO, String secret) {
        if (!rewardsSecretKey.equals(secret))
        {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key","403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.deactivateGoal(brazeUserGoalDeactivationDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service deactivate goal with reason : {} and data : {}", response.getStatusCode(), brazeUserGoalDeactivationDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("deactivate goal webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("deactivate goal webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> assignRewardCampaignByDomain(BrazeUserCampaignByDomainDTO brazeUserCampaignByDomainDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.assignCampaignByDomain(brazeUserCampaignByDomainDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service assign campaign by domain with reason : {} and data : {}", response.getStatusCode(), brazeUserCampaignByDomainDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("assign campaign by domain webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("assign campaign by domain webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> rewardEvent(BrazeUserRewardEventDTO brazeUserRewardEventDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.rewardEvent(brazeUserRewardEventDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service event-reward with reason : {} and data : {}", response.getStatusCode(), brazeUserRewardEventDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("Reward event webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Reward event webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

    public ResponseEntity<RewardsCampaignResponse> closeRewardCampaign(BrazeCloseCampaignDTO brazeCloseCampaignDTO, String secret) {
        if (!rewardsSecretKey.equals(secret)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new RewardsCampaignResponse(false, "Invalid secret header key", "403"));
        }

        try {
            String token = outboundUtils.getToken();

            ResponseEntity<RewardsCampaignResponse> response = rewardsClient.closeCampaign(brazeCloseCampaignDTO, String.format("Bearer %s", token));
            if (response.getStatusCode() != HttpStatus.OK) {
                log.info("Handling failure for rewards service close campaign with reason : {} and data : {}", response.getStatusCode(), brazeCloseCampaignDTO);
            }
            return ResponseEntity
                    .status(response.getStatusCode())
                    .body(response.getBody());
        } catch (FeignException exception) {
            log.error("Close campaign webhook to rewards service could not be processed: {}", exception.getMessage(), exception.getCause());
            RewardsCampaignResponse rewardsCampaignResponse;
            try {
                rewardsCampaignResponse = objectMapperHelper.deserializeStringToObject(exception.contentUTF8(), new TypeReference<>() {
                });
            } catch (Exception e) {
                rewardsCampaignResponse = new RewardsCampaignResponse(false, exception.contentUTF8(), null);
            }
            return ResponseEntity.status(exception.status()).body(rewardsCampaignResponse);
        } catch (Exception exception) {
            log.error("Close campaign webhook to rewards service could not be processed: {}", exception.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RewardsCampaignResponse(false, exception.getMessage(), "500"));
        }
    }

}
