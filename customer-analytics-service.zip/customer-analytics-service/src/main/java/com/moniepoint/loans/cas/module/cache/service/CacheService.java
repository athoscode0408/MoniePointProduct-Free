package com.moniepoint.loans.cas.module.cache.service;

public interface CacheService {

    boolean doesKeyExist(String key);
    void cacheString(String key, String value);
    void cacheString(String key, String value, long durationInSeconds);
    String getCachedString(String key);
    void deleteFromCache(String key);


}
