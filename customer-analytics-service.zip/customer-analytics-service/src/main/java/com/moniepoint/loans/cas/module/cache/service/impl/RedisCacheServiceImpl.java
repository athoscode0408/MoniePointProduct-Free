package com.moniepoint.loans.cas.module.cache.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.entity.SurveyAlert;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Slf4j
public class RedisCacheServiceImpl implements CacheService {

    private final RedisTemplate<String, String> redisTemplate;

    private final long redisExpiry;

    private final ObjectMapperHelper objectMapperHelper;



    private static final String EXPIRY_CURSOR_KEY = "pps-expiry-cursor";

    private String user_key(String userId) { return "pps-user:%s".formatted(userId); }
    private String id_key(String userId) { return "pps-id:%s".formatted(userId); }
    private String survey_alert_key(String userId, String moniepointAgentId) { return "survey-alert:%s:%s".formatted(userId, moniepointAgentId); }

    @Value("${survey.preprocessed-survey-cache-by-id-mins:10080}")
    public Integer PREPROCESSED_SURVEY_CACHE_BY_ID_TTL;

    @Value("${survey.preprocessed-survey-cache-by-user-ttl-mins:10080}")
    public Integer PREPROCESSED_SURVEY_CACHE_BY_USER_TTL;

    @Value("${survey.survey-alert-cache-ttl-mins:720}")
    public Integer SURVEY_ALERT_CACHE_TTL;


    public RedisCacheServiceImpl(RedisTemplate<String, String> redisTemplate,
                                 @Value("${redis.default.expiry-update:86400}") long redisExpiry, ObjectMapperHelper objectMapperHelper) {
        this.redisTemplate = redisTemplate;
        this.redisExpiry = redisExpiry;
        this.objectMapperHelper = objectMapperHelper;
    }

    @Override
    public boolean doesKeyExist(String key) {
        return Optional.ofNullable(redisTemplate.hasKey(key)).orElse(Boolean.FALSE);
    }

    @Override
    public void cacheString(String key, String value) {
        this.cacheString(key, value, redisExpiry);
    }

    @Override
    public void cacheString(String key, String value, long durationInSeconds) {
        redisTemplate.opsForValue().set(key, value, durationInSeconds, TimeUnit.SECONDS);
    }

    @Override
    public String getCachedString(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public void cachePreprocessedSurveyById(String key, String value) {
        cacheString(id_key(key), value, PREPROCESSED_SURVEY_CACHE_BY_ID_TTL*60);
    }

    public String getPreprocessedSurveyById(String key) {
        return getCachedString(id_key(key));
    }


    public void cacheAllPreprocessedSurveys(String userId, List<PreprocessedSurveyDTO> surveys) {
        String json = objectMapperHelper.serializeToString(surveys);
        redisTemplate.opsForValue().set(user_key(userId), json, PREPROCESSED_SURVEY_CACHE_BY_USER_TTL*60, TimeUnit.SECONDS);
    }

    public List<PreprocessedSurveyDTO> getAllPreprocessedSurveys(String userId) {
        String json = redisTemplate.opsForValue().get(user_key(userId));
        if (json == null || json.isBlank()) return List.of();
        List<PreprocessedSurveyDTO> surveys = objectMapperHelper.deserializeStringToObject(json, new TypeReference<List<PreprocessedSurveyDTO>>() {});
        return surveys.stream()
                .filter(s -> s != null && s.getTtl() != null && s.getTtl().isAfter(java.time.LocalDateTime.now()))
                .collect(Collectors.toList());
    }

    public void appendPreprocessedSurvey(String userId, PreprocessedSurveyDTO dto) {
        List<PreprocessedSurveyDTO> surveys = new ArrayList<>(getAllPreprocessedSurveys(userId));
        surveys.add(dto);
        cacheAllPreprocessedSurveys(userId, surveys);
    }

    public void evictAllPreprocessedSurveys(String userId) {
        deleteFromCache(user_key(userId));
    }

    public void removePreprocessedSurveyByUserId(String userId, String surveyId) {
        List<PreprocessedSurveyDTO> surveys = new ArrayList<>(getAllPreprocessedSurveys(userId));
        List<PreprocessedSurveyDTO> updated = surveys.stream()
                .filter(s -> s != null && !Objects.equals(s.getId(), Long.valueOf(surveyId))
                        && s.getTtl() != null && s.getTtl().isAfter(java.time.LocalDateTime.now()))
                .collect(Collectors.toList());
        cacheAllPreprocessedSurveys(userId, updated);
    }

    public void removePreprocessedSurveyBySurveyId(String surveyId) {
        redisTemplate.delete(id_key(surveyId));
    }

    public void deleteFromCache(String key) {
        redisTemplate.delete(key);
    }

    public void cacheSurveyAlerts(String userId, String moniepointAgentId, List<SurveyAlert> alerts) {
        String json = objectMapperHelper.serializeToString(alerts);
        cacheString(survey_alert_key(userId, moniepointAgentId), json, SURVEY_ALERT_CACHE_TTL * 60L);
    }

    public List<SurveyAlert> getCachedSurveyAlerts(String userId, String moniepointAgentId) {
        String json = getCachedString(survey_alert_key(userId, moniepointAgentId));
        if (json == null || json.isBlank()) return null;
        return objectMapperHelper.deserializeStringToObject(json, new TypeReference<List<SurveyAlert>>() {});
    }

    public void evictSurveyAlerts(String userId, String moniepointAgentId) {
        deleteFromCache(survey_alert_key(userId, moniepointAgentId));
    }

    public long getExpiryCursor() {
        String val = redisTemplate.opsForValue().get(EXPIRY_CURSOR_KEY);
        if (val == null) return 0L;
        try {
            return Long.parseLong(val);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    public void setExpiryCursor(long lastProcessedId) {
        redisTemplate.opsForValue().set(EXPIRY_CURSOR_KEY, String.valueOf(lastProcessedId));
    }

}
