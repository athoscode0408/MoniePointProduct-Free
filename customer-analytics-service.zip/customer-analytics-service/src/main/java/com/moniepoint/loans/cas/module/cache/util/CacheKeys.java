package com.moniepoint.loans.cas.module.cache.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CacheKeys {

  public static final String SUPPORTED_EVENT_CACHE_KEY_PREFIX = "SUPPORTED_EVENT::";
  public static final String SUPPORTED_PROVIDERS_CACHE_KEY = "SUPPORTED_ANALYTICS_PROVIDERS";
  public static final String ALLOWED_ATTRIBUTES_CACHE_KEY_SUFFIX = "_allowed_attributes";
  public static final String CAS_SURVEY_RULES_KEY="cas-survey-rules";
  public static final String CAS_ACCESS_TOKEN_KEY = "cas-access-token";


}
