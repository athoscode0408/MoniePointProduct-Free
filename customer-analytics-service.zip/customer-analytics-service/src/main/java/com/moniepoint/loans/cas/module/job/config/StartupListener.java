package com.moniepoint.loans.cas.module.job.config;

import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import com.moniepoint.loans.cas.module.job.service.JobScheduler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class StartupListener {

    private final List<ClusteredJob> clusteredJobs;

    private final JobScheduler jobScheduler;

    @Value("${quartz.jobs-to-delete.keys:}")
    private String jobKeysToDelete;

    @EventListener
    public void onApplicationEvent(@Nullable ContextRefreshedEvent contextRefreshedEvent) {
        deleteJobs();
        registerStartupJobs();
    }

    private void registerStartupJobs() {
        clusteredJobs.stream().filter(ClusteredJob::isCreatedAtStartUp)
                .forEach(this::addOrUpdateClusteredJob);
    }

    @SuppressWarnings("unchecked")
    private void addOrUpdateClusteredJob(ClusteredJob job) {
        try {
            Schedule schedule = job.getSchedule();
            Date dateCreated;

            if (schedule.isStartNow())

                dateCreated = jobScheduler.addOrUpdateClusteredJob(job.getJobClass(), job.getJobName(),
                        job.getJobGroup(), null, schedule.getRunInterval(), schedule.isStartNow());

            else if (StringUtils.isNotBlank(schedule.getCron()))

                dateCreated = jobScheduler.addOrUpdateClusteredJob(job.getJobClass(), job.getJobName(),
                        job.getJobGroup(), null, schedule.getCron());

            else
                dateCreated = jobScheduler.addOrUpdateClusteredJob(job.getJobClass(), job.getJobName(), job.getJobGroup(),
                        null, schedule.getRunInterval(), Timestamp.from(schedule.getStartTime().toInstant()));

        log.info("Successfully created job {} on {}", job.getJobKey(), dateCreated);

        } catch (Exception e) {

            log.error("Error occurred while creating job {}", job.getJobKey(), e);

        }
    }

    private void deleteJobs() {

        if (StringUtils.isBlank(jobKeysToDelete)) {
            return;
        }

        String[] keys = StringUtils.split(jobKeysToDelete, ",");
        if (keys.length < 1) {
            return;
        }

        for (String key : keys) {
            String[] keyParts = StringUtils.split(key, "|");
            if (keyParts.length < 2) {
                continue;
            }
            JobKey jobKey = new JobKey(keyParts[0], keyParts[1]);
            log.info("Deleting job {}", jobKey.getName());
            jobScheduler.deleteJob(jobKey);
        }
    }
}
