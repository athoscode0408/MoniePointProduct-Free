package com.moniepoint.loans.cas.module.job.controller;

import com.moniepoint.loans.cas.module.job.service.JobScheduler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/admin/job")
@RequiredArgsConstructor
@Slf4j
@Profile({"cloud_dev", "dev", "staging"})
public class AdminJobController {

    private final JobScheduler jobScheduler;

    @PostMapping("/{keyGroup}/trigger")
    public ResponseEntity<Void> triggerJob(@RequestParam("keyName") String keyName, @PathVariable("keyGroup") String keyGroup) {
        log.info("Admin trigger received for job keyName={} keyGroup={}", keyName, keyGroup);
        jobScheduler.triggerJob(keyName, keyGroup);
        return ResponseEntity.accepted().build();
    }
}