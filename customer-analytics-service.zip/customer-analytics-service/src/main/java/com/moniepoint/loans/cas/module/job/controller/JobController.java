package com.moniepoint.loans.cas.module.job.controller;

import com.moniepoint.loans.cas.module.job.pojo.JobResponse;
import com.moniepoint.loans.cas.module.job.service.JobScheduler;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/api/v1/job")
public class JobController {

    private final JobScheduler jobScheduler;

    @GetMapping
    public List<JobResponse> getAllJobs() {
        return jobScheduler.getJobs();
    }

    @GetMapping(path = "/{keyGroup}/get")
    public JobResponse getJob(@RequestParam("keyName") String keyName, @PathVariable("keyGroup") String keyGroup) {
        return jobScheduler.getJob(keyName, keyGroup);
    }

    @PostMapping(path = "/{keyGroup}/pause")
    public void pauseJob(@RequestParam("keyName") String keyName, @PathVariable("keyGroup") String keyGroup) {
        jobScheduler.pauseJob(keyName, keyGroup);
    }

    @PostMapping(path = "/{keyGroup}/resume")
    public void resume(@RequestParam("keyName") String keyName, @PathVariable("keyGroup") String keyGroup) {
        jobScheduler.resumeJob(keyName, keyGroup);
    }
}
