package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor
public class AnalyticsEventRetryTriggerJob implements ClusteredJob {

    @Value("${clustered.cron.job.analytics-event-retry.frequency}")
    private String analyticsEventRetryFrequency;

    private final EventRetryService eventRetryService;

    @Override
    public String getJobCode() {
        return "ANALYTICS_EVENT_RETRY_TRIGGER_JOB";
    }

    @Override
    public String getJobName() {
        return "Analytics event retry Trigger Job";
    }

    @Override
    public Class<AnalyticsEventRetryTriggerJob> getJobClass() {
        return AnalyticsEventRetryTriggerJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(analyticsEventRetryFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        eventRetryService.retryFailedEvents();
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}