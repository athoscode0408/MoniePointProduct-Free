package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.repository.service.EventDeadLetterRepositoryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EventDeadLetterCleanupTriggerJob implements ClusteredJob {

    @Value("${clustered.cron.job.event-dead-letter-clean-up.frequency}")
    private String eventDeadLetterCleanupFrequency;

    private final EventDeadLetterRepositoryService eventDeadLetterRepositoryService;

    @Override
    public String getJobCode() {
        return "EVENT_DEAD_LETTER_CLEANUP_TRIGGER_JOB";
    }

    @Override
    public String getJobName() {
        return "Event dead letter cleanup Trigger Job";
    }

    @Override
    public Class<EventDeadLetterCleanupTriggerJob> getJobClass() {
        return EventDeadLetterCleanupTriggerJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(eventDeadLetterCleanupFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        eventDeadLetterRepositoryService.deleteAllEventDeadLetter();
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}
