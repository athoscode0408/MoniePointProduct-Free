package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.common.util.IsoWeekUtil;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySampleExpiryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.ZoneId;

@Slf4j
@Component
@RequiredArgsConstructor
public class NpsWeeklyExpiredSampleJob implements ClusteredJob {

    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    @Value("${nps.programme.enabled:false}")
    private boolean npsProgrammeEnabled;

    @Value("${clustered.cron.job.nps-weekly-expired-sample.frequency:0 49 23 ? * SUN}")
    private String expiryJobFrequency;

    private final NpsWeeklySampleExpiryService npsWeeklySampleExpiryService;

    @Override
    public String getJobCode() {
        return "NPS_WEEKLY_EXPIRED_SAMPLE_JOB";
    }

    @Override
    public String getJobName() {
        return "NPS Weekly Expired Sample Job";
    }

    @Override
    public Class<NpsWeeklyExpiredSampleJob> getJobClass() {
        return NpsWeeklyExpiredSampleJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(expiryJobFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        if (!npsProgrammeEnabled) {
            log.info("NPS programme is disabled, skipping {}", getJobName());
            return;
        }
        String isoWeek = IsoWeekUtil.current(LAGOS);
        npsWeeklySampleExpiryService.expireWeeklySamples(isoWeek);
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}
