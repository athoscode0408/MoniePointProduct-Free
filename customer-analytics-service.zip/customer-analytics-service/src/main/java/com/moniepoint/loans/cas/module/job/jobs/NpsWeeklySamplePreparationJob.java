package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.common.util.IsoWeekUtil;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySamplePreparationService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.ZoneId;

@Slf4j
@Component
@RequiredArgsConstructor
public class NpsWeeklySamplePreparationJob implements ClusteredJob {

    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    @Value("${nps.programme.enabled:false}")
    private boolean npsProgrammeEnabled;

    @Value("${clustered.cron.job.nps-weekly-sample-preparation.frequency:0 0 1 ? * MON}")
    private String preparationJobFrequency;

    private final NpsWeeklySamplePreparationService npsWeeklySamplePreparationService;

    @Override
    public String getJobCode() {
        return "NPS_WEEKLY_SAMPLE_PREPARATION_JOB";
    }

    @Override
    public String getJobName() {
        return "NPS Weekly Sample Preparation Job";
    }

    @Override
    public Class<NpsWeeklySamplePreparationJob> getJobClass() {
        return NpsWeeklySamplePreparationJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(preparationJobFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        if (!npsProgrammeEnabled) {
            log.info("NPS programme is disabled, skipping {}", getJobName());
            return;
        }
        String isoWeek = IsoWeekUtil.current(LAGOS);
        npsWeeklySamplePreparationService.prepareWeeklySample(isoWeek);
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}
