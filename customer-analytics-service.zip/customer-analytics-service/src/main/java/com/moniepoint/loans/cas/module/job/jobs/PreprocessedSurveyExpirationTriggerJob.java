package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.service.PreprocessedSurveyExpiryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor
public class PreprocessedSurveyExpirationTriggerJob implements ClusteredJob {

    @Value("${survey.preprocessed-survey-expiry-frequency}")
    private String preprocessedSurveyExpiryFrequency;

    @Value("${survey.expiry-v2.enabled:true}")
    private boolean expiryV2Enabled;

    private final PreprocessedSurveyExpiryService preprocessedSurveyExpiryService;

    @Override
    public String getJobCode() {
        return "PREPROCESSED_SURVEY_EXPIRY_TRIGGER_JOB";
    }

    @Override
    public String getJobName() {
        return "Preprocessed Survey Expiry Trigger Job";
    }

    @Override
    public Class<PreprocessedSurveyExpirationTriggerJob> getJobClass() {
        return PreprocessedSurveyExpirationTriggerJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(preprocessedSurveyExpiryFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        if (expiryV2Enabled) {
            preprocessedSurveyExpiryService.expirePreprocessedSurveysV2();
        } else {
            preprocessedSurveyExpiryService.expirePreprocessedSurveys();
        }
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}