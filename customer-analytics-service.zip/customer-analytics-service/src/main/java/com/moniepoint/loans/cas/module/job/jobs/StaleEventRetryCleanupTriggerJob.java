package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.repository.EventRetryView;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class StaleEventRetryCleanupTriggerJob implements ClusteredJob {

    private static final int MAX_JOB_DURATION_MINUTES = 10;

    @Value("${stale-event-retry.batch-size:500}")
    private int batchSize;

    @Value("${clustered.cron.job.stale-event-retry-clean-up.frequency:0 0/15 * ? * * *}")
    private String staleEventRetryCleanupFrequency;

    @Value("${stale-event-retry.retention-value:30}")
    private long retentionValue;

    @Value("${stale-event-retry.retention-unit:DAYS}")
    private String retentionUnit;

    private final EventRetryRepositoryService eventRetryRepositoryService;

    @Override
    public String getJobCode() {
        return "STALE_EVENT_RETRY_CLEANUP_TRIGGER_JOB";
    }

    @Override
    public String getJobName() {
        return "Stale event retry cleanup Trigger Job";
    }

    @Override
    public Class<StaleEventRetryCleanupTriggerJob> getJobClass() {
        return StaleEventRetryCleanupTriggerJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(staleEventRetryCleanupFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("{}: starting — batchSize={}, retention={} {}, cutoffFrequency={}, fireTime={}",
                getJobCode(), batchSize, retentionValue, retentionUnit,
                staleEventRetryCleanupFrequency, jobExecutionContext.getFireTime());

        ChronoUnit unit;
        try {
            unit = ChronoUnit.valueOf(retentionUnit.toUpperCase());
        } catch (IllegalArgumentException e) {
            log.error("{}: invalid retention-unit '{}', aborting.", getJobCode(), retentionUnit);
            return;
        }

        Instant now = Instant.now();
        Timestamp cutoff = Timestamp.from(now.minus(retentionValue, unit));
        Instant deadline = now.plus(MAX_JOB_DURATION_MINUTES, ChronoUnit.MINUTES);

        long cursor = 0L;
        int totalDeleted = 0;
        int batchCount = 0;
        boolean timedOut = false;

        while (true) {
            if (Instant.now().isAfter(deadline)) {
                timedOut = true;
                break;
            }

            List<EventRetryView> batch = eventRetryRepositoryService.findBatchAfter(cursor, batchSize);

            if (batch.isEmpty()) {
                break;
            }

            EventRetryView lastInBatch = batch.getLast();
            List<Long> ids;
            boolean boundaryReached;

            if (lastInBatch.getCreatedOn().before(cutoff)) {
                ids = batch.stream().map(EventRetryView::getId).toList();
                boundaryReached = false;
            } else {
                ids = batch.stream()
                        .filter(e -> e.getCreatedOn().before(cutoff))
                        .map(EventRetryView::getId)
                        .toList();
                boundaryReached = true;
            }

            if (ids.isEmpty()) {
                log.info("{}: no stale entries in batch, first entry (id={}, createdOn={}) is at or after cutoff={}. Stopping.",
                        getJobCode(), batch.getFirst().getId(), batch.getFirst().getCreatedOn(), cutoff);
                break;
            }

            eventRetryRepositoryService.deleteAllByIds(ids);
            totalDeleted += ids.size();
            batchCount++;
            cursor = lastInBatch.getId();

            log.debug("{}: deleted batch {} ({}/{} entries), total deleted: {}, next cursor id: {}",
                    getJobCode(), batchCount, ids.size(), batch.size(), totalDeleted, cursor);

            if (boundaryReached) {
                log.info("{}: reached cutoff boundary in batch {}, stopping.", getJobCode(), batchCount);
                break;
            }
        }
        log.info("Done Running {}. total deleted: {}, batches: {}, timed out: {}, next fire time: {}",
                jobExecutionContext.getJobDetail().getKey().getName(), totalDeleted, batchCount, timedOut,
                jobExecutionContext.getNextFireTime());
    }
}
