package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.repository.service.UnsupportedEventRepositoryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import com.moniepoint.loans.cas.module.job.service.ClusteredJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class UnsupportedEventsCleanupTriggerJob implements ClusteredJob {

    @Value("${clustered.cron.job.unsupported-events-clean-up.frequency}")
    private String unsupportedEventsCleanupFrequency;

    private final UnsupportedEventRepositoryService unsupportedEventRepositoryService;

    @Override
    public String getJobCode() {
        return "UNSUPPORTED_EVENTS_CLEANUP_TRIGGER_JOB";
    }

    @Override
    public String getJobName() {
        return "Unsupported events cleanup Trigger Job";
    }

    @Override
    public Class<UnsupportedEventsCleanupTriggerJob> getJobClass() {
        return UnsupportedEventsCleanupTriggerJob.class;
    }

    @Override
    public Schedule getSchedule() {
        return Schedule.builder()
                .startNow(false)
                .cron(unsupportedEventsCleanupFrequency)
                .build();
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Running {} at {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getFireTime());
        unsupportedEventRepositoryService.deleteAllUnsupportedEvents();
        log.info("Done Running {}, Next fire time {}", jobExecutionContext.getJobDetail().getKey().getName(), jobExecutionContext.getNextFireTime());
    }
}
