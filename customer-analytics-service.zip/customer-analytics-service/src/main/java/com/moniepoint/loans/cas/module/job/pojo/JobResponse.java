package com.moniepoint.loans.cas.module.job.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.quartz.Trigger;

import java.util.Date;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class JobResponse {

    private String name;

    private String code;

    private String jobClass;

    private String group;

    private String description;

    private Date nextFireTime;

    private Date previousFireTime;

    private Date startTime;

    private Date endTime;

    private boolean mayFireAgain;

    private Trigger.TriggerState triggerState;
}
