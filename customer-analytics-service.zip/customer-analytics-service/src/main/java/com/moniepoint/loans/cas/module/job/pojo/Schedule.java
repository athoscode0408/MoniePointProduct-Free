package com.moniepoint.loans.cas.module.job.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class Schedule {

    private int runInterval;

    private String cron;

    private Date startTime;

    private boolean startNow;
}
