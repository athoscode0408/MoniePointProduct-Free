package com.moniepoint.loans.cas.module.job.service;

import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobKey;
import org.springframework.stereotype.Service;

@Service
@DisallowConcurrentExecution
public interface ClusteredJob extends Job {

    String getJobCode();

    String getJobName();

    default String getJobGroup() {
        return "CUSTOMER_ANALYTICS_SERVICE";
    }

    Class getJobClass();

    Schedule getSchedule();

    default boolean isCreatedAtStartUp() {
        return true;
    }

    default JobKey getJobKey() {
        return new JobKey(getJobName(), getJobGroup());
    }
}
