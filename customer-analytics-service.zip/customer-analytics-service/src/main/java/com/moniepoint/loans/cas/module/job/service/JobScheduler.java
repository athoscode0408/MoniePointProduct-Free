package com.moniepoint.loans.cas.module.job.service;

import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.module.job.pojo.JobResponse;
import com.teamapt.clustered.job.manager.ClusteredJobScheduler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobKey;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobScheduler extends ClusteredJobScheduler<ClusteredJob> {

    public void deleteJob(JobKey jobKey) {
        try {
            this.scheduler.deleteJob(jobKey);
        } catch (Exception e) {
            log.error("Unable to delete job", e);
        }
    }

    public List<JobResponse> getJobs() {
        List<JobResponse> jobResponses = new ArrayList<>();

        try {
            Set<JobKey> jobKeys = this.scheduler.getJobKeys(GroupMatcher.anyJobGroup());

            for (JobKey jobKey : jobKeys) {

                Trigger trigger = getJobTrigger(jobKey);

                JobResponse jobResponse = JobResponse.builder()
                        .name(jobKey.getName())
                        .group(jobKey.getGroup())
                        .build();

                if (trigger != null) {
                    jobResponse.setNextFireTime(trigger.getNextFireTime());
                    jobResponse.setPreviousFireTime(trigger.getPreviousFireTime());
                    jobResponse.setMayFireAgain(trigger.mayFireAgain());
                    jobResponse.setStartTime(trigger.getStartTime());
                    jobResponse.setEndTime(trigger.getEndTime());
                    jobResponse.setTriggerState(this.scheduler.getTriggerState(trigger.getKey()));
                }

                jobResponses.add(jobResponse);
            }
        } catch (SchedulerException e) {
            log.error("An error occurred while getting job keys", e);
        }

        return jobResponses;
    }

    private Trigger getJobTrigger(JobKey jobKey) throws SchedulerException {
        List<? extends Trigger> triggers = this.scheduler.getTriggersOfJob(jobKey);

        if (!CollectionUtils.isEmpty(triggers)) {
            return triggers.getFirst();
        }

        return null;
    }

    public JobResponse getJob(String keyName, String keyGroup) {
        JobResponse jobResponses = null;

        try {
            JobKey jobKey = new JobKey(keyName, keyGroup);

            List<? extends Trigger> triggers = this.scheduler.getTriggersOfJob(jobKey);

            if (!CollectionUtils.isEmpty(triggers)) {
                Trigger trigger = triggers.getFirst();
                jobResponses = JobResponse.builder()
                        .name(keyName)
                        .group(keyGroup)
                        .nextFireTime(trigger.getNextFireTime())
                        .previousFireTime(trigger.getPreviousFireTime())
                        .mayFireAgain(trigger.mayFireAgain())
                        .startTime(trigger.getStartTime())
                        .endTime(trigger.getEndTime())
                        .triggerState(this.scheduler.getTriggerState(trigger.getKey()))
                        .build();
            }
        } catch (SchedulerException e) {
            log.error("Error occurred when fetching job details", e);
            throw new ServerException("Unable to fetch Job details");
        }

        return jobResponses;
    }

    public void pauseJob(String keyName, String keyGroup) {
        try {
            this.pauseScheduledJob(keyName, keyGroup);
        } catch (Exception e) {
            log.error("Error occurred while trying to pause job", e);
            throw new ServerException("Unable to pause job: " + e.getMessage(), e);
        }
    }

    public void resumeJob(String keyName, String keyGroup) {
        try {
            this.resumeScheduledJob(keyName, keyGroup);
        } catch (Exception e) {
            log.error("Error occurred while trying to pause job", e);
            throw new ServerException("Unable to pause job: " + e.getMessage(), e);
        }
    }

    public void triggerJob(String keyName, String keyGroup) {
        try {
            this.scheduler.triggerJob(new JobKey(keyName, keyGroup));
        } catch (Exception e) {
            log.error("Error occurred while trying to trigger job", e);
            throw new ServerException("Unable to trigger job: " + e.getMessage(), e);
        }
    }
}
