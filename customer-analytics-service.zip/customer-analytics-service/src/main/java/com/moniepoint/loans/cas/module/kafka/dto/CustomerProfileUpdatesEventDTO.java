package com.moniepoint.loans.cas.module.kafka.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.module.kafka.enums.CustomerProfileUpdatesEventType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class CustomerProfileUpdatesEventDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Customer identifier can't be empty")
    private String customerIdentifier;

    @NotNull(message = "Event type can't be null")
    private CustomerProfileUpdatesEventType eventType;

    @NotNull(message = "Event date can't be null")
    private LocalDateTime eventDate;

    @NotNull(message = "Event data can't be null")
    private JsonNode data;

}