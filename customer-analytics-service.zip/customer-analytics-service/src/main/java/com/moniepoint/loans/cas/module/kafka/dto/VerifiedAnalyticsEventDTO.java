package com.moniepoint.loans.cas.module.kafka.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.validation.annotation.ValidEventEnvironment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class VerifiedAnalyticsEventDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Event id can't be empty")
    private String id;

    @NotBlank(message = "Event type can't be empty")
    private String eventType;

    @NotNull(message = "Event timestamp can't be null")
    private Timestamp timestamp;

    @ValidEventEnvironment
    private String appEnv;

    private String platform;

    private String platformv2;

    /**
     * IP address of the event sender
     */
    private String ip;

    @NotNull(message = "Event providers can't be null")
    @NotEmpty(message = "Event providers can't be empty")
    private Set<EventProvider> eventProviders;

    private JsonNode data;

    private String customerIdentifier;

    private UserEventIdentifier userIdentifiers;

    private UserAttributes userAttributes;

    private String applicationID;

    private Double longitude;

    private Double latitude;

    private String appDomain;
}
