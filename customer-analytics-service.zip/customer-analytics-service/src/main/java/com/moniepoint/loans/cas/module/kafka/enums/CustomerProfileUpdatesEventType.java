package com.moniepoint.loans.cas.module.kafka.enums;

public enum CustomerProfileUpdatesEventType {
    CUSTOMER_PROFILE_UPDATE
}