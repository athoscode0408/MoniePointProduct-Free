package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BrazeEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final Validator validator;
    private final EventProviderHandler brazeEventProviderHandler;

    @KafkaListener(topics = "${kafka.topic.verified-analytics-event}", groupId = "${spring.kafka.consumer-groups.braze-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.debug("BrazeEventListener :: Received event: {}", event);

        List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents = objectMapperHelper.deserializeStringToObject(
                JsonUtils.normalizeJsonToArray(event.value()),
                new TypeReference<>() {
                }
        );

        List<VerifiedAnalyticsEventDTO> validEvents = filterInvalidEvents(verifiedAnalyticsEvents);
        if (validEvents.isEmpty()) {
            log.warn("(BrazeEventListener) Failed to process verified analytics event due to missing valid event data");
            return;
        }

        brazeEventProviderHandler.processEvents(validEvents);
    }

    private List<VerifiedAnalyticsEventDTO> filterInvalidEvents(List<VerifiedAnalyticsEventDTO> events) {
        List<VerifiedAnalyticsEventDTO> validEvents = new ArrayList<>();
        events.forEach(event -> {
            if (event.getEventProviders().stream().noneMatch(brazeEventProviderHandler::support)) {
                return;
            }

            Set<ConstraintViolation<VerifiedAnalyticsEventDTO>> violations = validator.validate(event);
            if (!violations.isEmpty()) {
                log.warn(
                        "Failed to process verified analytics event due to : {}",
                        violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.joining(", "))
                );
                return;
            }
            if (StringUtils.isBlank(event.getApplicationID()) || StringUtils.isBlank(event.getAppDomain()))
            {
                log.warn("Failed to process verified analytics event due to missing appID or appDomain" );
                return;
            }

            if (event.getUserIdentifiers() == null || StringUtils.isBlank(event.getUserIdentifiers().getUserID())) {

                log.warn("Failed to process verified analytics event due to missing user identifier" );
                return;
            }

            validEvents.add(event);
        });
        return validEvents;
    }
}
