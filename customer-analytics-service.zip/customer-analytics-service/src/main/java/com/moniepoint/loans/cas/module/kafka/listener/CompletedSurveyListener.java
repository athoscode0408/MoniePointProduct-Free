package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.impl.SurveyEventCompletionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CompletedSurveyListener {
    private final SurveyEventCompletionService surveyEventCompletionService;
    private final ObjectMapperHelper objectMapperHelper;

    @KafkaListener(topics = "${kafka.topic.event-completed-survey}", groupId = "${spring.kafka.consumer-groups.survey-evaluator-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        try {
            log.info("SurveyCompletedListener :: Received completed survey event: {}", event.value());
            AnalyticsEventRequestDTO surveyCompletedEvent = objectMapperHelper.deserializeStringToObject(
                    event.value(),
                    new TypeReference<>() {
                    }
            );
            surveyEventCompletionService.processCompletedSurveyEvent(surveyCompletedEvent);
        } catch (Exception e) {
            log.error("Failed to process survey completed event. ", e);
        }

    }

}
