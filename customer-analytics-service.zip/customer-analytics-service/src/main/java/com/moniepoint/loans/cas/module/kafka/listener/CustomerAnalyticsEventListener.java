package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.mapper.AnalyticsEventV3Mapper;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import com.moniepoint.loans.cas.module.analytics.service.SessionService;
import com.moniepoint.loans.cas.module.analytics.service.impl.SessionServiceImpl;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerAnalyticsEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final AnalyticsService analyticsService;
    private final Validator validator;
    private final ModelMapper modelMapper;
    private final AnalyticsEventV3Mapper analyticsEventV3Mapper;
    private final SessionService sessionService;

    @Value("${events.disable-downstream-processing:false}")
    private boolean disableDownstreamProcessing;

    @KafkaListener(topics = "${kafka.topic.customer-analytics-event}", groupId = "${spring.kafka.consumer.group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.info("Received event on customer analytics topic {}", JsonUtils.normalizeJsonToArray(event.value()));

        if (disableDownstreamProcessing)
        {
            log.warn("Downstream processing disabled");
            return;
        }

        List<BaseAnalyticsEventRequestDTO<?>> eventsList = objectMapperHelper.deserializeStringToObject(
                JsonUtils.normalizeJsonToArray(event.value()),
                new TypeReference<>() {
                }
        );

        if (eventsList.isEmpty()) {
            return;
        }

        List<AnalyticsEventRequestDTO> mappedEvents = new ArrayList<>();
        HashMap<String, String> sessionIds = new HashMap<>();
        for (BaseAnalyticsEventRequestDTO<?> eventRequest : eventsList) {
            Set<ConstraintViolation<BaseAnalyticsEventRequestDTO<?>>> violations = validator.validate(eventRequest);
            if (!violations.isEmpty()) {
                logValidationErrors(violations);
                continue;
            }

            switch (eventRequest) {
                case AnalyticsEventV3RequestDTO v3Request -> {
                    String deviceID = null;
                    if (v3Request.getData() instanceof AnalyticsEventV3DataDTO dto
                            && dto.getDevice() != null) {
                        deviceID = dto.getDevice().getId();
                    }
                    UserEventIdentifier user = v3Request.getUserIdentifiers();

                    if (user == null) {
                        user = new UserEventIdentifier();
                        v3Request.setUserIdentifiers(user);
                    }

                        if (StringUtils.isNotBlank(deviceID) && sessionIds.containsKey(deviceID)) {
                            v3Request.setUserIdentifiers(
                                    new UserEventIdentifier(
                                            sessionIds.get(deviceID),
                                            user.getUserID(),
                                            user.getEmail(),
                                            user.getPhone(),
                                            user.getName()
                                    )
                            );
                        }
                        else {
                            UserEventIdentifier userEventIdentifier = ensureUserIdentification(user, deviceID);
                            v3Request.setUserIdentifiers(userEventIdentifier);

                            if (StringUtils.isNotBlank(deviceID)) {
                                sessionIds.put(deviceID, userEventIdentifier.getSessionID());
                            }
                        }
                    mappedEvents.add(analyticsEventV3Mapper.mapToAnalyticsEventRequestDTO(v3Request));
                }
                case AnalyticsEventV2RequestDTO v2Request ->
                        mappedEvents.add(modelMapper.map(v2Request, AnalyticsEventRequestDTO.class));
                default -> throw new IllegalArgumentException("Unsupported event version");
            }
        }
        if (mappedEvents.isEmpty()) {
            log.debug("No valid events found in event ({}). Skipping publishing of events...", event);
            return;
        }
        try
        {
            analyticsService.handleRawAnalyticsEvents(mappedEvents);
        } catch (Exception e) {
            log.error("CustomerAnalyticsEventListener:: Exception processing event {} ", e.getMessage(),e);
        }
    }

    private UserEventIdentifier ensureUserIdentification(UserEventIdentifier user, String deviceID) {
        String sessionID = StringUtils.isBlank(deviceID) ? SessionServiceImpl.generateSessionID() : sessionService.generateSessionID(deviceID, user != null ? user.getUserID() : null);
        if (user == null) {
            return new UserEventIdentifier(sessionID);
        }

        return new UserEventIdentifier(sessionID, user.getUserID(), user.getEmail(), user.getPhone(), user.getName());
    }

    private <T> void logValidationErrors(Set<ConstraintViolation<T>> violations) {
        String errorMessages = violations.stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));
        log.error("Failed to process event due to validation errors: {}", errorMessages);
    }
}