package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerIOEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final Validator validator;
    private final EventProviderHandler customerIOEventProviderHandler;

    @KafkaListener(topics = "${kafka.topic.verified-analytics-event}", groupId = "${spring.kafka.consumer-groups.customerio-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.info("CustomerIOEventListener :: Received event: {}", event);

        List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents =
                objectMapperHelper.deserializeStringToObject(JsonUtils.normalizeJsonToArray(event.value()), new TypeReference<>() {
                });

        processEvents(verifiedAnalyticsEvents);
    }

    private void processEvents(final List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents) {
        for (VerifiedAnalyticsEventDTO verifiedAnalyticsEvent : verifiedAnalyticsEvents) {
            Set<ConstraintViolation<VerifiedAnalyticsEventDTO>> violations = validator.validate(verifiedAnalyticsEvent);
            if (!violations.isEmpty()) {
                String errorMessages = violations.stream()
                        .map(ConstraintViolation::getMessage)
                        .collect(Collectors.joining(", "));

                log.warn("Failed to process verified analytics event due to : {}", errorMessages);
                return;
            }

            if (shouldProcess(verifiedAnalyticsEvent.getEventProviders())) {
                customerIOEventProviderHandler.processEvent(verifiedAnalyticsEvent);
            }
        }
    }

    private boolean shouldProcess(Set<EventProvider> eventProviders) {
        return eventProviders.stream().anyMatch(customerIOEventProviderHandler::support);
    }
}
