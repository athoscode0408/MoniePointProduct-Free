package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerProfileUpdateRequest;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import com.moniepoint.loans.cas.module.kafka.dto.CustomerProfileUpdatesEventDTO;
import com.moniepoint.loans.cas.module.kafka.enums.CustomerProfileUpdatesEventType;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerProfileUpdateEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final Validator validator;
    private final CustomerIOIntegrationService customerIOIntegrationService;
    private final CustomerIOConfig customerIOConfig;

    @KafkaListener(topics = "${kafka.topic.customer-profile-updates-event}", groupId = "${spring.kafka.consumer-groups.customerio-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.debug("CustomerProfileUpdateEventListener :: Received event: {}", event);

        CustomerProfileUpdatesEventDTO customerProfileUpdatesEventDTO =
                objectMapperHelper.deserializeStringToObject(event.value(), new TypeReference<>() {
                });
        if(customerIOConfig.isUpdateCustomerProfile()) {
            processEvent(customerProfileUpdatesEventDTO);
        }
    }

    private void processEvent(final CustomerProfileUpdatesEventDTO customerProfileUpdatesEventDTO) {
        Set<ConstraintViolation<CustomerProfileUpdatesEventDTO>> violations = validator.validate(customerProfileUpdatesEventDTO);
        if (!violations.isEmpty()) {
            String errorMessages = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining(", "));

            log.error("Failed to process customer profile update event due to : {}", errorMessages);
            return;
        }
        if (CustomerProfileUpdatesEventType.CUSTOMER_PROFILE_UPDATE.equals(customerProfileUpdatesEventDTO.getEventType())) {
            processCustomerProfileAttributeUpdateEvent(customerProfileUpdatesEventDTO);
        }
    }

    private void processCustomerProfileAttributeUpdateEvent(CustomerProfileUpdatesEventDTO customerProfileUpdatesEventDTO) {
        customerIOIntegrationService.updateCustomerProfile(customerProfileUpdatesEventDTO.getCustomerIdentifier(),
                getCustomerProfileUpdateRequest(customerProfileUpdatesEventDTO));
    }

    private static CustomerProfileUpdateRequest getCustomerProfileUpdateRequest(CustomerProfileUpdatesEventDTO customerProfileUpdatesEventDTO) {
        return CustomerProfileUpdateRequest.builder()
                .data(customerProfileUpdatesEventDTO.getData())
                .build();
    }

}