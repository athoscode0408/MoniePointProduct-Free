package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDTO;
import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventRetryIDListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final EventRetryRepositoryService eventRetryRepositoryService;
    private final List<EventProviderHandler> eventProviderHandlers;
    private final Validator validator;

    @KafkaListener(topics = "${kafka.topic.event-retry-id}", groupId = "${spring.kafka.consumer.group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.info("EventRetryIDListener :: Received event: {}", event);

        EventRetryDTO eventRetryDTO =
                objectMapperHelper.deserializeStringToObject(event.value(), new TypeReference<EventRetryDTO>() {
                });

        Set<ConstraintViolation<EventRetryDTO>> violations = validator.validate(eventRetryDTO);
        if (!violations.isEmpty()) {
            String errorMessages = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining(", "));

            log.error("Failed to process event retry due to : {}", errorMessages);
            return;
        }

        processEvent(eventRetryDTO);
    }

    @Async("appExecutor")
    private void processEvent(final EventRetryDTO eventRetryDTO) {
        Long eventRetryID = eventRetryDTO.getId();
        Optional<EventRetry> eventRetryOptional = eventRetryRepositoryService.findEventRetryById(eventRetryID);
        if (eventRetryOptional.isPresent()) {
            EventRetry eventRetry = eventRetryOptional.get();
            Optional<EventProviderHandler> eventProviderHandlerOptional = eventProviderHandlers.stream().filter(handler -> handler.support(eventRetry.getEventProvider())).findFirst();
            if (eventProviderHandlerOptional.isPresent()) {
                boolean success = eventProviderHandlerOptional.get().processEvent(eventRetry.getEventData());
                if (success) {
                    try{
                        eventRetryRepositoryService.deleteById(eventRetryID);
                    } catch (Exception e) {
                        log.error("Unable to delete retry for record {} in the database",eventRetryID, e);
                    }
                }
            }
        }
    }
}
