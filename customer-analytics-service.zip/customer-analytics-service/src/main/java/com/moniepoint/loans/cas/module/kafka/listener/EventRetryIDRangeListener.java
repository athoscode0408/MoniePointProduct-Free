package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventRetryIDRangeListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final EventRetryService eventRetryService;
    private final Validator validator;

    @KafkaListener(topics = "${kafka.topic.event-retry-id-range}", groupId = "${spring.kafka.consumer.group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.error("EventRetryIDRangeListener :: Received event: {}", event);

        EventRetryIDRangeDTO eventRetryIDRangeDTO =
                objectMapperHelper.deserializeStringToObject(event.value(), new TypeReference<EventRetryIDRangeDTO>() {
                });

        processEvent(eventRetryIDRangeDTO);
    }

    @Async("appExecutor")
    private void processEvent(final EventRetryIDRangeDTO eventRetryIDRange) {
        Set<ConstraintViolation<EventRetryIDRangeDTO>> violations = validator.validate(eventRetryIDRange);
        if (!violations.isEmpty()) {
            String errorMessages = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining(", "));

            log.error("Failed to process event retry id range due to : {}", errorMessages);
            return;
        }
        eventRetryService.handleEventRetryIDRange(eventRetryIDRange);
    }

}
