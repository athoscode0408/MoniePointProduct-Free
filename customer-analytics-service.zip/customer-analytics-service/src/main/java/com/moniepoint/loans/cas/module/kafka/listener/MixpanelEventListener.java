package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MixpanelEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final Validator validator;
    private final EventProviderHandler mixpanelEventProviderHandler;

    @KafkaListener(topics = "${kafka.topic.verified-analytics-event}", groupId = "${spring.kafka.consumer-groups.mixpanel-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.info("MixpanelEventListener :: Received event: {}", event);

        List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents = objectMapperHelper.deserializeStringToObject(
                JsonUtils.normalizeJsonToArray(event.value()),
                new TypeReference<>() {
                }
        );

        var validEvents = verifiedAnalyticsEvents.stream().filter(e -> {
                    Set<ConstraintViolation<VerifiedAnalyticsEventDTO>> violations = validator.validate(e);
                    if (!violations.isEmpty()) {
                        String errorMessages = violations.stream()
                                .map(ConstraintViolation::getMessage)
                                .collect(Collectors.joining(", "));

                        log.warn("Failed to process verified analytics event due to : {}", errorMessages);
                        return false;
                    }

                    return e.getEventProviders().stream().anyMatch(mixpanelEventProviderHandler::support);
                }
        ).toList();

        if (validEvents.isEmpty()) {
            log.warn("MixpanelEventListener :: Failed to process verified analytics event due to missing event data.");
            return;
        }

        mixpanelEventProviderHandler.processEvents(validEvents);
    }
}
