package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.modelmapper.ModelMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RawAnalyticsEventListener {

    private final ObjectMapperHelper objectMapperHelper;
    private final AnalyticsService analyticsService;
    private final Validator validator;
    private final ModelMapper modelMapper;

    @KafkaListener(topics = "${kafka.topic.raw-analytics-event}", groupId = "${spring.kafka.consumer.group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        log.info("RawAnalyticsEventListener :: Received event: {}", event);

        AnalyticsEventV1RequestDTO analyticsEventRequestDTO =
                objectMapperHelper.deserializeStringToObject(event.value(), new TypeReference<>() {
                });

        processEvent(analyticsEventRequestDTO);
    }

    private void processEvent(final AnalyticsEventV1RequestDTO analyticsEventV1Request) {
        Set<ConstraintViolation<AnalyticsEventV1RequestDTO>> violations = validator.validate(analyticsEventV1Request);
        if (!violations.isEmpty()) {
            String errorMessages = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining(", "));

            log.error("Failed to process raw analytic event due to : {}", errorMessages);
            return;
        }

        AnalyticsEventRequestDTO analyticsEventRequest = modelMapper.map(analyticsEventV1Request, AnalyticsEventRequestDTO.class);
        analyticsService.handleRawAnalyticsEvent(analyticsEventRequest);
    }

}
