package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.analytics.service.SurveyRulesCache;
import com.moniepoint.loans.cas.module.analytics.service.impl.RuleParserHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyEvaluatorListener {

    private final SurveyRulesCache surveyRulesCache;
    private final UserAttributesStorage userStorage;
    private final ObjectMapperHelper objectMapperHelper;
    private final RuleParserHandler ruleParserHandler;

    @Value("${survey.image-location-url}")
    private String imageLocationUrl;

    @KafkaListener(topics = "${kafka.topic.event-validated-survey}", groupId = "${spring.kafka.consumer-groups.survey-evaluator-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        try {
            log.info("SurveyEvaluatorListener :: Received event: {}", event.value());

            VerifiedAnalyticsEventDTO validEvent = objectMapperHelper.deserializeStringToObject(
                    event.value(),
                    new TypeReference<>() {
                    }
            );
            String userId = validEvent.getUserIdentifiers().getUserID();
            var surveyRules = surveyRulesCache.getRules();
            String userBusinessAccountNumber = validEvent.getUserAttributes() == null ? null : validEvent.getUserAttributes().getBusinessNubanAccountNumber();
            String userPersonalAccountNumber = validEvent.getUserAttributes() == null ? null : validEvent.getUserAttributes().getNubanAccountNumber();
            String userAccountNumber = StringUtils.isBlank(userBusinessAccountNumber) ? userPersonalAccountNumber : userBusinessAccountNumber;
            var user = StringUtils.isBlank(userAccountNumber) ? null : userStorage.findUser(userId, userAccountNumber);
            log.info("User data returned for user {} and account {} from bigtable is {}",userId, userAccountNumber, user);
            if (user == null) {
                log.warn("User data not found in bigtable");
                user = validEvent.getUserAttributes();
            } else {
                log.debug("User data found in bigtable");
                user.update(validEvent.getUserAttributes());
            }
            if (StringUtils.isNotBlank(userBusinessAccountNumber))
            {
                String userBrmImage = user.getBrmImage();
                String encodedImage = StringUtils.isBlank(userBrmImage) ? null : URLEncoder.encode(userBrmImage, StandardCharsets.UTF_8);
                userBrmImage= StringUtils.isBlank(encodedImage) ? null : imageLocationUrl+encodedImage+"?requestType=BRM_IMAGE";
                user.setBrmImage(userBrmImage);
            }

            log.debug("Parsing event through {} rules", surveyRules.size());
            for (var surveyRule : surveyRules) {
                ruleParserHandler.parseRule(surveyRule, validEvent, user);
            }
        } catch (Exception e) {
            log.error("Failed to process survey event. ", e);
        }
    }
}