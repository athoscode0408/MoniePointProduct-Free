package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyEventListener {
    private final ObjectMapperHelper objectMapperHelper;
    private final KafkaEventPublisher<VerifiedAnalyticsEventDTO> surveyEvaluatorKafkaEventPublisher;

    @KafkaListener(topics = "${kafka.topic.verified-analytics-event}", groupId = "${spring.kafka.consumer-groups.survey-evaluator-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        try {
            log.info("SurveyEventListener :: Received event: {}", event.value());
            var validEvents = getValidEvents(event);
            if (validEvents.isEmpty()) {
                return;
            }
            surveyEvaluatorKafkaEventPublisher.publishEvents(null, validEvents);
        } catch (Exception e) {
            log.error("Failed to process survey event.",e);
        }
    }

    private List<VerifiedAnalyticsEventDTO> getValidEvents(ConsumerRecord<String, String> event) {
        List<VerifiedAnalyticsEventDTO> events = objectMapperHelper.deserializeStringToObject(
                JsonUtils.normalizeJsonToArray(event.value()),
                new TypeReference<>() {
                }
        );
        return events.stream()
                .filter(e -> e.getUserIdentifiers() != null && StringUtils.isNotBlank(e.getUserIdentifiers().getUserID()))
                .collect(Collectors.toList());
    }
}
