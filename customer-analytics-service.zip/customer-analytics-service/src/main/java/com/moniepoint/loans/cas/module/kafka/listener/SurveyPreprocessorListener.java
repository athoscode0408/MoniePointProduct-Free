package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.node.NullNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.analytics.dto.v3.EventPreprocessSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.analytics.service.impl.BannerService;
import com.moniepoint.loans.cas.module.analytics.service.impl.SurveyBodyLoader;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyPreprocessorListener {
    private final PreprocessedSurveyStorage preprocessedSurveyStorage;
    private final ObjectMapperHelper objectMapperHelper;
    private final RedisCacheServiceImpl cache;
    private final KafkaEventPublisher<NotificationRequest> surveyPushNotificationKafkaEventPublisher;
    private final BannerService bannerService;
    private final SurveyBodyLoader surveyBodyLoader;
    private final UserAttributesStorage userAttributesStorage;
    @Value("${survey.preprocessed-survey-ttl-mins:10080}")
    private int preprocessedSurveyTtl;

    @KafkaListener(topics = "${kafka.topic.event-survey-preprocessor}", groupId = "${spring.kafka.consumer-groups.survey-evaluator-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        try {
            log.debug("SurveyPreprocessListener :: Received event: {}", event.value());
            EventPreprocessSurveyDTO preprocessEvent = objectMapperHelper.deserializeStringToObject(
                    event.value(),
                    new TypeReference<>() {
                    }
            );
            preprocessSurvey(preprocessEvent);
        } catch (Exception e) {
            log.error("Failed to process survey event.",e);
        }

    }

    private void preprocessSurvey(EventPreprocessSurveyDTO eventPreprocessSurveyDTO) {
        Telemetry.runInSpan("SurveyPreprocessor", () -> {
            log.debug("Preprocessing started");
            UserAttributes user = eventPreprocessSurveyDTO.getUserAttributes();
            if (user == null) {
                user = userAttributesStorage.findUser(
                        eventPreprocessSurveyDTO.getPreprocessedSurvey().getUser(), null);
            }
            Map<String, Object> valueMap = new HashMap<>();
            populateContextValuesMap(valueMap, "user", user);
            VerifiedAnalyticsEventDTO event = eventPreprocessSurveyDTO.getVerifiedAnalyticsEventDTO();
            if (event != null) {
                if (event.getData() != null && !(event.getData() instanceof NullNode)) {
                    try {
                        AnalyticsEventV3DataDTO data = objectMapperHelper.convertObjectToType(
                                event.getData(),
                                new TypeReference<>() {
                                }
                        );
                        populateContextValuesMap(valueMap, "event", data);
                        populateContextValuesMap(valueMap, "event.device", data.getDevice());
                    } catch (Exception e) {
                        log.warn("Could not add event data into survey due to: {}", e.getMessage());
                    }
                }
            }
            PreprocessedSurvey preprocessedSurvey = eventPreprocessSurveyDTO.getPreprocessedSurvey();
            if (eventPreprocessSurveyDTO.getCohortId() != null && preprocessedSurvey.getCohortId() == null) {
                preprocessedSurvey.setCohortId(eventPreprocessSurveyDTO.getCohortId());
            }
            if (StringUtils.isNotBlank(preprocessedSurvey.getIsoWeek())) {
                Optional<PreprocessedSurvey> existing = preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(
                        preprocessedSurvey.getUser(),
                        preprocessedSurvey.getIsoWeek(),
                        List.of(PreprocessedSurveyState.NOT_COMPLETED, PreprocessedSurveyState.NOT_READY)
                );
                if (existing.isPresent()) {
                    log.info("Skipping duplicate NPS preprocessed survey for user={} isoWeek={}, existing preprocessedSurveyId={}",
                            preprocessedSurvey.getUser(), preprocessedSurvey.getIsoWeek(), existing.get().getId());
                    return;
                }
            }
            Survey survey = eventPreprocessSurveyDTO.getSurvey();
            preprocessedSurvey.setSurvey(StringSubstitutor.replace(survey.getSurvey(), valueMap));
            preprocessedSurvey.setState(PreprocessedSurveyState.NOT_COMPLETED);
            SurveyBody surveyBody = surveyBodyLoader.load(survey);
            preprocessedSurveyTtl =surveyBody!= null && surveyBody.getPreprocessedSurveyTTL() > 0 ? surveyBody.getPreprocessedSurveyTTL()  : preprocessedSurveyTtl;

            Instant baseTime = event != null ? event.getTimestamp().toInstant() : Instant.now();
            preprocessedSurvey.setTtl(Timestamp.from(baseTime.plus(Duration.of(preprocessedSurveyTtl, ChronoUnit.MINUTES))));
            PreprocessedSurvey savedPreprocessedSurvey = preprocessedSurveyStorage.save(preprocessedSurvey);
            log.debug("Complete preprocessed data saved to database");
            if (surveyBody != null && surveyBody.isAssignBanner() && StringUtils.isNotBlank(surveyBody.getBannerId()))
            {
                bannerService.assignBannerToUser(user.getUserName(), surveyBody.getBannerId());
            }
            else if (event != null && isMobilePlatform(event.getPlatform()))
            {
                enqueuePushNotification(preprocessedSurvey, event);
            }
            writePreprocessedSurveyToCache(savedPreprocessedSurvey, survey);
        });
    }

    private void writePreprocessedSurveyToCache(PreprocessedSurvey preprocessedSurvey, Survey survey) {
        PreprocessedSurveyDTO dto = objectMapperHelper.convertObjectToType(preprocessedSurvey, new TypeReference<>() {});
        dto.setLocationWeb(survey.getWebLocation());
        dto.setLocationMobile(survey.getMobileLocation());
        cache.cachePreprocessedSurveyById(String.valueOf(preprocessedSurvey.getId()), objectMapperHelper.serializeToString(dto));

        if (preprocessedSurvey.isSampledNPSSurvey()) {
            /*
            NPS sampling feature replies on db getting his to mark sampled record for the user as SERVED,
            below logic evicts surveys for user if the generated survey is an NPS

            */
            log.debug("New NPS weekly survey for user {} isoWeek {}. Evicting cached survey list instead of appending",
                    preprocessedSurvey.getUser(), preprocessedSurvey.getIsoWeek());
            cache.evictAllPreprocessedSurveys(preprocessedSurvey.getUser());
            return;
        }

        List<PreprocessedSurveyDTO> savedPps = cache.getAllPreprocessedSurveys(preprocessedSurvey.getUser());
        if (!savedPps.isEmpty()) {
            log.debug("Appending new preprocessed survey to user history in cache");
            cache.appendPreprocessedSurvey(preprocessedSurvey.getUser(), dto);
        }
    }

    private void populateContextValuesMap(Map<String, Object> values, String prefix, Object object) {
        if (object == null) {
            return;
        }

        for (Field field : object.getClass().getDeclaredFields()) {
            try {
                field.setAccessible(true);
                Object value = field.get(object);

                if (value != null) {
                    values.put(String.format("%s.%s", prefix, StringUtils.capitalize(field.getName())), value);
                }
            } catch (IllegalAccessException e) {
                log.warn("Could not access field {} on {} via reflection", field.getName(), object.getClass(), e);
            }
        }
    }

    private Boolean isMobilePlatform (String platform)
    {
        return "ANDROID".equalsIgnoreCase(platform) || "IOS".equalsIgnoreCase(platform);
    }

    private void enqueuePushNotification(PreprocessedSurvey preprocessedSurvey, VerifiedAnalyticsEventDTO event) {
        log.debug("Now publishing partially preprocessed survey to kafka for push notification");
        surveyPushNotificationKafkaEventPublisher.publishEvent("survey-notification-"+event.getId(), new NotificationRequest(preprocessedSurvey, event));
    }

}
