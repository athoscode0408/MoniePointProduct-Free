package com.moniepoint.loans.cas.module.kafka.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import com.moniepoint.loans.cas.outbound.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
@Slf4j
@Service
@RequiredArgsConstructor
public class SurveyPushNotificationListener {
    private final NotificationService notificationService;
    private final ObjectMapperHelper objectMapperHelper;

    @KafkaListener(topics = "${kafka.topic.event-survey-push-notification}", groupId = "${spring.kafka.consumer-groups.survey-evaluator-group-id}")
    public void handleEvent(ConsumerRecord<String, String> event) {
        try {
            log.debug("SurveyPushNotificationListener :: Received event: {}", event.value());
            NotificationRequest notificationRequest = objectMapperHelper.deserializeStringToObject(
                    event.value(),
                    new TypeReference<>() {
                    }
            );
            notificationService.sendPushNotification(notificationRequest);
            log.debug("Notification successfully pushed to client");
        } catch (Exception e) {
            log.error("Failed to process survey event. ", e);
        }

    }

}
