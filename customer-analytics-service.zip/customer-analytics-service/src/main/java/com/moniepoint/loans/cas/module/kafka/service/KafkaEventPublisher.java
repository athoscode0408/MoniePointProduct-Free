package com.moniepoint.loans.cas.module.kafka.service;

import java.util.List;

public interface KafkaEventPublisher<T> {

    String getTopic();

    void publishEvent(String key, T event);

    void publishEvents(String key, List<T> events);

}
