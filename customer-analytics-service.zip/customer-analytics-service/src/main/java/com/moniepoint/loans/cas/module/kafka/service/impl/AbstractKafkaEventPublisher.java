package com.moniepoint.loans.cas.module.kafka.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import datadog.trace.api.Trace;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import java.util.UUID;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractKafkaEventPublisher<T> implements KafkaEventPublisher<T> {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapperHelper objectMapperHelper;
    private final Telemetry telemetry;

    @Override
    public void publishEvent(String key, T event) {
        final String serializedEvent = objectMapperHelper.serializeToString(event);
         final String safeKey = (key == null || key.isBlank())
            ? UUID.randomUUID().toString()
            : key;

        log.info("Now sending event to kafka topic {}", getTopic());
        long startTime = System.nanoTime();

        kafkaTemplate.send(getTopic(), safeKey, serializedEvent).whenComplete((result, ex) -> {
            long durationNs = System.nanoTime() - startTime;
            long durationMs = durationNs / 1_000_000;
            int payloadBytes = serializedEvent.getBytes(StandardCharsets.UTF_8).length;

            telemetry.recordMetric("Custom/publishEvent/PayloadBytes", payloadBytes);

            telemetry.recordMetric("Custom/publishEvent/TimeMs", durationMs);
            log.debug("publishEvent :: Kafka publish time for payload of size {} was {} ms", payloadBytes, durationMs);

            if (ex != null) {
                log.error("Failed to publish event with key {} to topic {}", safeKey, getTopic(), ex);
            } else {
                log.info("Successfully published event with key {} to topic {}", safeKey, getTopic());
            }
        });
    }

    @Override
    public void publishEvents(String key, List<T> events) {
        final String serializedEvent = objectMapperHelper.serializeToString(events);
        final String safeKey = (key == null || key.isBlank())
            ? UUID.randomUUID().toString()
            : key;
        long startTime = System.nanoTime();
        kafkaTemplate.send(getTopic(), safeKey, serializedEvent).whenComplete((result, ex) -> {
            long durationNs = System.nanoTime() - startTime;
            long durationMs = durationNs / 1_000_000;
            int payloadBytes = serializedEvent.getBytes(StandardCharsets.UTF_8).length;

            telemetry.recordMetric("Custom/publishEvents/PayloadBytes", payloadBytes);

            telemetry.recordMetric("Custom/publishEvents/TimeMs", durationMs);
            log.debug("publishEvents :: Kafka publish time for payload of size {} was {} ms", payloadBytes, durationMs);

            if (ex != null) {
                    log.error("Failed to publish batched event with key {} to topic {}", safeKey, getTopic(), ex);
                } else {
                    log.debug("Successfully published batched event with key {} to topic {}", safeKey, getTopic());
                }
            });
        log.info("Completed publishing setup for {} events to kafka topic {}", events.size(), getTopic());
    }


    @Async("appExecutor")
    @Trace
    public CompletableFuture<Void> publishEventsAsync(String key, List<T> events) {
        try {
            log.info("Starting async publishing of {} events to kafka topic {}", events.size(), getTopic());
             final String safeKey = (key == null || key.isBlank())
            ? UUID.randomUUID().toString()
            : key;
            events.forEach(event -> {
                try {
                    final String serializedEvent = objectMapperHelper.serializeToString(event);
                    long startTime = System.nanoTime();
                    kafkaTemplate.send(getTopic(), safeKey, serializedEvent).whenComplete((result, ex) -> {
                        long durationNs = System.nanoTime() - startTime;
                        long durationMs = durationNs / 1_000_000;
                        int payloadBytes = serializedEvent.getBytes(StandardCharsets.UTF_8).length;

                        telemetry.recordMetric("Custom/publishEventsAsync/PayloadBytes", payloadBytes);

                        telemetry.recordMetric("Custom/publishEventsAsync/TimeMs", durationMs);
                        log.debug("publishEventsAsync :: Kafka publish time for payload of size {} was {} ms", payloadBytes, durationMs);

                        if (ex != null) {
                            log.error("Failed to publish async event with key {} to topic {}", safeKey, getTopic(), ex);
                        } else {
                            log.debug("Successfully published async event with key {} to topic {}", safeKey, getTopic());
                        }
                    });
                } catch (Exception e) {
                    log.error("Failed to serialize event for async publishing: {}", e.getMessage());
                }
            });

            log.info("Completed async publishing setup for {} events to kafka topic {}", events.size(), getTopic());
            return CompletableFuture.completedFuture(null);
        } catch (Exception e) {
            log.error("Failed to publish events async with key {} to topic {}", key, getTopic(), e);
            return CompletableFuture.failedFuture(e);
        }
    }
}
