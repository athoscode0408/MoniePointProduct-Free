package com.moniepoint.loans.cas.module.ratelimiter.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface RateLimit {
    /**
     * Optional key to identify the rate limit bucket. If empty, generated from class, method and args.
     */
    String key() default "";

    /**
     * Maximum allowed calls within the time window.
     */
    long permits() default 1;

    /**
     * Time window in seconds.
     */
    long periodSeconds() default 60;
}
