package com.moniepoint.loans.cas.module.ratelimiter.aspect;

import com.moniepoint.loans.cas.module.ratelimiter.annotation.RateLimit;
import com.moniepoint.loans.cas.module.ratelimiter.exception.RateLimitExceededException;
import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Arrays;

@Aspect
@Component
public class RateLimiterAspect {

    private final RateLimiterService rateLimiterService;

    public RateLimiterAspect(RateLimiterService rateLimiterService) {
        this.rateLimiterService = rateLimiterService;
    }

    @Around("@annotation(com.moniepoint.loans.cas.module.ratelimiter.annotation.RateLimit)")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();
        RateLimit rateLimit = method.getAnnotation(RateLimit.class);

        String key = buildKey(rateLimit.key(), pjp);
        long permits = rateLimit.permits();
        long periodSeconds = rateLimit.periodSeconds();

        boolean allowed = rateLimiterService.tryAcquire(key, permits, periodSeconds);
        if (!allowed) {
            throw new RateLimitExceededException(String.format("Rate limit exceeded for key=%s", key));
        }

        return pjp.proceed();
    }

    private String buildKey(String configuredKey, ProceedingJoinPoint pjp) {
        if (configuredKey != null && !configuredKey.trim().isEmpty()) {
            return configuredKey;
        }

        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();
        String className = method.getDeclaringClass().getSimpleName();
        String methodName = method.getName();
        Object[] args = pjp.getArgs();

        String argsDigest = Arrays.deepToString(args);
        String key = String.format("ratelimit:%s.%s:%s", className, methodName, Integer.toHexString(argsDigest.hashCode()));
        return key;
    }
}
