package com.moniepoint.loans.cas.module.ratelimiter.service;

public interface RateLimiterService {
    /**
     * Try to acquire a permit for the given key. Returns true if allowed.
     */
    boolean tryAcquire(String key, long permits, long periodSeconds);
}
