package com.moniepoint.loans.cas.module.ratelimiter.service.impl;

import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Service
public class RedisRateLimiterService implements RateLimiterService {

    private final RedisTemplate<String, String> redisTemplate;

    public RedisRateLimiterService(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public boolean tryAcquire(String key, long permits, long periodSeconds) {
        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("Rate limiter key must not be empty");
        }

        Long count = redisTemplate.opsForValue().increment(key);
        if (count == null) {
            return false;
        }

        if (count == 1L) {
            // first hit - set expiration
            redisTemplate.expire(key, Duration.ofSeconds(periodSeconds));
        }

        return count <= permits;
    }
}
