package com.moniepoint.loans.cas.outbound;

import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.Instant;

@Data
@NoArgsConstructor(force = true)
public class NotificationRequest {
    private final String surveyID;
    private final Instant eventTime;
    private final String renderLocation;
    private final Instant ttl;
    private final int priority;

    private final UserEventIdentifier user;
    private final String deviceType;
    private final String appDomain;

    public NotificationRequest(PreprocessedSurvey survey, VerifiedAnalyticsEventDTO event) {
        surveyID = survey.getId().toString();
        eventTime = event.getTimestamp().toInstant();
        renderLocation = survey.getLocation();
        ttl = survey.getTTLAsInstant();
        priority = survey.getPriority();
        user = event.getUserIdentifiers();
        deviceType = event.getPlatform();
        appDomain =  event.getData() == null ? null :
                (StringUtils.isBlank(event.getData().path("properties").path("app_domain").asText(null)) ? event.getAppDomain()
                        : event.getData().path("properties").path("app_domain").asText(null) );
    }
}
