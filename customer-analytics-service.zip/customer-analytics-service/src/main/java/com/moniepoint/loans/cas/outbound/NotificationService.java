package com.moniepoint.loans.cas.outbound;

public interface NotificationService {
    boolean sendPushNotification(NotificationRequest request);
}
