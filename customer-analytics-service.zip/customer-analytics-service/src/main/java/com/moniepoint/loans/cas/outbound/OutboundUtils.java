package com.moniepoint.loans.cas.outbound;

import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import com.moniepoint.loans.cas.outbound.cosmos.CosmosClient;
import datadog.trace.api.Trace;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OutboundUtils {

    private static final long TOKEN_EXPIRY_BUFFER_SECONDS = 300;

    private final CosmosClient cosmosClient;
    private final String cosmosCredentials;
    private final CacheService cacheService;

    public OutboundUtils(
            @Value("${integrations.cosmos.credentials}") String cosmosCredentials,
            CosmosClient cosmosClient,
            CacheService cacheService) {
        this.cosmosClient = cosmosClient;
        this.cosmosCredentials = cosmosCredentials;
        this.cacheService = cacheService;
    }


    @Trace
    public String getToken() {
        try {
            String cached = cacheService.getCachedString(CacheKeys.CAS_ACCESS_TOKEN_KEY);
            if (StringUtils.isNotBlank(cached)) {
                return cached;
            }
            var response = cosmosClient.authorize(
                    "client_credentials",
                    String.format("Basic %s", cosmosCredentials)
            );
            if (response != null && !response.getStatusCode().is2xxSuccessful()) {
                var body = response.getBody() != null ? response.getBody().getResult() : null;
                log.error("Could not get client token. Error: ({})\n{}", body, response.getStatusCode());
                return "";
            }
            if (response != null && response.getBody() != null) {
                var result = response.getBody().getResult();
                String token = result.getAccessToken();
                long ttl = result.getExpiresIn() - TOKEN_EXPIRY_BUFFER_SECONDS;
                if (ttl > 0) {
                    cacheService.cacheString(CacheKeys.CAS_ACCESS_TOKEN_KEY, token, ttl);
                }
                return token;
            }

            log.error("Null body from access token response");
            return "";
        } catch (Exception e) {
            log.error("Could not get client token. Error: {}", e.getMessage());
        }

        return "";
    }
}
