package com.moniepoint.loans.cas.outbound.airflow;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "airflow-client", url = "${airflow.base-url}", configuration = FeignConfig.class)
public interface AirflowClient {

    @PostMapping("/api/v1/dags/{dagId}/dagRuns")
    ResponseEntity<Void> triggerDagRun(
            @PathVariable("dagId") String dagId,
            @RequestBody AirflowDagRunRequest body,
            @RequestHeader("Authorization") String authorization
    );
}