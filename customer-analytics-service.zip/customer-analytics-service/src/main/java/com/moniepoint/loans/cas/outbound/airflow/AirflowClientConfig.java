package com.moniepoint.loans.cas.outbound.airflow;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(AirflowConfig.class)
public class AirflowClientConfig {
}
