package com.moniepoint.loans.cas.outbound.airflow;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "airflow")
public record AirflowConfig(
        String baseUrl,
        String dagId,
        String apiToken
) {}
