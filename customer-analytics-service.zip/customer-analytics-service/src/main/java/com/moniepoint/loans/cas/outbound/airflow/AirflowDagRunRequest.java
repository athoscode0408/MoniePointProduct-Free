package com.moniepoint.loans.cas.outbound.airflow;

import java.util.Map;

record AirflowDagRunRequest(Map<String, String> conf) {
}