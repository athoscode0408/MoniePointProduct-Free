package com.moniepoint.loans.cas.outbound.airflow;

import com.moniepoint.loans.cas.common.exception.ServerException;
import jakarta.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class AirflowDagTriggerService {

    private final AirflowConfig config;
    private final AirflowClient airflowClient;

    /**
     * Triggers the Airflow NPS pipeline DAG for a specific ISO week.
     * Used by the admin API for manual re-runs only.
     * Normal weekly runs are scheduled in Airflow directly.
     *
     * @param isoWeek ISO week string e.g. "2026-W22", or null for current week
     */
    public void triggerNpsPipeline(@Nullable String isoWeek) {
        try {
            airflowClient.triggerDagRun(config.dagId(), buildRequest(isoWeek), "Bearer " + config.apiToken());
            log.info("Triggered Airflow DAG dagId={} isoWeek={}", config.dagId(), isoWeek);
        } catch (Exception e) {
            log.error("Failed to trigger Airflow DAG dagId={} error={}", config.dagId(), e.getMessage());
            throw new ServerException("Failed to trigger Airflow pipeline: " + e.getMessage());
        }
    }

    AirflowDagRunRequest buildRequest(@Nullable String isoWeek) {
        Map<String, String> conf = new HashMap<>();
        conf.put("triggered_by", "cas_admin");
        if (isoWeek != null) conf.put("iso_week", isoWeek);
        return new AirflowDagRunRequest(conf);
    }
}
