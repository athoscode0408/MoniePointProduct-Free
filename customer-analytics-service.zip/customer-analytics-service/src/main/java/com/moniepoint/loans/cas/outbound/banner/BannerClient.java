package com.moniepoint.loans.cas.outbound.banner;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerDTO;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerResponse;
import com.moniepoint.loans.cas.outbound.banner.dto.UnassignBannerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "banner-service", url = "${integrations.banner.base-url}", configuration = FeignConfig.class)
public interface BannerClient {


    @PostMapping("/api/v1/back-office/banners/assign")
    ResponseEntity<AssignBannerResponse> assignBanner(@RequestBody AssignBannerDTO request, @RequestHeader("Authorization") String authorizationToken);

    @DeleteMapping("/api/v1/back-office/banners/unassign")
    ResponseEntity<Void> unAssignBanner(@RequestBody UnassignBannerDTO request, @RequestHeader("Authorization") String authorizationToken);

}
