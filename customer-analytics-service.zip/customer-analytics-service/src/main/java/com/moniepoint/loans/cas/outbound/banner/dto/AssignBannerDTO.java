package com.moniepoint.loans.cas.outbound.banner.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.time.LocalDateTime;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class AssignBannerDTO {

    @Serial
    private static final long serialVersionUID = 1L;

    private String bannerId;

    private String ownerIdentifier;

    private String ownerIdentifierType;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime expiryDate;

}
