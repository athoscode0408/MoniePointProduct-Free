package com.moniepoint.loans.cas.outbound.banner.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class AssignBannerResponse {

    @Serial
    private static final long serialVersionUID = 1L;

    private boolean requestSuccessful;

    private String responseCode;

    private String responseMessage;

    private ResponseBody responseBody;

    public class ResponseBody {

        @Serial
        private static final long serialVersionUID = 1L;

        private String ownerIdentifier;

        private String bannerCode;

        private String responseMessage;

        private Banner banner;

    }

    public class Banner {

        @Serial
        private static final long serialVersionUID = 1L;

        private String id;

        private String title;

        private String deepLink;

        private int daystillExpiry;

        private String expiryDate;


    }

}
