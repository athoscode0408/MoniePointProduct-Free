package com.moniepoint.loans.cas.outbound.banner.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class UnassignBannerDTO {

    @Serial
    private static final long serialVersionUID = 1L;

    private String bannerOwnerIdentifier;

    private String bannerId;

}
