package com.moniepoint.loans.cas.outbound.cosmos;

import lombok.Data;

import java.io.Serializable;

@Data
public class AuthorizeResponse implements Serializable {
    private final boolean success;
    private final AuthorizeResponseResult result;
}
