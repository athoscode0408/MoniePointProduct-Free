package com.moniepoint.loans.cas.outbound.cosmos;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "cosmos-client", url = "${integrations.cosmos.base-url}", configuration = FeignConfig.class)
public interface CosmosClient {

    @PostMapping("/oauth/token")
    ResponseEntity<AuthorizeResponse> authorize(
            @RequestParam("grant_type") String grantType,
            @RequestHeader("Authorization") String authorizationToken);
}
