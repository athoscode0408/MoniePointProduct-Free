package com.moniepoint.loans.cas.outbound.nos;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * @see <a href="https://teamapt.atlassian.net/wiki/spaces/MAE/pages/1370882137/Notification+Orchestrator+Service">NOS documentation</a>
 */
@FeignClient(name = "nos-client", configuration = FeignConfig.class, url = "${integrations.nos.base-url}")
public interface NOSClient {

    @PostMapping("/v2/notification")
    ResponseEntity<Void> notify(@RequestBody NOSNotificationRequest request, @RequestHeader("Authorization") String authorizationToken,  @RequestHeader("banking-domain") String appDomain);
}
