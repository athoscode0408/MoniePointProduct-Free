package com.moniepoint.loans.cas.outbound.nos;

import lombok.Data;

import java.io.Serializable;

@Data
public class NOSIdentifier implements Serializable {
    // USERNAME, BVN, ACCOUNT_NUMBER, EMAIL, DEVICE_UNIQUE_IDENTIFIER, PHONE_NUMBER
    private final String identifierType;
    private final String value;
}
