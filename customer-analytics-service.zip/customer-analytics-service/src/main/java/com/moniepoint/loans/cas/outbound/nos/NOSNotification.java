package com.moniepoint.loans.cas.outbound.nos;

import lombok.Data;

import java.io.Serializable;

@Data
public class NOSNotification implements Serializable {
    private final NOSPushNotification pushNotification;
}
