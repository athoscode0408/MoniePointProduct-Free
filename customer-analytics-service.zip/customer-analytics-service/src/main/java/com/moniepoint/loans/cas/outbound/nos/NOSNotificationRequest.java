package com.moniepoint.loans.cas.outbound.nos;

import com.moniepoint.loans.cas.outbound.NotificationRequest;
import lombok.Data;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

@Data
public class NOSNotificationRequest implements Serializable {
    private static final String SURVEY_RENDER_EVENT = "RENDER_ANALYTICS_SURVEY";

    private final Collection<NOSIdentifier> identifiers;
    private final String notificationEvent;
    private final NOSNotification notification;

    public NOSNotificationRequest(NotificationRequest request) {
        identifiers = List.of(new NOSIdentifier(
                "USERNAME",
                request.getUser().getUserID()
        ));
        notificationEvent = SURVEY_RENDER_EVENT;
        notification = new NOSNotification(
                new NOSPushNotification(request)
        );
    }
}
