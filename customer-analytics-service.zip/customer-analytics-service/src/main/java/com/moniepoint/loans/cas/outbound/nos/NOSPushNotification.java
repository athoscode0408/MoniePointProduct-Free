package com.moniepoint.loans.cas.outbound.nos;

import com.moniepoint.loans.cas.outbound.NotificationRequest;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Data
public class NOSPushNotification implements Serializable {
    private final String deviceType;
    private final Map<String, String> additionalData;

    public NOSPushNotification(NotificationRequest request) {
        deviceType = request.getDeviceType();
        additionalData = new HashMap<>();
        additionalData.put("survey", request.getSurveyID());
        additionalData.put("eventTime", request.getEventTime().toString());
        additionalData.put("location", request.getRenderLocation());
        additionalData.put("ttl", request.getTtl().toString());
        additionalData.put("priority", String.valueOf(request.getPriority()));
    }
}
