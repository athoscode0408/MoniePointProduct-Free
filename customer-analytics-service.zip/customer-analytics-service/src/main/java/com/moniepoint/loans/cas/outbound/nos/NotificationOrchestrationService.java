package com.moniepoint.loans.cas.outbound.nos;

import com.moniepoint.loans.cas.outbound.NotificationRequest;
import com.moniepoint.loans.cas.outbound.NotificationService;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class NotificationOrchestrationService implements NotificationService {

    private final NOSClient nosClient;
    private final OutboundUtils outboundUtils;

    public NotificationOrchestrationService(
            NOSClient nosClient,OutboundUtils outboundUtils) {
        this.nosClient = nosClient;
        this.outboundUtils = outboundUtils;
    }

    @Override
    public boolean sendPushNotification(NotificationRequest request) {
        log.info("Sending push notification for user ({}), with survey id ({})", request.getUser().getUserID(), request.getSurveyID());
        try {
            NOSNotificationRequest nosRequest=  new NOSNotificationRequest(request);
            log.info("Sending request to NOS {}", nosRequest);
            String token = outboundUtils.getToken();
            String appDomain = "CONSUMER".equalsIgnoreCase(request.getAppDomain()) ? "PERSONAL" : request.getAppDomain();
            var response = nosClient.notify(nosRequest, String.format("Bearer %s", token), appDomain);
            log.info("Received push notification response from NOS {}", response);
            return response.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            log.error(
                    "Failed to send push notification for user ({}) with survey id ({}). Reason: {}",
                    request.getUser().getUserID(),
                    request.getSurveyID(),
                    e.getMessage(), e);
        }
        return false;
    }

}
