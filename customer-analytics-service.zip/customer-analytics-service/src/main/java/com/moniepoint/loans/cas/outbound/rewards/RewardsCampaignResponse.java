package com.moniepoint.loans.cas.outbound.rewards;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class RewardsCampaignResponse implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private Boolean requestSuccessful;

    private String responseMessage;

    private String responseCode;
}
