package com.moniepoint.loans.cas.outbound.rewards;

import com.moniepoint.loans.cas.integrations.FeignConfig;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateGoalDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalMarkerDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalDeactivationDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignByDomainDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserRewardEventDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeCloseCampaignDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "rewards-service", url = "${integrations.rewards.base-url}", configuration = FeignConfig.class)
public interface RewardsClient {


    @PostMapping("/assign-campaign")
    ResponseEntity<RewardsCampaignResponse> assignCampaign(@RequestBody BrazeUserCampaignDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/stop-campaign")
    ResponseEntity<RewardsCampaignResponse> stopCampaign(@RequestBody BrazeUserCampaignDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/campaigns")
    ResponseEntity<RewardsCampaignResponse> createCampaign(@RequestBody BrazeUserCreateCampaignDTO request, @RequestHeader("Authorization") String authorizationToken, @RequestHeader("x-reward-campaign-method-type") String campaignMethodType);

    @PostMapping("/goals")
    ResponseEntity<RewardsCampaignResponse> createGoal(@RequestBody BrazeUserCreateGoalDTO request, @RequestHeader("Authorization") String authorizationToken, @RequestHeader("x-reward-goal-method-type") String goalMethodType);

    @PostMapping("/mark-goal")
    ResponseEntity<RewardsCampaignResponse> markGoal(@RequestBody BrazeUserGoalMarkerDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/deactivate-goal")
    ResponseEntity<RewardsCampaignResponse> deactivateGoal(@RequestBody BrazeUserGoalDeactivationDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/assign-by-domain")
    ResponseEntity<RewardsCampaignResponse> assignCampaignByDomain(@RequestBody BrazeUserCampaignByDomainDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/event-reward")
    ResponseEntity<RewardsCampaignResponse> rewardEvent(@RequestBody BrazeUserRewardEventDTO request, @RequestHeader("Authorization") String authorizationToken);

    @PostMapping("/close-campaign")
    ResponseEntity<RewardsCampaignResponse> closeCampaign(@RequestBody BrazeCloseCampaignDTO request, @RequestHeader("Authorization") String authorizationToken);
}
