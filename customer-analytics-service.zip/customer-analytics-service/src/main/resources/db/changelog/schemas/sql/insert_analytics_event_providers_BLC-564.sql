INSERT INTO customer_analytics.analytics_event_providers
(provider_key, provider_name, created_by, last_modified_by)
VALUES
('CIO', 'CustomerIO', 'SYSTEM', 'SYSTEM'),
('MIX', 'Mixpanel', 'SYSTEM', 'SYSTEM');
