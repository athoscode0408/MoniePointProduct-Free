INSERT INTO customer_analytics.event_supported_user_attributes (event_id,user_attribute_id) VALUES
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'cards_request_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'has_cards_personal')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'cards_request_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'has_cards_business')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'card_transaction_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'card_rfscore_personal')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'card_transaction_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'card_rfscore_business')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'card_activation_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'has_cards_personal')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'card_activation_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'has_cards_business')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'card_activation_success'),(SELECT id FROM customer_analytics.supported_user_attributes WHERE user_attribute = 'cardExpiry'))
	 ;
