INSERT INTO customer_analytics.providers_event_types(event_type_id, provider_id)
SELECT events.id, providers.id FROM customer_analytics.supported_events events
CROSS JOIN customer_analytics.analytics_event_providers providers;