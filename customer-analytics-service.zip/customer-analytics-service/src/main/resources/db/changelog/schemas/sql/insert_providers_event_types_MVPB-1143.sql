INSERT INTO customer_analytics.providers_event_types (event_type_id,provider_id) VALUES
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'first_transaction_initiated'),(SELECT id FROM customer_analytics.analytics_event_providers WHERE provider_key = 'GA')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'first_transaction_failed'),(SELECT id FROM customer_analytics.analytics_event_providers WHERE provider_key = 'GA')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'first_succesful_transaction'),(SELECT id FROM customer_analytics.analytics_event_providers WHERE provider_key = 'GA')),
	 ((SELECT id FROM customer_analytics.supported_events WHERE event_type = 'first_succesful_VAS_transaction'),(SELECT id FROM customer_analytics.analytics_event_providers WHERE provider_key = 'GA'));
