INSERT INTO customer_analytics.supported_events
(event_type, created_by, last_modified_by)
VALUES
('first_transaction_initiated', 'SYSTEM', 'SYSTEM'),
('first_transaction_failed', 'SYSTEM', 'SYSTEM'),
('first_succesful_transaction', 'SYSTEM', 'SYSTEM'),
('first_succesful_VAS_transaction', 'SYSTEM', 'SYSTEM');
