package com.moniepoint.loans.cas;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAnalyticsServiceApplicationTests {


}
