package com.moniepoint.loans.cas.common.advice;

import com.moniepoint.loans.cas.common.advice.models.ErrorResponse;
import com.moniepoint.loans.cas.common.exception.NotFoundException;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.ApplicationConstants;
import com.moniepoint.loans.cas.module.analytics.controller.AnalyticsController;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import org.apache.coyote.BadRequestException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Collections;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GenericControllerAdviceTest {

    private GenericControllerAdvice underTest;

    @BeforeEach
    void setup() {
        underTest = new GenericControllerAdvice();
    }


    @Test
    void handleBadRequestException_success() {

        // given
        BadRequestException ex = new BadRequestException();

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleBadRequestException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(400);
        assertThat(actual.getBody().getMessage()).isNull();
    }

    @Test
    void handleHttpMessageNotReadableException_success() {

        // given
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException(ApplicationConstants.INVALID_DATE_ERROR_MESSAGE);

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleHttpMessageNotReadableException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(400);
        assertThat(actual.getBody().getMessage()).isEqualTo(ApplicationConstants.INVALID_DATE_ERROR_MESSAGE);
    }

    @Test
    void handleMethodArgumentNotValidException_success() throws NoSuchMethodException {
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError = new FieldError("eventRequest", "eventType", "Field is required");
        when(bindingResult.getAllErrors()).thenReturn(Collections.singletonList(fieldError));

        Method method = AnalyticsController.class.getMethod("pushEvent", AnalyticsEventV1RequestDTO.class);
        MethodParameter methodParameter = new MethodParameter(method, 0);

        MethodArgumentNotValidException exception = new MethodArgumentNotValidException(methodParameter, bindingResult);

        ResponseEntity<ErrorResponse> actual = underTest.handleMethodArgumentNotValidException(exception);

        // Assert response
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(400);
        assertThat(actual.getBody().getMessage().contains("Field is required"));
    }

    @Test
    void handleNotFoundException_success() {
        // given
        NotFoundException ex = new NotFoundException();

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleNotFoundException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(404);
        assertThat(actual.getBody().getMessage()).isNull();
    }

    @Test
    void handleServerException_success() {
        // given
        ServerException ex = new ServerException();

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleServerException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(500);
        assertThat(actual.getBody().getMessage()).isNull();

    }

    @Test
    void handleUnknownException_success() {
        IOException ex = new IOException("broker error");

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleUnknownException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(500);
        assertThat(actual.getBody().getMessage()).isEqualTo("broker error");
    }

    @Test
    void handleAuthorizationDeniedException_success() {
        // given
        AuthorizationDeniedException ex = new AuthorizationDeniedException("Authorization denied", new AuthorizationDecision(false));

        // when
        ResponseEntity<ErrorResponse> actual = underTest.handleAuthorizationDeniedException(ex);

        // then
        assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(actual.getBody().getStatusCode()).isEqualTo(403);
        assertThat(actual.getBody().getMessage()).isEqualTo("Authorization denied");
    }

}
