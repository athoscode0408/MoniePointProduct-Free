package com.moniepoint.loans.cas.common.audit;

import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.AuditorAware;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
class AuditorAwareImplTests {

    @Mock
    private AuthenticatedUser cosmosAuthenticatedUser;

    @InjectMocks
    private AuditorAwareImpl auditorAwareImpl;

    @BeforeEach
    public void setup() {
        auditorAwareImpl = new AuditorAwareImpl(cosmosAuthenticatedUser);
    }

    @Test
    void getCurrentAuditor_currentUserExists_success() {
        Mockito.when(cosmosAuthenticatedUser.getUsername())
                .thenReturn("fooBar");

        Optional<String> actual = auditorAwareImpl.getCurrentAuditor();

        assertThat(actual).hasValue("fooBar");
    }

    @Test
    void getCurrentAuditor_currentUserNotExists_returnsSystemUser() {
        Mockito.when(cosmosAuthenticatedUser.getUsername())
                .thenReturn(null);

        Optional<String> actual = auditorAwareImpl.getCurrentAuditor();

        assertThat(actual).hasValue("SYSTEM");
    }


    @Test
    void getCurrentAuditor_currentUserNull_returnsSystemUser() {
        AuditorAware<String> underTest = new AuditorAwareImpl(null);

        Optional<String> actual = underTest.getCurrentAuditor();

        assertThat(actual).hasValue("SYSTEM");
    }

    @Test
    void getCurrentAuditor_withFailure_returnsSystemUser() {
        Mockito.when(cosmosAuthenticatedUser.getUsername())
                .thenThrow(new UncheckedIOException(new IOException("io error")));

        Optional<String> actual = auditorAwareImpl.getCurrentAuditor();

        assertThat(actual).hasValue("SYSTEM");
    }

}
