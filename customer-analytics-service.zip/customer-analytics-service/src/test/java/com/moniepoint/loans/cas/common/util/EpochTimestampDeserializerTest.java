package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import java.time.format.DateTimeParseException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EpochTimestampDeserializerTest {

    private EpochTimestampDeserializer underTest;
    private ObjectMapper mapper;

    @BeforeEach
    void setup() {
        underTest = new EpochTimestampDeserializer();
        mapper = new ObjectMapper();
    }

    @Test
    void deserialize_epochMillisAsNumber_returnsCorrectTimestamp() throws IOException {
        long epochMillis = 1779366155138L;

        Timestamp result = deserialize(String.valueOf(epochMillis));

        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochMilli(epochMillis)));
    }

    @Test
    void deserialize_epochSecondsAsNumber_returnsCorrectTimestamp() throws IOException {
        long epochSeconds = 1747958400L;

        Timestamp result = deserialize(String.valueOf(epochSeconds));

        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochSecond(epochSeconds)));
    }

    @Test
    void deserialize_epochMillisAsQuotedString_returnsCorrectTimestamp() throws IOException {
        long epochMillis = 1779366155138L;

        Timestamp result = deserialize("\"" + epochMillis + "\"");

        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochMilli(epochMillis)));
    }

    @Test
    void deserialize_epochSecondsAsQuotedString_returnsCorrectTimestamp() throws IOException {
        long epochSeconds = 1747958400L;

        Timestamp result = deserialize("\"" + epochSeconds + "\"");

        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochSecond(epochSeconds)));
    }

    @Test
    void deserialize_quotedNumericStringWithWhitespace_trimsAndReturnsCorrectTimestamp() throws IOException {
        long epochMillis = 1779366155138L;

        Timestamp result = deserialize("\" " + epochMillis + " \"");

        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochMilli(epochMillis)));
    }

    @Test
    void deserialize_iso8601StringWithOffset_returnsCorrectTimestamp() throws IOException {
        String iso = "2026-05-22T10:30:00+01:00";

        Timestamp result = deserialize("\"" + iso + "\"");

        assertThat(result).isEqualTo(Timestamp.from(OffsetDateTime.parse(iso).toInstant()));
    }

    @Test
    void deserialize_iso8601StringUtc_returnsCorrectTimestamp() throws IOException {
        String iso = "2026-05-22T09:00:00Z";

        Timestamp result = deserialize("\"" + iso + "\"");

        assertThat(result).isEqualTo(Timestamp.from(OffsetDateTime.parse(iso).toInstant()));
    }

    @Test
    void deserialize_epochMillisAndEpochSeconds_produceDistinctTimestamps() throws IOException {
        long epochMillis = 1779366155138L;
        long epochSeconds = 1747958400L;

        Timestamp fromMillis = deserialize(String.valueOf(epochMillis));
        Timestamp fromSeconds = deserialize(String.valueOf(epochSeconds));

        assertThat(fromMillis).isNotEqualTo(fromSeconds);
        assertThat(fromMillis).isEqualTo(Timestamp.from(Instant.ofEpochMilli(epochMillis)));
        assertThat(fromSeconds).isEqualTo(Timestamp.from(Instant.ofEpochSecond(epochSeconds)));
    }

    @Test
    void deserialize_twelveDigitQuotedString_doesNotThrow() throws IOException {
        // 12-digit value is anomalous (not a standard seconds or millis epoch) but must not crash
        Timestamp result = deserialize("\"177971493372\"");

        assertThat(result).isNotNull();
        assertThat(result).isEqualTo(Timestamp.from(Instant.ofEpochSecond(177971493372L)));
    }

    @Test
    void deserialize_invalidString_throwsDateTimeParseException() {
        assertThatThrownBy(() -> deserialize("\"not-a-date\""))
                .isInstanceOf(DateTimeParseException.class);
    }

    @Test
    void deserialize_iso8601StringNoTZ_returnsCorrectTimestamp() throws IOException {
        String iso = "2026-05-29T10:35:02.714";

        Timestamp result = deserialize("\"" + iso + "\"");

        assertThat(result).isEqualTo(Timestamp.valueOf(LocalDateTime.parse(iso)));
    }

    private Timestamp deserialize(String json) throws IOException {
        JsonParser parser = mapper.getFactory().createParser(json);
        parser.nextToken();
        return underTest.deserialize(parser, null);
    }
}
