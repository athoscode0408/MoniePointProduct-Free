package com.moniepoint.loans.cas.common.util;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class HTTPUtilsTest {
    @Test
    void getIPAddressForValidIP() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-Forwarded-For")).thenReturn("192.168.1.100");
        assertEquals("192.168.1.100", HTTPUtils.getIPAddress(request));
    }

    @Test
    void getIPAddressForMultipleIPs() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-Forwarded-For")).thenReturn("192.168.1.100, 10.0.0.1, 172.16.0.1");
        assertEquals("192.168.1.100", HTTPUtils.getIPAddress(request));
    }

    @ParameterizedTest
    @ValueSource(strings = {"unknown", "", "some-invalid-format", " "})
    void getIPAddressForInvalidIPs(String ip) {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-Forwarded-For")).thenReturn(ip);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");
        assertEquals("127.0.0.1", HTTPUtils.getIPAddress(request));
    }

    @Test
    void getIPAddressForMissingHeader() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getHeader("X-Forwarded-For")).thenReturn(null);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");
        assertEquals("127.0.0.1", HTTPUtils.getIPAddress(request));
    }

    @Test
    void getDomainFromURL() {
        assertEquals("www.google.com", HTTPUtils.getDomainFromURL("https://www.google.com/search?q=search"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"unknown", "", "https.fake.domain"})
    void getDomainFromURLReturnsNullForInvalidURLs(String url) {
        assertNull(HTTPUtils.getDomainFromURL(url));
    }

    @Test
    void getDomainFromURLReturnsNullForNull() {
        assertNull(HTTPUtils.getDomainFromURL(null));
    }
}
