package com.moniepoint.loans.cas.common.util;

import org.junit.jupiter.api.Test;

import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.*;

class IsoWeekUtilTest {

    @Test
    void current_returnsIsoFormatString() {
        String result = IsoWeekUtil.current(ZoneId.of("UTC"));
        assertNotNull(result);
        assertTrue(result.matches("\\d{4}-W\\d{2}"), "Expected YYYY-Www format but got: " + result);
    }

    @Test
    void current_africaLagosZone_doesNotThrow() {
        assertDoesNotThrow(() -> IsoWeekUtil.current(ZoneId.of("Africa/Lagos")));
    }

    @Test
    void current_weekNumberIsTwoDigits() {
        String result = IsoWeekUtil.current(ZoneId.of("Africa/Lagos"));
        String weekPart = result.split("-W")[1];
        assertEquals(2, weekPart.length(), "Week number should be zero-padded to 2 digits");
    }
}
