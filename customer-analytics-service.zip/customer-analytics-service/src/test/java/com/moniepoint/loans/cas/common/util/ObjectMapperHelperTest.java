package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.assertj.core.api.AssertionsForClassTypes;
import org.json.JSONException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ObjectMapperHelperTest {

    private static ObjectMapper mapper;

    private ObjectMapperHelper underTest;

    @Mock
    private ObjectMapper mockedMapper;


    @BeforeAll
    static void globalSetup() {
        mapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @BeforeEach
    void setup() {
        underTest = new ObjectMapperHelper(mapper, new Telemetry(new SimpleMeterRegistry()));
    }

    @Test
    void serializeToString_success() throws Exception {
        AnalyticsEventRequestDTO analyticsEventRequestDTO = AnalyticsEventRequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(mockedMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        String expectedSerializedEvt = mapper.writeValueAsString(analyticsEventRequestDTO);

        String serializedEvt = underTest.serializeToString(analyticsEventRequestDTO);


        assertEquals(expectedSerializedEvt, serializedEvt);
    }

    @Test
    void serializeToString_fails() throws Exception {
        AnalyticsEventRequestDTO analyticsEventRequestDTO = AnalyticsEventRequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(mockedMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(mockedMapper.writeValueAsString(any(Object.class)))
                .thenAnswer(ans -> {
                    throw new IOException("fail.");
                });


        underTest = new ObjectMapperHelper(mockedMapper, new Telemetry(new SimpleMeterRegistry()));

        ServerException ex = assertThrows(ServerException.class, () -> underTest.serializeToString(analyticsEventRequestDTO));

        assertThat(ex).hasMessage("serializeToString error occurred");
        assertThat(ex).hasCauseInstanceOf(IOException.class);
    }

    @Test
    void serializeToString_withNull_fails() throws JSONException {
        String serializedEvt = underTest.serializeToString(null);

        JSONAssert.assertEquals("{}",
                serializedEvt, JSONCompareMode.STRICT
        );
    }

    @Test
    void deserializeStringToObject_success() {

        String content = "{\n" +
                "    \"eventType\": \"prequalification\",\n" +
                "    \"id\": \"123\",\n" +
                "    \"timestamp\": 1725887178,\n" +
                "    \"source\": \"LMS\",\n" +
                "    \"platform\": \"MOBILE\",\n" +
                "    \"environment\": \"DEVELOPMENT\",\n" +
                "    \"data\": {\n" +
                "        \"email\": \"test@test.co\"\n" +
                "    }\n" +
                "}";

        AnalyticsEventRequestDTO result = underTest.deserializeStringToObject(content, new TypeReference<AnalyticsEventRequestDTO>() {
        });

        AssertionsForClassTypes.assertThat(result).isNotNull();
        AssertionsForClassTypes.assertThat(result).isNotNull();
        AssertionsForClassTypes.assertThat(result.getEventType()).isEqualTo("prequalification");

    }

    @Test
    void deserializeStringToObject_fails() throws JsonProcessingException {

        String content = "{\n" +
                "    \"eventType\": \"prequalification\",\n" +
                "    \"id\": \"123\",\n" +
                "    \"timestamp\": 1725887178,\n" +
                "    \"platform\": \"MOBILE\",\n" +
                "    \"environment\": \"DEVELOPMENT\",\n" +
                "    \"data\": {\n" +
                "        \"email\": \"test@test.co\"\n" +
                "    }\n" +
                "}";

        when(mockedMapper.readValue(any(String.class), any(TypeReference.class)))
                .thenAnswer(ans -> {
                    throw new IOException("fail");
                });


        underTest = new ObjectMapperHelper(mockedMapper, new Telemetry(new SimpleMeterRegistry()));

        ServerException ex = assertThrows(ServerException.class, () -> underTest.deserializeStringToObject(content,
                new TypeReference<AnalyticsEventRequestDTO>() {
                }));

        assertThat(ex).hasMessage("deserializeStringToObject error occurred");
        assertThat(ex).hasCauseInstanceOf(IOException.class);

    }


    @Test
    void convertObjectToType_success() {

        AnalyticsEventRequestDTO analyticsEventRequestDTO = AnalyticsEventRequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(mockedMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        AnalyticsEventRequestDTO result = underTest.convertObjectToType(analyticsEventRequestDTO,
                new TypeReference<AnalyticsEventRequestDTO>() {
                });

        assertThat(result).isNotNull();
        assertThat(result.getEventType()).isEqualTo("prequalification");

    }
}
