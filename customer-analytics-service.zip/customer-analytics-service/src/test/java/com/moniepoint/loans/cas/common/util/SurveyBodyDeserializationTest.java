package com.moniepoint.loans.cas.common.util;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

class SurveyBodyDeserializationTest {

    private static ObjectMapperHelper objectMapperHelper;
    private static String surveyJson;

    @BeforeAll
    static void setup() throws IOException {
        objectMapperHelper = new ObjectMapperHelper(ObjectMapperConfiguration.constructObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
        surveyJson = IOUtils.toString(
                Objects.requireNonNull(
                        SurveyBodyDeserializationTest.class.getResourceAsStream("/survey_4_fixed.json")
                ),
                StandardCharsets.UTF_8
        );
    }

    @Test
    void deserialize_surveyBodyIsNotNull() {
        SurveyBody result = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});

        assertThat(result).isNotNull();
    }

    @Test
    void deserialize_directFields_areMappedCorrectly() {
        SurveyBody result = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});

        assertThat(result.getResponseWindowUniqueSurveyMins()).isEqualTo(129600L);
        assertThat(result.getMaxCountUniqueSurveyInResponseWindow()).isEqualTo(1);
        assertThat(result.getDisplayDelayPeriodInSecs()).isEqualTo(1296000L);
        assertThat(result.getBannerId()).isEqualTo("2eea5549-91b0-4f92-9098-448404e4fe3b");
    }

    @Test
    void deserialize_booleanFlags_defaultToFalseWhenAbsent() {
        SurveyBody result = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});

        assertThat(result.isRandomizeSurveyAssignment()).isFalse();
        assertThat(result.isGenerateUniqueSurveyPerBRM()).isFalse();
        assertThat(result.isAssignBanner()).isFalse();
        assertThat(result.isEnableAlertingAfterDismissal()).isFalse();
    }

    @Test
    void deserialize_unknownFields_capturedInCustomAttributes() {
        SurveyBody result = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});

        assertThat(result.getCustomAttributes()).isNotNull();
        assertThat(result.getCustomAttributes()).containsKey("id");
        assertThat(result.getCustomAttributes().get("id")).isEqualTo("nps_personal");
        assertThat(result.getCustomAttributes()).containsKey("schemaVersion");
        assertThat(result.getCustomAttributes().get("schemaVersion")).isEqualTo("0.1.0");
        assertThat(result.getCustomAttributes()).containsKey("completionMessage");
        assertThat(result.getCustomAttributes().get("completionMessage")).isEqualTo("Thanks for the feedback!");
        assertThat(result.getCustomAttributes()).containsKey("pages");
    }

    @Test
    void deserialize_isIdempotent() {
        SurveyBody first = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});
        SurveyBody second = objectMapperHelper.deserializeStringToObject(surveyJson, new TypeReference<>() {});

        assertThat(first.getResponseWindowUniqueSurveyMins()).isEqualTo(second.getResponseWindowUniqueSurveyMins());
        assertThat(first.getBannerId()).isEqualTo(second.getBannerId());
        assertThat(first.getCustomAttributes()).isEqualTo(second.getCustomAttributes());
    }
}