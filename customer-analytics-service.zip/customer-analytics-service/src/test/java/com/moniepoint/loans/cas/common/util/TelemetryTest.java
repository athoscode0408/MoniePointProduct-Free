package com.moniepoint.loans.cas.common.util;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class TelemetryTest {

    private final SimpleMeterRegistry meterRegistry = new SimpleMeterRegistry();
    private final Telemetry telemetry = new Telemetry(meterRegistry);

    @Test
    void recordMetric_recordsSampleIntoDistributionSummary() {
        telemetry.recordMetric("Custom/Test/Metric", 42);
        telemetry.recordMetric("Custom/Test/Metric", 8);

        var summary = meterRegistry.find("Custom/Test/Metric").summary();

        assertThat(summary).isNotNull();
        assertThat(summary.count()).isEqualTo(2);
        assertThat(summary.totalAmount()).isEqualTo(50.0);
    }

    @Test
    void runInSpan_returnsSupplierResult_andCompletesWithoutError() {
        String result = Telemetry.runInSpan("Test-Span", () -> "done");

        assertThat(result).isEqualTo("done");
    }

    @Test
    void runInSpan_runnableOverload_executesWork() {
        var executed = new boolean[]{false};
        Runnable work = () -> executed[0] = true;

        Telemetry.runInSpan("Test-Span", work);

        assertThat(executed[0]).isTrue();
    }

    @Test
    void runInSpan_propagatesExceptionFromWork() {
        Runnable work = () -> {
            throw new RuntimeException("boom");
        };

        assertThat(org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class, () ->
                Telemetry.runInSpan("Test-Span", work))).hasMessage("boom");
    }
}
