package com.moniepoint.loans.cas.common.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class TestDtoGenerator {

    public static AnalyticsEventV3RequestDTO getAnalyticsEventV3RequestDTO(){
        return AnalyticsEventV3RequestDTO.builder()
                .dtoVersion("v3")
                .id(UUID.randomUUID().toString())
                .eventType("prequalification")
                .appEnv("dev")
                .ip("127.0.0.1")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .applicationID("MonieWorld")
                .version("1.1.5")
                .data(AnalyticsEventV3DataDTO.builder()
                        .eventName("payment_success")
                        .properties(Map.of("amount", "30000"))
                        .device(AnalyticsEventV3DeviceInfoDTO.builder()
                                .id("random-xyz123")
                                .agent("chrome")
                                .agentVersion("135.0.7049.115")
                                .type("web")
                                .os("macOS")
                                .additionalInfo(Map.of("arch", "arm64"))
                                .build())
                        .build())
                .userAttributes(UserAttributes.builder()
                        .name("My Test User")
                        .build())
                .customerIdentifier("testIdentifier")
                .build();
    }

    public static AnalyticsEventV2RequestDTO getAnalyticsEventV2RequestDTO(){
        ObjectMapper objectMapper = new ObjectMapper();
        return AnalyticsEventV2RequestDTO.builder()
                .dtoVersion("v2")
                .id(UUID.randomUUID().toString())
                .eventType("prequalification")
                .appEnv("dev")
                .platform("android")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .customerIdentifier("testIdentifier")
                .build();

    }

    public static AnalyticsEventV1RequestDTO getAnalyticsEventV1RequestDTO() {
        return AnalyticsEventV1RequestDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .build();
    }

    public static Set<AnalyticsEventProvider> getAllAnalyticsProviders(){
        return Set.of(
                AnalyticsEventProvider.builder().providerKey(EventProvider.MIX).providerName("Mixpanel").build(),
                AnalyticsEventProvider.builder().providerKey(EventProvider.CIO).providerName("CustomerIO").build(),
                AnalyticsEventProvider.builder().providerKey(EventProvider.GA).providerName("GoogleAnalytics").build()
        );
    }
}
