package com.moniepoint.loans.cas.integrations.braze;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeEvent;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeIdentifyRequest;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackRequest;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BrazeClientTest {

    @Mock
    private ObjectMapperHelper objectMapperHelper;
    @Spy
    private EventRetryService eventRetryService;

    @Test
    void fallbackFactoryDoesNotRetryEmptyEvents() {
        var client = new BrazeClientFallbackFactory(eventRetryService, objectMapperHelper).create(new Throwable("some unexpected error"));
        var response = client.trackEvent(
                new BrazeTrackRequest(new ArrayList<>(), new ArrayList<>(), new ArrayList<>()),
                "Bearer my-token"
        );

        assertTrue(response.getStatusCode().is4xxClientError());
        verify(eventRetryService, times(0)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void fallbackFactoryReturnsErrorMessage() {
        var client = new BrazeClientFallbackFactory(eventRetryService, objectMapperHelper).create(new Throwable("some unexpected error"));
        ObjectNode eventProps = JsonNodeFactory.instance.objectNode();
        eventProps.set("name", eventProps);

        when(objectMapperHelper.serializeToString(any(BrazeTrackRequest.class))).thenReturn("{}");

        var response = client.trackEvent(
                new BrazeTrackRequest(
                        new ArrayList<>(),
                        List.of(BrazeEvent.builder().properties(eventProps).build()),
                        new ArrayList<>()),
                "Bearer my-token"
        );

        assertNotNull(response);
        assertTrue(response.getStatusCode().is5xxServerError());
        assertNotNull(response.getBody());
        assertEquals("some unexpected error", response.getBody().getMessage());

        verify(eventRetryService, times(1)).processFailedEventData(argThat(r -> {
            assertEquals("some unexpected error", r.getFailureReason());
            assertNotNull(r.getEventData());
            return true;
        }));
    }

    @Test
    void fallbackFactoryDoesNotRetryForEmptyIdentifyRequests() {
        var client = new BrazeClientFallbackFactory(eventRetryService, objectMapperHelper).create(new Throwable("some unexpected error"));

        var response = client.identify(
                new BrazeIdentifyRequest(List.of()),
                "Bearer my-token"
        );

        assertNotNull(response);
        assertTrue(response.getStatusCode().is4xxClientError());

        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void fallbackFactoryDoesNotRetryForIdentifyRequests() {
        var client = new BrazeClientFallbackFactory(eventRetryService, objectMapperHelper).create(new Throwable("some unexpected error"));

        var response = client.identify(
                new BrazeIdentifyRequest(List.of(VerifiedAnalyticsEventDTO.builder().userIdentifiers(
                        new UserEventIdentifier("my-session-ID", "my-user-ID", "email@email.com", "2454754454", "J. Doe")
                ).build())),
                "Bearer my-token"
        );

        assertNotNull(response);
        assertTrue(response.getStatusCode().is5xxServerError());
        assertNotNull(response.getBody());
        assertEquals("some unexpected error", response.getBody().getMessage());

        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }
}
