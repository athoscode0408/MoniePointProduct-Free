package com.moniepoint.loans.cas.integrations.customerio.service.impl;

import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerProfileUpdateRequest;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOClient;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import feign.FeignException;
import feign.Request;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerIOClientFallbackFactoryTests {

    private static final String AUTHORIZATION_TOKEN = "Basic c2l0ZS1pZDphcGkta2V5";
    private static final String FAILURE_REASON = "Feign Client Error";

    @InjectMocks
    private CustomerIOClientFallbackFactory customerIOClientFallbackFactory;

    @Mock
    private CustomerIOIntegrationService customerIOIntegrationService;

    private Throwable throwable;

    @BeforeEach
    void setUp() {
        throwable = new FeignException.InternalServerError(FAILURE_REASON, Request.create(Request.HttpMethod.POST, "http://test.co",
                Map.of(),
                null,
                null, null), null, null);
    }

    @Test
    void createCustomerEventFallback_withFeignException_callsFailureHandler() {
        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .id("123")
                .name("prequalification")
                .type(CustomerIOEventType.EVENT)
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .build();
        doNothing().when(customerIOIntegrationService).failureHandler(FAILURE_REASON, customerEventRequest);

        CustomerIOClient customerIOClient = customerIOClientFallbackFactory.create(throwable);

        ResponseEntity<Void> responseEntity = customerIOClient.sendCustomerEvent("test_username", customerEventRequest, AUTHORIZATION_TOKEN);

        verify(customerIOIntegrationService, times(1)).failureHandler(FAILURE_REASON, customerEventRequest);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    void createAnonymousEventFallback_withFeignException_callsFailureHandler() {
        AnonymousEventRequest anonymousEventRequest = AnonymousEventRequest.builder()
                .id("123")
                .name("prequalification")
                .type(CustomerIOEventType.EVENT)
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .build();
        doNothing().when(customerIOIntegrationService).failureHandler(FAILURE_REASON, anonymousEventRequest);

        CustomerIOClient customerIOClient = customerIOClientFallbackFactory.create(throwable);

        ResponseEntity<Void> responseEntity = customerIOClient.sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN);

        verify(customerIOIntegrationService, times(1)).failureHandler(FAILURE_REASON, anonymousEventRequest);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    void updateCustomerProfile_withFeignException_callsFailureHandler() {
        CustomerProfileUpdateRequest customerProfileUpdateRequest = CustomerProfileUpdateRequest.builder()
                .build();

        CustomerIOClient customerIOClient = customerIOClientFallbackFactory.create(throwable);

        ResponseEntity<Void> responseEntity = customerIOClient.updateCustomerProfile("test_username", customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN);
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

}
