package com.moniepoint.loans.cas.integrations.customerio.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerIOResponse;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerProfileUpdateRequest;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOClient;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerIOIntegrationServiceImplTests {

    @Mock
    private CustomerIOConfig customerIOConfig;

    @Mock
    private CustomerIOClient customerIOClient;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @InjectMocks
    private CustomerIOIntegrationServiceImpl customerIOIntegrationServiceImpl;

    private ObjectMapper objectMapper;

    private static final String AUTHORIZATION_TOKEN = "Basic c2l0ZS1pZDphcGkta2V5";
    private static final String IDENTIFIER = "test_username";
    private static final String FAILURE_REASON = "Feign Client Error";

    private static final ResponseEntity<Void> SUCCESS_RESPONSE_ENTITY = ResponseEntity.status(HttpStatus.OK).build();

    private static final CustomerIOResponse SUCCESS_RESPONSE = CustomerIOResponse.builder().success(true).build();
    private static final CustomerIOResponse FAILURE_RESPONSE = CustomerIOResponse.builder().success(false).build();


    @BeforeEach
    public void setUp() {
        doReturn("api-key").when(customerIOConfig).getApiKey();
        doReturn("site-id").when(customerIOConfig).getSiteId();
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @Test
    void sendCustomerEventToCustomerIO_success() {
        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .id("123")
                .name("prequalification")
                .type(CustomerIOEventType.EVENT)
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(customerIOClient.sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN)).thenReturn(SUCCESS_RESPONSE_ENTITY);

        CustomerIOResponse response = customerIOIntegrationServiceImpl.sendCustomerEventToCustomerIO(IDENTIFIER, customerEventRequest);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(customerIOClient, times(1)).sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN);
    }

    @Test
    void sendAnonymousEventToCustomerIO_success() {
        AnonymousEventRequest anonymousEventRequest = AnonymousEventRequest.builder()
                .id("123")
                .anonymousId("test-id")
                .name("prequalification")
                .type(CustomerIOEventType.EVENT)
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(customerIOClient.sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN)).thenReturn(SUCCESS_RESPONSE_ENTITY);

        CustomerIOResponse response = customerIOIntegrationServiceImpl.sendAnonymousEventToCustomerIO(anonymousEventRequest);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(customerIOClient, times(1)).sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN);
    }

    @Test
    void sendCustomerEventToCustomerIO_badRequest_failsToPushEvent() {
        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .id("123")
                .type(CustomerIOEventType.EVENT)
                .build();

        CustomerIOIntegrationServiceImpl spyService = spy(customerIOIntegrationServiceImpl);

        when(customerIOClient.sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN)).thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());

        CustomerIOResponse response = spyService.sendCustomerEventToCustomerIO(IDENTIFIER, customerEventRequest);

        assertEquals(FAILURE_RESPONSE, response);
        verify(customerIOClient, times(1)).sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN);
        verify(spyService, never()).failureHandler(any(), any());
    }

    @Test
    void sendCustomerEventToCustomerIO_withException_failsToPushEvent() {
        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .id("123")
                .type(CustomerIOEventType.EVENT)
                .build();

        CustomerIOIntegrationServiceImpl spyService = spy(customerIOIntegrationServiceImpl);

        when(customerIOClient.sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN)).thenThrow(new RuntimeException(FAILURE_REASON));

        CustomerIOResponse response = spyService.sendCustomerEventToCustomerIO(IDENTIFIER, customerEventRequest);

        assertEquals(FAILURE_RESPONSE, response);
        verify(customerIOClient, times(1)).sendCustomerEvent(IDENTIFIER, customerEventRequest, AUTHORIZATION_TOKEN);
        verify(spyService, times(1)).failureHandler(FAILURE_REASON, customerEventRequest);
    }

    @Test
    void sendAnonymousEventToCustomerIO_badRequest_failsToPushEvent() {
        AnonymousEventRequest anonymousEventRequest = AnonymousEventRequest.builder()
                .id("123")
                .type(CustomerIOEventType.EVENT)
                .build();

        CustomerIOIntegrationServiceImpl spyService = spy(customerIOIntegrationServiceImpl);

        when(customerIOClient.sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN)).thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());

        CustomerIOResponse response = spyService.sendAnonymousEventToCustomerIO(anonymousEventRequest);

        assertEquals(FAILURE_RESPONSE, response);
        verify(customerIOClient, times(1)).sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN);
        verify(spyService, never()).failureHandler(any(), any());
    }

    @Test
    void sendAnonymousEventToCustomerIO_withException_failsToPushEvent() {
        AnonymousEventRequest anonymousEventRequest = AnonymousEventRequest.builder()
                .id("123")
                .type(CustomerIOEventType.EVENT)
                .build();

        CustomerIOIntegrationServiceImpl spyService = spy(customerIOIntegrationServiceImpl);

        when(customerIOClient.sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN)).thenThrow(new RuntimeException(FAILURE_REASON));

        CustomerIOResponse response = spyService.sendAnonymousEventToCustomerIO(anonymousEventRequest);

        assertEquals(FAILURE_RESPONSE, response);
        verify(customerIOClient, times(1)).sendAnonymousEvent(anonymousEventRequest, AUTHORIZATION_TOKEN);
        verify(spyService, times(1)).failureHandler(FAILURE_REASON, anonymousEventRequest);
    }

    @Test
    void updateCustomerProfile_success() {
        CustomerProfileUpdateRequest customerProfileUpdateRequest = CustomerProfileUpdateRequest.builder()
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(customerIOClient.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN)).thenReturn(SUCCESS_RESPONSE_ENTITY);

        CustomerIOResponse response = customerIOIntegrationServiceImpl.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(customerIOClient, times(1)).updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN);
    }

    @Test
    void updateCustomerProfile_badRequest_failsToUpdateCustomerProfile() {
        CustomerProfileUpdateRequest customerProfileUpdateRequest = CustomerProfileUpdateRequest.builder()
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(customerIOClient.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN)).thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).build());

        ServerException exception = assertThrows(ServerException.class,
                () -> customerIOIntegrationServiceImpl.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getResponseCode());
        assertTrue(exception.getMessage().contains("Failed to update customer profile for: test_username"));
        verify(customerIOClient, times(1)).updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN);
    }

    @Test
    void updateCustomerProfile_throwsException_failsToUpdateCustomerProfile() {
        CustomerProfileUpdateRequest customerProfileUpdateRequest = CustomerProfileUpdateRequest.builder()
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        when(customerIOClient.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN)).thenThrow(new RuntimeException(FAILURE_REASON));

        ServerException exception = assertThrows(ServerException.class,
                () -> customerIOIntegrationServiceImpl.updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getResponseCode());
        assertTrue(exception.getMessage().contains("Failed to update customer profile for: test_username"));
        verify(customerIOClient, times(1)).updateCustomerProfile(IDENTIFIER, customerProfileUpdateRequest.getData(), AUTHORIZATION_TOKEN);
    }
}
