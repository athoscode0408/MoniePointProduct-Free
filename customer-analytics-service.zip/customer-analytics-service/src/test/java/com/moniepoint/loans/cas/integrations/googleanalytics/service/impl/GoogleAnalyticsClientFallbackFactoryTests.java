package com.moniepoint.loans.cas.integrations.googleanalytics.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsClient;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsIntegrationService;
import feign.FeignException;
import feign.Request;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class GoogleAnalyticsClientFallbackFactoryTests {

    private static final String FAILURE_REASON = "Feign Client Error";

    @Mock
    private GoogleAnalyticsIntegrationService googleAnalyticsIntegrationService;

    @InjectMocks
    private GoogleAnalyticsClientFallbackFactory googleAnalyticsClientFallbackFactory;

    private Throwable throwable;

    @BeforeEach
    void setUp() {
        throwable = new FeignException.InternalServerError(FAILURE_REASON, Request.create(Request.HttpMethod.POST, "http://test.co",
                Map.of(),
                null,
                null, null), null, null);
    }

    @Test
    void createValidateEventFallback_withFeignException_callsFailureHandler() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(ObjectMapperConfiguration.constructObjectMapper().readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000}}]"))
                .userId("test")
                .build();
        doNothing().when(googleAnalyticsIntegrationService).failureHandler(FAILURE_REASON, request);

        GoogleAnalyticsClient googleAnalyticsClient = googleAnalyticsClientFallbackFactory.create(throwable);

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", "api-secret");
        queryParams.put("firebase_app_id", "firebase-app-id");

        ResponseEntity<JsonNode> responseEntity = googleAnalyticsClient.validateEvent(queryParams, request);

        verify(googleAnalyticsIntegrationService, times(1)).failureHandler(FAILURE_REASON, request);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    void createSendEventFallback_withFeignException_callsFailureHandler() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(ObjectMapperConfiguration.constructObjectMapper().readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000}}]"))
                .userId("test")
                .build();
        doNothing().when(googleAnalyticsIntegrationService).failureHandler(FAILURE_REASON, request);

        GoogleAnalyticsClient googleAnalyticsClient = googleAnalyticsClientFallbackFactory.create(throwable);

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", "api-secret");
        queryParams.put("firebase_app_id", "firebase-app-id");

        ResponseEntity<Void> responseEntity = googleAnalyticsClient.sendEvent(queryParams, request);

        verify(googleAnalyticsIntegrationService, times(1)).failureHandler(FAILURE_REASON, request);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

}
