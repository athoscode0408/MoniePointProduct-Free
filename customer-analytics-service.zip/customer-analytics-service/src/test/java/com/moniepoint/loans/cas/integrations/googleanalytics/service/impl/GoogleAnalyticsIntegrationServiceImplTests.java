package com.moniepoint.loans.cas.integrations.googleanalytics.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.googleanalytics.config.GoogleAnalyticsConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsResponse;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsClient;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GoogleAnalyticsIntegrationServiceImplTests {

    private static final GoogleAnalyticsResponse SUCCESS_RESPONSE = GoogleAnalyticsResponse.builder().success(true).build();
    private static final GoogleAnalyticsResponse FAILURE_RESPONSE = GoogleAnalyticsResponse.builder().success(false).build();

    @Mock
    private GoogleAnalyticsConfig googleAnalyticsConfig;

    @Mock
    private GoogleAnalyticsClient googleAnalyticsClient;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @InjectMocks
    private GoogleAnalyticsIntegrationServiceImpl googleAnalyticsIntegrationServiceImpl;

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @Test
    void sendEventToGoogleAnalytics_withWebDeviceTypeAndPersonalDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .clientId("123456.7654321")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"WEB\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "web-personal-api-secret";
        String webMeasurementId = "web-personal-measurement-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("measurement_id", webMeasurementId);

        when(googleAnalyticsConfig.getWebPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getWebPersonalMeasurementId()).thenReturn(webMeasurementId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withWebDeviceTypeAndBusinessDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .clientId("123456.7654321")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"BUSINESS\",\"device_type\":\"WEB\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "web-business-api-secret";
        String webMeasurementId = "web-business-measurement-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("measurement_id", webMeasurementId);

        when(googleAnalyticsConfig.getWebBusinessApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getWebBusinessMeasurementId()).thenReturn(webMeasurementId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withAndroidDeviceTypeAndPersonalDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-android-api-secret";
        String firebaseAppId = "personal-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withAndroidDeviceTypeAndBusinessDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"BUSINESS\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "business-android-api-secret";
        String firebaseAppId = "business-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidBusinessApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidBusinessFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withIosDeviceTypeAndPersonalDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"IOS\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-ios-api-secret";
        String firebaseAppId = "personal-ios-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getIosPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getIosPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withIosDeviceTypeAndBusinessDomain_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"BUSINESS\",\"device_type\":\"IOS\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "business-ios-api-secret";
        String firebaseAppId = "business-ios-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getIosBusinessApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getIosBusinessFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_validationFailure_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-android-api-secret";
        String firebaseAppId = "personal-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[{\"fieldPath\":\"app_instance_id\",\"description\":\"Measurement requires an app_instance_id.\",\"validationCode\":\"VALUE_REQUIRED\"}]}")));

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(0)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_validateEventReturnsUnknownResponseCode_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-android-api-secret";
        String firebaseAppId = "personal-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.NO_CONTENT).body(objectMapper.readTree("{\"validationMessages\":[]}")));

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(0)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_sendEventReturnsUnknownResponseCode_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-android-api-secret";
        String firebaseAppId = "personal-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenReturn(ResponseEntity.ok(objectMapper.readTree("{\"validationMessages\":[]}")));
        when(googleAnalyticsClient.sendEvent(queryParams, request)).thenReturn(ResponseEntity.status(HttpStatus.OK).build());

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(1)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_anyException_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"ANDROID\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        String apiSecret = "personal-android-api-secret";
        String firebaseAppId = "personal-android-firebase-app-id";

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("api_secret", apiSecret);
        queryParams.put("firebase_app_id", firebaseAppId);

        when(googleAnalyticsConfig.getAndroidPersonalApiSecret()).thenReturn(apiSecret);
        when(googleAnalyticsConfig.getAndroidPersonalFirebaseAppId()).thenReturn(firebaseAppId);
        when(googleAnalyticsClient.validateEvent(queryParams, request)).thenThrow(new RuntimeException("Something went wrong!"));

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(1)).validateEvent(queryParams, request);
        verify(googleAnalyticsClient, times(0)).sendEvent(queryParams, request);
    }

    @Test
    void sendEventToGoogleAnalytics_withUnknownDomain_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"UNKNOWN\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(0)).validateEvent(anyMap(), any(GoogleAnalyticsEventRequest.class));
    }

    @Test
    void sendEventToGoogleAnalytics_withValidDomainButInvalidDeviceType_failsToPushEvent() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .events(objectMapper.readTree("[{\"name\":\"first_time_deposit\",\"params\":{\"amount\":30000,\"app_domain\":\"PERSONAL\",\"device_type\":\"UNKNOWN\",\"payment_type\":\"VAS\",\"eventId\":\"b00a49dd-ec88-406f-b0cc-ef8360cbb7a9\"}}]"))
                .userId("test")
                .build();

        GoogleAnalyticsResponse response = googleAnalyticsIntegrationServiceImpl.sendEventToGoogleAnalytics(request);

        assertEquals(FAILURE_RESPONSE, response);
        verify(googleAnalyticsClient, times(0)).validateEvent(anyMap(), any(GoogleAnalyticsEventRequest.class));
    }

}
