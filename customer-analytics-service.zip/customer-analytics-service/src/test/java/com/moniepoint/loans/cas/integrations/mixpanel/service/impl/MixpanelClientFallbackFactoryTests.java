package com.moniepoint.loans.cas.integrations.mixpanel.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventProperties;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelIntegrationService;
import feign.FeignException;
import feign.Request;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith({MockitoExtension.class, OutputCaptureExtension.class})
class MixpanelClientFallbackFactoryTests {

    private static final String AUTHORIZATION_TOKEN = "Basic c2l0ZS1pZDphcGkta2V5";
    private static final String ERROR_MESSAGE = "Feign Client Error";

    private static ObjectMapper objectMapper;

    @InjectMocks
    private MixpanelClientFallbackFactory mixpanelClientFallbackFactory;

    @Mock
    private MixpanelIntegrationService mixpanelIntegrationService;

    private Throwable throwable;

    @BeforeAll
    static void globalSetup() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @BeforeEach
    void setUp() {
        throwable = new FeignException.InternalServerError(ERROR_MESSAGE, Request.create(Request.HttpMethod.POST, "http://test.co",
                Map.of(),
                null,
                null, null), null, null);
    }

    @Test
    void sendImportEventRequest_withFeignException_callsFailureHandler(CapturedOutput output) throws JsonProcessingException {
        String json = """
                {
                    "$insert_id": "123"
                }
                """;
        MixpanelEventRequest mixpanelEventRequest = MixpanelEventRequest.builder()
                .event("Test event")
                .properties(objectMapper.readValue(json, MixpanelEventProperties.class))
                .build();
        MixpanelEventResponse response = MixpanelEventResponse.builder()
                .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .status(ERROR_MESSAGE)
                .numRecordsImported(0)
                .build();

        doNothing().when(mixpanelIntegrationService).failureHandler(ERROR_MESSAGE, mixpanelEventRequest);

        MixpanelClient mixpanelClient = mixpanelClientFallbackFactory.create(throwable);

        ResponseEntity<MixpanelEventResponse> responseEntity = mixpanelClient.sendImportEventRequest(List.of(mixpanelEventRequest), AUTHORIZATION_TOKEN);

        verify(mixpanelIntegrationService, times(1)).failureHandler(ERROR_MESSAGE, mixpanelEventRequest);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals(response, responseEntity.getBody());
        assertThat(output).contains("Mixpanel event 123 can't be pushed due to : Feign Client Error");
    }

    @Test
    void sendImportEventRequest_withFeignExceptionAndWithoutId_callsFailureHandler(CapturedOutput output) throws JsonProcessingException {
        MixpanelEventRequest mixpanelEventRequest = MixpanelEventRequest.builder()
                .event("Test event")
                .properties(objectMapper.readValue("{}", MixpanelEventProperties.class))
                .build();
        MixpanelEventResponse response = MixpanelEventResponse.builder()
                .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .status(ERROR_MESSAGE)
                .numRecordsImported(0)
                .build();

        doNothing().when(mixpanelIntegrationService).failureHandler(ERROR_MESSAGE, mixpanelEventRequest);

        MixpanelClient mixpanelClient = mixpanelClientFallbackFactory.create(throwable);

        ResponseEntity<MixpanelEventResponse> responseEntity = mixpanelClient.sendImportEventRequest(List.of(mixpanelEventRequest), AUTHORIZATION_TOKEN);

        verify(mixpanelIntegrationService, times(1)).failureHandler(ERROR_MESSAGE, mixpanelEventRequest);

        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals(response, responseEntity.getBody());
        assertThat(output).contains("Mixpanel event null can't be pushed due to : Feign Client Error");
    }

}
