package com.moniepoint.loans.cas.integrations.mixpanel.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventProperties;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelQueryAPIClient;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.repository.MixpanelApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MixpanelIntegrationServiceImplTests {

    private static final String TOKEN = "Basic dGVzdDp0ZXN0";

    private static final MixpanelResponse SUCCESS_RESPONSE = MixpanelResponse.builder().success(true).build();
    private static final MixpanelResponse FAILURE_RESPONSE = MixpanelResponse.builder().success(false).build();

    @Mock
    private MixpanelClient mixpanelClient;

    @Mock
    private MixpanelQueryAPIClient mixpanelQueryAPIClient;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @Mock
    private RateLimiterService rateLimiterService;

    @Mock
    private CacheService cacheService;

    @Mock
    private MixpanelApiKeyStorage mixpanelApiKeyStorage;

    private MixpanelIntegrationServiceImpl mixpanelIntegrationService;

    @BeforeEach
    void setUp() {
        mixpanelIntegrationService = new MixpanelIntegrationServiceImpl(
                "project-id",
                "api-secret",
                mixpanelClient,
                mixpanelQueryAPIClient,
                objectMapperHelper,
                eventRetryService,
                rateLimiterService,
                cacheService,
                mixpanelApiKeyStorage
        );
    }

    @Test
    void sendEventsToMixpanel_success_doesNotSubmitForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(SUCCESS_RESPONSE, response);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEventsToMixpanel_badRequest_doesNotSubmitForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN))
                .thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(FAILURE_RESPONSE, response);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEventsToMixpanel_feignExceptionWithBadRequestStatus_doesNotSubmitForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        FeignException feignException = mock(FeignException.class);
        when(feignException.status()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN)).thenThrow(feignException);

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(FAILURE_RESPONSE, response);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEventsToMixpanel_serverErrorWithFailedRecords_submitsForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        MixpanelEventResponse.FailedRecord failedRecord = MixpanelEventResponse.FailedRecord.builder()
                .index(0)
                .insertId("insert-1")
                .message("Internal error")
                .build();
        MixpanelEventResponse body = MixpanelEventResponse.builder()
                .failedRecords(List.of(failedRecord))
                .build();
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN))
                .thenReturn(new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR));
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(FAILURE_RESPONSE, response);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEventsToMixpanel_feignExceptionWithNonBadRequestStatus_submitsForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        FeignException feignException = mock(FeignException.class);
        when(feignException.status()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE.value());
        when(feignException.getMessage()).thenReturn("upstream unavailable");
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN)).thenThrow(feignException);
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(FAILURE_RESPONSE, response);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEventsToMixpanel_genericException_submitsForRetry() {
        List<MixpanelEventRequest> requests = List.of(buildEventRequest("insert-1"));
        when(mixpanelClient.sendImportEventRequest(requests, TOKEN)).thenThrow(new RuntimeException("network error"));
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        MixpanelResponse response = mixpanelIntegrationService.sendEventsToMixpanel(requests, TOKEN);

        assertEquals(FAILURE_RESPONSE, response);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    private MixpanelEventRequest buildEventRequest(String insertId) {
        return MixpanelEventRequest.builder()
                .event("test_event")
                .properties(MixpanelEventProperties.builder().insertID(insertId).build())
                .build();
    }
}