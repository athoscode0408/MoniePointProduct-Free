package com.moniepoint.loans.cas.integrations.singular.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularEventRequest;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularResponse;
import com.moniepoint.loans.cas.integrations.singular.service.SingularClient;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SingularIntegrationServiceImplTests {

    @Mock
    private SingularClient singularClient;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @InjectMocks
    private SingularIntegrationServiceImpl singularIntegrationService;

    private SingularEventRequest testEventRequest;

    @BeforeEach
    void setUp() {
        testEventRequest = SingularEventRequest.builder()
                .n("test_event")
                .a("test_api_key")
                .i("com.moniepoint.test")
                .p("android")
                .build();
    }

    @Test
    void sendEvent_whenApiCallIsSuccessful_returnsSuccess() {
        // Arrange
        SingularResponse successResponse = SingularResponse.builder().status("ok").build();
        ResponseEntity<SingularResponse> responseEntity = new ResponseEntity<>(successResponse, HttpStatus.OK);
        when(singularClient.sendEvent(any(SingularEventRequest.class))).thenReturn(responseEntity);

        // Act
        boolean result = singularIntegrationService.sendEvent(testEventRequest);

        // Assert
        assertTrue(result);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEvent_whenApiReturnsError_triggersFailureHandler() {
        // Arrange
        SingularResponse errorResponse = SingularResponse.builder().status("error").build();
        ResponseEntity<SingularResponse> responseEntity = new ResponseEntity<>(errorResponse, HttpStatus.OK);
        when(singularClient.sendEvent(any(SingularEventRequest.class))).thenReturn(responseEntity);
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        // Act
         boolean result = singularIntegrationService.sendEvent(testEventRequest);

        // Assert
        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEvent_whenApiClientThrowsException_triggersFailureHandler() {
        // Arrange
        when(singularClient.sendEvent(any(SingularEventRequest.class))).thenThrow(new RuntimeException("Network error"));
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        // Act
        boolean result = singularIntegrationService.sendEvent(testEventRequest);

        // Assert
        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void sendEvent_whenHttpError_triggersFailureHandler() {
        // Arrange
        ResponseEntity<SingularResponse> responseEntity = new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        when(singularClient.sendEvent(any(SingularEventRequest.class))).thenReturn(responseEntity);
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        // Act
        boolean result = singularIntegrationService.sendEvent(testEventRequest);

        // Assert
        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }
}
