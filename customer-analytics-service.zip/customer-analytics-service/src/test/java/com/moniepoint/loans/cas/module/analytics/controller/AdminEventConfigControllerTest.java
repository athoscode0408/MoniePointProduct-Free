package com.moniepoint.loans.cas.module.analytics.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.module.analytics.dto.EventConfigDTO;
import com.moniepoint.loans.cas.module.analytics.service.impl.EventConfigService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AdminEventConfigControllerTest {

    @Mock
    private EventConfigService eventConfigService;

    @InjectMocks
    private AdminEventConfigController adminEventConfigController;

    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(adminEventConfigController).build();
    }

    @Test
    void createEvent_delegatesToServiceAndReturnsOk() throws Exception {
        List<EventConfigDTO> events = List.of(
                EventConfigDTO.builder().eventName("dashboard_load_success").provider("BRAZE").build());

        mockMvc.perform(post("/internal/admin/event")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(events)))
                .andExpect(status().isOk());

        ArgumentCaptor<List<EventConfigDTO>> captor = ArgumentCaptor.forClass(List.class);
        verify(eventConfigService).createEventConfig(captor.capture());
        assertEquals("dashboard_load_success", captor.getValue().get(0).getEventName());
        assertEquals("BRAZE", captor.getValue().get(0).getProvider());
    }

    @Test
    void blacklistEvent_delegatesToServiceAndReturnsOk() throws Exception {
        List<EventConfigDTO> events = List.of(
                EventConfigDTO.builder().eventName("dashboard_load_success").provider("BRAZE").build());

        mockMvc.perform(delete("/internal/admin/event")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(events)))
                .andExpect(status().isOk());

        ArgumentCaptor<List<EventConfigDTO>> captor = ArgumentCaptor.forClass(List.class);
        verify(eventConfigService).removeEventConfig(captor.capture());
        assertEquals("dashboard_load_success", captor.getValue().get(0).getEventName());
        assertEquals("BRAZE", captor.getValue().get(0).getProvider());
    }
}
