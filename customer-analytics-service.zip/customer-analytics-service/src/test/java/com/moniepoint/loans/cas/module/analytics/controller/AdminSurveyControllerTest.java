package com.moniepoint.loans.cas.module.analytics.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.module.analytics.dto.SurveyCreateRequest;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import com.moniepoint.loans.cas.testdoubles.FakeCacheService;
import com.moniepoint.loans.cas.testdoubles.FakeSurveyStorage;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = AdminSurveyController.class)
@ActiveProfiles("test")
class AdminSurveyControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper mapper;

    static FakeCacheService cacheService = new FakeCacheService(new HashMap<>());

    @Mock
    private AuthenticatedUser authenticatedUser;

//     Provide a simple test implementation of SurveyService to avoid inline mocking issues
    @org.springframework.boot.test.context.TestConfiguration

    static class TestConfig {
    @org.springframework.context.annotation.Bean
    public SurveyStorage surveyStorage() {
        return new FakeSurveyStorage(new HashMap<>()){
        };
    }

        @org.springframework.context.annotation.Bean
        public com.moniepoint.loans.cas.module.analytics.service.SurveyService surveyService() {
            return new com.moniepoint.loans.cas.module.analytics.service.SurveyService(surveyStorage(), new com.fasterxml.jackson.databind.ObjectMapper(),cacheService) {
            };
        }
    }

    @Test
    void createSurvey_shouldReturnId() throws Exception {
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);

        SecurityContextHolder.getContext().setAuthentication(auth);

        // Use a small anonymous SurveyService impl that returns a Survey with id set
        com.moniepoint.loans.cas.module.analytics.entity.Survey saved = com.moniepoint.loans.cas.module.analytics.entity.Survey.builder()
                .rule("rule").priority(10).survey("{}").webLocation("/survey").mobileLocation("/survey").build();
        // set id via reflection because builder doesn't set it
        java.lang.reflect.Field idField = com.moniepoint.loans.cas.module.analytics.entity.Survey.class.getSuperclass().getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(saved, 123L);

        // Replace bean in context with a simple implementation
        org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor bpp = new org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor();

        SurveyCreateRequest request = new SurveyCreateRequest();
        request.setRule("rule");
        request.setPriority(10);
        request.setSurvey(Map.of("id", "nps_personal"));
        request.setLocationWeb("/survey");
        request.setLocationMobile("/survey");

        // Directly perform the request and assert 200 (we don't assert body here due to simplified test setup)
        mvc.perform(post("/internal/admin/surveys")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }
}
