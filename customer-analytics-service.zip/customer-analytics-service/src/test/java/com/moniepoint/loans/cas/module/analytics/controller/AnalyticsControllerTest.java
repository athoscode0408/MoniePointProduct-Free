package com.moniepoint.loans.cas.module.analytics.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.advice.models.ErrorResponse;
import com.moniepoint.loans.cas.common.util.ApplicationConstants;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AnalyticsController.class)
@ActiveProfiles("test")
class AnalyticsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AnalyticsService analyticsService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void publishEvent_success() throws Exception {
        AnalyticsEventV1RequestDTO analyticsEventRequestDTO = AnalyticsEventV1RequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("dev")
                .platform("IOS")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();
        AnalyticsEventResponseDTO response = AnalyticsEventResponseDTO.builder().success(true).build();

        when(analyticsService.pushEvent(analyticsEventRequestDTO)).thenReturn(response);

        MvcResult result = mockMvc.perform(post("/api/v1/push-event")
                        .content(objectMapper.writeValueAsString(analyticsEventRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isOk())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        AnalyticsEventResponseDTO actual = objectMapper.readValue(jsonResponse, AnalyticsEventResponseDTO.class);

        assertEquals(response, actual);
        verify(analyticsService, times(1)).pushEvent(analyticsEventRequestDTO);
    }

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void publishEvent_withoutMandatoryField_returnBadRequest() throws Exception {
        AnalyticsEventV1RequestDTO analyticsEventRequestDTO = AnalyticsEventV1RequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("dev")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        MvcResult result = mockMvc.perform(post("/api/v1/push-event")
                        .content(objectMapper.writeValueAsString(analyticsEventRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isBadRequest())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        ErrorResponse actual = objectMapper.readValue(jsonResponse, ErrorResponse.class);
        assertEquals(HttpStatus.BAD_REQUEST.value(), actual.getStatusCode());
        assertEquals("Event platform is not valid.;", actual.getMessage().trim());
    }

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void publishEvent_withoutRequestBody_returnBadRequest() throws Exception {

        MvcResult result = mockMvc.perform(post("/api/v1/push-event")
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isBadRequest())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        ErrorResponse actual = objectMapper.readValue(jsonResponse, ErrorResponse.class);
        assertEquals(HttpStatus.BAD_REQUEST.value(), actual.getStatusCode());
        assertEquals(ApplicationConstants.INVALID_DATE_ERROR_MESSAGE, actual.getMessage().trim());
    }


}
