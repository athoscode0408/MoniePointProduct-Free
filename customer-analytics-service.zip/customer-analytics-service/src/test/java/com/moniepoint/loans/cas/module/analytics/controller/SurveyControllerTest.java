package com.moniepoint.loans.cas.module.analytics.controller;
import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyAlertDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyAlertsResponse;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyHistoryItemDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyHistoryResponse;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveySchemaDTO;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.service.PreprocessedSurveyRepositoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SurveyController.class)
@ActiveProfiles("test")
class SurveyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PreprocessedSurveyRepositoryService surveyService;

    @Mock
    private AuthenticatedUser authenticatedUser;

    private PreprocessedSurveyDTO sampleSurvey;

    @BeforeEach
    void setUp() {
        sampleSurvey = PreprocessedSurveyDTO.builder()
                .surveyId(1L)
                .user("user-1")
                .survey("{\"sample\":\"data\"}")
                .build();
    }

    @Test
    void shouldReturnSurveysByUserId() throws Exception {

        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);

        SecurityContextHolder.getContext().setAuthentication(auth);

        List<PreprocessedSurveyDTO> surveys = List.of(sampleSurvey);
        when(surveyService.fetchSurveysByUserId("user-1")).thenReturn(surveys);
        when(authenticatedUser.getUsername()).thenReturn("user-1");

        mockMvc.perform(get("/api/surveys/user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].surveyId").value("1"))
                .andExpect(jsonPath("$[0].user").value("user-1"));
    }

    @Test
    void shouldReturnHttpOkAndEmptyListForUserWithoutSurveys() throws Exception {

        when(authenticatedUser.getUsername()).thenReturn("user-1");

        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);

        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/user"))
                .andExpect(status().isOk())
               .andExpect(jsonPath("$[0]").doesNotExist());

    }

    @Test
    void shouldReturnAuthErrorForUnauthenticatedUser() throws Exception {
        mockMvc.perform(get("/api/surveys/user"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void shouldReturn404ForAuthenticatedUser() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user9");

        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").doesNotExist());
    }

    @Test
    void shouldReturn400ForMissingUsername() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("");

        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/user"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturnSurveyById() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveyById(1L)).thenReturn(sampleSurvey);

        mockMvc.perform(get("/api/surveys/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.surveyId").value("1"))
                .andExpect(jsonPath("$.user").value("user-1"));
    }

    @Test
    void shouldReturn404ForSurveyNotAssignedToUser() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-2");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveyById(1L)).thenReturn(sampleSurvey);

        mockMvc.perform(get("/api/surveys/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturnStatusNotFoundWhenSurveyMissing() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-2");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveyById(4L)).thenReturn(null);

        mockMvc.perform(get("/api/surveys/4"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturnAuthErrorForUnauthenticatedUser2() throws Exception {
        mockMvc.perform(get("/api/surveys/4"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void shouldReturnStatusBadRequestWhenUserNameMissing() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn(null);
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveyById(4L)).thenReturn(sampleSurvey);

            mockMvc.perform(get("/api/surveys/4"))
                    .andExpect(status().isBadRequest());
        }

    @Test
    void shouldReturnSurveyHistory() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        SurveyHistoryItemDTO item = SurveyHistoryItemDTO.builder()
                .id(10L)
                .event("SURVEY_TRIGGERED")
                .state(PreprocessedSurveyState.COMPLETED)
                .ttl(LocalDateTime.of(2025, 2, 1, 0, 0, 0))
                .completedOn(LocalDateTime.of(2025, 1, 15, 10, 0, 0))
                .build();

        SurveyHistoryResponse historyResponse = new SurveyHistoryResponse(List.of(item));
        when(surveyService.fetchSurveyHistory(eq("user-1"), eq(1L), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(historyResponse);

        mockMvc.perform(get("/api/surveys/1/history")
                        .param("startDate", "2025-01-01")
                        .param("endDate", "2025-01-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.surveys[0].id").value(10))
                .andExpect(jsonPath("$.surveys[0].event").value("SURVEY_TRIGGERED"))
                .andExpect(jsonPath("$.surveys[0].state").value("COMPLETED"));
    }

    @Test
    void shouldReturn400ForMissingUsernameInHistoryEndpoint() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/1/history")
                        .param("startDate", "2025-01-01")
                        .param("endDate", "2025-01-31"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturn401ForUnauthenticatedHistoryRequest() throws Exception {
        mockMvc.perform(get("/api/surveys/1/history")
                        .param("startDate", "2025-01-01")
                        .param("endDate", "2025-01-31"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void shouldReturnSurveySchema() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        SurveySchemaDTO schema = SurveySchemaDTO.builder()
                .id(3L)
                .survey("{\"id\":\"nps_v1\"}")
                .build();
        when(surveyService.fetchSurveySchema(eq(3L), any(), any())).thenReturn(schema);

        mockMvc.perform(get("/api/surveys/schema/3"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.survey.id").value("nps_v1"));
    }

    @Test
    void shouldReturn404WhenSurveySchemaNotFound() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveySchema(eq(99L), any(), any())).thenReturn(null);

        mockMvc.perform(get("/api/surveys/schema/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void shouldReturn400ForMissingUsernameInSchemaEndpoint() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/schema/1"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturn401ForUnauthenticatedSchemaRequest() throws Exception {
        mockMvc.perform(get("/api/surveys/schema/1"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void shouldReturnSurveyAlerts() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        SurveyAlertDTO alert = SurveyAlertDTO.builder()
                .id("NPS_SURVEY_EVENT")
                .type("INFO")
                .priority(1)
                .title("BO-BRM Alert")
                .message("Rate your BRM here")
                .action(SurveyAlertDTO.Action.builder()
                        .label("View Details")
                        .target("/survey/10")
                        .build())
                .dismissible(false)
                .build();
        when(surveyService.fetchSurveyAlerts(eq("user-1"), anyString())).thenReturn(new SurveyAlertsResponse(List.of(alert)));

        mockMvc.perform(get("/api/surveys/dashboard-info")
                        .header("moniepointAgentId", "agent-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.alerts[0].id").value("NPS_SURVEY_EVENT"))
                .andExpect(jsonPath("$.alerts[0].type").value("INFO"))
                .andExpect(jsonPath("$.alerts[0].priority").value(1))
                .andExpect(jsonPath("$.alerts[0].title").value("BO-BRM Alert"))
                .andExpect(jsonPath("$.alerts[0].message").value("Rate your BRM here"))
                .andExpect(jsonPath("$.alerts[0].action.label").value("View Details"))
                .andExpect(jsonPath("$.alerts[0].action.target").value("/survey/10"))
                .andExpect(jsonPath("$.alerts[0].isDismissible").value(false));
    }

    @Test
    void shouldReturnEmptyAlertsForUserWithNoAlerts() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("user-1");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        when(surveyService.fetchSurveyAlerts(eq("user-1"), anyString())).thenReturn(new SurveyAlertsResponse(List.of()));

        mockMvc.perform(get("/api/surveys/dashboard-info")
                        .header("moniepointAgentId", "agent-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.alerts").isEmpty());
    }

    @Test
    void shouldReturn400ForMissingUsernameInAlertsEndpoint() throws Exception {
        when(authenticatedUser.getUsername()).thenReturn("");
        TestingAuthenticationToken auth = new TestingAuthenticationToken(authenticatedUser, null, "CAN_FETCH_SURVEY");
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        mockMvc.perform(get("/api/surveys/dashboard-info")
                        .header("moniepointAgentId", "agent-123"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldReturn401ForUnauthenticatedAlertsRequest() throws Exception {
        mockMvc.perform(get("/api/surveys/dashboard-info")
                        .header("moniepointAgentId", "agent-123"))
                .andExpect(status().isUnauthorized());
    }

}
