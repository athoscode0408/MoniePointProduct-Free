package com.moniepoint.loans.cas.module.analytics.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignByDomainDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateGoalDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalDeactivationDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalMarkerDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserRewardEventDTO;
import com.moniepoint.loans.cas.module.analytics.dto.RewardEventMetadataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeCloseCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.service.impl.WebhookService;
import com.moniepoint.loans.cas.outbound.rewards.RewardsCampaignResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class WebhookControllerTest {

    @Mock
    private WebhookService webhookService;

    @InjectMocks
    private WebhookController webhookController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    private static final String SECRET = "test-secret";
    private static final String CREATE_CAMPAIGN_URL = "/api/webhook/braze/campaigns";
    private static final String CREATE_GOAL_URL = "/api/webhook/braze/goals";
    private static final String MARK_GOAL_URL = "/api/webhook/braze/mark-goal";
    private static final String DEACTIVATE_GOAL_URL = "/api/webhook/braze/deactivate-goal";
    private static final String ASSIGN_BY_DOMAIN_URL = "/api/webhook/braze/assign-by-domain";
    private static final String REWARD_EVENT_URL = "/api/webhook/braze/event-reward";
    private static final String CLOSE_CAMPAIGN_URL = "/api/webhook/braze/close-campaign";

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
        validator.afterPropertiesSet();

        mockMvc = MockMvcBuilders.standaloneSetup(webhookController)
                .setMessageConverters(new MappingJackson2HttpMessageConverter(objectMapper))
                .setValidator(validator)
                .build();
    }

    private BrazeUserCreateCampaignDTO buildValidDTO() {
        return BrazeUserCreateCampaignDTO.builder()
                .campaignIdentifier("camp-001")
                .campaignExternalIdentifier("ext-001")
                .campaignImage("https://img.example.com/campaign.png")
                .campaignDetailsImage("https://img.example.com/details.png")
                .campaignDescription("Test campaign description")
                .campaignTitle("Test Campaign Title")
                .bannerId("banner-001")
                .domain("PERSONAL")
                .campaignEndDate(LocalDateTime.now().plusDays(30))
                .priority(2)
                .build();
    }

    @Test
    void createCampaign_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserCreateCampaignDTO dto = buildValidDTO();
        RewardsCampaignResponse campaignResponse = new RewardsCampaignResponse(true, "Campaign created", "200");

        when(webhookService.createRewardCampaign(any(BrazeUserCreateCampaignDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(campaignResponse));

        mockMvc.perform(post(CREATE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Campaign created"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).createRewardCampaign(any(BrazeUserCreateCampaignDTO.class), eq(SECRET));
    }

    @Test
    void createCampaign_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserCreateCampaignDTO dto = buildValidDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.createRewardCampaign(any(BrazeUserCreateCampaignDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(CREATE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).createRewardCampaign(any(BrazeUserCreateCampaignDTO.class), eq("wrong-secret"));
    }

    @Test
    void createCampaign_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserCreateCampaignDTO dto = buildValidDTO();

        mockMvc.perform(post(CREATE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void createCampaign_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserCreateCampaignDTO emptyDto = BrazeUserCreateCampaignDTO.builder().build();

        mockMvc.perform(post(CREATE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    private BrazeUserCreateGoalDTO buildValidGoalDTO() {
        BrazeUserCreateGoalDTO.Goal goal = BrazeUserCreateGoalDTO.Goal.builder()
                .rewardCode("reward-001")
                .goalType("INTER_BANK_TRANSFER")
                .code("goal-001")
                .title("Test Goal")
                .description("Test goal description")
                .expectedOccurrences(5)
                .deepLink("https://app.example.com/goal")
                .goalFrequency("DAILY")
                .rewardMode("REWARD_ON_EACH_OCCURRENCE")
                .goalManager("MONIEPOINT_REWARD_SERVICE")
                .daysTillExpiry(30)
                .businessIds(List.of(1L))
                .build();
        return BrazeUserCreateGoalDTO.builder()
                .campaignIdentifier("camp-001")
                .goals(List.of(goal))
                .build();
    }

    @Test
    void createGoal_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserCreateGoalDTO dto = buildValidGoalDTO();
        RewardsCampaignResponse goalResponse = new RewardsCampaignResponse(true, "Goal created", "200");

        when(webhookService.createRewardGoal(any(BrazeUserCreateGoalDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(goalResponse));

        mockMvc.perform(post(CREATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Goal created"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).createRewardGoal(any(BrazeUserCreateGoalDTO.class), eq(SECRET));
    }

    @Test
    void createGoal_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserCreateGoalDTO dto = buildValidGoalDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.createRewardGoal(any(BrazeUserCreateGoalDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(CREATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).createRewardGoal(any(BrazeUserCreateGoalDTO.class), eq("wrong-secret"));
    }

    @Test
    void createGoal_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserCreateGoalDTO dto = buildValidGoalDTO();

        mockMvc.perform(post(CREATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void createGoal_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserCreateGoalDTO emptyDto = BrazeUserCreateGoalDTO.builder().build();

        mockMvc.perform(post(CREATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

     private BrazeUserGoalMarkerDTO buildValidGoalMarkerDTO() {
        return BrazeUserGoalMarkerDTO.builder()
                .goalIdentifier("goal-001")
                .customerIdentifier("customer-001")
                .eventSourceDomain("PERSONAL")
                .build();
    }

    @Test
    void markGoal_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserGoalMarkerDTO dto = buildValidGoalMarkerDTO();
        RewardsCampaignResponse markGoalResponse = new RewardsCampaignResponse(true, "Goal marked", "200");

        when(webhookService.markRewardGoal(any(BrazeUserGoalMarkerDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(markGoalResponse));

        mockMvc.perform(post(MARK_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Goal marked"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).markRewardGoal(any(BrazeUserGoalMarkerDTO.class), eq(SECRET));
    }

    @Test
    void markGoal_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserGoalMarkerDTO dto = buildValidGoalMarkerDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.markRewardGoal(any(BrazeUserGoalMarkerDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(MARK_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).markRewardGoal(any(BrazeUserGoalMarkerDTO.class), eq("wrong-secret"));
    }

    @Test
    void markGoal_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserGoalMarkerDTO dto = buildValidGoalMarkerDTO();

        mockMvc.perform(post(MARK_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void markGoal_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserGoalMarkerDTO emptyDto = BrazeUserGoalMarkerDTO.builder().build();

        mockMvc.perform(post(MARK_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    private BrazeUserGoalDeactivationDTO buildValidGoalDeactivationDTO() {
        return BrazeUserGoalDeactivationDTO.builder()
                .campaignIdentifier("camp-001")
                .goalIdentifier("goal-001")
                .customerIdentifier("customer-001")
                .build();
    }

    @Test
    void deactivateGoal_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserGoalDeactivationDTO dto = buildValidGoalDeactivationDTO();
        RewardsCampaignResponse deactivateResponse = new RewardsCampaignResponse(true, "Goal deactivated", "200");

        when(webhookService.deactivateRewardGoal(any(BrazeUserGoalDeactivationDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(deactivateResponse));

        mockMvc.perform(post(DEACTIVATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Goal deactivated"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).deactivateRewardGoal(any(BrazeUserGoalDeactivationDTO.class), eq(SECRET));
    }

    @Test
    void deactivateGoal_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserGoalDeactivationDTO dto = buildValidGoalDeactivationDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.deactivateRewardGoal(any(BrazeUserGoalDeactivationDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(DEACTIVATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).deactivateRewardGoal(any(BrazeUserGoalDeactivationDTO.class), eq("wrong-secret"));
    }

    @Test
    void deactivateGoal_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserGoalDeactivationDTO dto = buildValidGoalDeactivationDTO();

        mockMvc.perform(post(DEACTIVATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void deactivateGoal_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserGoalDeactivationDTO emptyDto = BrazeUserGoalDeactivationDTO.builder().build();

        mockMvc.perform(post(DEACTIVATE_GOAL_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    private BrazeUserCampaignByDomainDTO buildValidCampaignByDomainDTO() {
        return BrazeUserCampaignByDomainDTO.builder()
                .campaignIdentifier("camp-001")
                .webhookReference("ref-001")
                .build();
    }

    @Test
    void assignCampaignByDomain_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserCampaignByDomainDTO dto = buildValidCampaignByDomainDTO();
        RewardsCampaignResponse assignResponse = new RewardsCampaignResponse(true, "Campaign assigned by domain", "200");

        when(webhookService.assignRewardCampaignByDomain(any(BrazeUserCampaignByDomainDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(assignResponse));

        mockMvc.perform(post(ASSIGN_BY_DOMAIN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Campaign assigned by domain"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).assignRewardCampaignByDomain(any(BrazeUserCampaignByDomainDTO.class), eq(SECRET));
    }

    @Test
    void assignCampaignByDomain_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserCampaignByDomainDTO dto = buildValidCampaignByDomainDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.assignRewardCampaignByDomain(any(BrazeUserCampaignByDomainDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(ASSIGN_BY_DOMAIN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).assignRewardCampaignByDomain(any(BrazeUserCampaignByDomainDTO.class), eq("wrong-secret"));
    }

    @Test
    void assignCampaignByDomain_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserCampaignByDomainDTO dto = buildValidCampaignByDomainDTO();

        mockMvc.perform(post(ASSIGN_BY_DOMAIN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void assignCampaignByDomain_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserCampaignByDomainDTO emptyDto = BrazeUserCampaignByDomainDTO.builder().build();

        mockMvc.perform(post(ASSIGN_BY_DOMAIN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    private BrazeUserRewardEventDTO buildValidRewardEventDTO() {
        return BrazeUserRewardEventDTO.builder()
                .eventName("TRANSFER_COMPLETED")
                .eventUserId("user-001")
                .eventReferenceId("ref-001")
                .metadata(RewardEventMetadataDTO.builder().domain("PERSONAL").build())
                .build();
    }

    @Test
    void rewardUserByEvent_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeUserRewardEventDTO dto = buildValidRewardEventDTO();
        RewardsCampaignResponse eventResponse = new RewardsCampaignResponse(true, "Event rewarded", "200");

        when(webhookService.rewardEvent(any(BrazeUserRewardEventDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(eventResponse));

        mockMvc.perform(post(REWARD_EVENT_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Event rewarded"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).rewardEvent(any(BrazeUserRewardEventDTO.class), eq(SECRET));
    }

    @Test
    void rewardUserByEvent_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeUserRewardEventDTO dto = buildValidRewardEventDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.rewardEvent(any(BrazeUserRewardEventDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(REWARD_EVENT_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).rewardEvent(any(BrazeUserRewardEventDTO.class), eq("wrong-secret"));
    }

    @Test
    void rewardUserByEvent_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeUserRewardEventDTO dto = buildValidRewardEventDTO();

        mockMvc.perform(post(REWARD_EVENT_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void rewardUserByEvent_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeUserRewardEventDTO emptyDto = BrazeUserRewardEventDTO.builder().build();

        mockMvc.perform(post(REWARD_EVENT_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    private BrazeCloseCampaignDTO buildValidCloseCampaignDTO() {
        return BrazeCloseCampaignDTO.builder()
                .campaignIdentifier("CAMPAIGN_IDENTIFIER")
                .build();
    }

    @Test
    void closeCampaign_validRequestAndSecret_delegatesToServiceAndReturnsResponse() throws Exception {
        BrazeCloseCampaignDTO dto = buildValidCloseCampaignDTO();
        RewardsCampaignResponse eventResponse = new RewardsCampaignResponse(true, "Campaign closed", "200");

        when(webhookService.closeRewardCampaign(any(BrazeCloseCampaignDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(eventResponse));

        mockMvc.perform(post(CLOSE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.requestSuccessful").value(true))
                .andExpect(jsonPath("$.responseMessage").value("Campaign closed"))
                .andExpect(jsonPath("$.responseCode").value("200"));

        verify(webhookService).closeRewardCampaign(any(BrazeCloseCampaignDTO.class), eq(SECRET));
    }

    @Test
    void closeCampaign_serviceReturnsForbidden_propagatesForbiddenStatus() throws Exception {
        BrazeCloseCampaignDTO dto = buildValidCloseCampaignDTO();
        RewardsCampaignResponse forbiddenResponse = new RewardsCampaignResponse(false, "Invalid secret header key", "403");

        when(webhookService.closeRewardCampaign(any(BrazeCloseCampaignDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.FORBIDDEN).body(forbiddenResponse));

        mockMvc.perform(post(CLOSE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", "wrong-secret")
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.requestSuccessful").value(false))
                .andExpect(jsonPath("$.responseCode").value("403"));

        verify(webhookService).closeRewardCampaign(any(BrazeCloseCampaignDTO.class), eq("wrong-secret"));
    }

    @Test
    void closeCampaign_missingSecretHeader_returnsBadRequest() throws Exception {
        BrazeCloseCampaignDTO dto = buildValidCloseCampaignDTO();

        mockMvc.perform(post(CLOSE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }

    @Test
    void closeCampaign_missingRequiredFields_returnsBadRequest() throws Exception {
        BrazeCloseCampaignDTO emptyDto = BrazeCloseCampaignDTO.builder().build();

        mockMvc.perform(post(CLOSE_CAMPAIGN_URL)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("X-Secret-Key", SECRET)
                        .content(objectMapper.writeValueAsString(emptyDto)))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(webhookService);
    }
}
