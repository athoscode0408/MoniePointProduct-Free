package com.moniepoint.loans.cas.module.analytics.controller.v1;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.moniepoint.loans.cas.module.analytics.dto.v1.BrazeAllowedEventsResponse;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class WhitelistedEventsControllerTest {

    @Mock
    private AnalyticsService analyticsService;

    @InjectMocks
    private WhitelistedEventsController whitelistedEventsController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        mockMvc = MockMvcBuilders.standaloneSetup(whitelistedEventsController)
                .setMessageConverters(new MappingJackson2HttpMessageConverter(objectMapper))
                .build();
    }

    @Test
    void getWhitelistedBrazeEvents_returnsWhitelist() throws Exception {
        Instant expiresAt = Instant.parse("2027-12-20T00:00:00Z");
        BrazeAllowedEventsResponse response = BrazeAllowedEventsResponse.builder()
                .expiresAt(expiresAt)
                .allowedEvents(List.of("dashboard_load_success", "sign_in_success", "business_selection_success"))
                .build();
        when(analyticsService.getPubliclyAllowedBrazeEvents()).thenReturn(response);

        MvcResult result = mockMvc.perform(get("/api/v1/white-listed-events"))
                .andExpect(status().isOk())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        BrazeAllowedEventsResponse actual = objectMapper.readValue(jsonResponse, BrazeAllowedEventsResponse.class);

        assertEquals(response, actual);
        assertEquals("{\"expires_at\":\"2027-12-20T00:00:00Z\",\"allowed_events\":[\"dashboard_load_success\",\"sign_in_success\",\"business_selection_success\"]}", jsonResponse);
    }

}
