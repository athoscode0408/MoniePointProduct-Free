package com.moniepoint.loans.cas.module.analytics.controller.v3;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.advice.models.ErrorResponse;
import com.moniepoint.loans.cas.common.util.ApplicationConstants;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import com.moniepoint.loans.cas.module.analytics.service.SessionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AnalyticsControllerV3.class)
@ActiveProfiles("test")
class AnalyticsControllerV3Test {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AnalyticsService analyticsService;

    @MockBean
    private SessionService sessionService;

    @MockBean
    private ObjectMapperHelper objectMapperHelper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void publishV2Event_success() throws Exception {
        AnalyticsEventV2RequestDTO analyticsEventV2RequestDTO = AnalyticsEventV2RequestDTO.builder()
                .dtoVersion("v2")
                .id("123")
                .eventType("prequalification")
                .appEnv("dev")
                .ip("127.0.0.1")
                .platform("android")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .customerIdentifier("testIdentifier")
                .userIdentifiers(new UserEventIdentifier(null))
                .build();

        AnalyticsEventResponseDTO response = AnalyticsEventResponseDTO.builder().success(true).build();

        MvcResult result = mockMvc.perform(post("/api/v3/event")
                    .content(objectMapper.writeValueAsString(
                            // Don't pass "v2" to cover a backward compatibility case with fallback to v2
                            AnalyticsEventV2RequestDTO.builder()
                                    .id("123")
                                    .eventType("prequalification")
                                    .appEnv("dev")
                                    .platform("android")
                                    .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                                    .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                                    .customerIdentifier("testIdentifier")
                                    .build()
                    ))
                    .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isOk())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        AnalyticsEventResponseDTO actual = objectMapper.readValue(jsonResponse, AnalyticsEventResponseDTO.class);

        assertEquals(response, actual);
        verify(analyticsService, times(1))
                .pushEvents(argThat(list ->
                        list.size() == 1 &&
                                "prequalification".equals(list.getFirst().getEventType())
                ));
    }

    // TODO fix unit test
//    @Test
//    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
//    void publishV3Event_success() throws Exception {
//        AnalyticsEventV3RequestDTO analyticsEventV3RequestDTO = TestDtoGenerator.getAnalyticsEventV3RequestDTO();
//        AnalyticsEventV3RequestDTO expectedEvent = TestDtoGenerator.getAnalyticsEventV3RequestDTO();
//        expectedEvent.setUserIdentifiers(new UserEventIdentifier("my-session-ID"));
//        expectedEvent.setId(analyticsEventV3RequestDTO.getId());
//        var matcher = new AnalyticsEventV3Matcher(new AnalyticsEventV3RequestDTO[]{expectedEvent}, null);
//        when(sessionService.generateSessionID(anyString(), any()))
//                .thenReturn("my-session-ID");
//
//        AnalyticsEventResponseDTO response = AnalyticsEventResponseDTO.builder().success(true).build();
//        when(analyticsService.pushEvents(argThat(matcher))).thenReturn(response);
//
//        MvcResult result = mockMvc.perform(post("/api/v3/event")
//                        .content(objectMapper.writeValueAsString(analyticsEventV3RequestDTO))
//                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
//                .andExpect(status().isOk())
//                .andReturn();
//
//        String jsonResponse = result.getResponse().getContentAsString();
//        AnalyticsEventResponseDTO actual = objectMapper.readValue(jsonResponse, AnalyticsEventResponseDTO.class);
//
//        assertEquals(response, actual);
//        verify(analyticsService, times(1)).pushEvents(argThat(matcher));
//    }

    // TODO fix unit test
//    @Test
//    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
//    void publishV3EventsBatch_success() throws Exception {
//        List<BaseAnalyticsEventRequestDTO<?>> analyticsEventsV3RequestDTO = List.of(
//                TestDtoGenerator.getAnalyticsEventV3RequestDTO(),
//                TestDtoGenerator.getAnalyticsEventV3RequestDTO(),
//                TestDtoGenerator.getAnalyticsEventV3RequestDTO());
//        analyticsEventsV3RequestDTO.forEach(e -> e.setUserIdentifiers(new UserEventIdentifier(null, null, null, null, null)));
//
//        AnalyticsEventResponseDTO response = AnalyticsEventResponseDTO.builder().success(true).build();
//        when(analyticsService.pushEvents(analyticsEventsV3RequestDTO)).thenReturn(response);
//
//        MvcResult result = mockMvc.perform(post("/api/v3/events")
//                        .content(objectMapper.writeValueAsString(analyticsEventsV3RequestDTO))
//                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
//                .andExpect(status().isOk())
//                .andReturn();
//
//        String jsonResponse = result.getResponse().getContentAsString();
//        AnalyticsEventResponseDTO actual = objectMapper.readValue(jsonResponse, AnalyticsEventResponseDTO.class);
//
//        assertEquals(response, actual);
//        verify(analyticsService, times(1)).pushEvents(analyticsEventsV3RequestDTO);
//    }

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void publishEvent_withoutRequestBody_returnBadRequest() throws Exception {

        MvcResult result = mockMvc.perform(post("/api/v3/event")
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isBadRequest())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        ErrorResponse actual = objectMapper.readValue(jsonResponse, ErrorResponse.class);
        assertEquals(HttpStatus.BAD_REQUEST.value(), actual.getStatusCode());
        assertEquals(ApplicationConstants.INVALID_DATE_ERROR_MESSAGE, actual.getMessage().trim());
    }

    @Test
    @WithMockUser(authorities = {"CAN_PUSH_ANALYTICS_EVENT"})
    void testUnsupportedDtoVersion_fail() throws Exception {
        String request = """
            {
              "dtoVersion": "v5",
              "id": "123",
              "eventType": "prequalification",
              "appEnv": "dev",
              "timestamp": "1970-01-20T23:24:47.178+00:00",
              "customerIdentifier": "testIdentifier",
              "platform": "android",
              "data": {
                "eventName": "payment_success"
              },
              "applicationId": "MonieWorld",
              "version": "1.1.5"
            }
        """;

        MvcResult result = mockMvc.perform(post("/api/v3/event")
                        .content(request)
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(HttpStatus.BAD_REQUEST.value(), result.getResponse().getStatus());
        assertEquals("{\"statusCode\":400,\"message\":\"Invalid dtoVersion. Accepted values: v2, v3; \"}", result.getResponse().getContentAsString());
    }
}
