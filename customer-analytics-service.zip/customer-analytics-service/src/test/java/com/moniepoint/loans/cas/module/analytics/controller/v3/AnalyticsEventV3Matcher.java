package com.moniepoint.loans.cas.module.analytics.controller.v3;

import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import lombok.AllArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.mockito.ArgumentMatcher;

import java.util.List;

@SuperBuilder
@AllArgsConstructor
public class AnalyticsEventV3Matcher implements ArgumentMatcher<List<BaseAnalyticsEventRequestDTO<?>>> {
    private BaseAnalyticsEventRequestDTO<?>[] expectedEvents;
    private String userID;

    public boolean matches(BaseAnalyticsEventRequestDTO<?> expected, BaseAnalyticsEventRequestDTO<?> actual) {
        return expected.equals(actual) && actual.getUserIdentifiers() != null && actual.getUserIdentifiers().getSessionID() != null;
    }

    @Override
    public boolean matches(List<BaseAnalyticsEventRequestDTO<?>> events) {
        if (events.size() != expectedEvents.length) {
            return false;
        }

        for (int i = 0; i < events.size(); i++) {
            if (!matches(expectedEvents[i], events.get(i))){
                return false;
            }
        }
        return true;
    }
}