package com.moniepoint.loans.cas.module.analytics.controller.v3;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.security.model.AuthenticatedUser;
import com.moniepoint.loans.cas.module.analytics.dto.UserInfoResponseDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.analytics.service.SessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserInfoController.class)
@ActiveProfiles("test")
class UserInfoControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockBean
    private SessionService sessionService;

    @MockBean
    private SecurityFilterChain securityFilterChain;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ModelMapper modelMapper;

    @Mock
    private AuthenticatedUser user;


    @BeforeEach
    void setup() {
        when(securityFilterChain.matches(any())).thenReturn(true);
    }

    @Test
    void unauthorizedUserReturnsSessionID() throws Exception {
        when(sessionService.generateSessionID("unknown-device-id", null)).thenReturn(UUID.randomUUID().toString());

        MvcResult result = mockMvc.perform(post("/api/v3/user-info")
                    .content(objectMapper.writeValueAsString(
                            AnalyticsEventV3DeviceInfoDTO.builder()
                                    .id("unknown-device-id")
                                    .agent("Chrome")
                                    .agentVersion("126.0.0.0")
                                    .type("web")
                                    .os("Windows 11")
                                    .additionalInfo(Map.of(
                                            "userAgent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
                                            "screenResolution", "1920x1080",
                                            "language", "en-US"
                                    ))
                                    .build()
                    ))
                    .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isOk())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        UserInfoResponseDTO response = objectMapper.readValue(jsonResponse, UserInfoResponseDTO.class);

        assertNotNull(response.getSessionID());
        assertNull(response.getUserID());
    }

    @Test
    @WithMockUser()
    void authorizedUserReturnsSessionIDAndUserID() {
        when(sessionService.generateSessionID("my-device-id", "my-user-id")).thenReturn("my-session-id");
        when(user.getUsername()).thenReturn("my-user-id");

        var controller = new UserInfoController(sessionService);
        var response = controller.userInfo(user, AnalyticsEventV3DeviceInfoDTO.builder()
                .id("my-device-id")
                .agent("Firefox")
                .agentVersion("127.0.2")
                .type("web")
                .os("Windows 11")
                .additionalInfo(Map.of(
                        "userAgent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
                        "screenResolution", "1920x1080",
                        "language", "en-US"
                ))
                .build());

        assertEquals("my-session-id", response.getSessionID());
        assertEquals("my-user-id", response.getUserID());
    }

    @Test
    void invalidRequestIsRejected() throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v3/user-info")
                        .content(objectMapper.writeValueAsString(
                                AnalyticsEventV3DeviceInfoDTO.builder().build()
                        ))
                        .contentType(MediaType.APPLICATION_JSON).with(csrf()))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertTrue(result.getResponse().getContentAsString().contains("Device id can't be empty"));
    }
}
