package com.moniepoint.loans.cas.module.analytics.dto.v1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@JsonTest
@ActiveProfiles("test")
class BrazeAllowedEventsResponseTest {

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void serialize_writesExpiresAtAsIsoString() throws Exception {
        BrazeAllowedEventsResponse response = BrazeAllowedEventsResponse.builder()
                .expiresAt(Instant.parse("2027-12-20T00:00:00Z"))
                .allowedEvents(List.of("dashboard_load_success"))
                .build();

        String json = objectMapper.writeValueAsString(response);

        assertEquals("{\"expires_at\":\"2027-12-20T00:00:00Z\",\"allowed_events\":[\"dashboard_load_success\"]}", json);
    }

}