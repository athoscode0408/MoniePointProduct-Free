package com.moniepoint.loans.cas.module.analytics.dto.v3;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SurveyBodyTest {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Test
    void surveyBodyWithNewFields_deserializesCorrectly() throws Exception {
        String json = """
                {
                  "reminderMinIntervalHours": 48,
                  "q2CopyByBand": {
                    "detractor": "Sorry to hear that",
                    "passive": "Thanks for the feedback",
                    "promoter": "Glad you love it"
                  }
                }
                """;

        SurveyBody body = mapper.readValue(json, SurveyBody.class);

        assertEquals(48, body.getReminderMinIntervalHours());
        assertNotNull(body.getQ2CopyByBand());
        assertEquals("Sorry to hear that", body.getQ2CopyByBand().getDetractor());
        assertEquals("Thanks for the feedback", body.getQ2CopyByBand().getPassive());
        assertEquals("Glad you love it", body.getQ2CopyByBand().getPromoter());
    }

    @Test
    void legacyBrmSurveyBody_deserializesWithoutException() throws Exception {
        String json = """
                {
                  "assignBanner": false,
                  "randomizeSurveyAssignment": true,
                  "preprocessedSurveyTTL": 10080
                }
                """;

        SurveyBody body = assertDoesNotThrow(() -> mapper.readValue(json, SurveyBody.class));

        assertEquals(0, body.getReminderMinIntervalHours());
        assertNull(body.getQ2CopyByBand());
    }

    @Test
    void surveyBodyRoundTrip_preservesNewFields() throws Exception {
        SurveyBody.Q2CopyByBand bands = SurveyBody.Q2CopyByBand.builder()
                .detractor("Sorry")
                .passive("OK")
                .promoter("Great")
                .build();
        SurveyBody original = SurveyBody.builder()
                .reminderMinIntervalHours(24)
                .q2CopyByBand(bands)
                .build();

        String json = mapper.writeValueAsString(original);
        SurveyBody deserialized = mapper.readValue(json, SurveyBody.class);

        assertEquals(24, deserialized.getReminderMinIntervalHours());
        assertNotNull(deserialized.getQ2CopyByBand());
        assertEquals("Sorry", deserialized.getQ2CopyByBand().getDetractor());
    }
}
