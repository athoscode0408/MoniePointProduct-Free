package com.moniepoint.loans.cas.module.analytics.dto.v3;

import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TsToLdtTest {

    private final PreprocessedSurveyDTO.TsToLdt converter = new PreprocessedSurveyDTO.TsToLdt();

    @Test
    void convert_null_returnsNull() {
        assertNull(converter.convert(null));
    }

    @Test
    void convert_sqlTimestamp_returnsLocalDateTimeTruncatedToSeconds() {
        LocalDateTime expected = LocalDateTime.of(2024, 6, 18, 10, 30, 45);
        Timestamp ts = Timestamp.valueOf(expected.withNano(999_000_000));

        assertEquals(expected, converter.convert(ts));
    }

    @Test
    void convert_epochMillisLong_returnsLocalDateTimeInUtc() {
        // 2024-06-18T10:30:45Z
        long epochMillis = 1718706645000L;
        LocalDateTime expected = LocalDateTime.of(2024, 6, 18, 10, 30, 45);

        assertEquals(expected, converter.convert(epochMillis));
    }

    @Test
    void convert_isoString_returnsLocalDateTime() {
        assertEquals(
                LocalDateTime.of(2024, 6, 18, 10, 30, 45),
                converter.convert("2024-06-18T10:30:45")
        );
    }

    @Test
    void convert_isoStringWithNanos_truncatesToSeconds() {
        assertEquals(
                LocalDateTime.of(2024, 6, 18, 10, 30, 45),
                converter.convert("2024-06-18T10:30:45.999999999")
        );
    }

    @Test
    void convert_jacksonTimestampArray_returnsLocalDateTime() {
        // JavaTimeModule writes LocalDateTime as [year, month, day, hour, min, sec, nano]
        // when WRITE_DATES_AS_TIMESTAMPS=true (the old default)
        List<Integer> array = List.of(2024, 6, 18, 10, 30, 45, 0);

        assertEquals(LocalDateTime.of(2024, 6, 18, 10, 30, 45), converter.convert(array));
    }

    @Test
    void convert_jacksonTimestampArrayWithoutSecondOrNano_returnsLocalDateTime() {
        // Arrays produced without optional trailing elements
        List<Integer> array = List.of(2024, 6, 18, 10, 30);

        assertEquals(LocalDateTime.of(2024, 6, 18, 10, 30, 0), converter.convert(array));
    }

    @Test
    void convert_unsupportedType_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> converter.convert(Boolean.TRUE));
    }
}