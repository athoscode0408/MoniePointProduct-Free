package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.Cohort;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyPlatform;
import com.moniepoint.loans.cas.module.analytics.enums.SurveySegment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest
class CohortStorageTest {

    @Autowired
    private CohortStorage cohortStorage;

    @Test
    void findByActiveTrue_returnsOnlyActiveRows() {
        cohortStorage.save(buildCohort("Personal Banking NPS", true));
        cohortStorage.save(buildCohort("Business Banking NPS", true));
        cohortStorage.save(buildCohort("Inactive Cohort", false));

        List<Cohort> result = cohortStorage.findByActiveTrue();

        assertThat(result).hasSize(2);
        assertThat(result).extracting(Cohort::getName)
                .containsExactlyInAnyOrder("Personal Banking NPS", "Business Banking NPS");
    }

    @Test
    void findByActiveTrue_noActiveCohorts_returnsEmptyList() {
        cohortStorage.save(buildCohort("Inactive Cohort", false));

        List<Cohort> result = cohortStorage.findByActiveTrue();

        assertThat(result).isEmpty();
    }

    @Test
    void ruleDefinition_roundTrips_correctly() {
        String jsonLogic = "{\"and\":[{\"==\":[{\"var\":\"customer_type\"},\"PERSONAL\"]}]}";
        Cohort cohort = buildCohort("Test Cohort", false);
        cohort.setRuleDefinition(jsonLogic);

        Cohort saved = cohortStorage.save(cohort);
        Cohort reloaded = cohortStorage.findById(saved.getId()).orElseThrow();

        assertThat(reloaded.getRuleDefinition()).isEqualTo(jsonLogic);
    }

    @Test
    void compiledClickhouseSql_persistsAndReloads() {
        String sql = "SELECT user_id FROM user_attributes WHERE customer_type = 'PERSONAL'";
        Cohort cohort = buildCohort("SQL Cohort", false);
        cohort.setCompiledClickhouseSql(sql);

        Cohort saved = cohortStorage.save(cohort);
        Cohort reloaded = cohortStorage.findById(saved.getId()).orElseThrow();

        assertThat(reloaded.getCompiledClickhouseSql()).isEqualTo(sql);
    }

    @Test
    void samplingConfig_roundTrips_capPreserved() {
        String config = "{\"type\":\"SIMPLE_RANDOM\",\"cap\":3200}";
        Cohort cohort = buildCohort("Sampling Cohort", false);
        cohort.setSamplingConfig(config);

        Cohort saved = cohortStorage.save(cohort);
        Cohort reloaded = cohortStorage.findById(saved.getId()).orElseThrow();

        assertThat(reloaded.getSamplingConfig()).isEqualTo(config);
        assertThat(reloaded.getSamplingConfig()).contains("3200");
    }

    @Test
    void nullRuleDefinitionAndCompiledSql_persistsWithoutError() {
        Cohort cohort = buildCohort("Unconfigured Cohort", false);
        cohort.setRuleDefinition(null);
        cohort.setCompiledClickhouseSql(null);
        cohort.setSamplingConfig(null);

        Cohort saved = cohortStorage.save(cohort);
        Cohort reloaded = cohortStorage.findById(saved.getId()).orElseThrow();

        assertThat(reloaded.getRuleDefinition()).isNull();
        assertThat(reloaded.getCompiledClickhouseSql()).isNull();
        assertThat(reloaded.getSamplingConfig()).isNull();
        assertThat(reloaded.isActive()).isFalse();
    }

    private Cohort buildCohort(String name, boolean active) {
        Cohort cohort = new Cohort();
        cohort.setName(name);
        cohort.setSurveyId(1L);
        cohort.setActive(active);
        cohort.setSegment(SurveySegment.PERSONAL);
        cohort.setPlatform(SurveyPlatform.MOBILE);
        cohort.setCreatedBy("test");
        cohort.setCreatedOn(Timestamp.from(Instant.now()));
        cohort.setLastModifiedBy("test");
        cohort.setLastModifiedOn(Timestamp.from(Instant.now()));
        return cohort;
    }
}
