package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EligibilityRule;
import com.moniepoint.loans.cas.module.analytics.enums.EligibilityRuleType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest
class EligibilityRuleStorageTest {

    @Autowired
    private EligibilityRuleStorage eligibilityRuleStorage;

    @Test
    void findActiveByCohortId_returnsRulesInRuleOrderSequence() {
        eligibilityRuleStorage.save(buildRule(1L, 2, "ANNUAL_CAP",
                "{\"type\":\"ANNUAL_CAP\",\"maxCount\":2}", true));
        eligibilityRuleStorage.save(buildRule(1L, 1, "COOL_OFF",
                "{\"type\":\"COOL_OFF\",\"days\":90}", true));

        List<EligibilityRule> result = eligibilityRuleStorage.findActiveByCohortId(1L);

        assertThat(result).hasSize(2);
        assertThat(result.get(0).getRuleType()).isEqualTo(EligibilityRuleType.COOL_OFF);
        assertThat(result.get(0).getRuleOrder()).isEqualTo(1);
        assertThat(result.get(1).getRuleType()).isEqualTo(EligibilityRuleType.ANNUAL_CAP);
        assertThat(result.get(1).getRuleOrder()).isEqualTo(2);
    }

    @Test
    void findActiveByCohortId_inactiveRuleExcluded() {
        eligibilityRuleStorage.save(buildRule(2L, 1, "COOL_OFF",
                "{\"type\":\"COOL_OFF\",\"days\":90}", true));
        eligibilityRuleStorage.save(buildRule(2L, 2, "ANNUAL_CAP",
                "{\"type\":\"ANNUAL_CAP\",\"maxCount\":2}", false));

        List<EligibilityRule> result = eligibilityRuleStorage.findActiveByCohortId(2L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRuleType()).isEqualTo(EligibilityRuleType.COOL_OFF);
    }

    @Test
    void findActiveByCohortId_unknownCohortId_returnsEmptyList() {
        List<EligibilityRule> result = eligibilityRuleStorage.findActiveByCohortId(999L);

        assertThat(result).isEmpty();
    }

    @Test
    void ruleConfig_roundTrips_daysFieldPreserved() {
        String config = "{\"type\":\"COOL_OFF\",\"sourceTable\":\"nps_user_state\",\"dateField\":\"last_nps_triggered_date\",\"days\":90}";
        eligibilityRuleStorage.save(buildRule(3L, 1, "COOL_OFF", config, true));

        List<EligibilityRule> result = eligibilityRuleStorage.findActiveByCohortId(3L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRuleConfig()).isEqualTo(config);
        assertThat(result.get(0).getRuleConfig()).contains("\"days\":90");
    }

    private EligibilityRule buildRule(Long cohortId, int ruleOrder, String ruleType,
                                      String ruleConfig, boolean active) {
        EligibilityRule rule = new EligibilityRule();
        rule.setCohortId(cohortId);
        rule.setRuleOrder(ruleOrder);
        rule.setRuleType(EligibilityRuleType.valueOf(ruleType));
        rule.setRuleConfig(ruleConfig);
        rule.setActive(active);
        rule.setCreatedOn(LocalDateTime.now());
        return rule;
    }
}
