package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
@DataJpaTest
class EventDeadLetterRepositoryTests {

    private static final String EVENT_ID = "1234";
    private static final EventProvider EVENT_PROVIDER = EventProvider.MIX;
    private static final LocalDateTime LAST_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 15, 0);

    @Autowired
    private EventDeadLetterRepository eventDeadLetterRepository;

    @Test
    void findByEventIdAndEventProvider_success() {
        String eventData = """
                "data": {
                    "email" : "test@test.co",
                    "username" : "test.user"
                   }
                """;
        EventDeadLetter eventDeadLetter = EventDeadLetter.builder()
                .eventId(EVENT_ID)
                .eventProvider(EVENT_PROVIDER)
                .eventData(eventData)
                .lastRetryTime(LAST_RETRY_DATE_TIME)
                .lastFailureReason("Failed")
                .build();
        eventDeadLetter.setCreatedBy("someTest");
        eventDeadLetter.setCreatedOn(Timestamp.from(Instant.now()));
        eventDeadLetter.setLastModifiedBy("someTest");
        eventDeadLetter.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventDeadLetterRepository.save(eventDeadLetter);

        Optional<EventDeadLetter> eventDeadLetterOptional = eventDeadLetterRepository.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER);

        assertTrue(eventDeadLetterOptional.isPresent());
        assertEquals(eventDeadLetter, eventDeadLetterOptional.get());
    }

    @Test
    void findByEventIdAndEventProvider_nonExistingEventIdWithProvider_returnsEmpty() {
        Optional<EventDeadLetter> eventDeadLetterOptional = eventDeadLetterRepository.findByEventIdAndEventProvider(EVENT_ID, EventProvider.CIO);

        assertTrue(eventDeadLetterOptional.isEmpty());
    }

}
