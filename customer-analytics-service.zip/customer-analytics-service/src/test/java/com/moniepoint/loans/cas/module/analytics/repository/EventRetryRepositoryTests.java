package com.moniepoint.loans.cas.module.analytics.repository;

import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
@DataJpaTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class EventRetryRepositoryTests {

    private static final String EVENT_ID = "1234";
    private static final String EVENT_DATA = """
            "data": {
                "email" : "test@test.co",
                "username" : "test.user"
               }
            """;
    private static final EventProvider EVENT_PROVIDER = EventProvider.MIX;
    private static final LocalDateTime LAST_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 15, 0);
    private static final LocalDateTime NEXT_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 20, 0);

    private static final EventRetry EVENT_RETRY = EventRetry.builder()
            .eventId(EVENT_ID)
            .eventProvider(EVENT_PROVIDER)
            .eventData(EVENT_DATA)
            .attemptCount(3)
            .lastRetryTime(LAST_RETRY_DATE_TIME)
            .nextRetryTime(NEXT_RETRY_DATE_TIME)
            .lastFailureReason("Failed")
            .build();

    @Autowired
    private EventRetryRepository eventRetryRepository;

    @BeforeEach
    void setup() {
        EVENT_RETRY.setCreatedBy("someTest");
        EVENT_RETRY.setCreatedOn(Timestamp.from(Instant.now()));
        EVENT_RETRY.setLastModifiedBy("someTest");
        EVENT_RETRY.setLastModifiedOn(Timestamp.from(Instant.now()));
    }

    @Test
    void findByEventIdAndEventProvider_success() {
        eventRetryRepository.save(EVENT_RETRY);

        Optional<EventRetry> eventRetryOptional = eventRetryRepository.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER);

        assertTrue(eventRetryOptional.isPresent());
        assertEquals(EVENT_RETRY, eventRetryOptional.get());
    }

    @Test
    void findByEventIdAndEventProvider_nonExistingEventIdWithProvider_returnsEmpty() {
        Optional<EventRetry> eventRetryOptional = eventRetryRepository.findByEventIdAndEventProvider(EVENT_ID, EventProvider.CIO);

        assertTrue(eventRetryOptional.isEmpty());
    }

    @Test
    void findMinId_success() {
        EventRetry eventRetryWithIdOne = EVENT_RETRY.toBuilder().build();
        EventRetry eventRetryWithIdTwo = EVENT_RETRY.toBuilder().build();

        eventRetryWithIdOne.setCreatedBy("someTest");
        eventRetryWithIdOne.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdOne.setLastModifiedBy("someTest");
        eventRetryWithIdOne.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryWithIdTwo.setCreatedBy("someTest");
        eventRetryWithIdTwo.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdTwo.setLastModifiedBy("someTest");
        eventRetryWithIdTwo.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryRepository.save(eventRetryWithIdOne);
        eventRetryRepository.save(eventRetryWithIdTwo);

        Long minId = eventRetryRepository.findMinId();

        assertEquals(1L, minId);
    }

    @Test
    void findMaxId_success() {
        EventRetry eventRetryWithIdOne = EVENT_RETRY.toBuilder().build();
        EventRetry eventRetryWithIdTwo = EVENT_RETRY.toBuilder().build();

        eventRetryWithIdOne.setCreatedBy("someTest");
        eventRetryWithIdOne.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdOne.setLastModifiedBy("someTest");
        eventRetryWithIdOne.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryWithIdTwo.setCreatedBy("someTest");
        eventRetryWithIdTwo.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdTwo.setLastModifiedBy("someTest");
        eventRetryWithIdTwo.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryRepository.save(eventRetryWithIdOne);
        eventRetryRepository.save(eventRetryWithIdTwo);

        Long maxId = eventRetryRepository.findMaxId(1L,100L);

        assertEquals(2L, maxId);
    }

    @Test
    void findIdsInRange_success() {
        Pageable pageable = PageRequest.of(0, 5, Sort.by("id").ascending());

        EventRetry eventRetryWithIdOne = EVENT_RETRY.toBuilder().build();
        EventRetry eventRetryWithIdTwo = EVENT_RETRY.toBuilder().build();

        eventRetryWithIdOne.setCreatedBy("someTest");
        eventRetryWithIdOne.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdOne.setLastModifiedBy("someTest");
        eventRetryWithIdOne.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryWithIdTwo.setCreatedBy("someTest");
        eventRetryWithIdTwo.setCreatedOn(Timestamp.from(Instant.now()));
        eventRetryWithIdTwo.setLastModifiedBy("someTest");
        eventRetryWithIdTwo.setLastModifiedOn(Timestamp.from(Instant.now()));

        eventRetryRepository.save(eventRetryWithIdOne);
        eventRetryRepository.save(eventRetryWithIdTwo);

        Page<Long> ids = eventRetryRepository.findIdsInRange(1L, 10L, pageable);

        assertEquals(List.of(1L, 2L), ids.getContent());
    }

}
