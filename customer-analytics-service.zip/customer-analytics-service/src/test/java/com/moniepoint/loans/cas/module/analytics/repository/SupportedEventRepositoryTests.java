package com.moniepoint.loans.cas.module.analytics.repository;


import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ActiveProfiles("test")
@DataJpaTest
class SupportedEventRepositoryTests {

    @Autowired
    private SupportedEventRepository supportedEventRepository;


    @Test
    void findByEventType_success() {
        SupportedEvent supportedEvent = SupportedEvent.builder()
                .eventType("prequalification")
                .build();
        supportedEvent.setCreatedBy("someTest");
        supportedEvent.setCreatedOn(Timestamp.from(Instant.now()));
        supportedEvent.setLastModifiedBy("someTest");
        supportedEvent.setLastModifiedOn(Timestamp.from(Instant.now()));

        supportedEventRepository.save(supportedEvent);

        Optional<SupportedEvent> supportedEventOptional = supportedEventRepository.findByEventType("prequalification");

        assertTrue(supportedEventOptional.isPresent());
        assertEquals(supportedEvent, supportedEventOptional.get());
        assertTrue(supportedEventOptional.get().getProviders().isEmpty());
    }

    @Test
    void findByEventType_nonExistingEventType_returnsEmpty() {
        Optional<SupportedEvent> supportedEventOptional = supportedEventRepository.findByEventType("prequalification");

        assertTrue(supportedEventOptional.isEmpty());
    }

}
