package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.AnalyticsEventProviderRepository;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Mock test to run on CI. For local tests, consider using AnalyticsEventProviderRepositoryTests
 * since it allows testing with proper containers
 */
@ExtendWith(MockitoExtension.class)
class AnalyticsEventProviderRepositoryMockTests {

    private AnalyticsEventProviderRepositoryService repositoryService;

    @Mock
    private AnalyticsEventProviderRepository analyticsEventProviderRepository;
    @Mock
    private RedisTemplate<String, String> redisTemplate;

    @Mock
    private ValueOperations<String, String> valueOperations;

    @BeforeEach
    void setUp() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        repositoryService = new AnalyticsEventProviderRepositoryService(
                analyticsEventProviderRepository,
                new RedisCacheServiceImpl(redisTemplate, 60, new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()))),
                new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()))
        );
    }

    @Test
    void testFindingSupportedProvidersByEventType() {
        when(valueOperations.get("SUPPORTED_ANALYTICS_PROVIDERS")).thenReturn(null);

        when(analyticsEventProviderRepository.findAllWithEvents()).thenReturn(List.of(
                new AnalyticsEventProvider("Mixpanel", EventProvider.MIX, Set.of()),
                new AnalyticsEventProvider("Google Analytics", EventProvider.GA, Set.of()),
                new AnalyticsEventProvider("Braze", EventProvider.BRAZE, Set.of(
                        new SupportedEvent("braze_supported_event", new HashSet<>(), new HashSet<>())
                ))
        ));
        var providers = repositoryService.getSupportedEventProviders(Set.of("payment_confirmation"));
        assertEquals(2, providers.get("payment_confirmation").size());
    }

    @Test
    void testFindingSupportedProvidersByEventTypeFromCache() {
        when(valueOperations.get("SUPPORTED_ANALYTICS_PROVIDERS")).thenReturn(new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry())).serializeToString(Map.of(
                EventProvider.BRAZE, List.of("braze_supported_event", "login"),
                EventProvider.MIX, List.of(),
                EventProvider.GA, List.of()
        )));

        var providers = repositoryService.getSupportedEventProviders(Set.of("login"));
        assertEquals(3, providers.get("login").size());
    }

    @Test
    void getAllowListedEventTypes_returnsCachedEventsForProvider() {
        when(valueOperations.get("SUPPORTED_ANALYTICS_PROVIDERS")).thenReturn(new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry())).serializeToString(Map.of(
                EventProvider.BRAZE, List.of("dashboard_load_success", "sign_in_success"),
                EventProvider.MIX, List.of("mixpanel_only_event")
        )));

        var events = repositoryService.getAllowListedEventTypes(EventProvider.BRAZE);

        assertEquals(List.of("dashboard_load_success", "sign_in_success"), events);
    }

    @Test
    void getAllowListedEventTypes_returnsEmptyListWhenProviderNotAllowListed() {
        when(valueOperations.get("SUPPORTED_ANALYTICS_PROVIDERS")).thenReturn(new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry())).serializeToString(Map.of(
                EventProvider.MIX, List.of("mixpanel_only_event")
        )));

        var events = repositoryService.getAllowListedEventTypes(EventProvider.BRAZE);

        assertEquals(List.of(), events);
    }
}
