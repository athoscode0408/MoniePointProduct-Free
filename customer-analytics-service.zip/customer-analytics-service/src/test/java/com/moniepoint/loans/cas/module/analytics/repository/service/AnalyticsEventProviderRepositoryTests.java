package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.AnalyticsEventProviderRepository;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedEventRepository;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import com.redis.testcontainers.RedisContainer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Testcontainers
@SpringBootTest
@Disabled("Do not run this in CI, since downloading the docker images takes a long time")
class AnalyticsEventProviderRepositoryTests {

    private AnalyticsEventProviderRepositoryService repositoryService;

    @Autowired
    private AnalyticsEventProviderRepository analyticsEventProviderRepository;
    @Autowired
    private SupportedEventRepository supportedEventRepository;
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Container
    public static MySQLContainer<?> mySQL = new MySQLContainer<>("mysql:8.0.36");

    @Container
    private static final RedisContainer redis = new RedisContainer(DockerImageName.parse("redis:6.2.6"));

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", mySQL::getJdbcUrl);
        registry.add("spring.datasource.username", mySQL::getUsername);
        registry.add("spring.datasource.password", mySQL::getPassword);

        registry.add("spring.data.redis.host", redis::getHost);
        registry.add("spring.data.redis.port", () -> redis.getMappedPort(6379).toString());
    }

    @BeforeEach
    void setUp() {
        supportedEventRepository.deleteAll();
        analyticsEventProviderRepository.deleteAll();

        analyticsEventProviderRepository.saveAll(Set.of(
                new AnalyticsEventProvider("Mixpanel", EventProvider.MIX, Set.of()),
                new AnalyticsEventProvider("Google Analytics", EventProvider.GA, Set.of())
        ));
        var braze = new AnalyticsEventProvider("Braze", EventProvider.BRAZE, new HashSet<>());
        var brazeSupportedEvent = new SupportedEvent("braze_supported_event", new HashSet<>(), new HashSet<>());
        braze.getEvents().add(brazeSupportedEvent);
        brazeSupportedEvent.getProviders().add(braze);
        supportedEventRepository.saveAndFlush(brazeSupportedEvent);

        repositoryService = new AnalyticsEventProviderRepositoryService(
                analyticsEventProviderRepository,
                new RedisCacheServiceImpl(redisTemplate, 60, new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()))),
                new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()))
        );
    }

    @Test
    void testFindingSupportedProvidersByEventType() {
        var providers = repositoryService.getSupportedEventProviders(Set.of("payment_confirmation"));
        assertEquals(2, providers.get("payment_confirmation").size());
    }

    @Test
    void testFindingSupportedProvidersByEventTypeFromCache() {
        var cachedList = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry())).serializeToString(Map.of(
                EventProvider.BRAZE, List.of("braze_supported_event", "login"),
                EventProvider.MIX, List.of(),
                EventProvider.GA, List.of()
        ));
        redisTemplate.opsForValue().set(
                "SUPPORTED_ANALYTICS_PROVIDERS",
                cachedList,
                30,
                TimeUnit.SECONDS
        );

        var providers = repositoryService.getSupportedEventProviders(Set.of("login"));
        assertEquals(3, providers.get("login").size());
    }
}
