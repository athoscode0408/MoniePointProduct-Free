package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.EventDeadLetterRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventDeadLetterRepositoryServiceTests {

    private static final String EVENT_ID = "1234";
    private static final String EVENT_DATE = """
            "data": {
                "email" : "test@test.co",
                "username" : "test.user"
               }
            """;

    private static final EventProvider EVENT_PROVIDER = EventProvider.MIX;

    private static final LocalDateTime LAST_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 15, 0);

    private static final EventDeadLetter EVENT_DEAD_LETTER = EventDeadLetter.builder()
            .eventId(EVENT_ID)
            .eventProvider(EVENT_PROVIDER)
            .eventData(EVENT_DATE)
            .lastRetryTime(LAST_RETRY_DATE_TIME)
            .lastFailureReason("Failed")
            .build();

    @Mock
    private EventDeadLetterRepository eventDeadLetterRepository;

    @InjectMocks
    private EventDeadLetterRepositoryService eventDeadLetterRepositoryService;

    @BeforeEach
    void setup() {
        EVENT_DEAD_LETTER.setCreatedBy("someTest");
        EVENT_DEAD_LETTER.setCreatedOn(Timestamp.from(Instant.now()));
        EVENT_DEAD_LETTER.setLastModifiedBy("someTest");
        EVENT_DEAD_LETTER.setLastModifiedOn(Timestamp.from(Instant.now()));
    }

    @Test
    void save_success() {
        when(eventDeadLetterRepository.save(EVENT_DEAD_LETTER)).thenReturn(EVENT_DEAD_LETTER);

        EventDeadLetter savedEventDeadLetter = eventDeadLetterRepositoryService.save(EVENT_DEAD_LETTER);

        assertNotNull(savedEventDeadLetter);
        assertEquals(EVENT_DEAD_LETTER, savedEventDeadLetter);
    }

    @Test
    void findByEventIdAndEventProvider_success() {
        when(eventDeadLetterRepository.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER)).thenReturn(Optional.of(EVENT_DEAD_LETTER));

        Optional<EventDeadLetter> eventDeadLetterOptional = eventDeadLetterRepositoryService.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER);

        assertTrue(eventDeadLetterOptional.isPresent());
        assertEquals(EVENT_DEAD_LETTER, eventDeadLetterOptional.get());
    }

    @Test
    void deleteAllEventDeadLetter_success(){
        eventDeadLetterRepositoryService.deleteAllEventDeadLetter();

        verify(eventDeadLetterRepository, times(1)).deleteAll();
    }

}
