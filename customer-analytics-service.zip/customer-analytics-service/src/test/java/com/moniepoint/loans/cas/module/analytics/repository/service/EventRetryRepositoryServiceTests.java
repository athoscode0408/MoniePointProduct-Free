package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryRepositoryServiceTests {

    private static final String EVENT_ID = "1234";
    private static final String EVENT_DATE = """
            "data": {
                "email" : "test@test.co",
                "username" : "test.user"
               }
            """;

    private static final EventProvider EVENT_PROVIDER = EventProvider.MIX;

    private static final LocalDateTime LAST_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 15, 0);
    private static final LocalDateTime NEXT_RETRY_DATE_TIME = LocalDateTime.of(2024, 10, 22, 10, 20, 0);

    private static final EventRetry EVENT_RETRY = EventRetry.builder()
            .eventId(EVENT_ID)
            .eventProvider(EVENT_PROVIDER)
            .eventData(EVENT_DATE)
            .attemptCount(3)
            .lastRetryTime(LAST_RETRY_DATE_TIME)
            .nextRetryTime(NEXT_RETRY_DATE_TIME)
            .lastFailureReason("Failed")
            .build();

    @Mock
    private EventRetryRepository eventRetryRepository;

    @InjectMocks
    private EventRetryRepositoryService eventRetryRepositoryService;

    @BeforeEach
    void setup() {
        EVENT_RETRY.setCreatedBy("someTest");
        EVENT_RETRY.setCreatedOn(Timestamp.from(Instant.now()));
        EVENT_RETRY.setLastModifiedBy("someTest");
        EVENT_RETRY.setLastModifiedOn(Timestamp.from(Instant.now()));
    }

    @Test
    void save_success() {
        when(eventRetryRepository.save(EVENT_RETRY)).thenReturn(EVENT_RETRY);

        EventRetry savedEventRetry = eventRetryRepositoryService.save(EVENT_RETRY);

        assertNotNull(savedEventRetry);
        assertEquals(EVENT_RETRY, savedEventRetry);
    }

    @Test
    void findByEventIdAndEventProvider_success() {
        when(eventRetryRepository.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER)).thenReturn(Optional.of(EVENT_RETRY));

        Optional<EventRetry> eventRetryOptional = eventRetryRepositoryService.findByEventIdAndEventProvider(EVENT_ID, EVENT_PROVIDER);

        assertTrue(eventRetryOptional.isPresent());
        assertEquals(EVENT_RETRY, eventRetryOptional.get());
    }

    @Test
    void findMaxEventRetryId_success() {
        when(eventRetryRepository.findMaxId(1L, 100L)).thenReturn(10L);

        Long maxId = eventRetryRepositoryService.findMaxEventRetryId(1L, 100L);

        assertEquals(10L, maxId);
        verify(eventRetryRepository, times(1)).findMaxId(1L, 100L);
    }

    @Test
    void findMinEventRetryId_success() {
        when(eventRetryRepository.findMinId()).thenReturn(2L);

        Long minId = eventRetryRepositoryService.findMinEventRetryId();

        assertEquals(2L, minId);
        verify(eventRetryRepository, times(1)).findMinId();
    }

    @Test
    void fetchPaginatedIdsInRange_success(){
        Pageable pageable = PageRequest.of(0, 5, Sort.by("id").ascending());
        Page<Long> result = new PageImpl<>(List.of(2L, 4L), pageable, 2);

        when(eventRetryRepository.findIdsInRange(1L, 10L, pageable)).thenReturn(result);

        Page<Long> ids = eventRetryRepositoryService.fetchPaginatedIdsInRange(1L, 10L, 0, 5);

        assertEquals(List.of(2L, 4L), ids.getContent());
        verify(eventRetryRepository, times(1)).findIdsInRange(1L, 10L, pageable);
    }

    @Test
    void findEventRetryById_success() {
        when(eventRetryRepository.findById(10L)).thenReturn(Optional.of(EVENT_RETRY));

        Optional<EventRetry> eventRetryOptional = eventRetryRepositoryService.findEventRetryById(10L);

        assertEquals(EVENT_RETRY, eventRetryOptional.get());
        verify(eventRetryRepository, times(1)).findById(10L);
    }

    @Test
    void deleteById_success() {
        doNothing().when(eventRetryRepository).deleteById(10L);

        eventRetryRepositoryService.deleteById(10L);

        verify(eventRetryRepository, times(1)).deleteById(10L);
    }
}
