package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyHistoryItemDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyHistoryResponse;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveySchemaDTO;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyAlertStorage;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySampleService;
import com.moniepoint.loans.cas.common.util.IsoWeekUtil;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.springframework.test.util.ReflectionTestUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static org.mockito.Mockito.*;

/**
 * Mock test to run on CI. For local tests, consider using AnalyticsEventProviderRepositoryTests
 * since it allows testing with proper containers
 */
@ExtendWith(MockitoExtension.class)
class PreprocessedSurveyRepositoryServiceTests {

    @Mock
    private PreprocessedSurveyStorage surveyRepository;

    @Mock
    ObjectMapperHelper objectMapperHelper;

    @Mock
    RedisCacheServiceImpl cacheService;

    @Mock
    SurveyRepositoryService surveyRepositoryService;

    @Mock
    UserAttributesStorage userStorage;

    @Mock
    SurveyAlertStorage surveyAlertStorage;

    @Mock
    NpsWeeklySampleService npsWeeklySampleService;

    @InjectMocks
    private PreprocessedSurveyRepositoryService surveyService;

    private PreprocessedSurvey survey;
    private PreprocessedSurveyDTO preprocessedSurveyDTO;


    @BeforeEach
    void setUp() {
        survey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .survey("{\"sample\":\"data\"}")
                .build();

        preprocessedSurveyDTO = PreprocessedSurveyDTO.builder()
                .surveyId(1L)
                .user("user-1")
                .survey("{\"sample\":\"data\"}")
                .build();
    }

    @Test
    void shouldReturnSurveysByUserId() {
        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class))).thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        List<PreprocessedSurveyDTO> result = surveyService.fetchSurveysByUserId("user-1");
        List<PreprocessedSurveyDTO> resultList = new ArrayList<>(result);

        Assertions.assertNotNull(resultList);
        Assertions.assertEquals(1, resultList.size());
        Assertions.assertEquals((Long)1L, resultList.getFirst().getSurveyId());
        verify(surveyRepository, times(1)).findByUserAndStateInAndTtlAfter(any(), any(),any(Timestamp.class));
    }

    @Test
    void shouldReturnSurveyBySurveyId() {
        when(surveyRepository.findByIdAndStateInAndTtlAfter(any(),any(), any(Timestamp.class))).thenReturn(Optional.ofNullable(survey));
        preprocessedSurveyDTO = PreprocessedSurveyDTO.builder()
                .surveyId(3L)
                .user("user-1")
                .survey("{\"sample\":\"data\"}")
                .build();
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());
        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(3L);

        Assertions.assertNotNull(result);
        Assertions.assertEquals((Long)3L, result.getSurveyId());
        verify(surveyRepository, times(1)).findByIdAndStateInAndTtlAfter(any(), any(), any());
    }

    @Test
    void shouldReturnEmptyWhenSurveyDoesNotExist() {
        when(surveyRepository.findByIdAndStateInAndTtlAfter(any(), any(),any(Timestamp.class))).thenReturn(Optional.empty());
        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(7L);
        Assertions.assertNull(result);
    }

    @Test
    void shouldReturnSurveyHistory() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);
        Timestamp ttl = Timestamp.valueOf(LocalDateTime.of(2025, 2, 1, 0, 0, 0));
        Timestamp completedOn = Timestamp.valueOf(LocalDateTime.of(2025, 1, 15, 10, 0, 0));

        PreprocessedSurvey historySurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .event("SURVEY_TRIGGERED")
                .ttl(ttl)
                .state(PreprocessedSurveyState.COMPLETED)
                .completedOn(completedOn)
                .additionalData("{\"key\":\"value\"}")
                .build();

        when(surveyRepository.findByUserAndSurveyIdAndLastModifiedOnBetween(eq("user-1"), eq(1L), any(Timestamp.class), any(Timestamp.class)))
                .thenReturn(List.of(historySurvey));
        when(objectMapperHelper.deserializeStringToObject(eq("{\"key\":\"value\"}"), any()))
                .thenReturn(Map.of("key", "value"));

        SurveyHistoryResponse response = surveyService.fetchSurveyHistory("user-1", 1L, startDate, endDate);

        Assertions.assertNotNull(response);
        Assertions.assertEquals(1, response.getSurveys().size());
        SurveyHistoryItemDTO item = response.getSurveys().getFirst();
        Assertions.assertEquals("SURVEY_TRIGGERED", item.getEvent());
        Assertions.assertEquals(PreprocessedSurveyState.COMPLETED, item.getState());
        Assertions.assertEquals(ttl.toLocalDateTime(), item.getTtl());
        Assertions.assertEquals(completedOn.toLocalDateTime(), item.getCompletedOn());
        Assertions.assertNotNull(item.getAdditionalData());
        verify(surveyRepository, times(1)).findByUserAndSurveyIdAndLastModifiedOnBetween(eq("user-1"), eq(1L), any(Timestamp.class), any(Timestamp.class));
    }

    @Test
    void shouldReturnEmptySurveyHistory() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);

        when(surveyRepository.findByUserAndSurveyIdAndLastModifiedOnBetween(any(), any(), any(Timestamp.class), any(Timestamp.class)))
                .thenReturn(List.of());

        SurveyHistoryResponse response = surveyService.fetchSurveyHistory("user-1", 1L, startDate, endDate);

        Assertions.assertNotNull(response);
        Assertions.assertTrue(response.getSurveys().isEmpty());
    }

    @Test
    void shouldMapNullAdditionalDataToNull() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);

        PreprocessedSurvey historySurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .event("SURVEY_TRIGGERED")
                .additionalData(null)
                .build();

        when(surveyRepository.findByUserAndSurveyIdAndLastModifiedOnBetween(any(), any(), any(Timestamp.class), any(Timestamp.class)))
                .thenReturn(List.of(historySurvey));

        SurveyHistoryResponse response = surveyService.fetchSurveyHistory("user-1", 1L, startDate, endDate);

        Assertions.assertNull(response.getSurveys().getFirst().getAdditionalData());
        verify(objectMapperHelper, never()).deserializeStringToObject(any(), any());
    }

    @Test
    void shouldFallBackToRawStringWhenAdditionalDataDeserializationFails() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);

        PreprocessedSurvey historySurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .event("SURVEY_TRIGGERED")
                .additionalData("plain-text-value")
                .build();

        when(surveyRepository.findByUserAndSurveyIdAndLastModifiedOnBetween(any(), any(), any(Timestamp.class), any(Timestamp.class)))
                .thenReturn(List.of(historySurvey));
        when(objectMapperHelper.deserializeStringToObject(eq("plain-text-value"), any()))
                .thenThrow(new RuntimeException("not valid json"));

        SurveyHistoryResponse response = surveyService.fetchSurveyHistory("user-1", 1L, startDate, endDate);

        Assertions.assertEquals("plain-text-value", response.getSurveys().getFirst().getAdditionalData());
    }

    @Test
    void shouldReturnSurveySchema() {
        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(1L);
        when(survey.getSurvey()).thenReturn("{\"id\":\"nps_v1\"}");
        when(surveyRepositoryService.findById(1L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        SurveySchemaDTO result = surveyService.fetchSurveySchema(1L, "user-1", new UserAttributes());

        Assertions.assertNotNull(result);
        Assertions.assertEquals(1L, result.getId());
        Assertions.assertEquals("{\"id\":\"nps_v1\"}", result.getSurvey());
        Assertions.assertNull(result.getPreprocessedSurveyId());
        verify(surveyRepositoryService, times(1)).findById(1L);
        verify(userStorage, never()).findUser(any(), any());
    }

    @Test
    void shouldReturnPreprocessedSurveyDataDirectlyWhenPreprocessedSurveyExists() {
        PreprocessedSurvey preprocessedSurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .survey("{\"id\":\"nps_v1\",\"questions\":[]}")
                .build();
        preprocessedSurvey.setId(42L);
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(eq("user-1"), eq(1L), any(), any(Timestamp.class)))
                .thenReturn(Optional.of(preprocessedSurvey));

        SurveySchemaDTO result = surveyService.fetchSurveySchema(1L, "user-1", new UserAttributes());

        Assertions.assertNotNull(result);
        Assertions.assertEquals(1L, result.getId());
        Assertions.assertEquals("{\"id\":\"nps_v1\",\"questions\":[]}", result.getSurvey());
        Assertions.assertEquals(42L, result.getPreprocessedSurveyId());
        verify(surveyRepositoryService, never()).findById(any());
        verify(userStorage, never()).findUser(any(), any());
    }

    @Test
    void shouldReturnNullWhenSurveySchemaNotFound() {
        when(surveyRepositoryService.findById(99L)).thenReturn(Optional.empty());
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        SurveySchemaDTO result = surveyService.fetchSurveySchema(99L, "user-1", new UserAttributes());

        Assertions.assertNull(result);
        verify(surveyRepositoryService, times(1)).findById(99L);
    }

    @Test
    void shouldNotEnrichSchemaWhenNoPlaceholdersPresent() {
        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(2L);
        when(survey.getSurvey()).thenReturn("{\"id\":\"static_survey\"}");
        when(surveyRepositoryService.findById(2L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        UserAttributes attrs = new UserAttributes();
        attrs.setNubanAccountNumber("1234567890");

        SurveySchemaDTO result = surveyService.fetchSurveySchema(2L, "user-1", attrs);

        Assertions.assertEquals("{\"id\":\"static_survey\"}", result.getSurvey());
        verify(userStorage, never()).findUser(any(), any());
    }

    @Test
    void shouldNotEnrichSchemaWhenUserAttributesEmpty() {
        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(3L);
        when(survey.getSurvey()).thenReturn("{\"greeting\":\"Hello ${user.FirstName}\"}");
        when(surveyRepositoryService.findById(3L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        SurveySchemaDTO result = surveyService.fetchSurveySchema(3L, "user-1", new UserAttributes());

        Assertions.assertEquals("{\"greeting\":\"Hello ${user.FirstName}\"}", result.getSurvey());
        verify(userStorage, never()).findUser(any(), any());
    }

    @Test
    void shouldEnrichSchemaWithBigtableUserAttributes() {
        ReflectionTestUtils.setField(surveyService, "imageLocationUrl", "https://images.example.com/");

        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(4L);
        when(survey.getSurvey()).thenReturn("{\"greeting\":\"Hello ${user.FirstName}\"}");
        when(surveyRepositoryService.findById(4L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        UserAttributes requestAttrs = new UserAttributes();
        requestAttrs.setNubanAccountNumber("1234567890");

        UserAttributes bigtableUser = new UserAttributes();
        bigtableUser.setFirstName("John");
        when(userStorage.findUser("user-1", "1234567890")).thenReturn(bigtableUser);

        SurveySchemaDTO result = surveyService.fetchSurveySchema(4L, "user-1", requestAttrs);

        Assertions.assertEquals("{\"greeting\":\"Hello John\"}", result.getSurvey());
        verify(userStorage, times(1)).findUser("user-1", "1234567890");
    }

    @Test
    void shouldFallBackToRequestAttributesWhenBigtableReturnsNull() {
        ReflectionTestUtils.setField(surveyService, "imageLocationUrl", "https://images.example.com/");

        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(5L);
        when(survey.getSurvey()).thenReturn("{\"greeting\":\"Hello ${user.FirstName}\"}");
        when(surveyRepositoryService.findById(5L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        UserAttributes requestAttrs = new UserAttributes();
        requestAttrs.setNubanAccountNumber("9999999999");
        requestAttrs.setFirstName("Jane");
        when(userStorage.findUser("user-1", "9999999999")).thenReturn(null);

        SurveySchemaDTO result = surveyService.fetchSurveySchema(5L, "user-1", requestAttrs);

        Assertions.assertEquals("{\"greeting\":\"Hello Jane\"}", result.getSurvey());
    }

    @Test
    void shouldEncodeBrmImageWhenBusinessAccountNumberPresent() {
        ReflectionTestUtils.setField(surveyService, "imageLocationUrl", "https://images.example.com/");

        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(6L);
        when(survey.getSurvey()).thenReturn("{\"image\":\"${user.BrmImage}\"}");
        when(surveyRepositoryService.findById(6L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        UserAttributes requestAttrs = new UserAttributes();
        requestAttrs.setBusinessNubanAccountNumber("0987654321");

        UserAttributes bigtableUser = new UserAttributes();
        bigtableUser.setBrmImage("path/to image.png");
        when(userStorage.findUser("user-1", "0987654321")).thenReturn(bigtableUser);

        SurveySchemaDTO result = surveyService.fetchSurveySchema(6L, "user-1", requestAttrs);

        Assertions.assertTrue(result.getSurvey().contains("https://images.example.com/"));
        Assertions.assertTrue(result.getSurvey().contains("?requestType=BRM_IMAGE"));
    }

    @Test
    void shouldSkipBigtableLookupWhenNoAccountNumber() {
        Survey survey = mock(Survey.class);
        when(survey.getId()).thenReturn(7L);
        when(survey.getSurvey()).thenReturn("{\"greeting\":\"Hello ${user.FirstName}\"}");
        when(surveyRepositoryService.findById(7L)).thenReturn(Optional.of(survey));
        when(surveyRepository.findFirstByUserAndSurveyIdAndStateInAndTtlAfter(any(), any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.empty());

        UserAttributes requestAttrs = new UserAttributes();
        requestAttrs.setFirstName("Alice");

        SurveySchemaDTO result = surveyService.fetchSurveySchema(7L, "user-1", requestAttrs);

        Assertions.assertEquals("{\"greeting\":\"Hello Alice\"}", result.getSurvey());
        verify(userStorage, never()).findUser(any(), any());
    }

//    @Test
//    void shouldReturnAlertsForUserByAccountNumber() {
//        UserAttributes userAttributes = new UserAttributes();
//        userAttributes.addCustomAttributes("agent_id", "agent_id_json");
//        when(userStorage.findUser("user-1")).thenReturn(userAttributes);
//        when(objectMapperHelper.deserializeStringToObject(any(), any()))
//                .thenReturn(Map.of("account-1", "agent-123"));
//
//        SurveyAlert surveyAlert = SurveyAlert.builder()
//                .user("user-1")
//                .event("NPS_SURVEY_EVENT")
//                .preprocessedSurveyId(10L)
//                .accountNumber("account-1")
//                .alertType("INFO")
//                .alertPriority(1)
//                .alertTitle("BO-BRM Alert")
//                .alertMessage("Rate your BRM here")
//                .alertActionLabel("View Details")
//                .alertDismissible(false)
//                .build();
//        when(surveyAlertStorage.findByUserAndAccountNumberAndTtlAfter(eq("user-1"), eq("account-1"), any(Timestamp.class)))
//                .thenReturn(List.of(surveyAlert));
//
//        SurveyAlertsResponse response = surveyService.fetchSurveyAlerts("user-1", "agent-123");
//
//        Assertions.assertNotNull(response);
//        Assertions.assertEquals(1, response.getAlerts().size());
//        SurveyAlertDTO alert = response.getAlerts().getFirst();
//        Assertions.assertEquals("NPS_SURVEY_EVENT", alert.getId());
//        Assertions.assertEquals("INFO", alert.getType());
//        Assertions.assertEquals(1, alert.getPriority());
//        Assertions.assertEquals("BO-BRM Alert", alert.getTitle());
//        Assertions.assertEquals("Rate your BRM here", alert.getMessage());
//        Assertions.assertEquals("View Details", alert.getAction().getLabel());
//        Assertions.assertEquals("/survey/10", alert.getAction().getTarget());
//        Assertions.assertFalse(alert.isDismissible());
//    }

//    @Test
//    void shouldReturnEmptyAlertsWhenNoNonExpiredAlertsFoundForAccount() {
//        UserAttributes userAttributes = new UserAttributes();
//        userAttributes.addCustomAttributes("agent_id", "agent_id_json");
//        when(userStorage.findUser("user-1")).thenReturn(userAttributes);
//        when(objectMapperHelper.deserializeStringToObject(any(), any()))
//                .thenReturn(Map.of("account-1", "agent-123"));
//        when(surveyAlertStorage.findByUserAndAccountNumberAndTtlAfter(eq("user-1"), eq("account-1"), any(Timestamp.class)))
//                .thenReturn(List.of());
//
//        SurveyAlertsResponse response = surveyService.fetchSurveyAlerts("user-1", "agent-123");
//
//        Assertions.assertTrue(response.getAlerts().isEmpty());
//    }

//    @Test
//    void shouldReturnEmptyAlertsWhenUserAttributesNotFound() {
//        when(userStorage.findUser("user-1")).thenReturn(null);
//
//        SurveyAlertsResponse response = surveyService.fetchSurveyAlerts("user-1", "agent-123");
//
//        Assertions.assertNotNull(response);
//        Assertions.assertTrue(response.getAlerts().isEmpty());
//        verify(objectMapperHelper, never()).deserializeStringToObject(any(), any());
//        verify(surveyAlertStorage, never()).findByUserAndAccountNumberAndTtlAfter(any(), any(), any());
//    }

//    @Test
//    void shouldReturnEmptyAlertsWhenAgentIdNotFoundForAccount() {
//        UserAttributes userAttributes = new UserAttributes();
//        userAttributes.addCustomAttributes("agent_id", "agent_id_json");
//        when(userStorage.findUser("user-1")).thenReturn(userAttributes);
//        when(objectMapperHelper.deserializeStringToObject(any(), any()))
//                .thenReturn(Map.of("account-1", "other-agent"));
//
//        SurveyAlertsResponse response = surveyService.fetchSurveyAlerts("user-1", "agent-123");
//
//        Assertions.assertTrue(response.getAlerts().isEmpty());
//        verify(surveyAlertStorage, never()).findByUserAndAccountNumberAndTtlAfter(any(), any(), any());
//    }

//    @Test
//    void shouldReturnMultipleAlertsWhenMultipleSurveyAlertsExist() {
//        UserAttributes userAttributes = new UserAttributes();
//        userAttributes.addCustomAttributes("agent_id", "agent_id_json");
//        when(userStorage.findUser("user-1")).thenReturn(userAttributes);
//        when(objectMapperHelper.deserializeStringToObject(any(), any()))
//                .thenReturn(Map.of("account-1", "agent-123"));
//
//        SurveyAlert alert1 = SurveyAlert.builder().user("user-1").event("NPS_EVENT").preprocessedSurveyId(1L).accountNumber("account-1").alertType("INFO").alertPriority(1).alertTitle("Title").alertMessage("Msg").alertActionLabel("Go").build();
//        SurveyAlert alert2 = SurveyAlert.builder().user("user-1").event("CES_EVENT").preprocessedSurveyId(2L).accountNumber("account-1").alertType("WARNING").alertPriority(2).alertTitle("Title2").alertMessage("Msg2").alertActionLabel("Open").build();
//        when(surveyAlertStorage.findByUserAndAccountNumberAndTtlAfter(eq("user-1"), eq("account-1"), any(Timestamp.class)))
//                .thenReturn(List.of(alert1, alert2));
//
//        SurveyAlertsResponse response = surveyService.fetchSurveyAlerts("user-1", "agent-123");
//
//        Assertions.assertEquals(2, response.getAlerts().size());
//        Assertions.assertEquals("NPS_EVENT", response.getAlerts().get(0).getId());
//        Assertions.assertEquals("CES_EVENT", response.getAlerts().get(1).getId());
//        Assertions.assertEquals("/survey/1", response.getAlerts().get(0).getAction().getTarget());
//        Assertions.assertEquals("/survey/2", response.getAlerts().get(1).getAction().getTarget());
//    }

    @Test
    void shouldMapNullTimestampsToNullInHistoryItem() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);

        PreprocessedSurvey historySurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .event("SURVEY_TRIGGERED")
                .ttl(null)
                .completedOn(null)
                .build();

        when(surveyRepository.findByUserAndSurveyIdAndLastModifiedOnBetween(any(), any(), any(Timestamp.class), any(Timestamp.class)))
                .thenReturn(List.of(historySurvey));

        SurveyHistoryResponse response = surveyService.fetchSurveyHistory("user-1", 1L, startDate, endDate);

        SurveyHistoryItemDTO item = response.getSurveys().getFirst();
        Assertions.assertNull(item.getTtl());
        Assertions.assertNull(item.getCompletedOn());
    }

    // ── fetchSurveysByUserId — location enrichment ────────────────────────────

    @Test
    void fetchSurveysByUserId_enrichesLocationWebAndMobile_whenSurveyFoundInRepo() {
        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());
        Survey mockSurvey = mock(Survey.class);
        when(mockSurvey.getWebLocation()).thenReturn("/web/brm");
        when(mockSurvey.getMobileLocation()).thenReturn("/mobile/brm");
        when(surveyRepositoryService.findById(1L)).thenReturn(Optional.of(mockSurvey));

        List<PreprocessedSurveyDTO> result = surveyService.fetchSurveysByUserId("user-1");

        Assertions.assertEquals("/web/brm", result.getFirst().getLocationWeb());
        Assertions.assertEquals("/mobile/brm", result.getFirst().getLocationMobile());
    }

    @Test
    void fetchSurveysByUserId_locationRemainsNull_whenSurveyNotFoundInRepo() {
        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());
        when(surveyRepositoryService.findById(1L)).thenReturn(Optional.empty());

        List<PreprocessedSurveyDTO> result = surveyService.fetchSurveysByUserId("user-1");

        Assertions.assertNull(result.getFirst().getLocationWeb());
        Assertions.assertNull(result.getFirst().getLocationMobile());
    }

    @Test
    void fetchSurveysByUserId_skipsEnrichment_whenDtoSurveyIdIsNull() {
        PreprocessedSurveyDTO dtoWithNoSurveyId = PreprocessedSurveyDTO.builder()
                .user("user-1").survey("{\"sample\":\"data\"}").build();
        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(dtoWithNoSurveyId);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyService.fetchSurveysByUserId("user-1");

        verify(surveyRepositoryService, never()).findById(any());
    }

    @Test
    void fetchSurveysByUserId_returnsCachedDtos_withoutCallingRepo() {
        PreprocessedSurveyDTO cachedDto = PreprocessedSurveyDTO.builder()
                .surveyId(1L).user("user-1")
                .locationWeb("/cached/web").locationMobile("/cached/mobile")
                .build();
        when(cacheService.getAllPreprocessedSurveys("user-1")).thenReturn(List.of(cachedDto));

        List<PreprocessedSurveyDTO> result = surveyService.fetchSurveysByUserId("user-1");

        Assertions.assertEquals("/cached/web", result.getFirst().getLocationWeb());
        Assertions.assertEquals("/cached/mobile", result.getFirst().getLocationMobile());
        verify(surveyRepository, never()).findByUserAndStateInAndTtlAfter(any(), any(), any());
        verify(surveyRepositoryService, never()).findById(any());
    }

    // ── fetchSurveysByUserId — NPS serve path ─────────────────────────────────

    @Test
    void fetchSurveysByUserId_servesNpsSurvey_whenCurrentWeekNpsSurveyPresent() {
        String currentIsoWeek = IsoWeekUtil.current(ZoneId.of("Africa/Lagos"));
        PreprocessedSurvey npsSurvey = PreprocessedSurvey.builder()
                .surveyId(1L)
                .user("user-1")
                .survey("{\"sample\":\"data\"}")
                .isoWeek(currentIsoWeek)
                .build();

        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(List.of(npsSurvey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyService.fetchSurveysByUserId("user-1");

        verify(npsWeeklySampleService, times(1)).serveNpsSurvey("user-1", currentIsoWeek);
    }

    @Test
    void fetchSurveysByUserId_doesNotServeNpsSurvey_whenNoIsoWeekMatchesCurrentWeek() {
        when(surveyRepository.findByUserAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyService.fetchSurveysByUserId("user-1");

        verify(npsWeeklySampleService, never()).serveNpsSurvey(any(), any());
    }

    @Test
    void fetchSurveysByUserId_doesNotServeNpsSurvey_whenCachedResultReturned() {
        PreprocessedSurveyDTO cachedDto = PreprocessedSurveyDTO.builder()
                .surveyId(1L).user("user-1").build();
        when(cacheService.getAllPreprocessedSurveys("user-1")).thenReturn(List.of(cachedDto));

        surveyService.fetchSurveysByUserId("user-1");

        verify(npsWeeklySampleService, never()).serveNpsSurvey(any(), any());
    }

    // ── fetchSurveyById — location enrichment ────────────────────────────────

    @Test
    void fetchSurveyById_enrichesLocationWebAndMobile_whenSurveyFoundInRepo() {
        PreprocessedSurveyDTO dto = PreprocessedSurveyDTO.builder()
                .surveyId(5L).user("user-1").survey("{\"sample\":\"data\"}")
                .ttl(LocalDateTime.now().plusHours(1)).build();
        when(surveyRepository.findByIdAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(dto);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());
        Survey mockSurvey = mock(Survey.class);
        when(mockSurvey.getWebLocation()).thenReturn("/web/brm");
        when(mockSurvey.getMobileLocation()).thenReturn("/mobile/brm");
        when(surveyRepositoryService.findById(5L)).thenReturn(Optional.of(mockSurvey));

        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(5L);

        Assertions.assertEquals("/web/brm", result.getLocationWeb());
        Assertions.assertEquals("/mobile/brm", result.getLocationMobile());
    }

    @Test
    void fetchSurveyById_locationRemainsNull_whenSurveyNotFoundInRepo() {
        PreprocessedSurveyDTO dto = PreprocessedSurveyDTO.builder()
                .surveyId(6L).user("user-1").survey("{\"sample\":\"data\"}")
                .ttl(LocalDateTime.now().plusHours(1)).build();
        when(surveyRepository.findByIdAndStateInAndTtlAfter(any(), any(), any(Timestamp.class)))
                .thenReturn(Optional.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(dto);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());
        when(surveyRepositoryService.findById(6L)).thenReturn(Optional.empty());

        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(6L);

        Assertions.assertNull(result.getLocationWeb());
        Assertions.assertNull(result.getLocationMobile());
    }

    @Test
    void fetchSurveyById_returnsCachedDto_withLocations_withoutCallingRepo() {
        PreprocessedSurveyDTO cachedDto = PreprocessedSurveyDTO.builder()
                .surveyId(10L).user("user-1")
                .locationWeb("/cached/web").locationMobile("/cached/mobile")
                .ttl(LocalDateTime.now().plusHours(1)).build();
        when(cacheService.getPreprocessedSurveyById("10")).thenReturn("cached-json");
        when(objectMapperHelper.deserializeStringToObject(eq("cached-json"), any())).thenReturn(cachedDto);

        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(10L);

        Assertions.assertEquals("/cached/web", result.getLocationWeb());
        Assertions.assertEquals("/cached/mobile", result.getLocationMobile());
        verify(surveyRepository, never()).findByIdAndStateInAndTtlAfter(any(), any(), any());
        verify(surveyRepositoryService, never()).findById(any());
    }

    // ── fetchSurveyById — expiry on deserialization failure ──────────────────

    @Test
    void fetchSurveyById_expiresSurveyAndReturnsNull_whenCachedSurveyDeserializationFails() {
        when(cacheService.getPreprocessedSurveyById("11")).thenReturn("corrupted-json");
        when(objectMapperHelper.deserializeStringToObject(eq("corrupted-json"), any()))
                .thenThrow(new ServerException("invalid json"));

        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(11L);

        Assertions.assertNull(result);
        verify(surveyRepository, times(1)).expireByIds(List.of(11L));
        verify(cacheService, times(1)).removePreprocessedSurveyBySurveyId("11");
        verify(surveyRepository, never()).findByIdAndStateInAndTtlAfter(any(), any(), any());
    }

    @Test
    void fetchSurveyById_expiresSurveyAndReturnsNull_whenSurveyBodyDeserializationFails() {
        when(surveyRepository.findByIdAndStateInAndTtlAfter(eq(12L), any(), any(Timestamp.class)))
                .thenReturn(Optional.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(eq(survey.getSurvey()), any()))
                .thenThrow(new ServerException("invalid json"));

        PreprocessedSurveyDTO result = surveyService.fetchSurveyById(12L);

        Assertions.assertNull(result);
        verify(surveyRepository, times(1)).expireByIds(List.of(12L));
        verify(cacheService, times(1)).removePreprocessedSurveyBySurveyId("12");
        verify(cacheService, never()).cachePreprocessedSurveyById(any(), any());
    }

    // ── fetchSurveysByUserId — expiry on deserialization failure ─────────────

    @Test
    void fetchSurveysByUserId_expiresSurveyAndSkipsIt_whenSurveyBodyDeserializationFails() {
        survey.setId(1L);
        preprocessedSurveyDTO.setId(1L);

        when(cacheService.getAllPreprocessedSurveys("user-1")).thenReturn(List.of());
        when(surveyRepository.findByUserAndStateInAndTtlAfter(eq("user-1"), any(), any(Timestamp.class)))
                .thenReturn(List.of(survey));
        when(objectMapperHelper.convertObjectToType(any(), any())).thenReturn(preprocessedSurveyDTO);
        when(objectMapperHelper.deserializeStringToObject(eq(survey.getSurvey()), any()))
                .thenThrow(new ServerException("invalid json"));

        List<PreprocessedSurveyDTO> result = surveyService.fetchSurveysByUserId("user-1");

        Assertions.assertTrue(result.isEmpty());
        verify(surveyRepository, times(1)).expireByIds(List.of(1L));
        verify(cacheService, times(1)).removePreprocessedSurveyBySurveyId("1");
        verify(cacheService, times(1)).cacheAllPreprocessedSurveys(eq("user-1"), eq(List.of()));
    }

}
