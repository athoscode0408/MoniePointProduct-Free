package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedEventRepository;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SupportedEventRepositoryServiceTests {

    @Mock
    private SupportedEventRepository supportedEventRepository;

    @Mock
    private CacheService cacheService;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @InjectMocks
    private SupportedEventRepositoryService supportedEventRepositoryService;

    private static final Timestamp CURRENT_TIMESTAMP = Timestamp.from(Instant.ofEpochMilli(1729151340));

    private static final String TEST_USER = "someTest";
    private static final String SUPPORTED_EVENT_CACHE_KEY = "SUPPORTED_EVENT::prequalification";
    private static final String PREQUALICATION_EVENT_STRING = """
            {
                "id": 1,
                "createdBy": "someTest",
                "createdOn": 1729151340,
                "lastModifiedBy": "someTest",
                "lastModifiedOn": 1729151340,
                "version": 1,
                "eventType": "prequalification"
            }
            """;

    private static final SupportedEvent PREQUALIFICATION_EVENT = SupportedEvent.builder()
            .eventType("prequalification")
            .build();
    private static final SupportedEvent LOAN_REQUEST_EVENT = SupportedEvent.builder()
            .eventType("Loan request")
            .build();

    @BeforeAll
    static void globalSetup() {

        PREQUALIFICATION_EVENT.setId(1L);
        PREQUALIFICATION_EVENT.setCreatedBy(TEST_USER);
        PREQUALIFICATION_EVENT.setCreatedOn(CURRENT_TIMESTAMP);
        PREQUALIFICATION_EVENT.setLastModifiedBy(TEST_USER);
        PREQUALIFICATION_EVENT.setLastModifiedOn(CURRENT_TIMESTAMP);

        LOAN_REQUEST_EVENT.setId(2L);
        LOAN_REQUEST_EVENT.setCreatedBy(TEST_USER);
        LOAN_REQUEST_EVENT.setCreatedOn(CURRENT_TIMESTAMP);
        LOAN_REQUEST_EVENT.setLastModifiedBy(TEST_USER);
        LOAN_REQUEST_EVENT.setLastModifiedOn(CURRENT_TIMESTAMP);
    }

    @BeforeEach
    public void setUp() throws Exception {
        Field field = SupportedEventRepositoryService.class.getDeclaredField("supportedEventExpiry");
        field.setAccessible(true);
        field.set(supportedEventRepositoryService, 60);
    }

    @Test
    void findByEventType_cacheHit_returnsSupportedEvent() {
        when(cacheService.getCachedString(SUPPORTED_EVENT_CACHE_KEY)).thenReturn(PREQUALICATION_EVENT_STRING);
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(PREQUALIFICATION_EVENT);

        Optional<SupportedEvent> supportedEventOptional = supportedEventRepositoryService.findByEventType("prequalification");

        assertTrue(supportedEventOptional.isPresent());
        assertEquals(PREQUALIFICATION_EVENT, supportedEventOptional.get());

        verify(cacheService, never()).cacheString(anyString(), anyString(), anyLong());
        verify(supportedEventRepository, never()).findByEventType(anyString());
        verify(objectMapperHelper, never()).serializeToString(anyString());
    }

    @Test
    void findByEventType_cacheMiss_returnsSupportedEvent() {
        when(cacheService.getCachedString(SUPPORTED_EVENT_CACHE_KEY)).thenReturn(null);
        when(objectMapperHelper.serializeToString(PREQUALIFICATION_EVENT)).thenReturn(PREQUALICATION_EVENT_STRING);
        when(supportedEventRepository.findByEventType("prequalification")).thenReturn(Optional.of(PREQUALIFICATION_EVENT));

        Optional<SupportedEvent> supportedEventOptional = supportedEventRepositoryService.findByEventType("prequalification");

        assertTrue(supportedEventOptional.isPresent());
        assertEquals(PREQUALIFICATION_EVENT, supportedEventOptional.get());

        verify(objectMapperHelper, never()).deserializeStringToObject(anyString(), any());
    }


    @Test
    void findByEventType_doesNotExistInDBAndCache_doesNotReturnSupportedEvent() {
        when(cacheService.getCachedString(SUPPORTED_EVENT_CACHE_KEY)).thenReturn(null);
        when(supportedEventRepository.findByEventType("prequalification")).thenReturn(Optional.empty());

        Optional<SupportedEvent> supportedEventOptional = supportedEventRepositoryService.findByEventType("prequalification");

        assertTrue(supportedEventOptional.isEmpty());
    }


    @Test
    void loadSupportedEventsToCache_success() {
        String loanRequestEventString = """
                {
                    "id": 2,
                    "createdBy": "someTest",
                    "createdOn": 1729151340,
                    "lastModifiedBy": "someTest",
                    "lastModifiedOn": 1729151340,
                    "version": 1,
                    "eventType": "Loan request"
                }
                """;
        when(supportedEventRepository.findAll()).thenReturn(List.of(PREQUALIFICATION_EVENT, LOAN_REQUEST_EVENT));
        when(objectMapperHelper.serializeToString(PREQUALIFICATION_EVENT)).thenReturn(PREQUALICATION_EVENT_STRING);
        when(objectMapperHelper.serializeToString(LOAN_REQUEST_EVENT)).thenReturn(loanRequestEventString);

        supportedEventRepositoryService.loadSupportedEventsToCache();

        verify(cacheService, times(1)).cacheString(SUPPORTED_EVENT_CACHE_KEY, PREQUALICATION_EVENT_STRING, 60);
        verify(cacheService, times(1)).cacheString("SUPPORTED_EVENT::Loan request", loanRequestEventString, 60);
    }
}
