package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.module.analytics.entity.UnsupportedEvent;
import com.moniepoint.loans.cas.module.analytics.repository.UnsupportedEventRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UnsupportedEventRepositoryServiceTests {

    @Mock
    private UnsupportedEventRepository unsupportedEventRepository;

    @InjectMocks
    private UnsupportedEventRepositoryService unsupportedEventRepositoryService;

    @Test
    void save_success() {
        String eventContent = """
                {
                	"eventType": "invalid_event",
                	"id": "12233",
                	"timestamp": 1725871279,
                	"platform": "MOBILE",
                	"source" : "LMS",
                	"environment": "DEVELOPMENT",
                	"data": {
                		"emai": "test@test.co"
                	}
                }
                """;
        UnsupportedEvent unsupportedEvent = UnsupportedEvent.builder()
                .eventType("invalid_event")
                .eventData(eventContent)
                .build();
        unsupportedEvent.setCreatedBy("someTest");
        unsupportedEvent.setCreatedOn(Timestamp.from(Instant.now()));
        unsupportedEvent.setLastModifiedBy("someTest");
        unsupportedEvent.setLastModifiedOn(Timestamp.from(Instant.now()));

        when(unsupportedEventRepository.save(unsupportedEvent)).thenReturn(unsupportedEvent);

        UnsupportedEvent savedUnsupportedEvent = unsupportedEventRepositoryService.save(unsupportedEvent);

        assertNotNull(savedUnsupportedEvent);
        assertEquals(savedUnsupportedEvent, unsupportedEvent);
    }

    @Test
    void deleteAllUnsupportedEvents_success() {
        unsupportedEventRepositoryService.deleteAllUnsupportedEvents();

        verify(unsupportedEventRepository, times(1)).deleteAll();
    }

}
