package com.moniepoint.loans.cas.module.analytics.repository.service;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Filters;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.RowCell;
import com.google.protobuf.ByteString;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

/**
 * Mock test to run on CI. For local tests, consider using AnalyticsEventProviderRepositoryTests
 * since it allows testing with proper containers
 */
@ExtendWith(MockitoExtension.class)
class UserAttributesRepositoryServiceTests {

    @Mock
    private BigtableDataClient dataClient;
    private final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
    @Mock
    CacheService cacheService;

    private UserAttributesRepositoryService userAttributesRepositoryService;
    private final Map<String , String> USER_ATTRIBUTES = Map.of(
            "name", "user name",
            "phone", "user phone",
            "email", "user email"
    );

    @BeforeEach
    void setUp() {
        userAttributesRepositoryService = new UserAttributesRepositoryService(dataClient,objectMapperHelper,cacheService);
        ReflectionTestUtils.setField(userAttributesRepositoryService, "USER_ATTRIBUTES_TABLE", "userAttributesTable");
        ReflectionTestUtils.setField(userAttributesRepositoryService, "USER_ATTRIBUTES_CACHE_TTL", 15);
    }


    @Test
    void findUsers_shouldReturnUsers_whenRowExists() {
        String userId = "user123";

        Row mockRow = Row.create(
                ByteString.copyFromUtf8(userId),
                List.of(
                        RowCell.create("cf1", ByteString.copyFromUtf8("email"),
                                0, List.of(), ByteString.copyFromUtf8("user@email.com")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("name"),
                                0, List.of(), ByteString.copyFromUtf8("User Name")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("phone"),
                                0, List.of(), ByteString.copyFromUtf8("1234554726")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("brm_id"),
                                0, List.of(), ByteString.copyFromUtf8("{\"5000218933\": 40,\"5000236751\": 7 }"))
                 )

        );

        when(dataClient.readRow(any(), anyString(), any(Filters.Filter.class))).thenReturn(mockRow);
        when(cacheService.getCachedString(any())).thenReturn("");

        UserAttributes user = userAttributesRepositoryService.findUser(userId, null);

        assertNotNull(user);
        Assertions.assertEquals("1234554726", user.getPhone());
        Assertions.assertEquals("user@email.com", user.getEmail());
        Assertions.assertEquals("User Name", user.getName());
        assertNull(user.getBrmId());
        verify(dataClient,times(1)).readRow(any(), anyString(), any(Filters.Filter.class));
    }

    @Test
    void findUsers_shouldReturnUniqueBrmData() {
        String userId = "user123";

        Row mockRow = Row.create(
                ByteString.copyFromUtf8(userId),
                List.of(
                        RowCell.create("cf1", ByteString.copyFromUtf8("email"),
                                0, List.of(), ByteString.copyFromUtf8("user@email.com")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("name"),
                                0, List.of(), ByteString.copyFromUtf8("User Name")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("phone"),
                                0, List.of(), ByteString.copyFromUtf8("1234554726")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("brm_id"),
                                0, List.of(), ByteString.copyFromUtf8("{\"5000218933\": 40,\"5000236751\": 7 }")),
                        RowCell.create("cf1", ByteString.copyFromUtf8("brm_name"),
                                0, List.of(), ByteString.copyFromUtf8("{\"5000218923\": \"Chika\",\"5000236751\": \"Onye\" }"))

                )

        );
        when(cacheService.getCachedString(any())).thenReturn("");

        when(dataClient.readRow(any(), anyString(), any(Filters.Filter.class))).thenReturn(mockRow);

        UserAttributes user = userAttributesRepositoryService.findUser(userId, "5000218933");

        assertNotNull(user);
        Assertions.assertEquals("40", user.getBrmId());
        assertNull(user.getBrmName());
        verify(dataClient,times(1)).readRow(any(), anyString(), any(Filters.Filter.class));
    }

    @Test
    void getUser_shouldReturnEmpty_whenRowIsNull() {
        String userId = "user123";

        UserAttributes user = userAttributesRepositoryService.findUser(userId,null);

        assertNull(user);
    }

    @Test
    void close_shouldCloseBigTableConnection() {

         userAttributesRepositoryService.close();

        verify(dataClient, times(1)).close();
    }

    //TODO write unit tests for new schema
//    @Test
//    void findUsers_fetchFromBusinessTable_whenBusinessAccountNumberPresent() {
//        String userId = "user123";
//        String businessAccountNumber = "userBusinessAccNumber";
//
//        Row mockRow = Row.create(
//                ByteString.copyFromUtf8(userId),
//                List.of(
//                        RowCell.create("cf1", ByteString.copyFromUtf8("email"),
//                                0, List.of(), ByteString.copyFromUtf8("user@email.com")),
//                        RowCell.create("cf1", ByteString.copyFromUtf8("name"),
//                                0, List.of(), ByteString.copyFromUtf8("User Name")),
//                        RowCell.create("cf1", ByteString.copyFromUtf8("phone"),
//                                0, List.of(), ByteString.copyFromUtf8("1234554726"))
//                )
//        );
//
//        Row businessMockRow = Row.create(
//                ByteString.copyFromUtf8(userId),
//                List.of(
//                        RowCell.create("cf1", ByteString.copyFromUtf8("brmId"),
//                                0, List.of(), ByteString.copyFromUtf8("brm ID")),
//                        RowCell.create("cf1", ByteString.copyFromUtf8("brmName"),
//                                0, List.of(), ByteString.copyFromUtf8("BRM Name")),
//                        RowCell.create("cf1", ByteString.copyFromUtf8("brmPhoneNumber"),
//                                0, List.of(), ByteString.copyFromUtf8("brm phone"))
//                )
//        );
//
//        when(dataClient.readRow(eq("userAttributesTable"), eq(userId), any(Filters.Filter.class))).thenReturn(mockRow);
//        when(dataClient.readRow(eq("userBusinessAttributesTable"),eq(userId+"_"+businessAccountNumber), any(Filters.Filter.class))).thenReturn(businessMockRow);
//
//
//        UserAttributes user = userAttributesRepositoryService.findUser(userId, businessAccountNumber);
//
//        assertNotNull(user);
//        Assertions.assertEquals("brm ID", user.getBrm_id());
//        Assertions.assertEquals("BRM Name", user.getBrm_name());
//        Assertions.assertEquals("brm phone", user.getBrm_phone_number());
//        verify(dataClient,times(2)).readRow(any(), anyString(), any(Filters.Filter.class));
//    }

}
