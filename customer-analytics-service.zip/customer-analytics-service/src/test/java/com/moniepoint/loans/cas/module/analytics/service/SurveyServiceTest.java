package com.moniepoint.loans.cas.module.analytics.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.module.analytics.dto.SurveyCreateRequest;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import com.moniepoint.loans.cas.testdoubles.FakeCacheService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

class SurveyServiceTest {

    static FakeCacheService cacheService = new FakeCacheService(new HashMap<>());


    @Test
    void createSurvey_stripsBomAndZeroWidthCharsBeforeSave() {
        SurveyStorage storage = mock(SurveyStorage.class);
        ObjectMapper mapper = new ObjectMapper();
        SurveyService underTest = new SurveyService(storage, mapper, cacheService);

        SurveyCreateRequest req = new SurveyCreateRequest();
        req.setRule("rule");
        req.setPriority(1);
        // include BOM (U+FEFF) and zero-width space (U+200B) inside a title string
        String problematicTitle = "Hello\uFEFF world\u200B";
        req.setSurvey(Map.of("title", problematicTitle));
        req.setLocationWeb("/survey");
        req.setLocationMobile("/survey");

        // Make storage return the same entity (simulate save)
        when(storage.save(org.mockito.ArgumentMatchers.any(Survey.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Survey saved = underTest.createSurvey(req);

        assertThat(saved).isNotNull();
        assertThat(saved.getSurvey()).doesNotContain("\uFEFF");
        assertThat(saved.getSurvey()).doesNotContain("\u200B");
        assertThat(saved.getSurvey()).contains("Hello world");

        // verify we called save
        ArgumentCaptor<Survey> captor = ArgumentCaptor.forClass(Survey.class);
        verify(storage).save(captor.capture());
    }

    @Test
    void createSurvey_escapesEmojiAsSurrogatePairsBeforeSave() {
        SurveyStorage storage = mock(SurveyStorage.class);
        ObjectMapper mapper = new ObjectMapper();
        SurveyService underTest = new SurveyService(storage, mapper, cacheService);

        SurveyCreateRequest req = new SurveyCreateRequest();
        req.setRule("rule");
        req.setPriority(1);
        // 😡 (U+1F621) and 😁 (U+1F601) are supplementary characters that MySQL utf8 rejects as 4-byte sequences
        req.setSurvey(Map.of("minRateEmoji", "😡", "maxRateEmoji", "😁"));
        req.setLocationWeb("/survey");
        req.setLocationMobile("/survey");

        when(storage.save(org.mockito.ArgumentMatchers.any(Survey.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Survey saved = underTest.createSurvey(req);

        // Stored JSON must not contain raw surrogate chars — only ASCII unicode escape sequences
        assertThat(saved.getSurvey()).doesNotContainAnyWhitespaces();
        assertThat(saved.getSurvey().chars().anyMatch(c -> c > 0xFFFF)).isFalse();
        assertThat(saved.getSurvey()).contains("\\ud83d\\ude21");
        assertThat(saved.getSurvey()).contains("\\ud83d\\ude01");
    }
}
