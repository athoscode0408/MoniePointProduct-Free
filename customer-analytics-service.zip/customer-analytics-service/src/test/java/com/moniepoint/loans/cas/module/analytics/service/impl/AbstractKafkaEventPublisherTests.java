package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AbstractKafkaEventPublisherTests {

    @Mock
    KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    SurveyPushNotificationKafkaEventPublisher publisher;

    NotificationRequest event;
    String key;
    String serialized;

    @BeforeEach
    void setUp() {
        publisher = new SurveyPushNotificationKafkaEventPublisher("events",kafkaTemplate,objectMapperHelper,telemetry);
        var e = VerifiedAnalyticsEventDTO.builder()
                .timestamp(Timestamp.from(Instant.now()))
                .userIdentifiers(new UserEventIdentifier("session-id", "user-id", null, null, null))
                .build();
        PreprocessedSurvey validSurvey = PreprocessedSurvey.builder().ttl(Timestamp.from(Instant.now())).build();
        validSurvey.setId(1L);

        key = "key";
        event = new NotificationRequest(validSurvey, e);
        serialized = "{\"notification\":nos-notification}";
    }

    @Test
    void publishEvent_success() {


        when(objectMapperHelper.serializeToString(event)).thenReturn(serialized);
        var sendResult = mock(SendResult.class);
        when(kafkaTemplate.send("events", key, serialized))
                .thenReturn(CompletableFuture.completedFuture(sendResult));

        publisher.publishEvent(key, event);

        verify(objectMapperHelper).serializeToString(event);
        verify(kafkaTemplate).send("events", key, serialized);
        verifyNoMoreInteractions(kafkaTemplate);
    }

    @Test
    void publishEvent_failure_logsButDoesNotThrow() {

        when(objectMapperHelper.serializeToString(event)).thenReturn(serialized);
        when(kafkaTemplate.send("events", key, serialized))
                .thenReturn(CompletableFuture.failedFuture(new RuntimeException("ka-boom")));

        publisher.publishEvent(key, event);

        verify(kafkaTemplate).send("events", key, serialized);
    }
}