package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.Telemetry;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v1.BrazeAllowedEventsResponse;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.service.AnalyticsEventProviderRepositoryService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AnalyticsServiceTests {

    @Spy
    @InjectMocks
    AnalyticsServiceImpl analyticsServiceImpl;

    @Mock
    SurveyEventCompletionService surveyEventCompletionService;

    @Mock
    VerifiedAnalyticsEventKafkaEventPublisher verifiedAnalyticsEventKafkaEventPublisher;

    @Mock
    AnalyticsEventProviderRepositoryService analyticsEventProviderRepositoryService;

    @Mock
    Telemetry telemetry;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(analyticsServiceImpl, "maxRequestSizeInBytes", 1000000000L);
        ReflectionTestUtils.setField(analyticsServiceImpl, "maxNoOfEvents", 2000);
    }

    private static ObjectNode dataWithEventName(String name) {
        ObjectMapper om = new ObjectMapper();
        ObjectNode root = om.createObjectNode();
        root.put("eventName", name);
        return root;
    }

    private static AnalyticsEventRequestDTO mockEvent(ObjectNode data) {
        AnalyticsEventRequestDTO dto = mock(AnalyticsEventRequestDTO.class);
        when(dto.getData()).thenReturn(data);
        return dto;
    }

//    @Test
//    void surveyCompletedDoesNotPublish() {
//        ObjectNode data = dataWithEventName("SURVEY_COMPLETED");
//        AnalyticsEventRequestDTO dto = mockEvent(data);
//
//        analyticsServiceImpl.handleRawAnalyticsEvents(List.of(dto));
//
//        verify(surveyEventCompletionService).processCompletedSurveyEvent(dto);
//        verifyNoInteractions(verifiedAnalyticsEventKafkaEventPublisher);
//        verify(analyticsServiceImpl, never()).prepareVerifiedAnalyticsEventDTO(any(), anyCollection());
//
//
//    }

//    @Test
//    void surveyAbandonedDoesNotPublish() {
//        ObjectNode data = dataWithEventName("SURVEY_ABANDONED");
//        AnalyticsEventRequestDTO dto = mockEvent(data);
//
//        analyticsServiceImpl.handleRawAnalyticsEvents(List.of(dto));
//
//        verify(surveyEventCompletionService).processCompletedSurveyEvent(dto);
//        verifyNoInteractions(verifiedAnalyticsEventKafkaEventPublisher);
//        verify(analyticsServiceImpl, never()).prepareVerifiedAnalyticsEventDTO(any(), anyCollection());
//
//    }

    @Test
    void nonSurveyCompletion_withProviders_preparesAndPublishesAll() {
        ObjectNode dataA = dataWithEventName("EVENT_A");
        ObjectNode dataB = dataWithEventName("EVENT_B");
        AnalyticsEventRequestDTO dtoA = mockEvent(dataA);
        AnalyticsEventRequestDTO dtoB = mockEvent(dataB);

        EventProvider p1 = mock(EventProvider.class);
        EventProvider p2 = mock(EventProvider.class);

        Map<String, Collection<EventProvider>> providerMap = new HashMap<>();
        providerMap.put("EVENT_A", Set.of(p1));
        providerMap.put("EVENT_B", Set.of(p2));

        when(analyticsEventProviderRepositoryService.getSupportedEventProviders(anyList()))
                .thenReturn(providerMap);

        VerifiedAnalyticsEventDTO vA = mock(VerifiedAnalyticsEventDTO.class);
        VerifiedAnalyticsEventDTO vB = mock(VerifiedAnalyticsEventDTO.class);
        doReturn(vA).when(analyticsServiceImpl).prepareVerifiedAnalyticsEventDTO(eq(dtoA), eq(Set.of(p1)));
        doReturn(vB).when(analyticsServiceImpl).prepareVerifiedAnalyticsEventDTO(eq(dtoB), eq(Set.of(p2)));

        analyticsServiceImpl.handleRawAnalyticsEvents(List.of(dtoA, dtoB));

        verify(analyticsServiceImpl).prepareVerifiedAnalyticsEventDTO(eq(dtoA), eq(Set.of(p1)));
        verify(analyticsServiceImpl).prepareVerifiedAnalyticsEventDTO(eq(dtoB), eq(Set.of(p2)));

        ArgumentCaptor<String> keyCap = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List<VerifiedAnalyticsEventDTO>> listCap = ArgumentCaptor.forClass(List.class);
        verify(verifiedAnalyticsEventKafkaEventPublisher).publishEvents(keyCap.capture(), listCap.capture());

        List<VerifiedAnalyticsEventDTO> sent = listCap.getValue();
        assertThat(sent).containsExactly(vA, vB);

        verify(surveyEventCompletionService, never()).processCompletedSurveyEvent(any());

    }

    @Test
    void getPubliclyAllowedBrazeEvents_returnsEventsAndFutureExpiry() {
        ReflectionTestUtils.setField(analyticsServiceImpl, "publicBrazeEventsTtlSeconds", 3600L);
        when(analyticsEventProviderRepositoryService.getAllowListedEventTypes(EventProvider.BRAZE))
                .thenReturn(List.of("dashboard_load_success", "sign_in_success"));

        Instant before = Instant.now();

        BrazeAllowedEventsResponse response = analyticsServiceImpl.getPubliclyAllowedBrazeEvents();

        assertThat(response.getAllowedEvents()).containsExactly("dashboard_load_success", "sign_in_success");
        assertThat(response.getExpiresAt()).isAfter(before.plusSeconds(3500));
    }

}
