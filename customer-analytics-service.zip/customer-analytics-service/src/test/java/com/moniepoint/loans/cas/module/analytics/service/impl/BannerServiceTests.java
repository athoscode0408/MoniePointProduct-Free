package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import com.moniepoint.loans.cas.outbound.banner.BannerClient;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerDTO;
import com.moniepoint.loans.cas.outbound.banner.dto.AssignBannerResponse;
import com.moniepoint.loans.cas.outbound.banner.dto.UnassignBannerDTO;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BannerServiceTests {

    @Mock
    private BannerClient bannerClient;

    @Mock
    private OutboundUtils outboundUtils;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @InjectMocks
    private BannerService bannerService;

    private static final String OWNER_IDENTIFIER = "test-user";
    private static final String BANNER_ID = "banner-001";
    private static final String ACCESS_TOKEN = "access-token-xyz";

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(bannerService, "preprocessedSurveyTtl", 10080);
    }

    // ── assignBannerToUser ──────────────────────────────────────────────────────

    @Test
    void assignBannerToUser_whenSuccessful_returnsOkResponse() {
        AssignBannerResponse successBody = new AssignBannerResponse(true, "200", "success", null);
        ResponseEntity<AssignBannerResponse> okResponse = ResponseEntity.ok(successBody);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(any(AssignBannerDTO.class), eq("Bearer " + ACCESS_TOKEN)))
                .thenReturn(okResponse);

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertTrue(result.getBody().isRequestSuccessful());
        verify(bannerClient, times(1)).assignBanner(any(AssignBannerDTO.class), anyString());
    }

    @Test
    void assignBannerToUser_whenBannerServiceReturnsNonOk_returnsOriginalResponse() {
        AssignBannerResponse body = new AssignBannerResponse(false, "400", "bad request", null);
        ResponseEntity<AssignBannerResponse> badResponse = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(any(AssignBannerDTO.class), anyString())).thenReturn(badResponse);

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertFalse(result.getBody().isRequestSuccessful());
    }

    @Test
    void assignBannerToUser_whenFeignExceptionThrown_andBodyDeserializes_returnsDeserializedResponse() {
        FeignException feignException = mock(FeignException.class);
        AssignBannerResponse errorBody = new AssignBannerResponse(false, "422", "Unprocessable", null);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(any(AssignBannerDTO.class), anyString())).thenThrow(feignException);
        when(feignException.status()).thenReturn(422);
        when(feignException.contentUTF8()).thenReturn("{\"requestSuccessful\":false}");
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(errorBody);

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(422, result.getStatusCode().value());
        assertFalse(result.getBody().isRequestSuccessful());
    }

    @Test
    void assignBannerToUser_whenFeignExceptionThrown_andBodyDeserializationFails_returnsFallbackResponse() {
        FeignException feignException = mock(FeignException.class);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(any(AssignBannerDTO.class), anyString())).thenThrow(feignException);
        when(feignException.status()).thenReturn(500);
        when(feignException.contentUTF8()).thenReturn("not-json");
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class)))
                .thenThrow(new RuntimeException("parse error"));

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(500, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertFalse(result.getBody().isRequestSuccessful());
        assertEquals("500", result.getBody().getResponseCode());
    }

    @Test
    void assignBannerToUser_whenGenericExceptionThrown_returnsInternalServerError() {
        when(outboundUtils.getToken()).thenThrow(new RuntimeException("token fetch failed"));

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertNotNull(result.getBody());
        assertFalse(result.getBody().isRequestSuccessful());
        assertEquals("500", result.getBody().getResponseCode());
    }

    @Test
    void assignBannerToUser_usesCorrectOwnerIdentifierAndBannerId() {
        AssignBannerResponse successBody = new AssignBannerResponse(true, "200", "success", null);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(
                argThat(dto -> OWNER_IDENTIFIER.equals(dto.getOwnerIdentifier()) && BANNER_ID.equals(dto.getBannerId())),
                anyString()
        )).thenReturn(ResponseEntity.ok(successBody));

        ResponseEntity<AssignBannerResponse> result = bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    void assignBannerToUser_usesUsernameOwnerIdentifierType() {
        AssignBannerResponse successBody = new AssignBannerResponse(true, "200", "success", null);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.assignBanner(
                argThat(dto -> "USERNAME".equals(dto.getOwnerIdentifierType())),
                anyString()
        )).thenReturn(ResponseEntity.ok(successBody));

        bannerService.assignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        verify(bannerClient, times(1)).assignBanner(
                argThat(dto -> "USERNAME".equals(dto.getOwnerIdentifierType())),
                anyString()
        );
    }

    // ── unAssignBannerToUser ────────────────────────────────────────────────────

    @Test
    void unAssignBannerToUser_whenSuccessful_returnsTrue() {
        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.unAssignBanner(any(UnassignBannerDTO.class), eq("Bearer " + ACCESS_TOKEN)))
                .thenReturn(ResponseEntity.ok(null));

        boolean result = bannerService.unAssignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertTrue(result);
        verify(bannerClient, times(1)).unAssignBanner(any(UnassignBannerDTO.class), anyString());
    }

    @Test
    void unAssignBannerToUser_whenNonOkStatus_returnsFalse() {
        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.unAssignBanner(any(UnassignBannerDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.NOT_FOUND).build());

        boolean result = bannerService.unAssignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertFalse(result);
    }

    @Test
    void unAssignBannerToUser_whenFeignExceptionThrown_returnsFalse() {
        FeignException feignException = mock(FeignException.class);

        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.unAssignBanner(any(UnassignBannerDTO.class), anyString())).thenThrow(feignException);

        boolean result = bannerService.unAssignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertFalse(result);
    }

    @Test
    void unAssignBannerToUser_whenGenericExceptionThrown_returnsFalse() {
        when(outboundUtils.getToken()).thenThrow(new RuntimeException("network error"));

        boolean result = bannerService.unAssignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        assertFalse(result);
    }

    @Test
    void unAssignBannerToUser_usesCorrectBearerToken() {
        when(outboundUtils.getToken()).thenReturn(ACCESS_TOKEN);
        when(bannerClient.unAssignBanner(any(UnassignBannerDTO.class), eq("Bearer " + ACCESS_TOKEN)))
                .thenReturn(ResponseEntity.ok(null));

        bannerService.unAssignBannerToUser(OWNER_IDENTIFIER, BANNER_ID);

        verify(bannerClient, times(1)).unAssignBanner(any(), eq("Bearer " + ACCESS_TOKEN));
    }
}
