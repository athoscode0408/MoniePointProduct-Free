package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.BrazeClient;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeIdentifyResponse;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackRequest;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackResponse;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.BrazeApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedUserAttributesRepository;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BrazeEventProviderHandlerTests {

    private static final String DEFAULT_API_KEY = "default-api-key";

    @Mock
    private BrazeClient brazeClient;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @Mock
    private BrazeApiKeyStorage brazeApiKeyStorage;

    @Mock
    private CacheService cacheService;

    @Mock
    private SupportedUserAttributesRepository supportedUserAttributesRepository;

    private BrazeEventProviderHandler handler;

    @BeforeEach
    void setUp() {
        // enable-workspace-targeting and enable-attributes-filtering are @Value-injected fields with
        // no field initializer, so plain construction (outside a Spring context) leaves them false —
        // this keeps the fixture on the defaultApiKey / unfiltered-attributes path.
        handler = new BrazeEventProviderHandler(
                true,
                DEFAULT_API_KEY,
                "android-id",
                "web-id",
                "ios-id",
                brazeClient,
                objectMapperHelper,
                eventRetryService,
                brazeApiKeyStorage,
                cacheService,
                supportedUserAttributesRepository
        );
    }

    @Test
    void processEvents_trackEventReturnsBadRequest_doesNotSubmitForRetry() {
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString()))
                .thenReturn(trackResponse(HttpStatus.BAD_REQUEST));

        boolean result = handler.processEvent(event("evt-1"));

        assertFalse(result);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void processEvents_trackEventThrowsFeignExceptionWithBadRequestStatus_doesNotSubmitForRetry() {
        FeignException feignException = mock(FeignException.class);
        when(feignException.status()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString())).thenThrow(feignException);

        boolean result = handler.processEvent(event("evt-1"));

        assertFalse(result);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void processEvents_trackEventReturnsServerError_submitsForRetry() {
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString()))
                .thenReturn(trackResponse(HttpStatus.INTERNAL_SERVER_ERROR));
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        boolean result = handler.processEvent(event("evt-1"));

        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void processEvents_trackEventThrowsFeignExceptionWithNonBadRequestStatus_submitsForRetry() {
        FeignException feignException = mock(FeignException.class);
        when(feignException.status()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE.value());
        when(feignException.getMessage()).thenReturn("upstream unavailable");
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString())).thenThrow(feignException);
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        boolean result = handler.processEvent(event("evt-1"));

        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void processEvents_trackEventThrowsGenericException_submitsForRetry() {
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString()))
                .thenThrow(new RuntimeException("network error"));
        when(objectMapperHelper.serializeToString(any())).thenReturn("{}");

        boolean result = handler.processEvent(event("evt-1"));

        assertFalse(result);
        verify(eventRetryService, times(1)).processFailedEventData(any(EventRetryDataDTO.class));
    }

    @Test
    void processEvents_trackEventSucceeds_doesNotSubmitForRetry() {
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString()))
                .thenReturn(trackResponse(HttpStatus.CREATED));
        when(brazeClient.identify(any(), anyString()))
                .thenReturn(identifyResponse(HttpStatus.CREATED));

        boolean result = handler.processEvent(event("evt-1"));

        assertTrue(result);
        verify(eventRetryService, never()).processFailedEventData(any(EventRetryDataDTO.class));
    }

    private ResponseEntity<BrazeTrackResponse> trackResponse(HttpStatus status) {
        return new ResponseEntity<>(status);
    }

    private ResponseEntity<BrazeIdentifyResponse> identifyResponse(HttpStatus status) {
        return new ResponseEntity<>(status);
    }

    private String event(String id) {
        VerifiedAnalyticsEventDTO event = VerifiedAnalyticsEventDTO.builder()
                .id(id)
                .eventType("test_event")
                .timestamp(Timestamp.from(Instant.now()))
                .eventProviders(Set.of(EventProvider.BRAZE))
                .applicationID("app-1")
                .appDomain("domain-1")
                .userIdentifiers(UserEventIdentifier.builder().sessionID("session-1").userID("user-1").build())
                .build();
        when(objectMapperHelper.deserializeStringToObject(anyString(), any()))
                .thenReturn(event);
        return "irrelevant-json";
    }
}