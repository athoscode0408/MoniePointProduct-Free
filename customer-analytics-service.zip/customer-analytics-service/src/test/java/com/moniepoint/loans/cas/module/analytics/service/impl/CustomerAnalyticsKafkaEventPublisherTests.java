package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v2.AnalyticsEventV2RequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3RequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerAnalyticsEventKafkaEventPublisherTest {

    private CustomerAnalyticsKafkaEventPublisher customerAnalyticsKafkaEventPublisher;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        customerAnalyticsKafkaEventPublisher = new CustomerAnalyticsKafkaEventPublisher(
                "test-topic", kafkaTemplate, objectMapperHelper, telemetry
        );
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    private static AnalyticsEventV3RequestDTO mockEvent(String id) {
        AnalyticsEventV3RequestDTO event= new AnalyticsEventV3RequestDTO() ;
        event.setId(id);
        return event;
    }

    @Test
    void getTopic_success() {
        assertThat(customerAnalyticsKafkaEventPublisher.getTopic()).isEqualTo("test-topic");
    }

    @Test
    void publishEvent_success() {
        AnalyticsEventV2RequestDTO analyticsEventRequestDTO = AnalyticsEventV2RequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .customerIdentifier("customer-identifier")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        String content = """
                {
                    "eventType": "prequalification",
                    "id": "123",
                    "customerIdentifier": "customer-identifier",
                    "timestamp": 1725887178,
                    "platform": "MOBILE",
                    "environment": "DEVELOPMENT",
                    "data": {
                        "email": "test@test.co"
                    }
                }""";
        @SuppressWarnings("unchecked")
        SendResult<String, String> sendResult = mock(SendResult.class);

        when(kafkaTemplate.send(any(), anyString(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));
        when(objectMapperHelper.serializeToString(any(AnalyticsEventV2RequestDTO.class)))
                .thenReturn(content);

        customerAnalyticsKafkaEventPublisher.publishEvent(analyticsEventRequestDTO);

        verify(kafkaTemplate).send(eq("test-topic"), anyString(), eq(content));
    }


    @Test
    void publishEvent_withoutEventData_verifiesEventNotSendKafka() {
        customerAnalyticsKafkaEventPublisher.publishEvent(null);

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV2RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any(), any());
    }

    @Test
    void publishEvent_withoutEventKey_verifiesEventNotSendKafka() {
        customerAnalyticsKafkaEventPublisher.publishEvent(AnalyticsEventV2RequestDTO.builder().build());

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV2RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any(), any());
    }

    @Test
    void publishEvents_nullList_returnsEarly() {
        customerAnalyticsKafkaEventPublisher.publishEvents(null);

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV2RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any(), any());
    }

    @Test
    void publishEvents_emptyList_returnsEarly() {
        customerAnalyticsKafkaEventPublisher.publishEvents(List.of());

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV2RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any(), any());
    }

    @Test
    void publishEvents_nonBlankKey_invokesSend() {
        var e1 = mockEvent("customer-123");
        var e2 = mockEvent("customer-127");
        var sendResult = mock(SendResult.class);

        List<BaseAnalyticsEventRequestDTO<?>> list = List.of(e1, e2);
        when(kafkaTemplate.send(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));

        customerAnalyticsKafkaEventPublisher.publishEvents(list);

        verify(objectMapperHelper, times(2)).serializeToString(any());
        verify(kafkaTemplate, times(2)).send(any(), any(), any());

    }

    @Test
    void publishEvents_blankKey_returnsEarly() {
        var e1 = mockEvent(" ");
        List<BaseAnalyticsEventRequestDTO<?>> list = List.of(e1);


        customerAnalyticsKafkaEventPublisher.publishEvents(list);

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV2RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any(), any());
    }

}
