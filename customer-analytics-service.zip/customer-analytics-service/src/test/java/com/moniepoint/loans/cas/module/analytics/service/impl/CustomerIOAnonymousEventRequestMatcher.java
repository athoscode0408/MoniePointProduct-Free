package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import org.mockito.ArgumentMatcher;

import java.sql.Timestamp;

public class CustomerIOAnonymousEventRequestMatcher implements ArgumentMatcher<AnonymousEventRequest> {

    private final String name;
    private final String id;
    private final Timestamp timestamp;
    private final CustomerIOEventType type;
    private final JsonNode data;

    private CustomerIOAnonymousEventRequestMatcher(Builder builder) {
        this.name = builder.name;
        this.id = builder.id;
        this.timestamp = builder.timestamp;
        this.type = builder.type;
        this.data = builder.data;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String name;
        private String id;
        private Timestamp timestamp;
        private CustomerIOEventType type;
        private JsonNode data;

        public Builder name(String name) { this.name = name; return this; }
        public Builder id(String id) { this.id = id; return this; }
        public Builder timestamp(Timestamp timestamp) { this.timestamp = timestamp; return this; }
        public Builder type(CustomerIOEventType type) { this.type = type; return this; }
        public Builder data(JsonNode data) { this.data = data; return this; }

        public CustomerIOAnonymousEventRequestMatcher build() {
            return new CustomerIOAnonymousEventRequestMatcher(this);
        }
    }

    @Override
    public boolean matches(AnonymousEventRequest request) {
        return name.equals(request.getName())
                && id.equals(request.getId())
                && timestamp == request.getTimestamp()
                && type.getValue().equals(request.getType())
                && data.equals(request.getData());
    }
}
