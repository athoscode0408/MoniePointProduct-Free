package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.AnonymousEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerIOResponse;
import com.moniepoint.loans.cas.integrations.customerio.enums.CustomerIOEventType;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.lenient;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerIOEventProviderHandlerTests {

    @Mock
    private CustomerIOConfig customerIOConfig;

    @Mock
    private CustomerIOIntegrationService customerIOIntegrationService;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @InjectMocks
    private CustomerIOEventProviderHandler customerIOEventProviderHandler;

    private static final String USERNAME = "test_username";
    private static final String ID = "1234";
    private static final String EVENT_NAME = "prequalification";

    private static final Timestamp TIMESTAMP = Timestamp.from(Instant.ofEpochMilli(1725887178));

    private static final VerifiedAnalyticsEventDTO VERIFIED_ANALYTICS_EVENT_DTO = VerifiedAnalyticsEventDTO.builder()
            .id(ID)
            .eventType(EVENT_NAME)
            .appEnv("DEVELOPMENT")
            .platform("MOBILE")
            .timestamp(TIMESTAMP)
            .build();

    private static final CustomerIOResponse SUCCESS_RESPONSE = CustomerIOResponse.builder().success(true).build();

    private static ObjectMapper objectMapper;

    @BeforeAll
    static void globalSetup() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @BeforeEach
    void setUp() {
        lenient().doReturn(true).when(customerIOConfig).isEnable();
    }


    @Test
    void support_withSupportedEventProvider_returnsTrue() {
        assertTrue(customerIOEventProviderHandler.support(EventProvider.CIO));
    }

    @Test
    void support_withUnsupportedEventProvider_returnsFalse() {
        assertFalse(customerIOEventProviderHandler.support(EventProvider.MIX));
    }

    @Test
    void processEvent_withUsername_processesCustomerEvent() {
        JsonNode jsonNode = objectMapper.convertValue(Map.of("username", USERNAME, "app_env", "DEVELOPMENT", "platform", "MOBILE"), JsonNode.class);
        CustomerEventRequest customerEventRequest = CustomerEventRequest.builder()
                .name(EVENT_NAME)
                .id(ID)
                .timestamp(TIMESTAMP)
                .type(CustomerIOEventType.EVENT)
                .data(jsonNode)
                .customerIdentifier(USERNAME)
                .build();
        VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder().data(objectMapper.convertValue(Map.of("username", USERNAME), JsonNode.class)).build();

        when(customerIOIntegrationService.sendCustomerEventToCustomerIO(USERNAME, customerEventRequest)).thenReturn(CustomerIOResponse.builder().success(true).build());

        customerIOEventProviderHandler.processEvent(verifiedAnalyticsEventDTO);

        verify(customerIOIntegrationService, times(1)).sendCustomerEventToCustomerIO(USERNAME, customerEventRequest);
    }

    @Test
    void processEvent_disableProcessing_success() {
        doReturn(false).when(customerIOConfig).isEnable();

        customerIOEventProviderHandler.processEvent(VERIFIED_ANALYTICS_EVENT_DTO);

        verify(customerIOIntegrationService, never()).sendCustomerEventToCustomerIO(anyString(), any(CustomerEventRequest.class));
    }

    @Test
    void processEvent_withoutUsername_processesAnonymousEvent() {
        JsonNode jsonNode = objectMapper.convertValue(Map.of("app_env", "DEVELOPMENT", "platform", "MOBILE"), JsonNode.class);
        CustomerIOAnonymousEventRequestMatcher eventMatcher = (CustomerIOAnonymousEventRequestMatcher) CustomerIOAnonymousEventRequestMatcher.builder()
                .name(EVENT_NAME)
                .id(ID)
                .timestamp(TIMESTAMP)
                .type(CustomerIOEventType.EVENT)
                .data(jsonNode)
                .build();
        VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder().data(objectMapper.convertValue(Map.of(), JsonNode.class)).build();

        when(customerIOIntegrationService.sendAnonymousEventToCustomerIO(argThat(eventMatcher)))
                .thenReturn(CustomerIOResponse.builder().success(true).build());

        customerIOEventProviderHandler.processEvent(verifiedAnalyticsEventDTO);

        verify(customerIOIntegrationService, times(1)).sendAnonymousEventToCustomerIO(argThat(eventMatcher));
    }

    @Test
    void processEvent_withUserName_sendsCustomerEvent() throws JsonProcessingException {
        JsonNode jsonNode = objectMapper.convertValue(Map.of("username", USERNAME), JsonNode.class);
        AnonymousEventRequest eventRequest = AnonymousEventRequest.builder()
                .name(EVENT_NAME)
                .id(ID)
                .timestamp(TIMESTAMP)
                .type(CustomerIOEventType.EVENT)
                .anonymousId("1234")
                .data(jsonNode)
                .build();

        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(eventRequest);
        when(customerIOIntegrationService.sendCustomerEventToCustomerIO(USERNAME, eventRequest)).thenReturn(SUCCESS_RESPONSE);

        boolean response = customerIOEventProviderHandler.processEvent(objectMapper.writeValueAsString(eventRequest));

        assertTrue(response);

        verify(customerIOIntegrationService, times(1)).sendCustomerEventToCustomerIO(USERNAME, eventRequest);
    }

    @Test
    void processEvent_withUserName_sendsAnonymousEvent() throws JsonProcessingException {
        JsonNode jsonNode = objectMapper.convertValue(Map.of(), JsonNode.class);
        AnonymousEventRequest eventRequest = AnonymousEventRequest.builder()
                .name(EVENT_NAME)
                .id(ID)
                .timestamp(TIMESTAMP)
                .type(CustomerIOEventType.EVENT)
                .anonymousId("1234")
                .data(jsonNode)
                .build();

        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(eventRequest);
        when(customerIOIntegrationService.sendAnonymousEventToCustomerIO(eventRequest)).thenReturn(SUCCESS_RESPONSE);

        boolean response = customerIOEventProviderHandler.processEvent(objectMapper.writeValueAsString(eventRequest));

        assertTrue(response);

        verify(customerIOIntegrationService, times(1)).sendAnonymousEventToCustomerIO(eventRequest);
    }

}
