package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.exception.NotFoundException;
import com.moniepoint.loans.cas.module.analytics.dto.EventConfigDTO;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.AnalyticsEventProviderRepository;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedEventRepository;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedUserAttributesRepository;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.cache.util.CacheKeys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EventConfigServiceTest {

    @Mock
    private SupportedEventRepository supportedEventRepository;

    @Mock
    private AnalyticsEventProviderRepository analyticsEventProviderRepository;

    @Mock
    private SupportedUserAttributesRepository supportedUserAttributesRepository;

    @Mock
    private CacheService cacheService;

    private EventConfigService eventConfigService;

    @BeforeEach
    void setUp() {
        eventConfigService = new EventConfigService(
                supportedEventRepository, analyticsEventProviderRepository, supportedUserAttributesRepository, cacheService);
    }

    private static AnalyticsEventProvider providerWithId(long id, EventProvider key) throws Exception {
        AnalyticsEventProvider provider = AnalyticsEventProvider.builder().providerKey(key).providerName(key.name()).build();
        setId(provider, id);
        return provider;
    }

    private static void setId(Object entity, long id) throws Exception {
        Field idField = entity.getClass().getSuperclass().getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(entity, id);
    }

    @Test
    void removeEventConfig_removesProviderAssociationAndEvictsCaches() throws Exception {
        AnalyticsEventProvider braze = providerWithId(1L, EventProvider.BRAZE);
        SupportedEvent event = SupportedEvent.builder()
                .eventType("dashboard_load_success")
                .providers(new HashSet<>(List.of(braze)))
                .build();

        EventConfigDTO dto = EventConfigDTO.builder().eventName("dashboard_load_success").provider("BRAZE").build();

        when(supportedEventRepository.findByEventType("dashboard_load_success")).thenReturn(Optional.of(event));
        when(analyticsEventProviderRepository.findByProviderKey(EventProvider.BRAZE)).thenReturn(Optional.of(braze));

        eventConfigService.removeEventConfig(List.of(dto));

        assertFalse(event.getProviders().contains(braze));
        verify(supportedEventRepository).save(event);
        verify(cacheService).deleteFromCache("dashboard_load_success" + CacheKeys.ALLOWED_ATTRIBUTES_CACHE_KEY_SUFFIX);
        verify(cacheService).deleteFromCache(CacheKeys.SUPPORTED_PROVIDERS_CACHE_KEY);
    }

    @Test
    void removeEventConfig_providerCaseInsensitive_resolvesCorrectProvider() throws Exception {
        AnalyticsEventProvider braze = providerWithId(1L, EventProvider.BRAZE);
        SupportedEvent event = SupportedEvent.builder()
                .eventType("dashboard_load_success")
                .providers(new HashSet<>(List.of(braze)))
                .build();

        EventConfigDTO dto = EventConfigDTO.builder().eventName("dashboard_load_success").provider("braze").build();

        when(supportedEventRepository.findByEventType("dashboard_load_success")).thenReturn(Optional.of(event));
        when(analyticsEventProviderRepository.findByProviderKey(EventProvider.BRAZE)).thenReturn(Optional.of(braze));

        eventConfigService.removeEventConfig(List.of(dto));

        assertFalse(event.getProviders().contains(braze));
        verify(supportedEventRepository).save(event);
    }

    @Test
    void removeEventConfig_eventNotFound_throwsNotFoundException() {
        EventConfigDTO dto = EventConfigDTO.builder().eventName("unknown_event").provider("BRAZE").build();
        when(supportedEventRepository.findByEventType("unknown_event")).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> eventConfigService.removeEventConfig(List.of(dto)));

        verify(analyticsEventProviderRepository, never()).findByProviderKey(any());
        verify(supportedEventRepository, never()).save(any());
    }

    @Test
    void removeEventConfig_providerNotFound_throwsNotFoundException() {
        SupportedEvent event = SupportedEvent.builder().eventType("dashboard_load_success").build();
        EventConfigDTO dto = EventConfigDTO.builder().eventName("dashboard_load_success").provider("BRAZE").build();

        when(supportedEventRepository.findByEventType("dashboard_load_success")).thenReturn(Optional.of(event));
        when(analyticsEventProviderRepository.findByProviderKey(EventProvider.BRAZE)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> eventConfigService.removeEventConfig(List.of(dto)));

        verify(supportedEventRepository, never()).save(any());
    }
}
