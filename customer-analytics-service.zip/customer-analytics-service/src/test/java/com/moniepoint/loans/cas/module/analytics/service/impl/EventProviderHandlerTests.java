package com.moniepoint.loans.cas.module.analytics.service.impl;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class EventProviderHandlerTests {

    private static final Logger log = LoggerFactory.getLogger(EventProviderHandlerTests.class);
    private static ObjectMapper objectMapper;

    private EventProviderHandler handler;

    @BeforeAll
    static void globalSetup() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @BeforeEach
    void setup() {
        handler = new EventProviderHandler() {
            @Override
            public boolean support(EventProvider provider) {
                return true;
            }

            @Override
            public void processEvent(VerifiedAnalyticsEventDTO verifiedAnalyticsEvent) {
                log.info("Inside test process event.");
            }

            @Override
            public boolean processEvent(String eventJsonString) {
                return true;
            }
        };
    }


    @Test
    void getUsername_withUsernameInJSON_returnsUsername() throws Exception {
        String json = """
                {
                    "username": "john_doe"
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getUserName(jsonNode);

        assertTrue(result.isPresent());
        assertEquals("john_doe", result.get());
    }

    @Test
    void getUsername_withoutUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "name": "john_doe"
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getUserName(jsonNode);

        assertFalse(result.isPresent());
    }

    @Test
    void getUsername_withNullUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "username": null
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getUserName(jsonNode);

        assertFalse(result.isPresent());
    }

    @Test
    void getUsername_withEmptyUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "username": ""
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getUserName(jsonNode);

        assertFalse(result.isPresent());
    }

    @Test
    void getUsername_withNullJSON_doesNotReturnUsername() {
        Optional<String> result = handler.getUserName(null);

        assertFalse(result.isPresent());
    }

    @Test
    void getIdentifier_withIdentifier_returnsIdentifier() throws Exception {
        String json = """
                {
                    "username": "john_doe"
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getIdentifier(jsonNode, "john_doe_identifier");

        assertTrue(result.isPresent());
        assertEquals("john_doe_identifier", result.get());
    }


    @Test
    void getIdentifier_withUsernameInJSON_returnsUsername() throws Exception {
        String json = """
                {
                    "username": "john_doe"
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getIdentifier(jsonNode, StringUtils.EMPTY);

        assertTrue(result.isPresent());
        assertEquals("john_doe", result.get());
    }

    @Test
    void getIdentifier_withoutUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "name": "john_doe"
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getIdentifier(jsonNode, StringUtils.EMPTY);

        assertFalse(result.isPresent());
    }

    @Test
    void getIdentifier_withNullUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "username": null
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getIdentifier(jsonNode, StringUtils.EMPTY);

        assertFalse(result.isPresent());
    }

    @Test
    void getIdentifier_withEmptyUsernameInJSON_doesNotReturnUsername() throws Exception {
        String json = """
                {
                    "username": ""
                }
                """;
        JsonNode jsonNode = objectMapper.readTree(json);

        Optional<String> result = handler.getIdentifier(jsonNode, StringUtils.EMPTY);

        assertFalse(result.isPresent());
    }

    @Test
    void getIdentifier_withNullJSON_doesNotReturnUsername() {
        Optional<String> result = handler.getIdentifier(null, StringUtils.EMPTY);

        assertFalse(result.isPresent());
    }

}
