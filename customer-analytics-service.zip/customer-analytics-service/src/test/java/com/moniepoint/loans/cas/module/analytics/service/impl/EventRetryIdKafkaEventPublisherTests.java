package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryIdKafkaEventPublisherTests {

    private EventRetryIdKafkaEventPublisher eventRetryIdKafkaEventPublisher;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    private static final EventRetryDTO EVENT_RETRY_DTO = EventRetryDTO.builder().id(10L).build();

    @BeforeEach
    void setup() {
        eventRetryIdKafkaEventPublisher = new EventRetryIdKafkaEventPublisher(
                "test-topic", kafkaTemplate, objectMapperHelper, telemetry
        );
    }

    @Test
    void getTopic_success() {
        assertThat(eventRetryIdKafkaEventPublisher.getTopic()).isEqualTo("test-topic");
    }

    @Test
    void publishEvent_success() {
        String content = """
                {
                "id" : 10
                }
                """;
        @SuppressWarnings("unchecked")
        SendResult<String, String> sendResult = mock(SendResult.class);

        when(kafkaTemplate.send(any(), anyString(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));
        when(objectMapperHelper.serializeToString(EVENT_RETRY_DTO))
                .thenReturn(content);



        eventRetryIdKafkaEventPublisher.publishEvent(EVENT_RETRY_DTO);

        verify(kafkaTemplate).send(eq("test-topic"), anyString(), eq(content));
    }

    @Test
    void publishEvent_withoutId_verifiesEventNotSendKafka() {
        eventRetryIdKafkaEventPublisher.publishEvent(null);

        verify(objectMapperHelper, never()).serializeToString(anyLong());
        verify(kafkaTemplate, never()).send(anyString(), any(), anyString());
    }
}
