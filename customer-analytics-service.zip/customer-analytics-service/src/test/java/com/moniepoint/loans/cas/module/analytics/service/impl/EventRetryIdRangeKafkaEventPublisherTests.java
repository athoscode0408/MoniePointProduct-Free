package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryIdRangeKafkaEventPublisherTests {

    private EventRetryIdRangeKafkaEventPublisher eventRetryIdRangeKafkaEventPublisher;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    @BeforeEach
    void setup() {
        eventRetryIdRangeKafkaEventPublisher = new EventRetryIdRangeKafkaEventPublisher(
                "test-topic", kafkaTemplate, objectMapperHelper, telemetry
        );
    }

    @Test
    void getTopic_success() {
        assertThat(eventRetryIdRangeKafkaEventPublisher.getTopic()).isEqualTo("test-topic");
    }

    @Test
    void publishEvent_success() {
        String content = """
                {
                	"start": "1",
                	"end": "20"
                """;
        EventRetryIDRangeDTO eventRetryIDRangeDTO =  EventRetryIDRangeDTO.builder().start(1L).end(20L).build();
        @SuppressWarnings("unchecked")
        SendResult<String, String> sendResult = mock(SendResult.class);

        when(kafkaTemplate.send(any(), anyString(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));
        when(objectMapperHelper.serializeToString(eventRetryIDRangeDTO))
                .thenReturn(content);

        eventRetryIdRangeKafkaEventPublisher.publishEvent(eventRetryIDRangeDTO);

        verify(kafkaTemplate).send(eq("test-topic"), anyString(), eq(content));
    }


    @Test
    void publishEvent_withoutRange_verifiesEventNotSendKafka() {
        eventRetryIdRangeKafkaEventPublisher.publishEvent(null);

        verify(objectMapperHelper, never()).serializeToString(any(EventRetryIDRangeDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }

    @Test
    void publishEvent_withoutStart_verifiesEventNotSendKafka() {
        eventRetryIdRangeKafkaEventPublisher.publishEvent(EventRetryIDRangeDTO.builder().end(10L).build());

        verify(objectMapperHelper, never()).serializeToString(any(EventRetryIDRangeDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }

    @Test
    void publishEvent_withoutEnd_verifiesEventNotSendKafka() {
        eventRetryIdRangeKafkaEventPublisher.publishEvent(EventRetryIDRangeDTO.builder().start(2L).build());

        verify(objectMapperHelper, never()).serializeToString(any(EventRetryIDRangeDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }
}
