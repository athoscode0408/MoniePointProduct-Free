package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDTO;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDataDTO;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;
import com.moniepoint.loans.cas.module.analytics.entity.EventDeadLetter;
import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventDeadLetterRepositoryService;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import java.lang.reflect.Field;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryServiceImplTests {

    private static final String EVENT_ID = "test-id";
    private static final String FAILURE_REASON = "fail";
    private static final String EVENT_DATA = """
            {
               "eventType": "Loan request",
               "id": "9321",
               "timestamp": 1725871279,
               "platform": "WEB",
               "environment" : "DEVELOPMENT",
               "data": {
                "emai" : "test@test.co",
                "username" : "test.user"
               }
            }
            """;
    private static final EventProvider MIXPANEL_PROVIDER = EventProvider.MIX;
    private static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(2024, 10, 23, 9, 11);

    private static final EventRetry EVENT_RETRY = EventRetry.builder()
            .eventId(EVENT_ID)
            .eventProvider(MIXPANEL_PROVIDER)
            .eventData(EVENT_DATA)
            .attemptCount(1)
            .lastFailureReason(FAILURE_REASON)
            .lastRetryTime(LOCAL_DATE_TIME)
            .nextRetryTime(LOCAL_DATE_TIME.plusSeconds(40))
            .build();

    private static final EventDeadLetter EVENT_DEAD_LETTER = EventDeadLetter.builder()
            .eventId(EVENT_ID)
            .eventProvider(MIXPANEL_PROVIDER)
            .eventData(EVENT_DATA)
            .lastFailureReason(FAILURE_REASON)
            .lastRetryTime(LOCAL_DATE_TIME)
            .build();

    private static final EventRetryDataDTO EVENT_RETRY_DATA_DTO = EventRetryDataDTO.builder()
            .eventId(EVENT_ID)
            .eventProvider(EventProvider.MIX)
            .failureReason(FAILURE_REASON)
            .eventData(EVENT_DATA)
            .build();

    @Mock
    private EventRetryRepositoryService eventRetryRepositoryService;

    @Mock
    private EventDeadLetterRepositoryService eventDeadLetterRepositoryService;

    @Mock
    private Clock clock;

    @Mock
    private KafkaEventPublisher<EventRetryIDRangeDTO> eventRetryIdRangeKafkaEventPublisher;

    @Mock
    private KafkaEventPublisher<EventRetryDTO> eventRetryIdKafkaEventPublisher;

    private EventRetryServiceImpl eventRetryServiceImpl;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        eventRetryServiceImpl = new EventRetryServiceImpl(eventRetryRepositoryService, eventDeadLetterRepositoryService, clock, eventRetryIdRangeKafkaEventPublisher, eventRetryIdKafkaEventPublisher);

        Field maxAttemptsField = EventRetryServiceImpl.class.getDeclaredField("maxAttempts");
        maxAttemptsField.setAccessible(true);
        maxAttemptsField.set(eventRetryServiceImpl, 3);

        Field nextIntervalField = EventRetryServiceImpl.class.getDeclaredField("nextIntervalInSeconds");
        nextIntervalField.setAccessible(true);
        nextIntervalField.set(eventRetryServiceImpl, 40);

        Field partitionSize = EventRetryServiceImpl.class.getDeclaredField("partitionSize");
        partitionSize.setAccessible(true);
        partitionSize.set(eventRetryServiceImpl, 5);

        Field pageSize = EventRetryServiceImpl.class.getDeclaredField("pageSize");
        pageSize.setAccessible(true);
        pageSize.set(eventRetryServiceImpl, 5);
    }

    @Test
    void processFailedEventData_withoutRetryEntryInDB_processesFirstEventRetry() {
        when(clock.getZone()).thenReturn(ZoneId.of("UTC"));
        when(clock.instant()).thenReturn(LOCAL_DATE_TIME.toInstant(ZoneOffset.UTC));
        when(eventRetryRepositoryService.findByEventIdAndEventProvider(EVENT_ID, MIXPANEL_PROVIDER)).thenReturn(Optional.empty());

        eventRetryServiceImpl.processFailedEventData(EVENT_RETRY_DATA_DTO);

        verify(eventRetryRepositoryService, times(1)).save(argThat(argument ->
                EVENT_RETRY.getEventId().equals(argument.getEventId())
                        && EVENT_RETRY.getEventProvider() == argument.getEventProvider()
                        && EVENT_RETRY.getAttemptCount() == 1
                        && EVENT_RETRY.getEventData().equals(EVENT_DATA)
                        && EVENT_RETRY.getLastFailureReason().equals(FAILURE_REASON)
                        && EVENT_RETRY.getLastRetryTime().equals(LOCAL_DATE_TIME)
                        && EVENT_RETRY.getNextRetryTime().equals(LOCAL_DATE_TIME.plusSeconds(40))
        ));
    }


    @Test
    void processFailedEventData_withMaxAttemptNotExhausted_updatesRetryEntry() {
        int expectedAttempt = EVENT_RETRY.getAttemptCount() + 1;
        LocalDateTime expectLastRetryDateTime = EVENT_RETRY.getNextRetryTime();
        LocalDateTime expectNextRetryDateTime = expectLastRetryDateTime.plusSeconds(40);

        when(clock.getZone()).thenReturn(ZoneId.of("UTC"));
        when(clock.instant()).thenReturn(LOCAL_DATE_TIME.plusSeconds(40).toInstant(ZoneOffset.UTC));
        when(eventRetryRepositoryService.findByEventIdAndEventProvider(EVENT_ID, MIXPANEL_PROVIDER)).thenReturn(Optional.of(EVENT_RETRY));

        eventRetryServiceImpl.processFailedEventData(EVENT_RETRY_DATA_DTO);

        verify(eventRetryRepositoryService, times(1)).save(argThat(argument ->
                EVENT_RETRY.getEventId().equals(argument.getEventId())
                        && EVENT_RETRY.getEventProvider() == argument.getEventProvider()
                        && EVENT_RETRY.getAttemptCount() == expectedAttempt
                        && EVENT_RETRY.getEventData().equals(EVENT_DATA)
                        && EVENT_RETRY.getLastFailureReason().equals(FAILURE_REASON)
                        && EVENT_RETRY.getLastRetryTime().equals(expectLastRetryDateTime)
                        && EVENT_RETRY.getNextRetryTime().equals(expectNextRetryDateTime)
        ));
    }

    @Test
    void processFailedEventData_withMaxAttemptExhausted_createsDeadLetterEntry() {
        EventRetry eventRetry = EVENT_RETRY.toBuilder().attemptCount(3).build();

        when(clock.getZone()).thenReturn(ZoneId.of("UTC"));
        when(clock.instant()).thenReturn(LOCAL_DATE_TIME.toInstant(ZoneOffset.UTC));
        when(eventRetryRepositoryService.findByEventIdAndEventProvider(EVENT_ID, MIXPANEL_PROVIDER)).thenReturn(Optional.of(eventRetry));

        eventRetryServiceImpl.processFailedEventData(EVENT_RETRY_DATA_DTO);

        verify(eventRetryRepositoryService, times(1)).deleteById(eventRetry.getId());

        verify(eventDeadLetterRepositoryService, times(1)).save(argThat(argument ->
                EVENT_DEAD_LETTER.getEventId().equals(argument.getEventId())
                        && EVENT_DEAD_LETTER.getEventProvider() == argument.getEventProvider()
                        && EVENT_DEAD_LETTER.getEventData().equals(EVENT_DATA)
                        && EVENT_DEAD_LETTER.getLastFailureReason().equals(FAILURE_REASON)
                        && EVENT_DEAD_LETTER.getLastRetryTime().equals(LOCAL_DATE_TIME)
        ));
    }

    @Test
    void retryFailedEvents_success() {
        when(eventRetryRepositoryService.findMaxEventRetryId(any(), any())).thenReturn(10L);
        when(eventRetryRepositoryService.findMinEventRetryId()).thenReturn(2L);

        eventRetryServiceImpl.retryFailedEvents();

        verify(eventRetryIdRangeKafkaEventPublisher, times(1)).publishEvent("2-6", EventRetryIDRangeDTO.builder().start(2L).end(6L).build());
        verify(eventRetryIdRangeKafkaEventPublisher, times(1)).publishEvent("7-10", EventRetryIDRangeDTO.builder().start(7L).end(10L).build());
    }

    @Test
    void retryFailedEvents_withoutMinId_doesNotPublishIdsToKafka() {
        when(eventRetryRepositoryService.findMaxEventRetryId(any(), any())).thenReturn(2L);
        when(eventRetryRepositoryService.findMinEventRetryId()).thenReturn(null);

        eventRetryServiceImpl.retryFailedEvents();

        verify(eventRetryIdRangeKafkaEventPublisher, never()).publishEvent(anyString(), any(EventRetryIDRangeDTO.class));
    }

    @Test
    void retryFailedEvents_withoutMaxId_doesNotPublishIdsToKafka() {
        when(eventRetryRepositoryService.findMaxEventRetryId(any(), any())).thenReturn(null);
        when(eventRetryRepositoryService.findMinEventRetryId()).thenReturn(10L);

        eventRetryServiceImpl.retryFailedEvents();

        verify(eventRetryIdRangeKafkaEventPublisher, never()).publishEvent(anyString(), any(EventRetryIDRangeDTO.class));
    }

    @Test
    void handleEventRetryIDRange_success() {
        Long start = 2L;
        Long end = 10L;
        EventRetryIDRangeDTO eventRetryIDRangeDTO = EventRetryIDRangeDTO.builder().start(start).end(end).build();
        Pageable pageable = PageRequest.of(0, 5, Sort.by("id").ascending());
        Page<Long> result = new PageImpl<>(List.of(3L, 4L), pageable, 2);

        when(eventRetryRepositoryService.fetchPaginatedIdsInRange(start, end, 0, 5)).thenReturn(result);

        eventRetryServiceImpl.handleEventRetryIDRange(eventRetryIDRangeDTO);

        verify(eventRetryIdKafkaEventPublisher, times(1)).publishEvent("3", EventRetryDTO.builder().id(3L).build());
        verify(eventRetryIdKafkaEventPublisher, times(1)).publishEvent("4", EventRetryDTO.builder().id(4L).build());
    }

    @Test
    void handleEventRetryIDRange_withNoRecordInDB_doesNotPublishEvent() {
        Long start = 2L;
        Long end = 10L;
        EventRetryIDRangeDTO eventRetryIDRangeDTO = EventRetryIDRangeDTO.builder().start(start).end(end).build();
        Pageable pageable = PageRequest.of(0, 5, Sort.by("id").ascending());
        Page<Long> result = new PageImpl<>(List.of(), pageable, 0);

        when(eventRetryRepositoryService.fetchPaginatedIdsInRange(start, end, 0, 5)).thenReturn(result);

        eventRetryServiceImpl.handleEventRetryIDRange(eventRetryIDRangeDTO);

        verify(eventRetryIdKafkaEventPublisher, never()).publishEvent(anyString(), any(EventRetryDTO.class));
    }
}
