package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.googleanalytics.config.GoogleAnalyticsConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsResponse;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsIntegrationService;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GoogleAnalyticsEventProviderHandlerTests {

    @Mock
    private GoogleAnalyticsIntegrationService googleAnalyticsIntegrationService;

    @Mock
    private GoogleAnalyticsConfig googleAnalyticsConfig;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @InjectMocks
    private GoogleAnalyticsEventProviderHandler googleAnalyticsEventProviderHandler;

    private static final String ID = "1234";
    private static final String EVENT_NAME = "prequalification";

    private static final Timestamp TIMESTAMP = Timestamp.from(Instant.ofEpochMilli(1725887178));

    private static final VerifiedAnalyticsEventDTO VERIFIED_ANALYTICS_EVENT_DTO = VerifiedAnalyticsEventDTO.builder()
            .id(ID)
            .eventType(EVENT_NAME)
            .appEnv("DEVELOPMENT")
            .platform("MOBILE")
            .timestamp(TIMESTAMP)
            .customerIdentifier("test")
            .build();

    private static final GoogleAnalyticsResponse SUCCESS_RESPONSE = GoogleAnalyticsResponse.builder().success(true).build();
    private static final GoogleAnalyticsResponse FAILURE_RESPONSE = GoogleAnalyticsResponse.builder().success(false).build();

    private static ObjectMapper objectMapper;

    @BeforeAll
    static void globalSetup() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @Test
    void support_withSupportedEventProvider_returnsTrue() {
        assertTrue(googleAnalyticsEventProviderHandler.support(EventProvider.GA));
    }

    @Test
    void support_withUnsupportedEventProvider_returnsFalse() {
        assertFalse(googleAnalyticsEventProviderHandler.support(EventProvider.MIX));
    }

    @Test
    void processEvent_web_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .clientId("123456.7654321")
                .events(objectMapper.readTree("[{\"name\":\"" + EVENT_NAME + "\",\"params\":{\"amount\":30000,\"device_type\":\"WEB\",\"eventId\":\"1234\", \"value\":30000.0,\"currency\":\"NGN\"}}]"))
                .userId("test")
                .build();
        VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder().data(objectMapper.readTree("{\"clientId\":\"123456.7654321\",\"amount\":30000,\"device_type\":\"WEB\"}")).build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(request)).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(verifiedAnalyticsEventDTO);

        verify(googleAnalyticsIntegrationService, times(1)).sendEventToGoogleAnalytics(request);
    }

    @Test
    void processEvent_android_success() throws JsonProcessingException {
        GoogleAnalyticsEventRequest request = GoogleAnalyticsEventRequest.builder()
                .appInstanceId("12345678901234567000123456789115")
                .events(objectMapper.readTree("[{\"name\":\"" + EVENT_NAME + "\",\"params\":{\"amount\":30000,\"device_type\":\"ANDROID\",\"eventId\":\"1234\", \"value\":30000.0,\"currency\":\"NGN\"}}]"))
                .userId("test")
                .build();
        VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder().data(objectMapper.readTree("{\"appInstanceId\":\"12345678901234567000123456789115\",\"amount\":30000,\"device_type\":\"ANDROID\"}")).build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(request)).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(verifiedAnalyticsEventDTO);

        verify(googleAnalyticsIntegrationService, times(1)).sendEventToGoogleAnalytics(request);
    }

    @Test
    void processEvent_disableProcessing_success() {
        doReturn(false).when(googleAnalyticsConfig).isEnable();

        googleAnalyticsEventProviderHandler.processEvent(VERIFIED_ANALYTICS_EVENT_DTO);

        verify(googleAnalyticsIntegrationService, never()).sendEventToGoogleAnalytics(any(GoogleAnalyticsEventRequest.class));
    }

    @Test
    void processEvent_withFlatData_paramsContainOnlyPrimitives() throws JsonProcessingException {
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"amount\":5000}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        params.fields().forEachRemaining(entry ->
                assertTrue(entry.getValue().isValueNode(),
                        "Expected only primitives in params but found object/array at key: " + entry.getKey()));
    }

    @Test
    void processEvent_withNestedObjectInData_flattensToTopLevelWithUnderscoreSeparator() throws JsonProcessingException {
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"metadata\":{\"source\":\"organic\",\"campaign\":\"promo1\"}}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        assertTrue(params.get("metadata_source").isValueNode());
        assertEquals("organic", params.get("metadata_source").asText());
        assertTrue(params.get("metadata_campaign").isValueNode());
        assertEquals("promo1", params.get("metadata_campaign").asText());
        assertNull(params.get("metadata"), "nested object 'metadata' should be removed after flattening");
    }

    @Test
    void processEvent_withDeeplyNestedObject_flattensCompletely() throws JsonProcessingException {
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"level1\":{\"level2\":{\"deepValue\":\"found\"}}}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        assertTrue(params.get("level1_level2_deepValue").isValueNode());
        assertEquals("found", params.get("level1_level2_deepValue").asText());
        assertNull(params.get("level1"), "intermediate object node 'level1' should be removed after flattening");
        assertNull(params.get("level1_level2"), "intermediate object node 'level1_level2' should be removed after flattening");
    }

    @Test
    void processEvent_withArrayInData_flattensToIndexedKeys() throws JsonProcessingException {
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"tags\":[\"loan\",\"promo\"]}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        assertEquals("loan", params.get("tags_0").asText());
        assertEquals("promo", params.get("tags_1").asText());
        assertNull(params.get("tags"), "original array field 'tags' should be removed after flattening");
    }

    @Test
    void processEvent_withNestedObjectInData_preservesPrimitiveFieldsUnchanged() throws JsonProcessingException {
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"amount\":30000,\"nested\":{\"x\":1}}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        assertEquals("ANDROID", params.get("device_type").asText());
        assertEquals(30000, params.get("amount").asInt());
        assertEquals(1, params.get("nested_x").asInt());
    }

    @Test
    void processEvent_withNestedObjectInData_addedFieldsAreAlsoFlattened() throws JsonProcessingException {
        // eventId, value, currency are added after extracting identifiers — confirm they appear in flat params
        VerifiedAnalyticsEventDTO event = VERIFIED_ANALYTICS_EVENT_DTO.toBuilder()
                .data(objectMapper.readTree("{\"appInstanceId\":\"abc123\",\"device_type\":\"ANDROID\",\"amount\":20000,\"extra\":{\"note\":\"test\"}}"))
                .build();

        doReturn(true).when(googleAnalyticsConfig).isEnable();
        when(googleAnalyticsIntegrationService.sendEventToGoogleAnalytics(any())).thenReturn(SUCCESS_RESPONSE);

        googleAnalyticsEventProviderHandler.processEvent(event);

        JsonNode params = captureParams();
        assertEquals(ID, params.get("eventId").asText());
        assertEquals(20000.0, params.get("value").asDouble());
        assertEquals("NGN", params.get("currency").asText());
        // nested field is also flattened
        assertEquals("test", params.get("extra_note").asText());
        assertNull(params.get("extra"));
    }

    private JsonNode captureParams() {
        ArgumentCaptor<GoogleAnalyticsEventRequest> captor = ArgumentCaptor.forClass(GoogleAnalyticsEventRequest.class);
        verify(googleAnalyticsIntegrationService).sendEventToGoogleAnalytics(captor.capture());
        return captor.getValue().getEvents().get(0).get("params");
    }

}
