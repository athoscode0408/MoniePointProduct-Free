package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;
import com.moniepoint.loans.cas.testdoubles.FakeNpsUserStateStorage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;

class NpsUserStateServiceImplTest {

    private static final int COOL_OFF_DAYS = 90;
    private static final int YEARLY_CAP = 2;
    private static final ZoneId LAGOS = ZoneId.of("Africa/Lagos");

    private FakeNpsUserStateStorage storage;
    private NpsUserStateServiceImpl service;

    @BeforeEach
    void setUp() {
        storage = new FakeNpsUserStateStorage(new HashMap<>());
        service = new NpsUserStateServiceImpl(storage);
    }

    @Test
    void isInCoolOff_firstTimeUser_returnsEligible() {
        assertThat(service.isInCoolOff("user-1", COOL_OFF_DAYS, YEARLY_CAP)).isFalse();
    }

    @Test
    void isInCoolOff_within89Days_returnsInCoolOff() {
        LocalDate today = LocalDate.now(LAGOS);
        storage.save(stateWithTriggerDate("user-2", today.minusDays(89)));

        assertThat(service.isInCoolOff("user-2", COOL_OFF_DAYS, YEARLY_CAP)).isTrue();
    }

    @Test
    void isInCoolOff_exactly90DaysElapsed_returnsEligible() {
        LocalDate today = LocalDate.now(LAGOS);
        storage.save(stateWithTriggerDate("user-3", today.minusDays(90)));

        assertThat(service.isInCoolOff("user-3", COOL_OFF_DAYS, YEARLY_CAP)).isFalse();
    }

    @Test
    void isInCoolOff_beyond90Days_returnsEligible() {
        LocalDate today = LocalDate.now(LAGOS);
        storage.save(stateWithTriggerDate("user-4", today.minusDays(91)));

        assertThat(service.isInCoolOff("user-4", COOL_OFF_DAYS, YEARLY_CAP)).isFalse();
    }

    @Test
    void isInCoolOff_annualCapHit_returnsInCoolOffEvenAfterWindow() {
        int thisYear = LocalDate.now(LAGOS).getYear();
        LocalDate today = LocalDate.now(LAGOS);
        NpsUserState state = NpsUserState.builder()
                .userId("user-5")
                .userName("user-5")
                .lastNpsTriggeredDate(today.minusDays(95))
                .triggerYear(thisYear)
                .triggerCountYear(2)
                .build();
        storage.save(state);

        assertThat(service.isInCoolOff("user-5", COOL_OFF_DAYS, YEARLY_CAP)).isTrue();
    }

    @Test
    void isInCoolOff_sameYearCountBelowCap_returnsEligible() {
        int thisYear = LocalDate.now(LAGOS).getYear();
        LocalDate today = LocalDate.now(LAGOS);
        NpsUserState state = NpsUserState.builder()
                .userId("user-6")
                .userName("user-6")
                .lastNpsTriggeredDate(today.minusDays(95))
                .triggerYear(thisYear)
                .triggerCountYear(1)
                .build();
        storage.save(state);

        assertThat(service.isInCoolOff("user-6", COOL_OFF_DAYS, YEARLY_CAP)).isFalse();
    }

    @Test
    void isInCoolOff_priorYearCountExhausted_returnsEligible() {
        int priorYear = LocalDate.now(LAGOS).getYear() - 1;
        LocalDate today = LocalDate.now(LAGOS);
        NpsUserState state = NpsUserState.builder()
                .userId("user-7")
                .userName("user-7")
                .lastNpsTriggeredDate(today.minusDays(91))
                .triggerYear(priorYear)
                .triggerCountYear(2)
                .build();
        storage.save(state);

        assertThat(service.isInCoolOff("user-7", COOL_OFF_DAYS, YEARLY_CAP)).isFalse();
    }

    @Test
    void writeTriggered_firstTrigger_createsRowWithCountOne() {
        NpsUserState result = service.writeTriggered("user-8");

        assertThat(result.getUserId()).isEqualTo("user-8");
        assertThat(result.getUserName()).isEqualTo("user-8");
        assertThat(result.getTriggerCountYear()).isEqualTo(1);
        assertThat(result.getTriggerYear()).isEqualTo(LocalDate.now(LAGOS).getYear());
        assertThat(result.getLastNpsTriggeredDate()).isEqualTo(LocalDate.now(LAGOS));
    }

    @Test
    void writeTriggered_secondTriggerSameYear_incrementsCount() {
        int thisYear = LocalDate.now(LAGOS).getYear();
        storage.save(NpsUserState.builder()
                .userId("user-9")
                .userName("user-9")
                .lastNpsTriggeredDate(LocalDate.now(LAGOS).minusDays(95))
                .triggerYear(thisYear)
                .triggerCountYear(1)
                .build());

        NpsUserState result = service.writeTriggered("user-9");

        assertThat(result.getTriggerCountYear()).isEqualTo(2);
        assertThat(result.getTriggerYear()).isEqualTo(thisYear);
    }

    @Test
    void writeTriggered_yearRollover_resetsCountAndUpdatesYear() {
        int priorYear = LocalDate.now(LAGOS).getYear() - 1;
        storage.save(NpsUserState.builder()
                .userId("user-10")
                .userName("user-10")
                .lastNpsTriggeredDate(LocalDate.now(LAGOS).minusDays(95))
                .triggerYear(priorYear)
                .triggerCountYear(2)
                .build());

        NpsUserState result = service.writeTriggered("user-10");

        assertThat(result.getTriggerYear()).isEqualTo(LocalDate.now(LAGOS).getYear());
        assertThat(result.getTriggerCountYear()).isEqualTo(1);
    }

    @Test
    void writeTriggered_nullTriggerYear_treatedAsRollover() {
        storage.save(NpsUserState.builder()
                .userId("user-11")
                .userName("user-11")
                .lastNpsTriggeredDate(LocalDate.now(LAGOS).minusDays(95))
                .triggerYear(null)
                .triggerCountYear(2)
                .build());

        NpsUserState result = service.writeTriggered("user-11");

        assertThat(result.getTriggerYear()).isEqualTo(LocalDate.now(LAGOS).getYear());
        assertThat(result.getTriggerCountYear()).isEqualTo(1);
    }

    private NpsUserState stateWithTriggerDate(String username, LocalDate date) {
        return NpsUserState.builder()
                .userId(username)
                .userName(username)
                .lastNpsTriggeredDate(date)
                .triggerYear(date.getYear())
                .triggerCountYear(1)
                .build();
    }
}
