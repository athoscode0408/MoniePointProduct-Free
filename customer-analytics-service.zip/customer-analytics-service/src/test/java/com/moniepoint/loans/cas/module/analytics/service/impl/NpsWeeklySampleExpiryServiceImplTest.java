package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.testdoubles.FakeNpsWeeklySampleStorage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;

class NpsWeeklySampleExpiryServiceImplTest {

    private static final String ISO_WEEK = "2026-W22";
    private static final String PRIOR_WEEK = "2026-W21";
    private static final String FUTURE_WEEK = "2026-W23";

    private FakeNpsWeeklySampleStorage storage;
    private NpsWeeklySampleExpiryServiceImpl service;

    @BeforeEach
    void setUp() {
        storage = new FakeNpsWeeklySampleStorage(new HashMap<>());
        service = new NpsWeeklySampleExpiryServiceImpl(storage);
    }

    @Test
    void expireWeeklySamples_pendingBecomesExpired() {
        storage.save(sample(1001L, NpsSampleStatus.PENDING, ISO_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1001L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.EXPIRED));
    }

    @Test
    void expireWeeklySamples_servedBecomesAbandoned() {
        storage.save(sample(1002L, NpsSampleStatus.SERVED, ISO_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1002L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.ABANDONED));
    }

    @Test
    void expireWeeklySamples_generatedBecomesExpired() {
        storage.save(sample(1005L, NpsSampleStatus.GENERATED, ISO_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1005L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.EXPIRED));
    }

    @Test
    void expireWeeklySamples_respondedRowUnaffected() {
        storage.save(sample(1003L, NpsSampleStatus.RESPONDED, ISO_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1003L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.RESPONDED));
    }

    @Test
    void expireWeeklySamples_priorWeekPendingBecomesExpired() {
        storage.save(sample(1004L, NpsSampleStatus.PENDING, PRIOR_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1004L, PRIOR_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.EXPIRED));
    }

    @Test
    void expireWeeklySamples_priorWeekServedBecomesAbandoned() {
        storage.save(sample(1006L, NpsSampleStatus.SERVED, PRIOR_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1006L, PRIOR_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.ABANDONED));
    }

    @Test
    void expireWeeklySamples_futureWeekRowsUnaffected() {
        storage.save(sample(1007L, NpsSampleStatus.PENDING, FUTURE_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1007L, FUTURE_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.PENDING));
    }

    @Test
    void expireWeeklySamples_mixedStatuses_correctTransitions() {
        storage.save(sample(1001L, NpsSampleStatus.PENDING, ISO_WEEK));
        storage.save(sample(1002L, NpsSampleStatus.SERVED, ISO_WEEK));
        storage.save(sample(1003L, NpsSampleStatus.RESPONDED, ISO_WEEK));
        storage.save(sample(1005L, NpsSampleStatus.GENERATED, ISO_WEEK));

        service.expireWeeklySamples(ISO_WEEK);

        assertThat(storage.findByUserIdAndIsoWeek(1001L, ISO_WEEK).get().getStatus()).isEqualTo(NpsSampleStatus.EXPIRED);
        assertThat(storage.findByUserIdAndIsoWeek(1002L, ISO_WEEK).get().getStatus()).isEqualTo(NpsSampleStatus.ABANDONED);
        assertThat(storage.findByUserIdAndIsoWeek(1003L, ISO_WEEK).get().getStatus()).isEqualTo(NpsSampleStatus.RESPONDED);
        assertThat(storage.findByUserIdAndIsoWeek(1005L, ISO_WEEK).get().getStatus()).isEqualTo(NpsSampleStatus.EXPIRED);
    }

    private NpsWeeklySample sample(Long userId, NpsSampleStatus status, String isoWeek) {
        return NpsWeeklySample.builder()
                .userId(userId)
                .cohortId(1L)
                .isoWeek(isoWeek)
                .status(status)
                .build();
    }
}
