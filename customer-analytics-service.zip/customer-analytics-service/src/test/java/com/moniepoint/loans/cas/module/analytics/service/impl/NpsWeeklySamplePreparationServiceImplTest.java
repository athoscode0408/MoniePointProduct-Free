package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.EventPreprocessSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.entity.Cohort;
import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyPlatform;
import com.moniepoint.loans.cas.module.analytics.enums.SurveySegment;
import com.moniepoint.loans.cas.module.analytics.repository.CohortStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;
import com.moniepoint.loans.cas.testdoubles.FakeNpsWeeklySampleStorage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NpsWeeklySamplePreparationServiceImplTest {

    private static final String ISO_WEEK = "2026-W22";
    private static final Long COHORT_ID = 1L;
    private static final Long SURVEY_ID = 10L;

    @Mock
    private CohortStorage cohortStorage;
    @Mock
    private SurveyStorage surveyStorage;
    @Mock
    private SurveyPreprocessorKafkaEventPublisher kafkaPublisher;

    private FakeNpsWeeklySampleStorage npsWeeklySampleStorage;
    private NpsWeeklySamplePreparationServiceImpl service;

    @BeforeEach
    void setUp() {
        npsWeeklySampleStorage = new FakeNpsWeeklySampleStorage(new HashMap<>());
        service = new NpsWeeklySamplePreparationServiceImpl(
                npsWeeklySampleStorage, cohortStorage, surveyStorage, kafkaPublisher);
    }

    @Test
    void prepareWeeklySample_happyPath_publishesOneEventPerPendingRow() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));

        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher, times(2)).publishEvent(any(), any(EventPreprocessSurveyDTO.class));
    }

    @Test
    void prepareWeeklySample_happyPath_marksPublishedRowsAsGenerated() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));

        service.prepareWeeklySample(ISO_WEEK);

        assertThat(npsWeeklySampleStorage.findByUserIdAndIsoWeek(1001L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.GENERATED));
        assertThat(npsWeeklySampleStorage.findByUserIdAndIsoWeek(1002L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.GENERATED));
    }

    @Test
    void prepareWeeklySample_rowPublishFails_rowStaysPendingForRetry() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));
        doThrow(new RuntimeException("kafka down"))
                .when(kafkaPublisher).publishEvent(eq("1001"), any(EventPreprocessSurveyDTO.class));

        assertThatThrownBy(() -> service.prepareWeeklySample(ISO_WEEK))
                .isInstanceOf(ServerException.class);

        assertThat(npsWeeklySampleStorage.findByUserIdAndIsoWeek(1001L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.PENDING));
    }

    @Test
    void prepareWeeklySample_rerunSameWeek_alreadyGeneratedRowsAreNotRepublished() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));

        service.prepareWeeklySample(ISO_WEEK);
        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher, times(1)).publishEvent(eq("1001"), any(EventPreprocessSurveyDTO.class));
    }

    @Test
    void prepareWeeklySample_noPendingRows_publishesNothing() {
        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void prepareWeeklySample_multipleCohorts_batchesCohortAndSurveyLookups() {
        Long cohortId2 = 2L;
        Long surveyId2 = 20L;

        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1003L, cohortId2, ISO_WEEK));

        when(cohortStorage.findAllById(anyList())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID), cohort(cohortId2, surveyId2)));
        when(surveyStorage.findAllById(anyList())).thenReturn(List.of(survey(SURVEY_ID), survey(surveyId2)));

        service.prepareWeeklySample(ISO_WEEK);

        verify(cohortStorage, times(1)).findAllById(any());
        verify(surveyStorage, times(1)).findAllById(any());
        verify(kafkaPublisher, times(3)).publishEvent(any(), any(EventPreprocessSurveyDTO.class));
    }

    @Test
    void prepareWeeklySample_dtoHasCohortIdAndIsoWeek() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));

        ArgumentCaptor<EventPreprocessSurveyDTO> captor = ArgumentCaptor.forClass(EventPreprocessSurveyDTO.class);
        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher).publishEvent(any(), captor.capture());
        EventPreprocessSurveyDTO dto = captor.getValue();
        assertThat(dto.getCohortId()).isEqualTo(COHORT_ID);
        assertThat(dto.getPreprocessedSurvey().getIsoWeek()).isEqualTo(ISO_WEEK);
        assertThat(dto.getPreprocessedSurvey().getCohortId()).isEqualTo(COHORT_ID);
        assertThat(dto.getUserAttributes()).isNull();
        assertThat(dto.getVerifiedAnalyticsEventDTO()).isNull();
    }

    @Test
    void prepareWeeklySample_dtoHasNonNullTtlAndNotReadyState_serializesWithoutError() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));

        ArgumentCaptor<EventPreprocessSurveyDTO> captor = ArgumentCaptor.forClass(EventPreprocessSurveyDTO.class);
        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher).publishEvent(any(), captor.capture());
        EventPreprocessSurveyDTO dto = captor.getValue();
        assertThat(dto.getPreprocessedSurvey().getTtl()).isNotNull();
        assertThat(dto.getPreprocessedSurvey().getState()).isEqualTo(PreprocessedSurveyState.NOT_READY);

        ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
        assertThatCode(() -> objectMapperHelper.serializeToString(dto)).doesNotThrowAnyException();
    }

    @Test
    void prepareWeeklySample_onePublishFails_stillPublishesOtherRowsThenThrows() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));
        doThrow(new RuntimeException("kafka down"))
                .when(kafkaPublisher).publishEvent(eq("1001"), any(EventPreprocessSurveyDTO.class));

        assertThatThrownBy(() -> service.prepareWeeklySample(ISO_WEEK))
                .isInstanceOf(ServerException.class);

        verify(kafkaPublisher).publishEvent(eq("1001"), any(EventPreprocessSurveyDTO.class));
        verify(kafkaPublisher).publishEvent(eq("1002"), any(EventPreprocessSurveyDTO.class));
    }

    @Test
    void prepareWeeklySample_onePublishFails_onlySuccessfulRowsBecomeGenerated() {
        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, COHORT_ID, ISO_WEEK));
        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(COHORT_ID, SURVEY_ID)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(SURVEY_ID)));
        doAnswer(invocation -> {
            if ("1001".equals(invocation.getArgument(0, String.class))) {
                throw new RuntimeException("kafka down");
            }
            return null;
        }).when(kafkaPublisher).publishEvent(anyString(), any(EventPreprocessSurveyDTO.class));

        assertThatThrownBy(() -> service.prepareWeeklySample(ISO_WEEK))
                .isInstanceOf(ServerException.class);

        assertThat(npsWeeklySampleStorage.findByUserIdAndIsoWeek(1001L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.PENDING));
        assertThat(npsWeeklySampleStorage.findByUserIdAndIsoWeek(1002L, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.GENERATED));
    }

    @Test
    void prepareWeeklySample_cohortNotFound_skipsThatCohortButProcessesOthersThenThrows() {
        Long cohortId2 = 2L;
        Long surveyId2 = 20L;

        npsWeeklySampleStorage.save(pendingSample(1001L, COHORT_ID, ISO_WEEK));
        npsWeeklySampleStorage.save(pendingSample(1002L, cohortId2, ISO_WEEK));

        when(cohortStorage.findAllById(any())).thenReturn(List.of(cohort(cohortId2, surveyId2)));
        when(surveyStorage.findAllById(any())).thenReturn(List.of(survey(surveyId2)));

        assertThatThrownBy(() -> service.prepareWeeklySample(ISO_WEEK))
                .isInstanceOf(ServerException.class);

        verify(kafkaPublisher, never()).publishEvent(eq("1001"), any());
        verify(kafkaPublisher).publishEvent(eq("1002"), any(EventPreprocessSurveyDTO.class));
    }

    @Test
    void prepareWeeklySample_doesNotPublishServedRows() {
        NpsWeeklySample served = pendingSample(1001L, COHORT_ID, ISO_WEEK);
        served.setStatus(NpsSampleStatus.SERVED);
        npsWeeklySampleStorage.save(served);

        service.prepareWeeklySample(ISO_WEEK);

        verify(kafkaPublisher, never()).publishEvent(any(), any());
    }

    private NpsWeeklySample pendingSample(Long userId, Long cohortId, String isoWeek) {
        return NpsWeeklySample.builder()
                .userId(userId)
                .cohortId(cohortId)
                .isoWeek(isoWeek)
                .status(NpsSampleStatus.PENDING)
                .build();
    }

    private Cohort cohort(Long cohortId, Long surveyId) {
        Cohort cohort = Cohort.builder()
                .surveyId(surveyId)
                .name("Test Cohort " + cohortId)
                .surveyCategory(SurveyCategory.NPS)
                .segment(SurveySegment.PERSONAL)
                .platform(SurveyPlatform.MOBILE)
                .active(true)
                .build();
        cohort.setId(cohortId);
        return cohort;
    }

    private Survey survey(Long surveyId) {
        Survey s = new Survey();
        s.setId(surveyId);
        s.setSurvey("{\"type\":\"NPS\"}");
        s.setRule("{}");
        s.setWebLocation("/web");
        s.setMobileLocation("/mobile");
        s.setPriority(10);
        return s;
    }
}
