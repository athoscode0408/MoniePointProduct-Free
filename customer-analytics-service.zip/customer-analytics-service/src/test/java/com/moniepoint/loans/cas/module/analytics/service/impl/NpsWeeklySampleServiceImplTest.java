package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.service.NpsUserStateService;
import com.moniepoint.loans.cas.testdoubles.FakeNpsWeeklySampleStorage;
import jakarta.persistence.OptimisticLockException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NpsWeeklySampleServiceImplTest {

    private static final String USERNAME = "jdoe123";
    private static final String ISO_WEEK = "2026-W22";

    @Mock
    private PreprocessedSurveyStorage preprocessedSurveyStorage;
    @Mock
    private NpsUserStateService npsUserStateService;

    private FakeNpsWeeklySampleStorage npsWeeklySampleStorage;
    private NpsWeeklySampleServiceImpl service;

    @BeforeEach
    void setUp() {
        npsWeeklySampleStorage = new FakeNpsWeeklySampleStorage(new HashMap<>());
        service = new NpsWeeklySampleServiceImpl(npsWeeklySampleStorage, preprocessedSurveyStorage, npsUserStateService);
    }

    @Test
    void serveNpsSurvey_noSampleForUserAndWeek_returnsEmpty() {
        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).isEmpty();
        verifyNoInteractions(npsUserStateService);
    }

    @Test
    void serveNpsSurvey_pendingSample_marksServedAndWritesTrigger() {
        npsWeeklySampleStorage.save(pendingSample(1001L, ISO_WEEK));
        PreprocessedSurvey expected = preprocessedSurvey();
        when(preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(eq(USERNAME), eq(ISO_WEEK), any()))
                .thenReturn(Optional.of(expected));
        when(npsUserStateService.writeTriggered(USERNAME)).thenReturn(new NpsUserState());

        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).contains(expected);
        assertThat(npsWeeklySampleStorage.findByUserNameAndIsoWeek(USERNAME, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.SERVED));
        verify(npsUserStateService, times(1)).writeTriggered(USERNAME);
    }

    @Test
    void serveNpsSurvey_generatedSample_marksServedAndWritesTrigger() {
        NpsWeeklySample generated = pendingSample(1001L, ISO_WEEK);
        generated.setStatus(NpsSampleStatus.GENERATED);
        npsWeeklySampleStorage.save(generated);
        PreprocessedSurvey expected = preprocessedSurvey();
        when(preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(eq(USERNAME), eq(ISO_WEEK), any()))
                .thenReturn(Optional.of(expected));
        when(npsUserStateService.writeTriggered(USERNAME)).thenReturn(new NpsUserState());

        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).contains(expected);
        assertThat(npsWeeklySampleStorage.findByUserNameAndIsoWeek(USERNAME, ISO_WEEK))
                .hasValueSatisfying(s -> assertThat(s.getStatus()).isEqualTo(NpsSampleStatus.SERVED));
        verify(npsUserStateService, times(1)).writeTriggered(USERNAME);
    }

    @Test
    void serveNpsSurvey_alreadyServed_returnsSurveyWithoutWritingTrigger() {
        NpsWeeklySample served = pendingSample(1001L, ISO_WEEK);
        served.setStatus(NpsSampleStatus.SERVED);
        served.setServedAt(Timestamp.from(Instant.now()));
        npsWeeklySampleStorage.save(served);

        PreprocessedSurvey expected = preprocessedSurvey();
        when(preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(eq(USERNAME), eq(ISO_WEEK), any()))
                .thenReturn(Optional.of(expected));

        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).contains(expected);
        verify(npsUserStateService, never()).writeTriggered(any());
    }

    @Test
    void serveNpsSurvey_expiredSample_returnsEmpty() {
        NpsWeeklySample expired = pendingSample(1001L, ISO_WEEK);
        expired.setStatus(NpsSampleStatus.EXPIRED);
        npsWeeklySampleStorage.save(expired);

        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).isEmpty();
        verifyNoInteractions(npsUserStateService);
    }

    @Test
    @Tag("simulation")
    void serveNpsSurvey_optimisticLockException_returnsExistingSurveyWithoutSecondTrigger() {
        npsWeeklySampleStorage.save(pendingSample(1001L, ISO_WEEK));
        PreprocessedSurvey expected = preprocessedSurvey();

        when(npsUserStateService.writeTriggered(USERNAME)).thenThrow(new OptimisticLockException("concurrent write"));
        when(preprocessedSurveyStorage.findFirstByUserAndIsoWeekAndStateIn(eq(USERNAME), eq(ISO_WEEK), any()))
                .thenReturn(Optional.of(expected));

        Optional<PreprocessedSurvey> result = service.serveNpsSurvey(USERNAME, ISO_WEEK);

        assertThat(result).contains(expected);
        verify(npsUserStateService, times(1)).writeTriggered(USERNAME);
    }

    private NpsWeeklySample pendingSample(Long userId, String isoWeek) {
        return NpsWeeklySample.builder()
                .userId(userId)
                .userName(USERNAME)
                .cohortId(1L)
                .isoWeek(isoWeek)
                .status(NpsSampleStatus.PENDING)
                .build();
    }

    private PreprocessedSurvey preprocessedSurvey() {
        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setId(999L);
        ps.setUser(USERNAME);
        ps.setIsoWeek(ISO_WEEK);
        ps.setSurveyId(10L);
        ps.setSurvey("{\"type\":\"NPS\"}");
        ps.setEvent("NPS");
        ps.setLocation("");
        ps.setPriority(10);
        ps.setState(PreprocessedSurveyState.NOT_COMPLETED);
        ps.setTtl(Timestamp.valueOf(LocalDate.now().plusDays(7).atStartOfDay()));
        return ps;
    }
}
