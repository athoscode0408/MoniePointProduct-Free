package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyExpiryView;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.test.util.ReflectionTestUtils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PreprocessedSurveyExpiryServiceImplTests {

    private static final long BATCH_SIZE = 500L;
    private static final int V2_BATCH_SIZE = 10;

    @Mock
    private PreprocessedSurveyStorage preprocessedSurveyStorage;

    @Mock
    private RedisCacheServiceImpl cache;

    @InjectMocks
    private PreprocessedSurveyExpiryServiceImpl expiryService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(expiryService, "batchSize", BATCH_SIZE);
        ReflectionTestUtils.setField(expiryService, "maxDurationMins", 60L);
        ReflectionTestUtils.setField(expiryService, "v2BatchSize", V2_BATCH_SIZE);
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "NOT_COMPLETED,NOT_READY");
        lenient().when(cache.getExpiryCursor()).thenReturn(0L);
    }

    // ── expirePreprocessedSurveys (v1) ────────────────────────────────────────

    @Test
    void expirePreprocessedSurveys_zeroExpiredOnFirstBatch_stopsAfterOneBatchCall() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE)).thenReturn(0);

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(1)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_partialBatch_stopsAfterOneBatchCall() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE)).thenReturn(250);

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(1)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_fullBatchThenPartialBatch_stopAfterTwoBatchCalls() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenReturn((int) BATCH_SIZE)
                .thenReturn(120);

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(2)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_fullBatchThenEmpty_stopsAfterTwoBatchCalls() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenReturn((int) BATCH_SIZE)
                .thenReturn(0);

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(2)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_multipleFullBatchesThenPartial_processesAllBatches() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenReturn((int) BATCH_SIZE)
                .thenReturn((int) BATCH_SIZE)
                .thenReturn((int) BATCH_SIZE)
                .thenReturn(99);

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(4)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_exceptionInFirstBatch_doesNotPropagate() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenThrow(new RuntimeException("Database connection lost"));

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveys());
    }

    @Test
    void expirePreprocessedSurveys_exceptionInFirstBatch_stopsAfterOneAttempt() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenThrow(new RuntimeException("Timeout"));

        expiryService.expirePreprocessedSurveys();

        verify(preprocessedSurveyStorage, times(1)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    @Test
    void expirePreprocessedSurveys_exceptionAfterSuccessfulBatches_stopsGracefully() {
        when(preprocessedSurveyStorage.expirePreprocessedSurveys(BATCH_SIZE))
                .thenReturn((int) BATCH_SIZE)
                .thenReturn((int) BATCH_SIZE)
                .thenThrow(new RuntimeException("Transient failure"));

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveys());
        verify(preprocessedSurveyStorage, times(3)).expirePreprocessedSurveys(BATCH_SIZE);
    }

    // ── expirePreprocessedSurveysV2 — config guards ───────────────────────────

    @Test
    void expirePreprocessedSurveysV2_noEligibleStates_abortsWithoutAnyDbCalls() {
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "");

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
    }

    @Test
    void expirePreprocessedSurveysV2_invalidEligibleState_ignoresItAndProceedsWithValidStates() {
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "NOT_COMPLETED,BOGUS_STATE");
        when(preprocessedSurveyStorage.findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        // Did not abort — reached the DB call
        verify(preprocessedSurveyStorage, times(1)).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
    }

    @Test
    void expirePreprocessedSurveysV2_allStatesInvalid_abortsWithoutDbCalls() {
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "BOGUS,ANOTHER_BOGUS");

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
    }

    // ── expirePreprocessedSurveysV2 — cursor initialisation ──────────────────

    @Test
    void expirePreprocessedSurveysV2_startsFromStoredCursor() {
        long storedCursor = 500L;
        when(cache.getExpiryCursor()).thenReturn(storedCursor);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(storedCursor), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(1))
                .findBatchStartingAfter(eq(storedCursor), anyCollection(), any(Pageable.class));
    }

    @Test
    void expirePreprocessedSurveysV2_noCursorInRedis_startsFromZero() {
        when(cache.getExpiryCursor()).thenReturn(0L);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(1))
                .findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class));
    }

    // ── expirePreprocessedSurveysV2 — empty batch ────────────────────────────

    @Test
    void expirePreprocessedSurveysV2_emptyFirstBatch_resetsCursorToZero() {
        when(preprocessedSurveyStorage.findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(cache, times(1)).setExpiryCursor(0L);
        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
    }

    // ── expirePreprocessedSurveysV2 — TTL filtering ──────────────────────────

    @Test
    void expirePreprocessedSurveysV2_allRowsExpired_expiresAllIdsInBatch() {
        List<PreprocessedSurveyExpiryView> batch = List.of(
                expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(2L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(3L, PreprocessedSurveyState.NOT_READY)
        );
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(3L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(1)).expireByIds(List.of(1L, 2L, 3L));
    }

    @Test
    void expirePreprocessedSurveysV2_mixedTtl_expiresOnlyExpiredRows() {
        List<PreprocessedSurveyExpiryView> batch = List.of(
                expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED),
                activeView(2L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(3L, PreprocessedSurveyState.NOT_READY),
                activeView(4L, PreprocessedSurveyState.NOT_READY)
        );
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(4L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(1)).expireByIds(List.of(1L, 3L));
    }

    @Test
    void expirePreprocessedSurveysV2_allRowsActiveTtl_stopsEarlyAndSavesCursor() {
        List<PreprocessedSurveyExpiryView> batch = List.of(
                activeView(1L, PreprocessedSurveyState.NOT_COMPLETED),
                activeView(2L, PreprocessedSurveyState.NOT_COMPLETED)
        );
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch);

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
        // cursor saved at last id in batch, not reset to 0
        verify(cache).setExpiryCursor(2L);
        verify(cache, never()).setExpiryCursor(0L);
        // no further batch fetched after the empty-toExpire stop
        verify(preprocessedSurveyStorage, times(1)).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
    }

    @Test
    void expirePreprocessedSurveysV2_nullTtl_rowSkippedAndJobStopsEarly() {
        PreprocessedSurveyExpiryView nullTtlView = mock(PreprocessedSurveyExpiryView.class);
        when(nullTtlView.getId()).thenReturn(1L);
        when(nullTtlView.getState()).thenReturn(PreprocessedSurveyState.NOT_COMPLETED);
        when(nullTtlView.getTtl()).thenReturn(null);

        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of(nullTtlView));

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
        verify(cache).setExpiryCursor(1L);
        // stopped early — no second batch fetch
        verify(preprocessedSurveyStorage, times(1)).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
    }

    @Test
    void expirePreprocessedSurveysV2_batchWithNoExpiredRows_doesNotFetchSubsequentBatches() {
        List<PreprocessedSurveyExpiryView> expiredBatch = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        List<PreprocessedSurveyExpiryView> activeBatch  = List.of(activeView(2L, PreprocessedSurveyState.NOT_COMPLETED));

        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(expiredBatch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class)))
                .thenReturn(activeBatch);

        expiryService.expirePreprocessedSurveysV2();

        // expired batch processed, active batch triggers early stop — no third fetch
        verify(preprocessedSurveyStorage, times(2)).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
        verify(preprocessedSurveyStorage, times(1)).expireByIds(anyCollection());
        verify(cache).setExpiryCursor(1L);  // after expired batch
        verify(cache).setExpiryCursor(2L);  // early stop cursor
        verify(cache, never()).setExpiryCursor(0L);
    }

    // ── expirePreprocessedSurveysV2 — cursor advancement ────────────────────

    @Test
    void expirePreprocessedSurveysV2_cursorAdvancesToLastIdInEachBatch() {
        List<PreprocessedSurveyExpiryView> batch1 = List.of(
                expiredView(10L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(20L, PreprocessedSurveyState.NOT_COMPLETED)
        );
        List<PreprocessedSurveyExpiryView> batch2 = List.of(
                expiredView(30L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(40L, PreprocessedSurveyState.NOT_COMPLETED)
        );
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch1);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(20L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch2);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(40L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(cache).setExpiryCursor(20L);
        verify(cache).setExpiryCursor(40L);
        verify(cache).setExpiryCursor(0L); // reset at end
    }

    @Test
    void expirePreprocessedSurveysV2_multipleBatches_processesAllBatches() {
        List<PreprocessedSurveyExpiryView> batch1 = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        List<PreprocessedSurveyExpiryView> batch2 = List.of(expiredView(2L, PreprocessedSurveyState.NOT_COMPLETED));
        List<PreprocessedSurveyExpiryView> batch3 = List.of(expiredView(3L, PreprocessedSurveyState.NOT_COMPLETED));

        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class))).thenReturn(batch1);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class))).thenReturn(batch2);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(2L), anyCollection(), any(Pageable.class))).thenReturn(batch3);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(3L), anyCollection(), any(Pageable.class))).thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(4)).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
        verify(preprocessedSurveyStorage, times(3)).expireByIds(anyCollection());
    }

    @Test
    void expirePreprocessedSurveysV2_endOfTable_cursorResetToZero() {
        PreprocessedSurveyExpiryView row = expiredView(5L, PreprocessedSurveyState.NOT_COMPLETED);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of(row));
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(5L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(cache).setExpiryCursor(5L);   // after first batch
        verify(cache).setExpiryCursor(0L);   // reset at end
    }

    // ── expirePreprocessedSurveysV2 — error resilience ───────────────────────

    @Test
    void expirePreprocessedSurveysV2_expireByIdsThrows_cursorStillAdvancesAndDoesNotPropagate() {
        List<PreprocessedSurveyExpiryView> batch = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class)))
                .thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());
        when(preprocessedSurveyStorage.expireByIds(anyCollection()))
                .thenThrow(new RuntimeException("DB unavailable"));

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveysV2());
        verify(cache).setExpiryCursor(1L);  // cursor advanced despite expiry failure
    }

    @Test
    void expirePreprocessedSurveysV2_doesNotPropagate() {
        when(preprocessedSurveyStorage.findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveysV2());
    }

    // ── expirePreprocessedSurveysV2 — additional edge cases ──────────────────

    @Test
    void expirePreprocessedSurveysV2_expireByIdsThrowsOnSecondBatch_continuesScanningAndDoesNotPropagate() {
        List<PreprocessedSurveyExpiryView> batch1 = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        List<PreprocessedSurveyExpiryView> batch2 = List.of(expiredView(2L, PreprocessedSurveyState.NOT_COMPLETED));

        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class))).thenReturn(batch1);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class))).thenReturn(batch2);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(2L), anyCollection(), any(Pageable.class))).thenReturn(List.of());
        when(preprocessedSurveyStorage.expireByIds(List.of(1L))).thenReturn(1);
        when(preprocessedSurveyStorage.expireByIds(List.of(2L))).thenThrow(new RuntimeException("DB timeout"));

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveysV2());

        // both batches attempted
        verify(preprocessedSurveyStorage, times(2)).expireByIds(anyCollection());
        // cursor advanced past the failing batch and then reset at end-of-table
        verify(cache).setExpiryCursor(1L);
        verify(cache).setExpiryCursor(2L);
        verify(cache).setExpiryCursor(0L);
    }

    @Test
    void expirePreprocessedSurveysV2_nonZeroCursorAndEmptyFirstBatch_resetsCursorToZero() {
        long storedCursor = 500L;
        when(cache.getExpiryCursor()).thenReturn(storedCursor);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(storedCursor), anyCollection(), any(Pageable.class)))
                .thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
        verify(cache, times(1)).setExpiryCursor(0L);
    }

    @Test
    void expirePreprocessedSurveysV2_expireByIdsReturnsZero_cursorAdvancesNormally() {
        List<PreprocessedSurveyExpiryView> batch = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class))).thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class))).thenReturn(List.of());
        when(preprocessedSurveyStorage.expireByIds(anyCollection())).thenReturn(0);

        assertDoesNotThrow(() -> expiryService.expirePreprocessedSurveysV2());

        verify(cache).setExpiryCursor(1L);
        verify(cache).setExpiryCursor(0L);
    }

    @Test
    void expirePreprocessedSurveysV2_whitespaceOnlyEligibleStates_abortsWithoutDbCalls() {
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "   ");

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, never()).findBatchStartingAfter(anyLong(), anyCollection(), any(Pageable.class));
        verify(preprocessedSurveyStorage, never()).expireByIds(anyCollection());
    }

    @Test
    void expirePreprocessedSurveysV2_singleEligibleState_processesCorrectly() {
        ReflectionTestUtils.setField(expiryService, "eligibleStatesConfig", "NOT_COMPLETED");
        List<PreprocessedSurveyExpiryView> batch = List.of(
                expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED),
                expiredView(2L, PreprocessedSurveyState.NOT_COMPLETED)
        );
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class))).thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(2L), anyCollection(), any(Pageable.class))).thenReturn(List.of());

        expiryService.expirePreprocessedSurveysV2();

        verify(preprocessedSurveyStorage, times(1)).expireByIds(List.of(1L, 2L));
        verify(cache).setExpiryCursor(2L);
        verify(cache).setExpiryCursor(0L);
    }

    @Test
    void expirePreprocessedSurveysV2_expireByIdsThrows_fullCursorLifecycleCompletes() {
        List<PreprocessedSurveyExpiryView> batch = List.of(expiredView(1L, PreprocessedSurveyState.NOT_COMPLETED));
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(0L), anyCollection(), any(Pageable.class))).thenReturn(batch);
        when(preprocessedSurveyStorage.findBatchStartingAfter(eq(1L), anyCollection(), any(Pageable.class))).thenReturn(List.of());
        when(preprocessedSurveyStorage.expireByIds(anyCollection())).thenThrow(new RuntimeException("DB unavailable"));

        expiryService.expirePreprocessedSurveysV2();

        verify(cache).setExpiryCursor(1L);  // cursor advanced past failing batch
        verify(cache).setExpiryCursor(0L);  // reset at end-of-table
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private PreprocessedSurveyExpiryView expiredView(long id, PreprocessedSurveyState state) {
        return view(id, state, Timestamp.from(Instant.now().minus(1, ChronoUnit.HOURS)));
    }

    private PreprocessedSurveyExpiryView activeView(long id, PreprocessedSurveyState state) {
        return view(id, state, Timestamp.from(Instant.now().plus(1, ChronoUnit.HOURS)));
    }

    private PreprocessedSurveyExpiryView view(long id, PreprocessedSurveyState state, Timestamp ttl) {
        PreprocessedSurveyExpiryView v = mock(PreprocessedSurveyExpiryView.class);
        lenient().when(v.getId()).thenReturn(id);
        lenient().when(v.getState()).thenReturn(state);
        lenient().when(v.getTtl()).thenReturn(ttl);
        return v;
    }
}
