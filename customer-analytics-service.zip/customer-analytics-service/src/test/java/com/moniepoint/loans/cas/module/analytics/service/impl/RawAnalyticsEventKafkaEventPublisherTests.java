package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RawAnalyticsEventKafkaEventPublisherTests {

    private RawAnalyticsEventKafkaEventPublisher rawAnalyticsEventKafkaEventPublisher;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        rawAnalyticsEventKafkaEventPublisher = new RawAnalyticsEventKafkaEventPublisher(
                "test-topic", kafkaTemplate, objectMapperHelper, telemetry
        );
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @Test
    void getTopic_success() {
        assertThat(rawAnalyticsEventKafkaEventPublisher.getTopic()).isEqualTo("test-topic");
    }

    @Test
    void publishEvent_success() {
        AnalyticsEventV1RequestDTO analyticsEventRequestDTO = AnalyticsEventV1RequestDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();

        String content = "{\n" +
                "    \"eventType\": \"prequalification\",\n" +
                "    \"id\": \"123\",\n" +
                "    \"timestamp\": 1725887178,\n" +
                "    \"platform\": \"MOBILE\",\n" +
                "    \"environment\": \"DEVELOPMENT\",\n" +
                "    \"data\": {\n" +
                "        \"email\": \"test@test.co\"\n" +
                "    }\n" +
                "}";
        @SuppressWarnings("unchecked")
        SendResult<String, String> sendResult = mock(SendResult.class);

        when(kafkaTemplate.send(any(), anyString(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));
        when(objectMapperHelper.serializeToString(any(AnalyticsEventV1RequestDTO.class)))
                .thenReturn(content);

        rawAnalyticsEventKafkaEventPublisher.publishEvent(analyticsEventRequestDTO);

        verify(kafkaTemplate).send(eq("test-topic"), anyString(), eq(content));
    }


    @Test
    void publishEvent_withoutEventData_verifiesEventNotSendKafka() {
        rawAnalyticsEventKafkaEventPublisher.publishEvent(null);

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV1RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }

    @Test
    void publishEvent_withoutEventKey_verifiesEventNotSendKafka() {
        rawAnalyticsEventKafkaEventPublisher.publishEvent(AnalyticsEventV1RequestDTO.builder().build());

        verify(objectMapperHelper, never()).serializeToString(any(AnalyticsEventV1RequestDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }
}
