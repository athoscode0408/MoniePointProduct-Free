package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.testdoubles.FakePreprocessedSurveyStorage;
import com.moniepoint.loans.cas.testdoubles.FakeSurveyStorage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import org.mockito.ArgumentCaptor;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RuleParserTests {
    private VerifiedAnalyticsEventDTO surveyTriggeringEvent;

    private FakeSurveyStorage surveyStorage;
    private FakePreprocessedSurveyStorage preprocessedSurveyStorage;



    @InjectMocks
    private RuleParserHandler ruleParserHandler;
    @Mock
    SurveyPreprocessorKafkaEventPublisher surveyPreprocessorKafkaEventPublisher;
    ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
    @Mock
    RuntimeSurveyScheduler runtimeSurveyScheduler;
    Survey rule;
    Survey rule2;

    @BeforeEach
    void setup() {
        rule = new Survey("event.eventType == 'trigger_survey_event'", 10, "{}","","", SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(3L);

        rule2 = new Survey("event.platform == 'ios'", 9, "{}","","", SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule2.setId(4L);

        surveyStorage = new FakeSurveyStorage(new HashMap<>() {{
            put(3L, rule);
            put(4L, rule2);

        }});
        preprocessedSurveyStorage = new FakePreprocessedSurveyStorage(new HashMap<>());

        surveyTriggeringEvent = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        surveyTriggeringEvent.setEventType("trigger_survey_event");

        ruleParserHandler = new RuleParserHandler(
                surveyPreprocessorKafkaEventPublisher,
                preprocessedSurveyStorage,
                objectMapperHelper,
                runtimeSurveyScheduler,
                new SurveyBodyLoader(objectMapperHelper)
        );
        ReflectionTestUtils.setField(ruleParserHandler, "responseWindowMins", 7L);
        ReflectionTestUtils.setField(ruleParserHandler, "responseCount", 2);
        ReflectionTestUtils.setField(ruleParserHandler, "responseWindowMinsIndividualsurvey", 30L);
        ReflectionTestUtils.setField(ruleParserHandler, "responseCountIndividualsurvey", 1);
        ReflectionTestUtils.setField(ruleParserHandler, "useUserSurveyHistory", true);

    }

    @Test
    void eventOnlyRulesAreEvaluated() {

        ruleParserHandler.parseRule(rule,surveyTriggeringEvent,surveyTriggeringEvent.getUserAttributes());

//        verify(surveyPushNotificationKafkaEventPublisher, times(1)).publishEvent(any(), any());
        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
        assertEquals(1, preprocessedSurveyStorage.data.size());

    }

    @Test
    void eventWithNoMatchingRulesAreNotPreprocessed() {

        surveyTriggeringEvent.setEventType("not_trigger_survey_event");

        ruleParserHandler.parseRule(rule,surveyTriggeringEvent,surveyTriggeringEvent.getUserAttributes());

//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
        assertEquals(0, preprocessedSurveyStorage.data.size());

    }

    @Test
    void eventPlatformIsWeb_webLocationUsed() {
        var rule = new Survey("event.eventType == 'trigger_survey_user_event' && user.email == 'test@email.com'", 10, "{}","webLocation","mobileLocation",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(2L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .webAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        event.setEventType("trigger_survey_user_event");
        event.setUserAttributes(UserAttributes.builder().email("test@email.com").build());

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

         assertEquals("webLocation", preprocessedSurveyStorage.findAll().getFirst().getLocation());
    }

    @Test
    void eventPlatformIsWeb_androidLocationUsed() {
        var rule = new Survey("event.eventType == 'trigger_survey_user_event' && user.email == 'test@email.com'", 10, "{}","webLocation","mobileLocation",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(2L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        event.setEventType("trigger_survey_user_event");
        event.setUserAttributes(UserAttributes.builder().email("test@email.com").build());

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        assertEquals("mobileLocation", preprocessedSurveyStorage.findAll().getFirst().getLocation());
    }



    @Test
    void eventPlatformMissingInRequest_defaultToMobile() {
        var rule = new Survey("event.eventType == 'trigger_survey_user_event' && user.email == 'test@email.com'", 10, "{}","webLocation","mobileLocation",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(2L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .authenticatedEventWithNoPlatform("known-test-user", "test@email.com", "2169633555", "Test user");
        event.setEventType("trigger_survey_user_event");
        event.setUserAttributes(UserAttributes.builder().email("test@email.com").build());

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        assertEquals("mobileLocation", preprocessedSurveyStorage.findAll().getFirst().getLocation());
    }


    @Test
    void userAttributeRulesAreEvaluated() {
        var rule = new Survey("event.eventType == 'trigger_survey_user_event' && user.email == 'test@email.com'", 10, "{\"body\":\"body\"}","","",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(2L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        event.setEventType("trigger_survey_user_event");
        event.setUserAttributes(UserAttributes.builder().email("test@email.com").build());

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

//        verify(surveyPushNotificationKafkaEventPublisher, times(1)).publishEvent(any(), any());
        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
        assertEquals(1, preprocessedSurveyStorage.data.size());

    }

    @Test
    void canEvaluateRulesWithJustEventUserAttributes() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{}","","",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(2L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user6", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

//        verify(surveyPushNotificationKafkaEventPublisher, times(1)).publishEvent(any(), any());
        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
        assertEquals(1, preprocessedSurveyStorage.data.size());
    }


    @Test
    void willEvaluateBRMSurveyScheduleRules() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt())).thenReturn(new RuntimeSurveyScheduler.Plan(2,true,false));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(runtimeSurveyScheduler, times(1)).planNext(anyLong(), any(), any(), anyInt());

    }

    @Test
    void willNotEvaluateBRMSurveyScheduleRules() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{}","","",SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(runtimeSurveyScheduler, never()).planNext(anyLong(), any(), any(), anyInt());

    }

    @Test
    void evaluate_returnsFalse_whenPlanEvaluateSurveyFalse() {

        Survey survey = mock(Survey.class);
        long surveyId = 123L;
        Timestamp start = Timestamp.from(Instant.now());
        when(survey.getId()).thenReturn(surveyId);
        when(survey.getStart()).thenReturn(start);
        when(survey.getDurationInDays()).thenReturn(90);


        var expectedPlan = new RuntimeSurveyScheduler.Plan(2, true, false);
        when(runtimeSurveyScheduler.planNext(surveyId, "user-1", start.toInstant(), 90))
                .thenReturn(expectedPlan);
        boolean result = ruleParserHandler.evaluateBRMSurveyEligibilityForUser(survey, "user-1");
        assertThat(result).isFalse();
        verify(runtimeSurveyScheduler, times(1)).planNext(surveyId, "user-1", start.toInstant(),90);
    }

    @Test
    void evaluate_returnsTrue_whenPlanEvaluateSurveyTrue(){

        Survey survey = mock(Survey.class);
        long surveyId = 123L;
        Timestamp start = Timestamp.from(Instant.now());
        when(survey.getId()).thenReturn(surveyId);
        when(survey.getStart()).thenReturn(start);
        when(survey.getDurationInDays()).thenReturn(90);


        var expectedPlan = new RuntimeSurveyScheduler.Plan(2, false, true);
        when(runtimeSurveyScheduler.planNext(surveyId, "user-1", start.toInstant(),90))
                .thenReturn(expectedPlan);
        boolean result = ruleParserHandler.evaluateBRMSurveyEligibilityForUser(survey, "user-1");
        assertThat(result).isTrue();
        verify(runtimeSurveyScheduler, times(1)).planNext(surveyId, "user-1", start.toInstant(),90);
    }

    @Test
    void hasOpenBrmSurvey_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);
        PreprocessedSurvey ps = new PreprocessedSurvey();
        String additionalInfo = "{\"brmId\":\"brmid\"}";
        ps.setAdditionalData(additionalInfo);
        preprocessedSurveyStorage.save(ps);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasOpenBrmSurvey_requestWithoutBrmID_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);
        PreprocessedSurvey ps = new PreprocessedSurvey();
        String additionalInfo = "{\"brmId\":\"brmid\"}";
        ps.setAdditionalData(additionalInfo);
        preprocessedSurveyStorage.save(ps);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasOpenNonBrmSurvey_WillNotEvaluate() {
    var rule = new Survey("user.email == 'test@email.com'", 10, "{}","","",SurveyCategory.CSAT, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);
        PreprocessedSurvey ps = new PreprocessedSurvey();
        String additionalInfo = "{\"brmId\":\"brmid\"}";
        ps.setAdditionalData(additionalInfo);
        preprocessedSurveyStorage.save(ps);

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasOpenBrmSurveyWithNoBrmId_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);
        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasSameRecentlyBRMCompletedSurvey_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);

        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasSameRecentlyNonBRMCompletedSurvey_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{}","","",SurveyCategory.CSAT, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);

        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasRecentlyCompletedSameSurveyWithoutBrmId_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);

        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);

        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user1", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasMaxTotalSurveyInConfiguredPeriod_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);

        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);

        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user2", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasMaxTotalSurveyInConfiguredPeriod_WithNoBRMSurveys_WillNotEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{}","","",SurveyCategory.CSAT, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        PreprocessedSurvey ps = new PreprocessedSurvey();
        ps.setSurveyId(8L);
        preprocessedSurveyStorage.save(ps);

        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user2", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void hasMaxTotalSurveyInConfiguredPeriod_WithoutBrmId_WillEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user3", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
//        verify(surveyPushNotificationKafkaEventPublisher, times(1)).publishEvent(any(), any());
    }

    @Test
    void hasNoSurveyCompletedInConfiguredPeriod_willEvaluate() {
        var rule = new Survey("user.email == 'test@email.com'", 10, "{\"randomizeSurveyAssignment\" : true}","","",SurveyCategory.BRM, Timestamp.from(Instant.now()),90);
        rule.setId(8L);
        surveyStorage.save(rule);
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("unknown-test-user4", "test@email.com", "2169633555", "Test user");
        UserAttributes userAttributes = UserAttributes.builder().email("test@email.com").phone("2169633555").name("Test user").brmId("brmid").customAttributes(Map.of()).build();
        event.setUserAttributes(userAttributes);

        when(runtimeSurveyScheduler.planNext(anyLong(), any(), any(), anyInt()))
                .thenReturn(new RuntimeSurveyScheduler.Plan(2,false,true));

        ruleParserHandler.parseRule(rule,event,event.getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
    }

    // -----------------------------------------------------------------------
    // Tests for the maxMins DB query window fix
    // -----------------------------------------------------------------------

    @Test
    void dbQuery_usesIndividualWindowWhenLargerThanGlobal() {
        // survey body has a 60-min individual window; global default is 7 min
        // the DB query cutoff must use the wider 60-min window so completed-survey
        // records between 7 and 60 minutes ago are not missed
        var rule = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 60, \"maxCountUniqueSurveyInResponseWindow\": 1}", 201L);

        PreprocessedSurveyStorage mockStorage = mock(PreprocessedSurveyStorage.class);
        ArgumentCaptor<Timestamp> cutoffCaptor = ArgumentCaptor.forClass(Timestamp.class);
        when(mockStorage.findByUserAndStateInOrUserAndCompletedOnAfter(any(), any(), any(), cutoffCaptor.capture()))
                .thenReturn(List.of());

        var handler = handlerWithMockStorage(mockStorage);
        handler.parseRule(rule, androidEvent("dbq-user-1"), androidEvent("dbq-user-1").getUserAttributes());

        long diffSeconds = Math.abs(Duration.between(
                cutoffCaptor.getValue().toInstant(),
                Instant.now().minus(60, ChronoUnit.MINUTES)).toSeconds());
        assertThat(diffSeconds).isLessThan(5L);
    }

    @Test
    void dbQuery_usesGlobalWindowWhenLargerThanIndividual() {
        // survey body has a 5-min individual window; global default is 7 min
        // the DB query cutoff must use the wider 7-min global window
        var rule = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 5, \"maxCountUniqueSurveyInResponseWindow\": 1}", 202L);

        PreprocessedSurveyStorage mockStorage = mock(PreprocessedSurveyStorage.class);
        ArgumentCaptor<Timestamp> cutoffCaptor = ArgumentCaptor.forClass(Timestamp.class);
        when(mockStorage.findByUserAndStateInOrUserAndCompletedOnAfter(any(), any(), any(), cutoffCaptor.capture()))
                .thenReturn(List.of());

        var handler = handlerWithMockStorage(mockStorage);
        handler.parseRule(rule, androidEvent("dbq-user-2"), androidEvent("dbq-user-2").getUserAttributes());

        long diffSeconds = Math.abs(Duration.between(
                cutoffCaptor.getValue().toInstant(),
                Instant.now().minus(7, ChronoUnit.MINUTES)).toSeconds());
        assertThat(diffSeconds).isLessThan(5L);
    }

    @Test
    void surveyBodyWindow_preventsRepeatDeliveryWithinIndividualWindow() {
        // survey body: 60-min individual window, max 1 completion
        // user completed the same survey 30 minutes ago — must be blocked
        var rule = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 60, \"maxCountUniqueSurveyInResponseWindow\": 1}", 203L);
        Timestamp thirtyMinsAgo = Timestamp.from(Instant.now().minus(30, ChronoUnit.MINUTES));
        PreprocessedSurvey completed = completedSurvey(rule.getId(), "repeat-user", thirtyMinsAgo);

        PreprocessedSurveyStorage mockStorage = mock(PreprocessedSurveyStorage.class);
        when(mockStorage.findByUserAndStateInOrUserAndCompletedOnAfter(any(), any(), any(), any()))
                .thenReturn(List.of(completed));

        handlerWithMockStorage(mockStorage).parseRule(rule, androidEvent("repeat-user"), androidEvent("repeat-user").getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, never()).publishEvent(any(), any());
    }

    @Test
    void surveyBodyCount_higherThanDefault_allowsAdditionalCompletionsUpToBodyLimit() {
        // survey body: 60-min window, max 3 completions (default is 1)
        // user completed the same survey twice 20 minutes ago — must still be eligible
        var rule = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 60, \"maxCountUniqueSurveyInResponseWindow\": 3}", 204L);
        Timestamp twentyMinsAgo = Timestamp.from(Instant.now().minus(20, ChronoUnit.MINUTES));
        PreprocessedSurvey ps1 = completedSurvey(rule.getId(), "multi-user", twentyMinsAgo);
        PreprocessedSurvey ps2 = completedSurvey(rule.getId(), "multi-user", twentyMinsAgo);

        PreprocessedSurveyStorage mockStorage = mock(PreprocessedSurveyStorage.class);
        when(mockStorage.findByUserAndStateInOrUserAndCompletedOnAfter(any(), any(), any(), any()))
                .thenReturn(List.of(ps1, ps2));

        handlerWithMockStorage(mockStorage).parseRule(rule, androidEvent("multi-user"), androidEvent("multi-user").getUserAttributes());

        verify(surveyPreprocessorKafkaEventPublisher, times(1)).publishEvent(any(), any());
    }

    // -----------------------------------------------------------------------
    // Test for the race condition fix (no instance-field mutation)
    // -----------------------------------------------------------------------

    @Test
    void concurrentParseRule_differentSurveyBodies_eachCallUsesItsOwnWindow() throws InterruptedException {
        // Survey A: 120-min individual window. Survey B: 10-min individual window.
        // Fire both concurrently many times; every captured DB-query cutoff must land
        // squarely at either ~120 min or ~10 min ago. A race on instance fields would
        // produce cutoffs that match neither.
        var surveyA = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 120, \"maxCountUniqueSurveyInResponseWindow\": 1}", 301L);
        var surveyB = surveyWithBody("{\"responseWindowUniqueSurveyMins\": 10, \"maxCountUniqueSurveyInResponseWindow\": 1}", 302L);

        List<Timestamp> capturedCutoffs = Collections.synchronizedList(new ArrayList<>());
        PreprocessedSurveyStorage mockStorage = mock(PreprocessedSurveyStorage.class);
        when(mockStorage.findByUserAndStateInOrUserAndCompletedOnAfter(any(), any(), any(), any()))
                .thenAnswer(inv -> { capturedCutoffs.add(inv.getArgument(3)); return List.of(); });

        RuleParserHandler handler = handlerWithMockStorage(mockStorage);
        ReflectionTestUtils.setField(handler, "notReadySurveyTtl", 180);

        int rounds = 20;
        CountDownLatch latch = new CountDownLatch(rounds * 2);
        ExecutorService executor = Executors.newFixedThreadPool(rounds * 2);

        for (int i = 0; i < rounds; i++) {
            final int idx = i;
            executor.submit(() -> {
                try { handler.parseRule(surveyA, androidEvent("concurrent-a-" + idx), androidEvent("concurrent-a-" + idx).getUserAttributes()); }
                finally { latch.countDown(); }
            });
            executor.submit(() -> {
                try { handler.parseRule(surveyB, androidEvent("concurrent-b-" + idx), androidEvent("concurrent-b-" + idx).getUserAttributes()); }
                finally { latch.countDown(); }
            });
        }

        latch.await(10, TimeUnit.SECONDS);
        executor.shutdown();

        Instant expectedA = Instant.now().minus(120, ChronoUnit.MINUTES);
        Instant expectedB = Instant.now().minus(10, ChronoUnit.MINUTES);

        for (Timestamp cutoff : capturedCutoffs) {
            long diffA = Math.abs(Duration.between(cutoff.toInstant(), expectedA).toSeconds());
            long diffB = Math.abs(Duration.between(cutoff.toInstant(), expectedB).toSeconds());
            assertThat(diffA <= 5 || diffB <= 5)
                    .as("cutoff %s must be within 5 s of either the 120-min or 10-min window", cutoff)
                    .isTrue();
        }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private Survey surveyWithBody(String bodyJson, long id) {
        var s = new Survey("user.email == 'test@email.com'", 10, bodyJson, "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        s.setId(id);
        return s;
    }

    private RuleParserHandler handlerWithMockStorage(PreprocessedSurveyStorage storage) {
        RuleParserHandler h = new RuleParserHandler(surveyPreprocessorKafkaEventPublisher, storage, objectMapperHelper, runtimeSurveyScheduler, new SurveyBodyLoader(objectMapperHelper));
        ReflectionTestUtils.setField(h, "responseWindowMins", 7L);
        ReflectionTestUtils.setField(h, "responseCount", 2);
        ReflectionTestUtils.setField(h, "responseWindowMinsIndividualsurvey", 30L);
        ReflectionTestUtils.setField(h, "responseCountIndividualsurvey", 1);
        ReflectionTestUtils.setField(h, "useUserSurveyHistory", true);
        return h;
    }

    private VerifiedAnalyticsEventDTO androidEvent(String userId) {
        var event = com.moniepoint.loans.cas.module.kakfa.listner.VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent(userId, "test@email.com", "1234567890", "Test User");
        event.setUserAttributes(UserAttributes.builder().email("test@email.com").build());
        return event;
    }

    private PreprocessedSurvey completedSurvey(Long surveyId, String userId, Timestamp completedOn) {
        return PreprocessedSurvey.builder()
                .surveyId(surveyId)
                .user(userId)
                .state(PreprocessedSurveyState.COMPLETED)
                .completedOn(completedOn)
                .ttl(Timestamp.from(Instant.now().plus(60, ChronoUnit.MINUTES)))
                .event("test-event")
                .build();
    }
}
