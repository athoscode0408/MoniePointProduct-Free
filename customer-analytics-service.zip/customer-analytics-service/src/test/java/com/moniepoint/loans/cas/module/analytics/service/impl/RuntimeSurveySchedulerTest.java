package com.moniepoint.loans.cas.module.analytics.service.impl;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


@ExtendWith(MockitoExtension.class)
public class RuntimeSurveySchedulerTest {

    private static Method getPlan;
    private static Method getStartAndEnd;
    private static Class<?> rangeClass;


    @BeforeAll
    static void setup() throws Exception {
        getPlan = RuntimeSurveyScheduler.class.getDeclaredMethod(
                "getPlan",
                long.class, String.class, ZoneId.class, ZonedDateTime.class, Instant.class, int.class,int.class
        );
        getPlan.setAccessible(true);

        Class<?> scheduler = Class.forName("com.moniepoint.loans.cas.module.analytics.service.impl.RuntimeSurveyScheduler");
        getStartAndEnd = scheduler.getDeclaredMethod(
                "getStartAndEnd",
                ZonedDateTime.class, ZonedDateTime.class, ZonedDateTime.class, ZonedDateTime.class, int.class
        );
        getStartAndEnd.setAccessible(true);

        for (Class<?> nested : scheduler.getDeclaredClasses()) {
            if (nested.getSimpleName().equals("Range")) {
                rangeClass = nested;
                break;
            }
        }
        if (rangeClass == null) throw new IllegalStateException("Range class not found");


    }

    private RuntimeSurveyScheduler.Plan invoke(long surveyId, String userId, ZoneId zone,
                                               ZonedDateTime surveyStartLocal, Instant nowUtc, int initialWindow) {
        try {
            return (RuntimeSurveyScheduler.Plan) getPlan.invoke(
                    null, surveyId, userId, zone, surveyStartLocal, nowUtc, initialWindow, 90
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Integer tryGetWindow(RuntimeSurveyScheduler.Plan p) {
        try {
            var f = p.getClass().getDeclaredField("windowIndex");
            f.setAccessible(true);
            return (Integer) f.get(p);
        } catch (NoSuchFieldException ignore) {
            return null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private final ZoneId ZONE = ZoneId.of("UTC");
    private final ZonedDateTime SURVEY_START = ZonedDateTime.of(2025, 1, 1, 0, 0, 0, 0, ZONE);
    // Derived window boundaries (because getPlan uses +30 day steps):
    // w1Start = 2025-01-31T00:00Z, w2Start = 2025-03-02T00:00Z, w3Start = 2025-04-01T00:00Z

    private ZonedDateTime zdt(int y, int m, int d) {
        return ZonedDateTime.of(y, m, d, 0, 0, 0, 0, ZoneId.of("UTC"));
    }

    private Object call(ZonedDateTime w1Start, ZonedDateTime w2Start, ZonedDateTime w3Start,
                        ZonedDateTime surveyStartLocal, int window) {
        try {
            return getStartAndEnd.invoke(null, w1Start, w2Start, w3Start, surveyStartLocal, window);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ZonedDateTime startOf(Object range) {
        try {
            var f = rangeClass.getDeclaredField("start");
            f.setAccessible(true);
            return (ZonedDateTime) f.get(range);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ZonedDateTime endOf(Object range) {
        try {
            var f = rangeClass.getDeclaredField("end");
            f.setAccessible(true);
            return (ZonedDateTime) f.get(range);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void beforeStart_returnsNotScheduled() {
        var now = Instant.parse("2025-01-30T12:00:00Z");
        var plan = invoke(42L, "u1", ZONE, SURVEY_START, now, 1);

        assertFalse(plan.evaluateSurvey, "should not evaluate");
        assertFalse(plan.expired, "not expired");
        var w = tryGetWindow(plan);
        Assertions.assertEquals(1, w);
    }

    @Test
    void insideWindow_returnsScheduled() {
        var now = Instant.parse("2025-02-10T09:00:00Z");
        var plan = invoke(42L, "u1", ZONE, SURVEY_START, now, 1);

        assertTrue(plan.evaluateSurvey, "should evaluate");
        assertFalse(plan.expired, "not expired");
        var w = tryGetWindow(plan);
        Assertions.assertEquals(1, w);
    }

    @Test
    void elapsedWindow1_reschedulesTo2_andSchedulesIfInside() {
        var now = Instant.parse("2025-03-15T08:00:00Z");
        var plan = invoke(42L, "u1", ZONE, SURVEY_START, now, 1);

        assertTrue(plan.evaluateSurvey, "moved to new window, should evaluate");
        assertFalse(plan.expired, "not expired");
        var w = tryGetWindow(plan);
        Assertions.assertEquals(2, w, "should have moved to window 2");
    }

    @Test
    void initialWindow0_inFinalWindow_shouldDoEvaluation() {
        var now = Instant.parse("2025-03-28T08:00:00Z");
        var plan = invoke(777L, "any-user", ZONE, SURVEY_START, now, 0);

        assertTrue(plan.evaluateSurvey, "final window→ should evaluate");
        assertFalse(plan.expired, "not expired");
        var w = tryGetWindow(plan);
        Assertions.assertEquals(2, w, "should have moved to final window 2");
    }

    @Test
    void window0_returnsSurveyStart_to_w1Start() {
        var surveyStart = zdt(2025, 1, 1);
        var w1 = zdt(2025, 1, 31);
        var w2 = zdt(2025, 3, 2);
        var w3 = zdt(2025, 4, 1);

        var range = call(w1, w2, w3, surveyStart, 0);

        Assertions.assertEquals(surveyStart, startOf(range), "start for window 0");
        Assertions.assertEquals(w1, endOf(range), "end for window 0");
    }

    @Test
    void window1_returns_w1Start_to_w2Start() {
        var surveyStart = zdt(2025, 1, 1);
        var w1 = zdt(2025, 1, 31);
        var w2 = zdt(2025, 3, 2);
        var w3 = zdt(2025, 4, 1);

        var range = call(w1, w2, w3, surveyStart, 1);

        Assertions.assertEquals(w1, startOf(range), "start for window 1");
        Assertions.assertEquals(w2, endOf(range), "end for window 1");
    }

    @Test
    void windowDefault_returns_w2Start_to_w3Start_for_anyOtherValue() {
        var surveyStart = zdt(2025, 1, 1);
        var w1 = zdt(2025, 1, 31);
        var w2 = zdt(2025, 3, 2);
        var w3 = zdt(2025, 4, 1);

        var rangeFor2 = call(w1, w2, w3, surveyStart, 2);
        var rangeFor99 = call(w1, w2, w3, surveyStart, 99);

        Assertions.assertEquals(w2, startOf(rangeFor2), "start for window 2");
        Assertions.assertEquals(w3, endOf(rangeFor2), "end for window 2");

        Assertions.assertEquals(w2, startOf(rangeFor99), "start for default window");
        Assertions.assertEquals(w3, endOf(rangeFor99), "end for default window");
    }
}
