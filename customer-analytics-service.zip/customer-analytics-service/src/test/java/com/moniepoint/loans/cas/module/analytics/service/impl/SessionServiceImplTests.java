package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.moniepoint.loans.cas.module.cache.service.CacheService;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SessionServiceImplTests {

    @Mock
    private CacheService cacheService;

    @InjectMocks
    private SessionServiceImpl service;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(service, "SESSION_TTL", 7200L);
    }

    @Test
    void generateAnonymousUserIDs() {
        String sessionID = service.generateSessionID("my-device-id", null);
        assertTrue(StringUtils.isNotBlank(sessionID), "non blank session id should have been generated for anonymous user");

        verify(cacheService, times(1)).getCachedString("my-device-id");
        verify(cacheService, times(1)).cacheString("my-device-id", sessionID, 7200);
    }

    @Test
    void sessionIDIsConsistentForSequentialAnonymousRequests() {
        String cachedSessionID = UUID.randomUUID().toString();
        when(cacheService.getCachedString("my-other-device-id")).thenReturn(cachedSessionID);

        String sessionID = service.generateSessionID("my-other-device-id", null);
        assertEquals(cachedSessionID, sessionID, "Session IDs generated for anonymous users of the same device in a short time should be equal");

        verify(cacheService, times(1)).getCachedString("my-other-device-id");
    }

    @Test
    void userGetsSessionIDFromKnownDevice() {
        String cachedSessionID = UUID.randomUUID().toString();
        when(cacheService.getCachedString("user-device-id")).thenReturn(cachedSessionID);

        String sessionID = service.generateSessionID("user-device-id", "user@moniepoint.com");
        assertEquals(cachedSessionID, sessionID, "Session ID for user should be the same as the one for the device");

        verify(cacheService, times(1)).getCachedString("user-device-id");
    }

    @Test
    void userGetsSessionIDWithNoDeviceId() {
        when(cacheService.getCachedString("user-device-id")).thenReturn(null);

        String sessionID = service.generateSessionID("user-device-id", "user@moniepoint.com");

        verify(cacheService, times(1)).getCachedString("user-device-id");
        verify(cacheService, times(1)).cacheString("user-device-id", sessionID + ";user@moniepoint.com", 7200);
    }

    @Test
    void userRequestsStoreSessionID() {
        String sessionID = service.generateSessionID("another-user-device-id", "another@moniepoint.com");
        assertTrue(StringUtils.isNotBlank(sessionID), "non blank session id should have been generated for user");

        verify(cacheService, times(1)).getCachedString("another-user-device-id");
        verify(cacheService, times(1)).cacheString("another-user-device-id", sessionID + ";another@moniepoint.com", 7200);
    }

    @Test
    void requestsWithOtherUserGenerateNewSessionID() {
        String cachedSessionID = UUID.randomUUID().toString();
        when(cacheService.getCachedString("device-id")).thenReturn(cachedSessionID + ";userA@moniepoint.com");

        String sessionID = service.generateSessionID("device-id", "userB@moniepoint.com");
        assertNotEquals(cachedSessionID, sessionID, "Session ID for new user should be different than existing stored session id");

        verify(cacheService, times(1)).getCachedString("device-id");
        verify(cacheService, times(1)).cacheString("device-id", sessionID + ";userB@moniepoint.com", 7200);
    }

    @Test
    void anonymousUserForKnownUserDeviceGeneratesNewSessionID() {
        String cachedSessionID = UUID.randomUUID().toString();
        when(cacheService.getCachedString("device-id")).thenReturn(cachedSessionID + ";user@moniepoint.com");

        String sessionID = service.generateSessionID("device-id", null);
        assertNotEquals(cachedSessionID, sessionID, "Session ID for anonymous user should be different than existing stored session id");

        verify(cacheService, times(1)).getCachedString("device-id");
        verify(cacheService, times(1)).cacheString("device-id", sessionID, 7200);
    }
}
