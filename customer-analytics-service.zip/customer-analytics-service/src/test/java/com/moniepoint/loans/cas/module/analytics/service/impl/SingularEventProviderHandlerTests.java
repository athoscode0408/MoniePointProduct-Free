package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.singular.dto.SingularEventRequest;
import com.moniepoint.loans.cas.integrations.singular.service.SingularIntegrationService;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SingularEventProviderHandlerTests {

    @Mock
    private SingularIntegrationService singularIntegrationService;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    private SingularEventProviderHandler handler;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        handler = new SingularEventProviderHandler(
                true,
                "test-api-key",
                singularIntegrationService,
                objectMapperHelper
        );
    }

    @Test
    void support_withSingularProvider_returnsTrue() {
        assertTrue(handler.support(EventProvider.SIN));
    }

    @Test
    void support_withBrazeProvider_returnsFalse() {
        assertFalse(handler.support(EventProvider.BRAZE));
    }

    @Test
    void support_withMixpanelProvider_returnsFalse() {
        assertFalse(handler.support(EventProvider.MIX));
    }

    @Test
    void support_withCustomerIOProvider_returnsFalse() {
        assertFalse(handler.support(EventProvider.CIO));
    }

    @Test
    void processEvent_whenDisabled_doesNotSendEvent() {
        handler = new SingularEventProviderHandler(false, "test-api-key", singularIntegrationService, objectMapperHelper);
        VerifiedAnalyticsEventDTO event = buildAndroidEvent("android-device-id");

        handler.processEvent(event);

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void processEvent_withAndroidDeviceMetadata_setsAifa() {
        ObjectNode deviceMetadata = objectMapper.createObjectNode();
        deviceMetadata.put("googleDeviceId", "google-device-123");

        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        data.put("device_type", "android");
        data.put("device_id", "fallback-device-id");
        data.set("device_metadata", deviceMetadata);

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "google-device-123".equals(req.getAifa())
                        && req.getIdfv() == null
                        && req.getSdid() == null
        ));
    }

    @Test
    void processEvent_withIosDeviceMetadata_setsIdfv() {
        ObjectNode deviceMetadata = objectMapper.createObjectNode();
        deviceMetadata.put("identifierForVendor", "ios-vendor-id-456");

        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        data.put("device_type", "ios");
        data.put("device_id", "fallback-device-id");
        data.set("device_metadata", deviceMetadata);

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "ios-vendor-id-456".equals(req.getIdfv())
                        && req.getAifa() == null
                        && req.getSdid() == null
        ));
    }

    @Test
    void processEvent_withWebPlatform_setsSdid() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        data.put("device_type", "web");
        data.put("device_id", "web-session-device-id");

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "web-session-device-id".equals(req.getSdid())
                        && req.getAifa() == null
                        && req.getIdfv() == null
        ));
    }

    @Test
    void processEvent_withAndroidFallbackDeviceId_whenNoMetadata_setsAifaFromDeviceId() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        data.put("device_type", "android");
        data.put("device_id", "fallback-android-id");

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "fallback-android-id".equals(req.getAifa())
        ));
    }

    @Test
    void processEvent_withMissingDeviceIdentifiers_doesNotSendEvent() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        // No device_type, no device_id → all identifiers null → Web platform with null sdid

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        handler.processEvent(event);

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void processEvent_withFirstDepositTransaction_setsRevenueEvent() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "first_deposit_transaction");
        data.put("device_type", "android");
        data.put("device_id", "android-device-id");
        data.put("amount", 5000.0);
        data.put("currency", "NGN");

        VerifiedAnalyticsEventDTO event = buildEventWithData(data);

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                req.getIs_revenue_event()
                        && req.getAmt() == 5000.0
                        && "NGN".equals(req.getCur())
        ));
    }

    @Test
    void processEvent_withNonRevenueEvent_doesNotSetRevenueFlag() {
        VerifiedAnalyticsEventDTO event = buildAndroidEvent("android-device-id");

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                !req.getIs_revenue_event()
        ));
    }

    @Test
    void processEvent_withNoEventNameInData_usesEventTypeAsName() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("device_type", "android");
        data.put("device_id", "android-device-id");

        VerifiedAnalyticsEventDTO event = VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("fallback_event_name")
                .timestamp(Timestamp.from(Instant.now()))
                .eventProviders(Set.of(EventProvider.SIN))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(data)
                .build();

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "fallback_event_name".equals(req.getN())
        ));
    }

    @Test
    void processEvent_withUserIdentifiers_setsCustomUserId() {
        VerifiedAnalyticsEventDTO event = buildAndroidEvent("android-device-id");
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), "user-123", null, null, null));

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "user-123".equals(req.getCustom_user_id())
        ));
    }

    @Test
    void processEvent_setsApiKeyInRequest() {
        VerifiedAnalyticsEventDTO event = buildAndroidEvent("android-device-id");

        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        handler.processEvent(event);

        verify(singularIntegrationService, times(1)).sendEvent(argThat(req ->
                "test-api-key".equals(req.getA())
        ));
    }

    @Test
    void processEvent_withStringEventData_whenEnabled_sendsToIntegrationService() {
        SingularEventRequest request = SingularEventRequest.builder()
                .n("test_event")
                .aifa("aifa-123")
                .a("api-key")
                .p("android")
                .build();

        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(request);
        when(singularIntegrationService.sendEvent(request)).thenReturn(true);

        boolean result = handler.processEvent("{\"n\":\"test_event\"}");

        assertTrue(result);
        verify(singularIntegrationService, times(1)).sendEvent(request);
    }

    @Test
    void processEvent_withStringEventData_whenDisabled_returnsFalse() {
        handler = new SingularEventProviderHandler(false, "test-api-key", singularIntegrationService, objectMapperHelper);

        boolean result = handler.processEvent("{\"n\":\"test_event\"}");

        assertFalse(result);
        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void processEvent_withStringEventData_whenDeserializesNull_returnsFalse() {
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(null);

        boolean result = handler.processEvent("{\"n\":\"test_event\"}");

        assertFalse(result);
        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void processEvent_withStringEventData_whenExceptionThrown_returnsFalse() {
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class)))
                .thenThrow(new RuntimeException("Parse error"));

        boolean result = handler.processEvent("invalid-json");

        assertFalse(result);
        verify(singularIntegrationService, never()).sendEvent(any());
    }

    private VerifiedAnalyticsEventDTO buildAndroidEvent(String deviceId) {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");
        data.put("device_type", "android");
        data.put("device_id", deviceId);
        return buildEventWithData(data);
    }

    private VerifiedAnalyticsEventDTO buildEventWithData(JsonNode data) {
        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("test_event")
                .timestamp(Timestamp.from(Instant.now()))
                .eventProviders(Set.of(EventProvider.SIN))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(data)
                .build();
    }
}
