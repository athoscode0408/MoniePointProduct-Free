package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.SurveyBody;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyAlertStorage;
import com.moniepoint.loans.cas.module.analytics.repository.service.SurveyRepositoryService;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SurveyEventsCompletionServiceTests {

    @Mock
    AnalyticsEventRequestDTO analyticsEventRequestDTO;
    @Mock
    PreprocessedSurveyStorage preprocessedSurveyStorage;
    @Mock
    RedisCacheServiceImpl cacheService;
    @Mock
    ObjectMapperHelper objectMapperHelper;
    @Mock
    SurveyAlertStorage surveyAlertStorage;
    @Mock
    UserAttributesStorage userStorage;
    @Mock
    BannerService bannerService;
    @Mock
    SurveyRepositoryService surveyRepositoryService;
    @InjectMocks
    SurveyEventCompletionService surveyEventCompletionService;

    private final ObjectMapper om = new ObjectMapper();
    private static final String SURVEY_COMPLETED_EVENT = "SURVEY_COMPLETED";
    private static final String SURVEY_DISMISSED_EVENT = "SURVEY_DISMISSED";
    private static final String SURVEY_ABANDONED_EVENT = "SURVEY_ABANDONED";

    private ObjectNode payload(String eventName, long surveyId, boolean withMeta) {
        ObjectNode data = om.createObjectNode();
        data.put("eventName", eventName);
        if (withMeta) {
            ObjectNode meta = om.createObjectNode();
            meta.put("surveyId", surveyId);
            data.set("meta", meta);
        }
        return data;
    }

    @Test
    void processCompletedSurveyEvent_setsCompleted_whenEventMatches_andSaves() {
        String userId = "user-123";
        long surveyId = 55L;
        Timestamp ts = Timestamp.from(Instant.now());

        ObjectNode data = payload(SURVEY_COMPLETED_EVENT, surveyId, true);

        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setState(NOT_COMPLETED);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(
            eq(userId), eq(surveyId), eq(List.of(NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED))
        )).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(COMPLETED);
        assertThat(found.getCompletedOn()).isEqualTo(ts);
        verify(preprocessedSurveyStorage).save(found);
    }

    @Test
    void processCompletedSurveyEvent_setsAbandoned_whenEventNotCompleted() {
        String userId = "user-456";
        long surveyId = 77L;
        Timestamp ts = Timestamp.from(Instant.now());

        ObjectNode data = payload(SURVEY_ABANDONED_EVENT, surveyId, true);

        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setState(NOT_COMPLETED);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(
                eq(userId), eq(surveyId), eq(List.of(NOT_COMPLETED, DISMISSED,  ABANDONED, EXPIRED))
        )).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(ABANDONED);
        assertThat(found.getCompletedOn()).isEqualTo(ts);
        verify(preprocessedSurveyStorage).save(found);
    }

    @Test
    void processCompletedSurveyEvent_isCaseInsensitiveForCompleted() {
        String userId = "user-789";
        long surveyId = 99L;
        Timestamp ts = Timestamp.from(Instant.now());

        ObjectNode data = payload("survey_completed", surveyId, true); // lower case

        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setState(ABANDONED);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(
                eq(userId), eq(surveyId), eq(List.of(NOT_COMPLETED, DISMISSED,  ABANDONED, EXPIRED))
        )).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(COMPLETED);
        verify(preprocessedSurveyStorage).save(found);
    }

    @Test
    void processCompletedSurveyEvent_noMeta_logsWarnAndReturns_withoutSave() {

        ObjectNode data = payload(SURVEY_COMPLETED_EVENT, 123L, false); // meta missing

        when(analyticsEventRequestDTO.getData()).thenReturn(data);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        verify(preprocessedSurveyStorage, never()).findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), anyList());
        verify(preprocessedSurveyStorage, never()).save(any());
    }

    @Test
    void processCompletedSurveyEvent_noPreprocessedSurveyFound_returnsWithoutSave() {
        String userId = "user-111";
        long surveyId = 1234L;

        ObjectNode data = payload(SURVEY_COMPLETED_EVENT, surveyId, true);

        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(
                eq(userId), eq(surveyId), eq(List.of(NOT_COMPLETED, DISMISSED,  ABANDONED, EXPIRED))
        )).thenReturn(Optional.empty());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        verify(preprocessedSurveyStorage, never()).save(any());
    }

    @Test
    void processCompletedSurveyEvent_setsDismissed_andDoesNotSetCompletedOn() {
        String userId = "user-dismissed";
        long surveyId = 10L;

        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setId(surveyId);
        found.setUser(userId);
        found.setState(NOT_COMPLETED);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(
                eq(userId), eq(surveyId), eq(List.of(NOT_COMPLETED, DISMISSED, ABANDONED, EXPIRED))
        )).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(SurveyBody.builder().build());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(DISMISSED);
        assertThat(found.getCompletedOn()).isNull();
        verify(preprocessedSurveyStorage).save(found);
    }

    @Test
    void processCompletedSurveyEvent_dismissed_withAlertingDisabled_doesNotTouchCache() {
        String userId = "user-no-alert";
        long surveyId = 11L;

        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setId(surveyId);
        found.setUser(userId);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        when(objectMapperHelper.deserializeStringToObject(any(), any()))
                .thenReturn(SurveyBody.builder().enableAlertingAfterDismissal(false).build());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(DISMISSED);
        verify(cacheService, never()).cachePreprocessedSurveyById(any(), any());
        verify(cacheService, never()).appendPreprocessedSurvey(any(), any());
        verify(cacheService, never()).removePreprocessedSurveyBySurveyId(any());
        verify(cacheService, never()).removePreprocessedSurveyByUserId(any(), any());
    }

//    @Test
//    void processCompletedSurveyEvent_dismissed_withAlertingEnabled_setsAlertModalTypeAndRefreshesCache() {
//        String userId = "user-alert";
//        long surveyId = 20L;
//
//        UserAttributes ua = new UserAttributes();
//        ua.addCustomAttributes("active_terminal_count", 1);
//        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
//
//        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
//        when(analyticsEventRequestDTO.getData()).thenReturn(data);
//        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
//        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));
//
//        PreprocessedSurvey found = new PreprocessedSurvey();
//        found.setId(surveyId);
//        found.setUser(userId);
//        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
//        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
//
//        SurveyBody surveyBody = SurveyBody.builder()
//                .enableAlertingAfterDismissal(true)
//                .alertingCondition("user.customAttributes['active_terminal_count'] > 0")
//                .build();
//        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(surveyBody);
//        when(objectMapperHelper.serializeToString(any())).thenReturn("serialized");
//        when(cacheService.getAllPreprocessedSurveys(userId)).thenReturn(List.of(found));
//
//        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);
//
//        assertThat(surveyBody.getDisplayModalType()).isEqualTo("ALERT");
//        verify(cacheService).removePreprocessedSurveyBySurveyId(String.valueOf(surveyId));
//        verify(cacheService).removePreprocessedSurveyByUserId(userId, String.valueOf(surveyId));
//        verify(cacheService).cachePreprocessedSurveyById(eq(String.valueOf(surveyId)), any());
//        verify(cacheService).appendPreprocessedSurvey(eq(userId), eq(found));
//        assertThat(found.getState()).isEqualTo(DISMISSED);
//        assertThat(found.getCompletedOn()).isNull();
//    }

//    @Test
//    void processCompletedSurveyEvent_dismissed_withAlertingEnabled_skipsAppendWhenUserCacheIsEmpty() {
//        String userId = "user-alert-empty";
//        long surveyId = 21L;
//
//        UserAttributes ua = new UserAttributes();
//        ua.addCustomAttributes("active_terminal_count", 1);
//        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
//
//        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
//        when(analyticsEventRequestDTO.getData()).thenReturn(data);
//        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
//        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));
//
//        PreprocessedSurvey found = new PreprocessedSurvey();
//        found.setId(surveyId);
//        found.setUser(userId);
//        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
//        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
//        when(objectMapperHelper.deserializeStringToObject(any(), any()))
//                .thenReturn(SurveyBody.builder()
//                        .enableAlertingAfterDismissal(true)
//                        .alertingCondition("user.customAttributes['active_terminal_count'] > 0")
//                        .build());
//        when(objectMapperHelper.serializeToString(any())).thenReturn("serialized");
//        when(cacheService.getAllPreprocessedSurveys(userId)).thenReturn(List.of());
//
//        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);
//
//        verify(cacheService).cachePreprocessedSurveyById(eq(String.valueOf(surveyId)), any());
//        verify(cacheService, never()).appendPreprocessedSurvey(any(), any());
//    }

    @Test
    void processCompletedSurveyEvent_dismissed_doesNotRemoveSurveyFromCacheAfterSave() {
        String userId = "user-dismissed-post-save";
        long surveyId = 22L;

        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setId(surveyId);
        found.setUser(userId);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        // alerting disabled — no cache ops expected at all
        when(objectMapperHelper.deserializeStringToObject(any(), any()))
                .thenReturn(SurveyBody.builder().enableAlertingAfterDismissal(false).build());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        verify(preprocessedSurveyStorage).save(found);
        // cache is never touched after save for dismissed events
        verify(cacheService, never()).removePreprocessedSurveyBySurveyId(any());
        verify(cacheService, never()).removePreprocessedSurveyByUserId(any(), any());
    }

    // ── saveUserVoluntarySurvey ────────────────────────────────────────────────

    private ObjectNode voluntaryPayload(String eventName, long surveyId, String brmId) {
        return voluntaryPayload(eventName, surveyId, brmId, null);
    }

    private ObjectNode voluntaryPayload(String eventName, long surveyId, String brmId, String source) {
        ObjectNode meta = om.createObjectNode();
        meta.put("surveyId", 0L);   // 0 triggers the voluntary path
        meta.put("surveySchemaId", surveyId);
        if (brmId != null) meta.put("brmId", brmId);
        if (source != null) meta.put("source", source);
        ObjectNode data = om.createObjectNode();
        data.put("eventName", eventName);
        data.set("meta", meta);
        return data;
    }

    @Test
    void saveUserVoluntarySurvey_triggeredWhenSurveyIdIsZero_neverQueriesExistingSurvey() {
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        verify(preprocessedSurveyStorage, never()).findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any());
        verify(preprocessedSurveyStorage).save(any());
    }

    @Test
    void saveUserVoluntarySurvey_savesCorrectFieldsWithCompletedState() {
        String userId = "user-vol-1";
        String eventId = "dto-event-id";
        long surveyId = 55L;
        Timestamp ts = Timestamp.from(Instant.now());

        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveyId, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getId()).thenReturn(eventId);

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        PreprocessedSurvey saved = captor.getValue();
        assertThat(saved.getState()).isEqualTo(COMPLETED);
        assertThat(saved.getUser()).isEqualTo(userId);
        assertThat(saved.getEvent()).isEqualTo(eventId);
        assertThat(saved.getSurveyId()).isEqualTo(surveyId);
        assertThat(saved.getCompletedOn()).isEqualTo(ts);
        assertThat(saved.getAdditionalData()).isNull();
    }

    @Test
    void saveUserVoluntarySurvey_savesLocationFromSurveyEntity_mobileByDefault() {
        String userId = "user-vol-loc";
        long surveyId = 56L;
        Timestamp ts = Timestamp.from(Instant.now());

        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveyId, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getId()).thenReturn("event-loc");
        when(analyticsEventRequestDTO.getPlatform()).thenReturn("mobile");

        Survey survey = mock(Survey.class);
        when(survey.getMobileLocation()).thenReturn("/brm-dashboard");
        when(surveyRepositoryService.findById(surveyId)).thenReturn(Optional.of(survey));

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getLocation()).isEqualTo("/brm-dashboard");
    }

    @Test
    void saveUserVoluntarySurvey_savesWebLocation_whenPlatformIsWeb() {
        String userId = "user-vol-web";
        long surveyId = 57L;
        Timestamp ts = Timestamp.from(Instant.now());

        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveyId, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getId()).thenReturn("event-loc-web");
        when(analyticsEventRequestDTO.getPlatform()).thenReturn("web");

        Survey survey = mock(Survey.class);
        when(survey.getWebLocation()).thenReturn("/web-brm-dashboard");
        when(surveyRepositoryService.findById(surveyId)).thenReturn(Optional.of(survey));

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getLocation()).isEqualTo("/web-brm-dashboard");
    }

    @Test
    void saveUserVoluntarySurvey_savesSurveyWithDismissedState() {
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_DISMISSED_EVENT, 10L, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-2"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getState()).isEqualTo(DISMISSED);
    }

    @Test
    void saveUserVoluntarySurvey_savesSurveyWithAbandonedState_whenUnknownEvent() {
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload("SURVEY_ABANDONED", 10L, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-3"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getState()).isEqualTo(ABANDONED);
    }

    @Test
    void saveUserVoluntarySurvey_includesBrmIdInAdditionalData_whenPresent() {
        UserAttributes ua = new UserAttributes();
        ua.setBrmId("brm-123");
        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, "brm-123"));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-4"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getAdditionalData()).contains("brm-123");
    }

    @Test
    void saveUserVoluntarySurvey_doesNotSetAdditionalData_whenBrmIdAbsent() {
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-5"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getAdditionalData()).isNull();
    }

    @Test
    void saveUserVoluntarySurvey_includesSourceInAdditionalData_whenPresentInMeta() {
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, null, "BRM_DASHBOARD"));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-src"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getAdditionalData()).contains("\"source\"").contains("BRM_DASHBOARD");
    }

    @Test
    void saveUserVoluntarySurvey_includesBothBrmIdAndSource_whenBothPresentInMeta() {
        UserAttributes ua = new UserAttributes();
        ua.setBrmId("brm-xyz");
        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, "brm-xyz", "BRM_DASHBOARD"));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier("user-vol-both"));
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getAdditionalData()).contains("brm-xyz").contains("BRM_DASHBOARD");
    }

    @Test
    void resolveVoluntarySurvey_appendsSourceToExistingAdditionalData_whenPresentInMeta() {
        String userId = "user-brm-src";
        long surveySchemaId = 13L;
        String brmId = "brm-abc";
        String source = "BRM_DASHBOARD";
        Timestamp ts = Timestamp.from(Instant.now());

        UserAttributes ua = new UserAttributes();
        ua.setBrmId(brmId);
        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveySchemaId, brmId, source));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);

        PreprocessedSurvey existing = new PreprocessedSurvey();
        existing.setId(102L);
        existing.setUser(userId);
        existing.setAdditionalData("{\"brmId\":\"" + brmId + "\"}");
        when(preprocessedSurveyStorage.findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(
                eq(userId), eq(surveySchemaId), any(), any(Timestamp.class))).thenReturn(List.of(existing));
        when(preprocessedSurveyStorage.save(any())).thenReturn(existing);
        // 1st: brmIdMatchesAdditionalData; 2nd: appendSourceToAdditionalData existing data; 3rd: SurveyBody
        when(objectMapperHelper.deserializeStringToObject(any(), any()))
                .thenReturn(Map.of("brmId", brmId))
                .thenReturn(Map.of("brmId", brmId))
                .thenReturn(new SurveyBody());
        when(objectMapperHelper.serializeToString(any())).thenReturn("{\"brmId\":\"" + brmId + "\",\"source\":\"" + source + "\"}");

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(existing.getAdditionalData()).contains("source").contains(source);
    }

    @Test
    void saveUserVoluntarySurvey_fallsBackToCustomerIdentifier_whenUserIdIsNull() {
        UserEventIdentifier identifier = mock(UserEventIdentifier.class);
        when(identifier.getUserID()).thenReturn(null);

        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, 10L, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(identifier);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn("customer-fallback");
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(Timestamp.from(Instant.now()));
        when(analyticsEventRequestDTO.getId()).thenReturn("event-id");

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(captor.getValue().getUser()).isEqualTo("customer-fallback");
    }

    @Test
    void processCompletedSurveyEvent_dismissed_withNullSurveyBody_skipsAlertingAndSetsDismissedState() {
        String userId = "user-null-body";
        long surveyId = 30L;

        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));

        PreprocessedSurvey found = new PreprocessedSurvey();
        found.setId(surveyId);
        found.setUser(userId);
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        assertThat(found.getState()).isEqualTo(DISMISSED);
        verify(cacheService, never()).cachePreprocessedSurveyById(any(), any());
        verify(cacheService, never()).appendPreprocessedSurvey(any(), any());
    }

//    @Test
//    void processCompletedSurveyEvent_dismissed_withAlertingEnabled_savesSurveyAlert_whenAccountNumberPresent() {
//        String userId = "user-alert-acct";
//        long surveyId = 25L;
//        String accountNumber = "account-001";
//        Timestamp ttl = Timestamp.from(Instant.now().plusSeconds(3600));
//
//        UserAttributes ua = new UserAttributes();
//        ua.addCustomAttributes("active_terminal_count", 1);
//        ua.setNubanAccountNumber(accountNumber);
//        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
//
//        ObjectNode data = payload(SURVEY_DISMISSED_EVENT, surveyId, true);
//        when(analyticsEventRequestDTO.getData()).thenReturn(data);
//        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
//        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));
//
//        PreprocessedSurvey found = new PreprocessedSurvey();
//        found.setId(surveyId);
//        found.setUser(userId);
//        found.setEvent("NPS_EVENT");
//        found.setTtl(ttl);
//
//        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(any(), anyLong(), any())).thenReturn(Optional.of(found));
//        when(preprocessedSurveyStorage.save(any())).thenReturn(found);
//
//        SurveyBody surveyBody = SurveyBody.builder()
//                .enableAlertingAfterDismissal(true)
//                .alertingCondition("user.customAttributes['active_terminal_count'] > 0")
//                .alertType("INFO")
//                .alertPriority(2)
//                .alertTitle("Rate your BRM")
//                .alertMessage("Help us improve")
//                .alertActionLabel("Rate Them")
//                .alertDismissible(false)
//                .build();
//        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(surveyBody);
//        when(objectMapperHelper.serializeToString(any())).thenReturn("serialized");
//        when(cacheService.getAllPreprocessedSurveys(userId)).thenReturn(List.of());
//
//        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);
//
//        ArgumentCaptor<SurveyAlert> alertCaptor = ArgumentCaptor.forClass(SurveyAlert.class);
//        verify(surveyAlertStorage).save(alertCaptor.capture());
//        SurveyAlert saved = alertCaptor.getValue();
//        assertThat(saved.getUser()).isEqualTo(userId);
//        assertThat(saved.getPreprocessedSurveyId()).isEqualTo(surveyId);
//        assertThat(saved.getAccountNumber()).isEqualTo(accountNumber);
//        assertThat(saved.getTtl()).isEqualTo(ttl);
//        assertThat(saved.getEvent()).isEqualTo("NPS_EVENT");
//        assertThat(saved.getAlertType()).isEqualTo("INFO");
//        assertThat(saved.getAlertPriority()).isEqualTo(2);
//        assertThat(saved.getAlertTitle()).isEqualTo("Rate your BRM");
//        assertThat(saved.getAlertMessage()).isEqualTo("Help us improve");
//        assertThat(saved.getAlertActionLabel()).isEqualTo("Rate Them");
//        assertThat(saved.isAlertDismissible()).isFalse();
//    }

    @Test
    void processCompletedSurveyEvent_repoThrows_bubblesUp() {
        String userId = "user-err";
        long surveyId = 777L;

        ObjectNode data = payload(SURVEY_COMPLETED_EVENT, surveyId, true);

        when(analyticsEventRequestDTO.getData()).thenReturn(data);
        when(analyticsEventRequestDTO.getCustomerIdentifier()).thenReturn(userId);
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(new UserEventIdentifier(String.valueOf(UUID.randomUUID())));
        when(preprocessedSurveyStorage.findPreprocessedSurveyByUserAndIdAndStateIn(anyString(), anyLong(), any()))
                .thenThrow(new RuntimeException("DB down"));

        org.assertj.core.api.Assertions.assertThatThrownBy(
                () -> surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO)
        ).hasMessageContaining("DB down");
    }

    // ── resolveVoluntarySurvey brmId matching ─────────────────────────────────

    @Test
    void resolveVoluntarySurvey_existingSurveyFound_brmIdMatches_updatesExistingSurvey() {
        String userId = "user-brm-match";
        long surveySchemaId = 10L;
        String brmId = "brm-abc";
        Timestamp ts = Timestamp.from(Instant.now());

        UserAttributes ua = new UserAttributes();
        ua.setBrmId(brmId);
        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveySchemaId, brmId));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);

        PreprocessedSurvey existing = new PreprocessedSurvey();
        existing.setId(99L);
        existing.setUser(userId);
        existing.setAdditionalData("{\"brmId\":\"" + brmId + "\"}");
        when(preprocessedSurveyStorage.findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(
                eq(userId), eq(surveySchemaId), any(), any(Timestamp.class))).thenReturn(List.of(existing));
        when(preprocessedSurveyStorage.save(any())).thenReturn(existing);
        // first call: deserialize additionalData for brmId check; second call: deserialize SurveyBody
        when(objectMapperHelper.deserializeStringToObject(any(), any()))
                .thenReturn(Map.of("brmId", brmId))
                .thenReturn(new SurveyBody());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        verify(preprocessedSurveyStorage).save(captor.capture());
        assertThat(captor.getValue()).isSameAs(existing);
        assertThat(existing.getState()).isEqualTo(COMPLETED);
    }

    @Test
    void resolveVoluntarySurvey_existingSurveyFound_brmIdMismatch_savesNewVoluntarySurvey() {
        String userId = "user-brm-mismatch";
        long surveySchemaId = 11L;
        Timestamp ts = Timestamp.from(Instant.now());

        UserAttributes ua = new UserAttributes();
        ua.setBrmId("brm-new");
        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(ua);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveySchemaId, "brm-new"));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);
        when(analyticsEventRequestDTO.getId()).thenReturn("event-brm-mismatch");

        PreprocessedSurvey existing = new PreprocessedSurvey();
        existing.setId(100L);
        existing.setUser(userId);
        existing.setAdditionalData("{\"brmId\":\"brm-old\"}");
        when(preprocessedSurveyStorage.findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(
                eq(userId), eq(surveySchemaId), any(), any(Timestamp.class))).thenReturn(List.of(existing));
        when(objectMapperHelper.deserializeStringToObject(any(), any()))
                .thenReturn(Map.of("brmId", "brm-old"));

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        when(preprocessedSurveyStorage.save(captor.capture())).thenReturn(null);

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        // a brand-new survey is saved (from saveUserVoluntarySurvey), not the pre-existing one
        assertThat(captor.getValue()).isNotSameAs(existing);
        assertThat(captor.getValue().getState()).isEqualTo(COMPLETED);
        assertThat(captor.getValue().getUser()).isEqualTo(userId);
    }

    @Test
    void resolveVoluntarySurvey_noBrmIdInEither_treatsAsMatchAndUpdatesExistingSurvey() {
        String userId = "user-no-brm";
        long surveySchemaId = 12L;
        Timestamp ts = Timestamp.from(Instant.now());

        when(analyticsEventRequestDTO.getUserAttributes()).thenReturn(null);
        when(analyticsEventRequestDTO.getData()).thenReturn(voluntaryPayload(SURVEY_COMPLETED_EVENT, surveySchemaId, null));
        when(analyticsEventRequestDTO.getUserIdentifiers()).thenReturn(
                UserEventIdentifier.builder().sessionID(UUID.randomUUID().toString()).userID(userId).build());
        when(analyticsEventRequestDTO.getTimestamp()).thenReturn(ts);

        PreprocessedSurvey existing = new PreprocessedSurvey();
        existing.setId(101L);
        existing.setUser(userId);
        existing.setAdditionalData(null); // no brmId stored — null == null is a match
        when(preprocessedSurveyStorage.findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(
                eq(userId), eq(surveySchemaId), any(), any(Timestamp.class))).thenReturn(List.of(existing));
        when(preprocessedSurveyStorage.save(any())).thenReturn(existing);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(new SurveyBody());

        surveyEventCompletionService.processCompletedSurveyEvent(analyticsEventRequestDTO);

        ArgumentCaptor<PreprocessedSurvey> captor = ArgumentCaptor.forClass(PreprocessedSurvey.class);
        verify(preprocessedSurveyStorage).save(captor.capture());
        assertThat(captor.getValue()).isSameAs(existing);
        assertThat(existing.getState()).isEqualTo(COMPLETED);
    }


}
