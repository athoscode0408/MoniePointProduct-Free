package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VerifiedAnalyticsEventKafkaEventPublisherTests {

    private VerifiedAnalyticsEventKafkaEventPublisher verifiedAnalyticsEventKafkaEventPublisher;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setup() {
        verifiedAnalyticsEventKafkaEventPublisher = new VerifiedAnalyticsEventKafkaEventPublisher(
                "test-topic", kafkaTemplate, objectMapperHelper, telemetry
        );
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
    }

    @Test
    void getTopic_success() {
        assertThat(verifiedAnalyticsEventKafkaEventPublisher.getTopic()).isEqualTo("test-topic");
    }

    @Test
    void publishEvent_success() {
        VerifiedAnalyticsEventDTO verifiedAnalyticsEventDTO = VerifiedAnalyticsEventDTO.builder()
                .id("123")
                .eventType("prequalification")
                .appEnv("DEVELOPMENT")
                .platform("MOBILE")
                .eventProviders(Set.of(EventProvider.MIX))
                .timestamp(Timestamp.from(Instant.ofEpochMilli(1725887178)))
                .data(objectMapper.convertValue(Map.of("email", "test@test.co"), JsonNode.class))
                .build();
        String content = """
                [{
                	"eventType": "invalid_event",
                	"id": "12233",
                	"timestamp": 1725871279,
                	"platform": "MOBILE",
                	"eventProvider" : "MIXPANEL",
                	"environment": "DEVELOPMENT",
                	"data": {
                		"emai": "test@test.co"
                	}
                }]
                """;
        @SuppressWarnings("unchecked")
        SendResult<String, String> sendResult = mock(SendResult.class);

        when(objectMapperHelper.serializeToString(any(VerifiedAnalyticsEventDTO.class)))
                .thenReturn(content);
        when(kafkaTemplate.send(any(), anyString(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(sendResult));

        verifiedAnalyticsEventKafkaEventPublisher.publishEvents(List.of(verifiedAnalyticsEventDTO));

        verify(objectMapperHelper, times(1)).serializeToString(any(VerifiedAnalyticsEventDTO.class));
        verify(kafkaTemplate, times(1)).send(eq("test-topic"), anyString(), eq(content));
    }


    @Test
    void publishEvent_withoutEventData_verifiesEventNotSendKafka() {
        verifiedAnalyticsEventKafkaEventPublisher.publishEvents(null);

        verify(objectMapperHelper, never()).serializeToString(any(VerifiedAnalyticsEventDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }

    @Test
    void publishEvent_withoutEventKey_verifiesEventNotSendKafka() {
        verifiedAnalyticsEventKafkaEventPublisher.publishEvents(List.of(VerifiedAnalyticsEventDTO.builder().build()));

        verify(objectMapperHelper, never()).serializeToString(any(VerifiedAnalyticsEventDTO.class));
        verify(kafkaTemplate, never()).send(anyString(), any());
    }
}
