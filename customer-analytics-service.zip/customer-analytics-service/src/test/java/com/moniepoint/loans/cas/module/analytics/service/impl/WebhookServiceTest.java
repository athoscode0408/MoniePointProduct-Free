package com.moniepoint.loans.cas.module.analytics.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCampaignByDomainDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateCampaignDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserCreateGoalDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalDeactivationDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserGoalMarkerDTO;
import com.moniepoint.loans.cas.module.analytics.dto.BrazeUserRewardEventDTO;
import com.moniepoint.loans.cas.module.analytics.dto.RewardEventMetadataDTO;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import com.moniepoint.loans.cas.outbound.rewards.RewardsClient;
import com.moniepoint.loans.cas.outbound.rewards.RewardsCampaignResponse;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class WebhookServiceTest {

    @Mock
    private RewardsClient rewardsClient;

    @Mock
    private OutboundUtils outboundUtils;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @InjectMocks
    private WebhookService webhookService;

    private static final String VALID_SECRET = "test-secret-key";
    private static final String INVALID_SECRET = "wrong-secret";
    private static final String TOKEN = "mock-access-token";

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(webhookService, "rewardsSecretKey", VALID_SECRET);
    }

    private BrazeUserCreateCampaignDTO buildCreateCampaignDTO() {
        return BrazeUserCreateCampaignDTO.builder()
                .campaignIdentifier("camp-001")
                .campaignExternalIdentifier("ext-001")
                .campaignImage("https://img.example.com/campaign.png")
                .campaignDetailsImage("https://img.example.com/details.png")
                .campaignDescription("Test campaign")
                .campaignTitle("Test Title")
                .bannerId("banner-001")
                .domain("PERSONAL")
                .campaignEndDate(LocalDateTime.now().plusDays(30))
                .priority(1)
                .build();
    }

    @Test
    void createRewardCampaign_invalidSecret_returnsForbidden() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, INVALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("403");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Invalid secret header key");
        verifyNoInteractions(rewardsClient, outboundUtils);
    }

    @Test
    void createRewardCampaign_validSecretAndOkResponse_returnsOkWithBody() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();
        RewardsCampaignResponse campaignResponse = new RewardsCampaignResponse(true, "Campaign created", "200");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createCampaign(any(BrazeUserCreateCampaignDTO.class), anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(campaignResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isTrue();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Campaign created");
        verify(outboundUtils).getToken();
        verify(rewardsClient).createCampaign(dto, "Bearer " + TOKEN, "CREATE");
    }

    @Test
    void createRewardCampaign_validSecretAndNon200Response_returnsDownstreamStatus() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();
        RewardsCampaignResponse campaignResponse = new RewardsCampaignResponse(false, "Service unavailable", "503");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createCampaign(any(BrazeUserCreateCampaignDTO.class), anyString(), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(campaignResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Service unavailable");
        verify(rewardsClient).createCampaign(dto, "Bearer " + TOKEN, "CREATE");
    }

    @Test
    void createRewardCampaign_feignExceptionWithParsableBody_returnsDeserializedError() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();
        FeignException feignException = mock(FeignException.class);
        RewardsCampaignResponse errorResponse = new RewardsCampaignResponse(false, "Not found", "404");
        String rawBody = "{\"requestSuccessful\":false,\"responseMessage\":\"Not found\",\"responseCode\":\"404\"}";

        when(feignException.status()).thenReturn(404);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createCampaign(any(BrazeUserCreateCampaignDTO.class), anyString(), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class))).thenReturn(errorResponse);

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(404);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Not found");
        assertThat(result.getBody().getResponseCode()).isEqualTo("404");
    }

    @Test
    void createRewardCampaign_feignExceptionWithUnparsableBody_returnsRawBodyAsMessage() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();
        FeignException feignException = mock(FeignException.class);
        String rawBody = "upstream error - not json";

        when(feignException.status()).thenReturn(502);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createCampaign(any(BrazeUserCreateCampaignDTO.class), anyString(), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class)))
                .thenThrow(new RuntimeException("JSON parse error"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(502);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo(rawBody);
        assertThat(result.getBody().getResponseCode()).isNull();
    }

    @Test
    void createRewardCampaign_unexpectedException_returnsInternalServerError() {
        BrazeUserCreateCampaignDTO dto = buildCreateCampaignDTO();

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createCampaign(any(BrazeUserCreateCampaignDTO.class), anyString(), anyString()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardCampaign(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("500");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Unexpected failure");
    }

    private BrazeUserCreateGoalDTO buildCreateGoalDTO() {
        BrazeUserCreateGoalDTO.Goal goal = BrazeUserCreateGoalDTO.Goal.builder()
                .rewardCode("reward-001")
                .goalType("INTER_BANK_TRANSFER")
                .code("goal-001")
                .title("Test Goal")
                .description("Test goal description")
                .expectedOccurrences(5)
                .deepLink("https://app.example.com/goal")
                .goalFrequency("DAILY")
                .rewardMode("REWARD_ON_EACH_OCCURRENCE")
                .goalManager("MONIEPOINT_REWARD_SERVICE")
                .daysTillExpiry(30)
                .businessIds(List.of(1L))
                .build();
        return BrazeUserCreateGoalDTO.builder()
                .campaignIdentifier("camp-001")
                .goals(List.of(goal))
                .build();
    }

    @Test
    void createRewardGoal_invalidSecret_returnsForbidden() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, INVALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("403");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Invalid secret header key");
        verifyNoInteractions(rewardsClient, outboundUtils);
    }

    @Test
    void createRewardGoal_validSecretAndOkResponse_returnsOkWithBody() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();
        RewardsCampaignResponse goalResponse = new RewardsCampaignResponse(true, "Goal created", "200");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createGoal(any(BrazeUserCreateGoalDTO.class), anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(goalResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isTrue();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Goal created");
        verify(outboundUtils).getToken();
        verify(rewardsClient).createGoal(dto, "Bearer " + TOKEN, "CREATE");
    }

    @Test
    void createRewardGoal_validSecretAndNon200Response_returnsDownstreamStatus() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();
        RewardsCampaignResponse goalResponse = new RewardsCampaignResponse(false, "Service unavailable", "503");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createGoal(any(BrazeUserCreateGoalDTO.class), anyString(), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(goalResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Service unavailable");
        verify(rewardsClient).createGoal(dto, "Bearer " + TOKEN, "CREATE");
    }

    @Test
    void createRewardGoal_feignExceptionWithParsableBody_returnsDeserializedError() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();
        FeignException feignException = mock(FeignException.class);
        RewardsCampaignResponse errorResponse = new RewardsCampaignResponse(false, "Not found", "404");
        String rawBody = "{\"requestSuccessful\":false,\"responseMessage\":\"Not found\",\"responseCode\":\"404\"}";

        when(feignException.status()).thenReturn(404);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createGoal(any(BrazeUserCreateGoalDTO.class), anyString(), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class))).thenReturn(errorResponse);

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(404);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Not found");
        assertThat(result.getBody().getResponseCode()).isEqualTo("404");
    }

    @Test
    void createRewardGoal_feignExceptionWithUnparsableBody_returnsRawBodyAsMessage() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();
        FeignException feignException = mock(FeignException.class);
        String rawBody = "upstream error - not json";

        when(feignException.status()).thenReturn(502);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createGoal(any(BrazeUserCreateGoalDTO.class), anyString(), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class)))
                .thenThrow(new RuntimeException("JSON parse error"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(502);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo(rawBody);
        assertThat(result.getBody().getResponseCode()).isNull();
    }

    @Test
    void createRewardGoal_unexpectedException_returnsInternalServerError() {
        BrazeUserCreateGoalDTO dto = buildCreateGoalDTO();

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.createGoal(any(BrazeUserCreateGoalDTO.class), anyString(), anyString()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.createRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("500");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Unexpected failure");
    }

      private BrazeUserGoalMarkerDTO buildGoalMarkerDTO() {
        return BrazeUserGoalMarkerDTO.builder()
                .goalIdentifier("goal-001")
                .customerIdentifier("customer-001")
                .eventSourceDomain("PERSONAL")
                .build();
    }

    @Test
    void processRewardGoal_Marking_invalidSecret_returnsForbidden() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, INVALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("403");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Invalid secret header key");
        verifyNoInteractions(rewardsClient, outboundUtils);
    }

    @Test
    void processRewardGoal_Marking_validSecretAndOkResponse_returnsOkWithBody() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();
        RewardsCampaignResponse markGoalResponse = new RewardsCampaignResponse(true, "Goal marked", "200");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.markGoal(any(BrazeUserGoalMarkerDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(markGoalResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isTrue();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Goal marked");
        verify(outboundUtils).getToken();
        verify(rewardsClient).markGoal(dto, "Bearer " + TOKEN);
    }

    @Test
    void processRewardGoal_Marking_validSecretAndNon200Response_returnsDownstreamStatus() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();
        RewardsCampaignResponse goalResponse = new RewardsCampaignResponse(false, "Service unavailable", "503");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.markGoal(any(BrazeUserGoalMarkerDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(goalResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Service unavailable");
        verify(rewardsClient).markGoal(dto, "Bearer " + TOKEN);
    }

    @Test
    void processRewardGoal_Marking_feignExceptionWithParsableBody_returnsDeserializedError() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();
        FeignException feignException = mock(FeignException.class);
        RewardsCampaignResponse errorResponse = new RewardsCampaignResponse(false, "Not found", "404");
        String rawBody = "{\"requestSuccessful\":false,\"responseMessage\":\"Not found\",\"responseCode\":\"404\"}";

        when(feignException.status()).thenReturn(404);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.markGoal(any(BrazeUserGoalMarkerDTO.class), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class))).thenReturn(errorResponse);

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(404);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Not found");
        assertThat(result.getBody().getResponseCode()).isEqualTo("404");
    }

    @Test
    void processRewardGoal_Marking_feignExceptionWithUnparsableBody_returnsRawBodyAsMessage() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();
        FeignException feignException = mock(FeignException.class);
        String rawBody = "upstream error - not json";

        when(feignException.status()).thenReturn(502);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.markGoal(any(BrazeUserGoalMarkerDTO.class), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class)))
                .thenThrow(new RuntimeException("JSON parse error"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(502);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo(rawBody);
        assertThat(result.getBody().getResponseCode()).isNull();
    }

    @Test
    void processRewardGoal_Marking_unexpectedException_returnsInternalServerError() {
        BrazeUserGoalMarkerDTO dto = buildGoalMarkerDTO();

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.markGoal(any(BrazeUserGoalMarkerDTO.class), anyString()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.markRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("500");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Unexpected failure");
    }

    private BrazeUserGoalDeactivationDTO buildGoalDeactivationDTO() {
        return BrazeUserGoalDeactivationDTO.builder()
                .campaignIdentifier("camp-001")
                .goalIdentifier("goal-001")
                .build();
    }

    @Test
    void deactivateRewardGoal_invalidSecret_returnsForbidden() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, INVALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("403");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Invalid secret header key");
        verifyNoInteractions(rewardsClient, outboundUtils);
    }

    @Test
    void deactivateRewardGoal_validSecretAndOkResponse_returnsOkWithBody() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();
        RewardsCampaignResponse deactivateResponse = new RewardsCampaignResponse(true, "Goal deactivated", "200");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.deactivateGoal(any(BrazeUserGoalDeactivationDTO.class), anyString()))
                .thenReturn(ResponseEntity.ok(deactivateResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isTrue();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Goal deactivated");
        verify(outboundUtils).getToken();
        verify(rewardsClient).deactivateGoal(dto, "Bearer " + TOKEN);
    }

    @Test
    void deactivateRewardGoal_validSecretAndNon200Response_returnsDownstreamStatus() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();
        RewardsCampaignResponse goalResponse = new RewardsCampaignResponse(false, "Service unavailable", "503");

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.deactivateGoal(any(BrazeUserGoalDeactivationDTO.class), anyString()))
                .thenReturn(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(goalResponse));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Service unavailable");
        verify(rewardsClient).deactivateGoal(dto, "Bearer " + TOKEN);
    }

    @Test
    void deactivateRewardGoal_feignExceptionWithParsableBody_returnsDeserializedError() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();
        FeignException feignException = mock(FeignException.class);
        RewardsCampaignResponse errorResponse = new RewardsCampaignResponse(false, "Not found", "404");
        String rawBody = "{\"requestSuccessful\":false,\"responseMessage\":\"Not found\",\"responseCode\":\"404\"}";

        when(feignException.status()).thenReturn(404);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.deactivateGoal(any(BrazeUserGoalDeactivationDTO.class), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class))).thenReturn(errorResponse);

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(404);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Not found");
        assertThat(result.getBody().getResponseCode()).isEqualTo("404");
    }

    @Test
    void deactivateRewardGoal_feignExceptionWithUnparsableBody_returnsRawBodyAsMessage() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();
        FeignException feignException = mock(FeignException.class);
        String rawBody = "upstream error - not json";

        when(feignException.status()).thenReturn(502);
        when(feignException.contentUTF8()).thenReturn(rawBody);
        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.deactivateGoal(any(BrazeUserGoalDeactivationDTO.class), anyString())).thenThrow(feignException);
        when(objectMapperHelper.deserializeStringToObject(eq(rawBody), any(TypeReference.class)))
                .thenThrow(new RuntimeException("JSON parse error"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode().value()).isEqualTo(502);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseMessage()).isEqualTo(rawBody);
        assertThat(result.getBody().getResponseCode()).isNull();
    }

    @Test
    void deactivateRewardGoal_unexpectedException_returnsInternalServerError() {
        BrazeUserGoalDeactivationDTO dto = buildGoalDeactivationDTO();

        when(outboundUtils.getToken()).thenReturn(TOKEN);
        when(rewardsClient.deactivateGoal(any(BrazeUserGoalDeactivationDTO.class), anyString()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        ResponseEntity<RewardsCampaignResponse> result = webhookService.deactivateRewardGoal(dto, VALID_SECRET);

        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(result.getBody()).isNotNull();
        assertThat(result.getBody().getRequestSuccessful()).isFalse();
        assertThat(result.getBody().getResponseCode()).isEqualTo("500");
        assertThat(result.getBody().getResponseMessage()).isEqualTo("Unexpected failure");
    }
}
