package com.moniepoint.loans.cas.module.analytics.validation.validator;


import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class EventEnvironmentValidatorTests {

    @Mock
    private ConstraintValidatorContext context;

    private EventEnvironmentValidator eventEnvironmentValidator;

    private static final String VALID_ENVIRONMENTS = "DEVELOPMENT,STAGING,PRODUCTION";

    @BeforeEach
    public void setup() {
        eventEnvironmentValidator = new EventEnvironmentValidator(VALID_ENVIRONMENTS);
        eventEnvironmentValidator.initialize(null);
    }

    @Test
    public void isValid_whenNullValue_returnsFalse() {
        assertFalse(eventEnvironmentValidator.isValid(null, context));
    }

    @Test
    public void isValid_whenEmptyValue_returnsFalse() {
        assertFalse(eventEnvironmentValidator.isValid("", context));
    }

    @Test
    public void isValid_withValidValues_returnsTrue() {
        assertTrue(eventEnvironmentValidator.isValid("DEVELOPMENT", context));
        assertTrue(eventEnvironmentValidator.isValid("STAGING", context));
        assertTrue(eventEnvironmentValidator.isValid("PRODUCTION", context));
    }

    @Test
    public void isValid_withInvalidValue_returnsFalse() {
        assertFalse(eventEnvironmentValidator.isValid("UNKNOWN", context));
    }

    @Test
    public void isValid_withLowercaseValue_returnsTrue() {
        assertTrue(eventEnvironmentValidator.isValid("development", context));
    }
}
