package com.moniepoint.loans.cas.module.analytics.validation.validator;


import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class EventPlatformValidatorTests {

    @Mock
    private ConstraintValidatorContext context;

    private EventPlatformValidator eventPlatformValidator;

    private static final String VALID_PLATFORMS = "BACKEND,WEB,MOBILE";

    @BeforeEach
    public void setup() {
        eventPlatformValidator = new EventPlatformValidator(VALID_PLATFORMS);
        eventPlatformValidator.initialize(null);
    }

    @Test
    public void isValid_whenNullValue_returnsFalse() {
        assertFalse(eventPlatformValidator.isValid(null, context));
    }

    @Test
    public void isValid_whenEmptyValue_returnsFalse() {
        assertFalse(eventPlatformValidator.isValid("", context));
    }

    @Test
    public void isValid_withValidValues_returnsTrue() {
        assertTrue(eventPlatformValidator.isValid("MOBILE", context));
        assertTrue(eventPlatformValidator.isValid("BACKEND", context));
        assertTrue(eventPlatformValidator.isValid("MOBILE", context));
    }

    @Test
    public void isValid_withInvalidValue_returnsFalse() {
        assertFalse(eventPlatformValidator.isValid("UNKNOWN", context));
    }

    @Test
    public void isValid_withLowercaseValue_returnsTrue() {
        assertTrue(eventPlatformValidator.isValid("mobile", context));
    }
}
