package com.moniepoint.loans.cas.module.cache.impl;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Verifies the full serialize → Redis → deserialize round-trip using real Jackson.
 * The unit tests in RedisCacheServiceImplTests mock ObjectMapperHelper, so they never
 * exercise the TsToLdt converter or the ObjectMapper configuration. These tests do.
 */
@ExtendWith(MockitoExtension.class)
class RedisCacheServiceImplRoundTripTest {

    @Mock
    private RedisTemplate<String, String> redisTemplate;

    @Mock
    private ValueOperations<String, String> valueOperations;

    private RedisCacheServiceImpl sut;
    private ObjectMapperHelper realObjectMapperHelper;

    private static final String USER_ID = "user-123";

    @BeforeEach
    void setUp() {
        realObjectMapperHelper = new ObjectMapperHelper(ObjectMapperConfiguration.constructObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
        sut = new RedisCacheServiceImpl(redisTemplate, 3600L, realObjectMapperHelper);
        ReflectionTestUtils.setField(sut, "PREPROCESSED_SURVEY_CACHE_BY_USER_TTL", 100);
    }

    @Test
    void getAllPreprocessedSurveys_roundTrip_ttlDeserializedCorrectly() {
        // JavaTimeModule with WRITE_DATES_AS_TIMESTAMPS=true (default) serializes LocalDateTime
        // as a JSON array [year,month,day,hour,min,sec,nano]. TsToLdt must handle this.
        LocalDateTime future = LocalDateTime.of(2030, 1, 1, 0, 0, 0);
        String json = realObjectMapperHelper.serializeToString(List.of(
                PreprocessedSurveyDTO.builder().user("alice").surveyId(42L).ttl(future).build()
        ));

        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:" + USER_ID)).thenReturn(json);

        List<PreprocessedSurveyDTO> result = sut.getAllPreprocessedSurveys(USER_ID);

        assertEquals(1, result.size());
        assertEquals("alice", result.getFirst().getUser());
        assertEquals(42L, result.getFirst().getSurveyId());
        assertEquals(future, result.getFirst().getTtl());
    }

    @Test
    void getAllPreprocessedSurveys_jacksonArrayFormat_ttlDeserializedCorrectly() {
        // Primary wire format: JavaTimeModule array [year,month,day,hour,min,sec,nano].
        // This test guards the TsToLdt List<?> branch directly with a hand-crafted payload.
        String json = "[{\"user\":\"bob\",\"surveyId\":7," +
                "\"ttl\":[2030,1,1,0,0,0,0]," +
                "\"priority\":10}]";

        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:" + USER_ID)).thenReturn(json);

        List<PreprocessedSurveyDTO> result = sut.getAllPreprocessedSurveys(USER_ID);

        assertEquals(1, result.size());
        assertEquals("bob", result.getFirst().getUser());
        assertEquals(LocalDateTime.of(2030, 1, 1, 0, 0, 0), result.getFirst().getTtl());
    }

    @Test
    void getAllPreprocessedSurveys_roundTrip_expiredSurveysFiltered() {
        LocalDateTime past = LocalDateTime.of(2020, 1, 1, 0, 0, 0);
        LocalDateTime future = LocalDateTime.of(2030, 1, 1, 0, 0, 0);
        String json = realObjectMapperHelper.serializeToString(List.of(
                PreprocessedSurveyDTO.builder().user("expired").ttl(past).build(),
                PreprocessedSurveyDTO.builder().user("active").ttl(future).build()
        ));

        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:" + USER_ID)).thenReturn(json);

        List<PreprocessedSurveyDTO> result = sut.getAllPreprocessedSurveys(USER_ID);

        assertEquals(1, result.size());
        assertEquals("active", result.getFirst().getUser());
    }
}
