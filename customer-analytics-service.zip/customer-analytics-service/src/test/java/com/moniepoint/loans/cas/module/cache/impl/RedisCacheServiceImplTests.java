package com.moniepoint.loans.cas.module.cache.impl;

import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RedisCacheServiceImplTests {

    @Mock
    private RedisTemplate<String, String> redisTemplate;

    @Mock
    private ValueOperations<String, String> valueOperations;

    @Mock
    ObjectMapperHelper objectMapperHelper;

    @Captor
    ArgumentCaptor<List<PreprocessedSurveyDTO>> updatedPreprocessedSurveys;

    private RedisCacheServiceImpl redisCacheServiceImpl;

    private static final Long DEFAULT_EXPIRY = 3600L;

    private static final String KEY = "key";
    private static final String VALUE = "value";


    @BeforeEach
    void setUp() {
        redisCacheServiceImpl = new RedisCacheServiceImpl(redisTemplate, DEFAULT_EXPIRY, objectMapperHelper);
        ReflectionTestUtils.setField(redisCacheServiceImpl, "PREPROCESSED_SURVEY_CACHE_BY_ID_TTL", 10);
        ReflectionTestUtils.setField(redisCacheServiceImpl, "PREPROCESSED_SURVEY_CACHE_BY_USER_TTL", 100);
    }

    @Test
    void doesKeyExist_existingKey_returnsTrue() {
        when(redisTemplate.hasKey(KEY)).thenReturn(true);

        assertTrue(redisCacheServiceImpl.doesKeyExist(KEY));
    }

    @Test
    void doesKeyExist_nonExistingKey_returnsFalse() {
        when(redisTemplate.hasKey(KEY)).thenReturn(false);

        assertFalse(redisCacheServiceImpl.doesKeyExist(KEY));
    }

    @Test
    void cacheString_withDefaultExpiry_success() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);

        redisCacheServiceImpl.cacheString(KEY, VALUE);

        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).set(KEY, VALUE, DEFAULT_EXPIRY, TimeUnit.SECONDS);
    }


    @Test
    void cacheString_withCustomExpiry_success() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);

        redisCacheServiceImpl.cacheString(KEY, VALUE, 200);

        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).set(KEY, VALUE, 200, TimeUnit.SECONDS);
    }

    @Test
    void getCachedString_success() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(KEY)).thenReturn(VALUE);

        String actualValue = redisCacheServiceImpl.getCachedString(KEY);

        assertEquals(VALUE, actualValue);

        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).get(KEY);
    }

    @Test
    void cachePreprocessedSurvey_ById_success() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        redisCacheServiceImpl.cachePreprocessedSurveyById(KEY, VALUE);
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).set("pps-id:"+KEY, VALUE,600, TimeUnit.SECONDS);
    }

    @Test
    void getPreprocessedSurvey_ById_success() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-id:"+KEY)).thenReturn(VALUE);
        String actualValue = redisCacheServiceImpl.getPreprocessedSurveyById(KEY);

        assertEquals(VALUE, actualValue);

        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).get("pps-id:"+KEY);
    }

    @Test
    void cacheAllPreprocessedSurvey_success() {
        when(objectMapperHelper.serializeToString(any())).thenReturn(VALUE);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        redisCacheServiceImpl.cacheAllPreprocessedSurveys(KEY, List.of(new PreprocessedSurveyDTO()));
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).set("pps-user:"+KEY, VALUE,6000, TimeUnit.SECONDS);
    }

    @Test
    void getAllPreprocessedSurvey_nullValueInCache() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(null);
        List<PreprocessedSurveyDTO> actualValue = redisCacheServiceImpl.getAllPreprocessedSurveys(KEY);

        assertEquals(0, actualValue.size());

        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
    }

    @Test
    void getAllPreprocessedSurvey_valueFoundInCache() {
        LocalDateTime future = LocalDateTime.now().plusSeconds(1440);
        LocalDateTime future2 = LocalDateTime.now().plusSeconds(1600);

        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(List.of(
                PreprocessedSurveyDTO.builder().user("user1").ttl(future).build(),
                PreprocessedSurveyDTO.builder().user("user2").ttl(future2).build()
        ));
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(VALUE);
        List<PreprocessedSurveyDTO> actualValue = redisCacheServiceImpl.getAllPreprocessedSurveys(KEY);

        assertEquals(2, actualValue.size());
        assertEquals("user1", actualValue.getFirst().getUser());
        assertEquals("user2", actualValue.getLast().getUser());
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
    }

    @Test
    void getAllPreprocessedSurvey_expiredSurveyNotReturned() {
        LocalDateTime future = LocalDateTime.now().plusSeconds(1440);
        LocalDateTime past = LocalDateTime.now().minusSeconds(1440);

        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(List.of(
                PreprocessedSurveyDTO.builder().user("user1").ttl(future).build(),
                PreprocessedSurveyDTO.builder().user("user2").ttl(past).build()
        ));
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(VALUE);
        List<PreprocessedSurveyDTO> actualValue = redisCacheServiceImpl.getAllPreprocessedSurveys(KEY);

        assertEquals(1, actualValue.size());
        assertEquals("user1", actualValue.getFirst().getUser());
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
    }

    @Test
    void appendPreprocessedSurvey_success() {
        when(objectMapperHelper.serializeToString(any())).thenReturn(VALUE);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(VALUE);
        LocalDateTime future = LocalDateTime.now().plusSeconds(1440);
        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(List.of(
                PreprocessedSurveyDTO.builder().user("user1").ttl(future).build(),
                PreprocessedSurveyDTO.builder().user("user2").ttl(future).build()
        ));

        redisCacheServiceImpl.appendPreprocessedSurvey(KEY, PreprocessedSurveyDTO.builder().user("user3").build());
        verify(objectMapperHelper).serializeToString(updatedPreprocessedSurveys.capture());
        List<PreprocessedSurveyDTO> updatedSurveys = updatedPreprocessedSurveys.getValue();
        assertEquals(3, updatedSurveys.size());
        assertEquals("user1", updatedSurveys.getFirst().getUser());
        assertEquals("user2", updatedSurveys.get(1).getUser());
        assertEquals("user3", updatedSurveys.getLast().getUser());
        verify(redisTemplate, times(2)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
        verify(valueOperations, times(1)).set("pps-user:"+KEY, VALUE,6000, TimeUnit.SECONDS);
    }

    @Test
    void appendPreprocessedSurvey_ignoreExpiredSurveysInCache() {
        when(objectMapperHelper.serializeToString(any())).thenReturn(VALUE);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(VALUE);
        LocalDateTime future = LocalDateTime.now().plusSeconds(1440);
        LocalDateTime past = LocalDateTime.now().minusSeconds(1440);

        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(List.of(
                PreprocessedSurveyDTO.builder().user("user1").ttl(future).build(),
                PreprocessedSurveyDTO.builder().user("user2").ttl(past).build()
        ));

        redisCacheServiceImpl.appendPreprocessedSurvey(KEY, PreprocessedSurveyDTO.builder().user("user3").build());
        verify(objectMapperHelper).serializeToString(updatedPreprocessedSurveys.capture());
        List<PreprocessedSurveyDTO> updatedSurveys = updatedPreprocessedSurveys.getValue();
        assertEquals(2, updatedSurveys.size());
        assertEquals("user1", updatedSurveys.getFirst().getUser());
        assertEquals("user3", updatedSurveys.getLast().getUser());
        verify(redisTemplate, times(2)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
        verify(valueOperations, times(1)).set("pps-user:"+KEY, VALUE,6000, TimeUnit.SECONDS);
    }

    @Test
    void removePreprocessedSurveyFromUserCachedSurveys_success() {
        when(objectMapperHelper.serializeToString(any())).thenReturn(VALUE);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("pps-user:"+KEY)).thenReturn(VALUE);
        LocalDateTime future = LocalDateTime.now().plusSeconds(1440);
        PreprocessedSurveyDTO survey1 = PreprocessedSurveyDTO.builder().user("user1").ttl(future).id(7L).build();
        PreprocessedSurveyDTO survey2 = PreprocessedSurveyDTO.builder().user("user2").ttl(future).build();

        when(objectMapperHelper.deserializeStringToObject(any(), any())).thenReturn(List.of(survey2, survey1));

        redisCacheServiceImpl.removePreprocessedSurveyByUserId(KEY, String.valueOf(7L));
        verify(objectMapperHelper).serializeToString(updatedPreprocessedSurveys.capture());
        List<PreprocessedSurveyDTO> updatedSurveys = updatedPreprocessedSurveys.getValue();
        assertEquals(1, updatedSurveys.size());
        assertEquals("user2", updatedSurveys.getFirst().getUser());
        verify(redisTemplate, times(2)).opsForValue();
        verify(valueOperations, times(1)).get("pps-user:"+KEY);
        verify(valueOperations, times(1)).set("pps-user:"+KEY, VALUE,6000, TimeUnit.SECONDS);
    }

    @Test
    void removePreprocessedSurveyById_success() {
        redisCacheServiceImpl.removePreprocessedSurveyBySurveyId(KEY);

        verify(redisTemplate, times(1)).delete("pps-id:"+KEY);
    }

    @Test
    void evictAllPreprocessedSurveys_deletesUserCacheKey() {
        redisCacheServiceImpl.evictAllPreprocessedSurveys(KEY);

        verify(redisTemplate, times(1)).delete("pps-user:"+KEY);
    }

}
