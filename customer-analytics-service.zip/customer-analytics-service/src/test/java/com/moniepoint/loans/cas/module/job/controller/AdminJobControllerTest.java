package com.moniepoint.loans.cas.module.job.controller;

import com.moniepoint.loans.cas.module.job.service.JobScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AdminJobControllerTest {

    @Mock
    private JobScheduler jobScheduler;

    @InjectMocks
    private AdminJobController adminJobController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(adminJobController).build();
    }

    @Test
    void triggerJob_Success() throws Exception {
        mockMvc.perform(post("/internal/admin/job/{keyGroup}/trigger?keyName=keyName", "keyGroup"))
                .andExpect(status().isAccepted());

        verify(jobScheduler, times(1)).triggerJob("keyName", "keyGroup");
    }
}