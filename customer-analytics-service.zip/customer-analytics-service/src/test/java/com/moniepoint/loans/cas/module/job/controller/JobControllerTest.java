package com.moniepoint.loans.cas.module.job.controller;

import com.moniepoint.loans.cas.module.job.pojo.JobResponse;
import com.moniepoint.loans.cas.module.job.service.JobScheduler;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class JobControllerTest {

    @Mock
    private JobScheduler jobScheduler;

    @InjectMocks
    private JobController jobController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(jobController).build();
    }

    @Test
    void testGetAllJobs() throws Exception {
        List<JobResponse> jobResponses = new ArrayList<>();
        when(jobScheduler.getJobs()).thenReturn(jobResponses);

        mockMvc.perform(get("/api/v1/job"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andReturn();

        verify(jobScheduler, times(1)).getJobs();
    }

    @Test
    void testGetJob() throws Exception {
        String jobName = RandomStringUtils.random(10, true, false);
        String jobGroup = RandomStringUtils.random(10, true, false);

        JobResponse jobResponse = new JobResponse();
        jobResponse.setName(jobName);
        jobResponse.setGroup(jobName);

        when(jobScheduler.getJob(jobName, jobGroup)).thenReturn(jobResponse);

        mockMvc.perform(get("/api/v1/job/{keyGroup}/get?keyName=" + jobName, jobGroup))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").exists())
                .andReturn();

        verify(jobScheduler, times(1)).getJob(jobName, jobGroup);
    }

    @Test
    void testPauseJob() throws Exception {
        mockMvc.perform(post("/api/v1/job/{keyGroup}/pause?keyName=keyName", "keyGroup"))
                .andExpect(status().isOk());

        verify(jobScheduler, times(1)).pauseJob("keyName", "keyGroup");
    }

    @Test
    void testResumeJob() throws Exception {
        mockMvc.perform(post("/api/v1/job/{keyGroup}/resume?keyName=keyName", "keyGroup"))
                .andExpect(status().isOk());

        verify(jobScheduler, times(1)).resumeJob("keyName", "keyGroup");
    }
}