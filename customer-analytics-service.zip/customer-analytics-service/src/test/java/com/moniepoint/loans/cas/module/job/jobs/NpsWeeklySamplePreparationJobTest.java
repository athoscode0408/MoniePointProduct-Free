package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.service.NpsWeeklySamplePreparationService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NpsWeeklySamplePreparationJobTest {

    private static final String CRON = "0 0 1 ? * MON";

    @Mock
    private NpsWeeklySamplePreparationService preparationService;

    @InjectMocks
    private NpsWeeklySamplePreparationJob underTest;

    @BeforeEach
    void setUp() {
        underTest = new NpsWeeklySamplePreparationJob(preparationService);
        ReflectionTestUtils.setField(underTest, "preparationJobFrequency", CRON);
        ReflectionTestUtils.setField(underTest, "npsProgrammeEnabled", true);
    }

    @Test
    void getJobCode_returnsExpectedCode() {
        assertThat(underTest.getJobCode()).isEqualTo("NPS_WEEKLY_SAMPLE_PREPARATION_JOB");
    }

    @Test
    void getJobName_returnsExpectedName() {
        assertThat(underTest.getJobName()).isEqualTo("NPS Weekly Sample Preparation Job");
    }

    @Test
    void getJobClass_returnsOwnClass() {
        assertThat(underTest.getJobClass()).isEqualTo(NpsWeeklySamplePreparationJob.class);
    }

    @Test
    void getSchedule_returnsConfiguredCron() {
        Schedule schedule = underTest.getSchedule();

        assertThat(schedule.getCron()).isEqualTo(CRON);
        assertThat(schedule.isStartNow()).isFalse();
    }

    @Test
    void execute_whenProgrammeEnabled_callsPreparationService() {
        JobExecutionContext ctx = buildJobContext();

        underTest.execute(ctx);

        verify(preparationService, times(1)).prepareWeeklySample(any());
    }

    @Test
    void execute_whenProgrammeDisabled_doesNotCallPreparationService() {
        ReflectionTestUtils.setField(underTest, "npsProgrammeEnabled", false);
        JobExecutionContext ctx = buildMinimalJobContext();

        underTest.execute(ctx);

        verify(preparationService, never()).prepareWeeklySample(any());
    }

    private JobExecutionContext buildJobContext() {
        JobExecutionContext ctx = Mockito.mock(JobExecutionContext.class);
        JobDetail detail = Mockito.mock(JobDetail.class);
        JobKey key = Mockito.mock(JobKey.class);
        when(ctx.getJobDetail()).thenReturn(detail);
        when(detail.getKey()).thenReturn(key);
        when(key.getName()).thenReturn("NPS_WEEKLY_SAMPLE_PREPARATION_JOB");
        when(ctx.getFireTime()).thenReturn(new Date());
        when(ctx.getNextFireTime()).thenReturn(new Date());
        return ctx;
    }

    private JobExecutionContext buildMinimalJobContext() {
        JobExecutionContext ctx = Mockito.mock(JobExecutionContext.class);
        JobDetail detail = Mockito.mock(JobDetail.class);
        JobKey key = Mockito.mock(JobKey.class);
        when(ctx.getJobDetail()).thenReturn(detail);
        when(detail.getKey()).thenReturn(key);
        when(key.getName()).thenReturn("NPS_WEEKLY_SAMPLE_PREPARATION_JOB");
        when(ctx.getFireTime()).thenReturn(new Date());
        return ctx;
    }
}
