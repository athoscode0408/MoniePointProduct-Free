package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.repository.EventRetryView;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.springframework.test.util.ReflectionTestUtils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StaleEventRetryCleanupTriggerJobTests {

    private static final int BATCH_SIZE = 500;

    @Mock
    private EventRetryRepositoryService eventRetryRepositoryService;

    @Mock
    private JobExecutionContext jobExecutionContext;

    private StaleEventRetryCleanupTriggerJob job;

    @BeforeEach
    void setUp() {
        job = new StaleEventRetryCleanupTriggerJob(eventRetryRepositoryService);
        ReflectionTestUtils.setField(job, "staleEventRetryCleanupFrequency", "0 0 0 * * ?");
        ReflectionTestUtils.setField(job, "retentionValue", 30L);
        ReflectionTestUtils.setField(job, "retentionUnit", "DAYS");
        ReflectionTestUtils.setField(job, "batchSize", BATCH_SIZE);

        JobDetail jobDetail = mock(JobDetail.class);
        lenient().when(jobDetail.getKey()).thenReturn(JobKey.jobKey("STALE_EVENT_RETRY_CLEANUP_TRIGGER_JOB"));
        lenient().when(jobExecutionContext.getJobDetail()).thenReturn(jobDetail);
        lenient().when(jobExecutionContext.getFireTime()).thenReturn(new java.util.Date());
        lenient().when(jobExecutionContext.getNextFireTime()).thenReturn(new java.util.Date());
    }

    // ── metadata ──────────────────────────────────────────────────────────────

    @Test
    void getJobCode_returnsExpectedCode() {
        assertThat(job.getJobCode()).isEqualTo("STALE_EVENT_RETRY_CLEANUP_TRIGGER_JOB");
    }

    @Test
    void getJobName_returnsExpectedName() {
        assertThat(job.getJobName()).isEqualTo("Stale event retry cleanup Trigger Job");
    }

    @Test
    void getJobClass_returnsCorrectClass() {
        assertThat(job.getJobClass()).isEqualTo(StaleEventRetryCleanupTriggerJob.class);
    }

    @Test
    void getSchedule_returnsCronSchedule() {
        Schedule schedule = job.getSchedule();
        assertThat(schedule.getCron()).isEqualTo("0 0 0 * * ?");
        assertThat(schedule.isStartNow()).isFalse();
    }

    // ── execute — early exits ─────────────────────────────────────────────────

    @Test
    void execute_invalidRetentionUnit_abortsWithoutDeleting() {
        ReflectionTestUtils.setField(job, "retentionUnit", "FORTNIGHT");

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, never()).findBatchAfter(anyLong(), anyInt());
        verify(eventRetryRepositoryService, never()).deleteAllByIds(any());
    }

    @Test
    void execute_emptyTable_exitsWithoutDeleting() {
        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).findBatchAfter(0L, BATCH_SIZE);
        verify(eventRetryRepositoryService, never()).deleteAllByIds(any());
    }

    // ── execute — stop condition ──────────────────────────────────────────────

    @Test
    void execute_batchAllEntriesWithinRetention_stopsWithoutDeleting() {
        // all entries within the 30-day retention window
        Timestamp recent = Timestamp.from(Instant.now().minus(1, ChronoUnit.DAYS));
        EventRetryView entry = staleEntry(1L, recent);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(entry));

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, never()).deleteAllByIds(any());
    }

    @Test
    void execute_boundaryBatch_deletesOnlyStaleEntriesAndStops() {
        Timestamp stale = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        Timestamp fresh = Timestamp.from(Instant.now().minus(1, ChronoUnit.DAYS));
        EventRetryView staleEntry = staleEntry(1L, stale);
        EventRetryView freshEntry = staleEntry(2L, fresh);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(staleEntry, freshEntry));

        job.execute(jobExecutionContext);

        // only the stale row deleted, fresh row skipped
        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(1L));
        // stopped after boundary batch — no further fetch
        verify(eventRetryRepositoryService, times(1)).findBatchAfter(anyLong(), anyInt());
    }

    @Test
    void execute_boundaryBatch_doesNotFetchNextBatch() {
        Timestamp stale = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        Timestamp fresh = Timestamp.from(Instant.now().minus(1, ChronoUnit.DAYS));
        EventRetryView staleRow = staleEntry(1L, stale);
        EventRetryView freshRow = staleEntry(2L, fresh);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE))
                .thenReturn(List.of(staleRow, freshRow));

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).findBatchAfter(anyLong(), anyInt());
    }

    @Test
    void execute_staleEntry_isDeleted() {
        Timestamp oldCreatedOn = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        EventRetryView entry = staleEntry(1L, oldCreatedOn);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(entry));
        when(eventRetryRepositoryService.findBatchAfter(1L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(1L));
    }

    @Test
    void execute_staleEntryWithFutureNextRetryTime_isStillDeleted() {
        // nextRetryTime is NOT a deletion guard — only createdOn matters
        Timestamp oldCreatedOn = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        EventRetryView entry = staleEntry(1L, oldCreatedOn);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(entry));
        when(eventRetryRepositoryService.findBatchAfter(1L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(1L));
    }

    @Test
    void execute_multipleStaleBatches_processesAll() {
        Timestamp oldCreatedOn = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        EventRetryView entry1 = staleEntry(1L, oldCreatedOn);
        EventRetryView entry2 = staleEntry(2L, oldCreatedOn);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(entry1));
        when(eventRetryRepositoryService.findBatchAfter(1L, BATCH_SIZE)).thenReturn(List.of(entry2));
        when(eventRetryRepositoryService.findBatchAfter(2L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(1L));
        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(2L));
    }

    @Test
    void execute_batchWithMultipleEntries_cursorAdvancesToLastId() {
        Timestamp oldCreatedOn = Timestamp.from(Instant.now().minus(60, ChronoUnit.DAYS));
        EventRetryView entry1 = staleEntry(1L, oldCreatedOn);
        EventRetryView entry2 = staleEntry(5L, oldCreatedOn);

        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of(entry1, entry2));
        when(eventRetryRepositoryService.findBatchAfter(5L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService, times(1)).deleteAllByIds(List.of(1L, 5L));
        // cursor advances to last id in batch (5), not last+1
        verify(eventRetryRepositoryService, times(1)).findBatchAfter(eq(5L), anyInt());
    }

    @Test
    void execute_cursorStartsAtZeroNotMinId() {
        // Job starts from cursor=0 always — no findMinEventRetryId call
        when(eventRetryRepositoryService.findBatchAfter(0L, BATCH_SIZE)).thenReturn(List.of());

        job.execute(jobExecutionContext);

        verify(eventRetryRepositoryService).findBatchAfter(eq(0L), anyInt());
        verify(eventRetryRepositoryService, never()).findMinEventRetryId();
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private EventRetryView staleEntry(long id, Timestamp createdOn) {
        EventRetryView entry = mock(EventRetryView.class);
        lenient().when(entry.getId()).thenReturn(id);
        lenient().when(entry.getCreatedOn()).thenReturn(createdOn);
        return entry;
    }
}
