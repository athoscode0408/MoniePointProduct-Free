package com.moniepoint.loans.cas.module.job.jobs;

import com.moniepoint.loans.cas.module.analytics.repository.service.UnsupportedEventRepositoryService;
import com.moniepoint.loans.cas.module.job.pojo.Schedule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;

import java.lang.reflect.Field;
import java.util.Date;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UnsupportedEventsCleanupTriggerJobTests {

    private static final String CRON = "0 1/1 * ? * * *";

    @Mock
    private UnsupportedEventRepositoryService unsupportedEventRepositoryService;

    @InjectMocks
    private UnsupportedEventsCleanupTriggerJob underTest;

    @BeforeEach
    public void setUp() throws Exception {
        Field field = UnsupportedEventsCleanupTriggerJob.class.getDeclaredField("unsupportedEventsCleanupFrequency");
        field.setAccessible(true);
        field.set(underTest, CRON);
    }


    @Test
    void getJobCode_success() {
        assertThat(underTest.getJobCode()).isEqualTo("UNSUPPORTED_EVENTS_CLEANUP_TRIGGER_JOB");
    }

    @Test
    void getJobName_success() {
        assertThat(underTest.getJobName()).isEqualTo("Unsupported events cleanup Trigger Job");
    }

    @Test
    void getJobClass_success() {
        assertThat(underTest.getJobClass()).isEqualTo(UnsupportedEventsCleanupTriggerJob.class);
    }

    @Test
    void getSchedule_success() {
        Schedule result = underTest.getSchedule();

        assertThat(result.isStartNow()).isFalse();
        assertThat(result.getCron()).isEqualTo(CRON);
    }

    @Test
    void execute_success() {
        JobExecutionContext jobExecutionContext = Mockito.mock(JobExecutionContext.class);
        JobDetail jobDetail = Mockito.mock(JobDetail.class);
        JobKey jobKey = Mockito.mock(JobKey.class);

        when(jobExecutionContext.getJobDetail())
                .thenReturn(jobDetail);
        when(jobDetail.getKey())
                .thenReturn(jobKey);
        when(jobKey.getName()).thenReturn("jobKeyName");
        when(jobExecutionContext.getFireTime()).thenReturn(new Date());
        when(jobExecutionContext.getNextFireTime()).thenReturn(new Date());

        underTest.execute(jobExecutionContext);

        verify(unsupportedEventRepositoryService, times(1)).deleteAllUnsupportedEvents();
    }

}
