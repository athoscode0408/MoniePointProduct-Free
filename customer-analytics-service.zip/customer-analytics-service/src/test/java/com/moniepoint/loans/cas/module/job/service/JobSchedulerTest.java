package com.moniepoint.loans.cas.module.job.service;

import com.moniepoint.loans.cas.common.exception.ServerException;
import com.moniepoint.loans.cas.module.job.pojo.JobResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.matchers.GroupMatcher;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JobSchedulerTest {

    @Mock
    private Scheduler scheduler;

    @InjectMocks
    private JobScheduler underTest;

    @Test
    void deleteJob_Success() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        when(scheduler.deleteJob(jobKey)).thenReturn(true);
        underTest.deleteJob(jobKey);
        verify(scheduler, times(1)).deleteJob(jobKey);
    }

    @Test
    void deleteJob_Failure() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        when(scheduler.deleteJob(jobKey)).thenThrow(SchedulerException.class);
        underTest.deleteJob(jobKey);
        verify(scheduler, times(1)).deleteJob(jobKey);
    }

    @Test
    void getJobs_Success() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        Trigger trigger = mock(Trigger.class);
        when(scheduler.getJobKeys(GroupMatcher.anyJobGroup())).thenReturn(new HashSet<>(Collections.singleton(jobKey)));
        doReturn(Collections.singletonList(trigger)).when(scheduler).getTriggersOfJob(jobKey);
        when(trigger.getNextFireTime()).thenReturn(null);
        when(trigger.getPreviousFireTime()).thenReturn(null);
        when(trigger.mayFireAgain()).thenReturn(false);
        when(trigger.getStartTime()).thenReturn(null);
        when(trigger.getEndTime()).thenReturn(null);
        when(scheduler.getTriggerState(trigger.getKey())).thenReturn(Trigger.TriggerState.NORMAL);

        List<JobResponse> jobResponses = underTest.getJobs();
        assertEquals(1, jobResponses.size());
        JobResponse response = jobResponses.getFirst();
        assertEquals("jobName", response.getName());
        assertEquals("jobGroup", response.getGroup());
        assertNull(response.getNextFireTime());
        assertNull(response.getPreviousFireTime());
        assertFalse(response.isMayFireAgain());
        assertNull(response.getStartTime());
        assertNull(response.getEndTime());
        assertEquals(Trigger.TriggerState.NORMAL, response.getTriggerState());
    }

    @Test
    void getJobs_Success_TriggerIsNull() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        Trigger trigger = mock(Trigger.class);
        when(scheduler.getJobKeys(GroupMatcher.anyJobGroup())).thenReturn(new HashSet<>(Collections.singleton(jobKey)));
        doReturn(Collections.singletonList(trigger)).when(scheduler).getTriggersOfJob(jobKey);
        when(scheduler.getTriggersOfJob(jobKey)).thenReturn(null);

        List<JobResponse> jobResponses = underTest.getJobs();
        assertEquals(1, jobResponses.size());
        JobResponse response = jobResponses.getFirst();
        assertEquals("jobName", response.getName());
        assertEquals("jobGroup", response.getGroup());
        assertNull(response.getTriggerState());
    }

    @Test
    void getJobs_Exception() throws SchedulerException {
        when(scheduler.getJobKeys(GroupMatcher.anyJobGroup())).thenThrow(SchedulerException.class);
        List<JobResponse> jobResponses = underTest.getJobs();
        assertTrue(jobResponses.isEmpty());
    }

    @Test
    void getJob_Success() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        Trigger trigger = mock(Trigger.class);
        doReturn(Collections.singletonList(trigger)).when(scheduler).getTriggersOfJob(jobKey);
        when(trigger.getNextFireTime()).thenReturn(null);
        when(trigger.getPreviousFireTime()).thenReturn(null);
        when(trigger.mayFireAgain()).thenReturn(false);
        when(trigger.getStartTime()).thenReturn(null);
        when(trigger.getEndTime()).thenReturn(null);
        when(scheduler.getTriggerState(trigger.getKey())).thenReturn(Trigger.TriggerState.NORMAL);

        JobResponse response = underTest.getJob("jobName", "jobGroup");

        assertNotNull(response);
        assertEquals("jobName", response.getName());
        assertEquals("jobGroup", response.getGroup());
        assertNull(response.getNextFireTime());
        assertNull(response.getPreviousFireTime());
        assertFalse(response.isMayFireAgain());
        assertNull(response.getStartTime());
        assertNull(response.getEndTime());
        assertEquals(Trigger.TriggerState.NORMAL, response.getTriggerState());
    }

    @Test
    void getJob_TriggersAreNull() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        Trigger trigger = mock(Trigger.class);
        doReturn(Collections.singletonList(trigger)).when(scheduler).getTriggersOfJob(jobKey);
        when(scheduler.getTriggersOfJob(jobKey)).thenReturn(null);

        JobResponse response = underTest.getJob("jobName", "jobGroup");

        assertNull(response);
    }

    @Test
    void getJob_Exception() throws SchedulerException {
        JobKey jobKey = new JobKey("jobName", "jobGroup");
        when(scheduler.getTriggersOfJob(jobKey)).thenThrow(SchedulerException.class);
        assertThrows(
            ServerException.class, () -> underTest.getJob("jobName", "jobGroup"));
    }

    @Test
    void pauseJob_Success() throws SchedulerException {
        underTest.pauseJob("jobName", "jobGroup");
        verify(scheduler, times(1)).pauseJob(new JobKey("jobName", "jobGroup"));
    }

    @Test
    void pauseJob_Exception() throws SchedulerException {
        doThrow(SchedulerException.class).when(scheduler).pauseJob(new JobKey("jobName", "jobGroup"));
        assertThrows(ServerException.class, () -> underTest.pauseJob("jobName", "jobGroup"));
    }

    @Test
    void resumeJob_Success() throws SchedulerException {
        underTest.resumeJob("jobName", "jobGroup");
        verify(scheduler, times(1)).resumeJob(new JobKey("jobName", "jobGroup"));
    }

    @Test
    void resumeJob_Exception() throws SchedulerException {
        doThrow(SchedulerException.class).when(scheduler).resumeJob(new JobKey("jobName", "jobGroup"));
        assertThrows(ServerException.class, () -> underTest.resumeJob("jobName", "jobGroup"));
    }

    @Test
    void triggerJob_Success() throws SchedulerException {
        underTest.triggerJob("jobName", "jobGroup");
        verify(scheduler, times(1)).triggerJob(new JobKey("jobName", "jobGroup"));
    }

    @Test
    void triggerJob_Exception() throws SchedulerException {
        doThrow(SchedulerException.class).when(scheduler).triggerJob(new JobKey("jobName", "jobGroup"));
        assertThrows(ServerException.class, () -> underTest.triggerJob("jobName", "jobGroup"));
    }
}