package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.HashUtil;
import com.moniepoint.loans.cas.common.util.JsonUtils;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeUserAlias;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.BrazeApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.impl.BrazeEventProviderHandler;
import com.moniepoint.loans.cas.module.analytics.service.impl.EventRetryServiceImpl;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.BrazeEventListener;
import com.moniepoint.loans.cas.testdoubles.*;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.time.Clock;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class BrazeEventListenerTests {
    private static final String API_KEY = "my-braze-api-key";
    private static final String ANDROID_APP_ID = "android-id";
    private static final String IOS_APP_ID = "ios-id";
    private static final String WEB_APP_ID = "web-id";
    private final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    private FakeValidator validator;
    private FakeBrazeClient brazeClient;
    private FakeEventRetryRepository retryStorage;
    private FakeSupportedUserAttributesRepository supportedUserAttributesRepository;
    @InjectMocks
    private BrazeEventListener listener;
    @Mock
    BrazeApiKeyStorage brazeApiKeyStorage;
    CacheService cacheService = new FakeCacheService(Map.of());

    @BeforeEach
    void setup() {
        brazeClient = new FakeBrazeClient(List.of(String.format("Bearer %s", API_KEY)));
        validator = new FakeValidator(Set.of());
        retryStorage = new FakeEventRetryRepository(new HashMap<>());
        supportedUserAttributesRepository = new FakeSupportedUserAttributesRepository() ;
        listener = new BrazeEventListener(
                objectMapperHelper,
                validator,
                new BrazeEventProviderHandler(
                        true,
                        API_KEY,
                        ANDROID_APP_ID,
                        WEB_APP_ID,
                        IOS_APP_ID,
                        brazeClient,
                        objectMapperHelper,
                        new EventRetryServiceImpl(
                                new EventRetryRepositoryService(retryStorage),
                                null,
                                Clock.systemUTC(),
                                null,
                                null
                        ), brazeApiKeyStorage, cacheService, supportedUserAttributesRepository
                )
        );
    }

    @Test
    void unsupportedEventsAreNotProcessed() {
        var dto = VerifiedAnalyticsEventFactory.anonymousAndroidEvent();
        dto.setEventProviders(Set.of(EventProvider.MIX));
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        );

        listener.handleEvent(event);

        assertEquals(0, brazeClient.trackRequests.size());
        assertEquals(0, brazeClient.identifyRequests.size());
    }

    @Test
    void invalidEventsAreNotProcessed() {
        validator.violations = Set.of(new FakeConstraintViolation());

        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", "{\"eventProviders\":[\"BRAZE\"]}"
        );

        listener.handleEvent(event);

        assertEquals(0, brazeClient.trackRequests.size());
        assertEquals(0, brazeClient.identifyRequests.size());
    }

    @Test
    void eventsAreSkippedIfBrazeIsDisabled() {
        listener = new BrazeEventListener(
                objectMapperHelper,
                validator,
                new BrazeEventProviderHandler(
                        false,
                        "some-api-key",
                        "android-sdk-id",
                        "web-sdk-id",
                        "ios-sdk-id",
                        brazeClient,
                        objectMapperHelper,
                        new EventRetryServiceImpl(
                                new EventRetryRepositoryService(retryStorage),
                                null,
                                Clock.systemUTC(),
                                null,
                                null
                        ), brazeApiKeyStorage, cacheService, supportedUserAttributesRepository
                )
        );

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                VerifiedAnalyticsEventFactory.anonymousAndroidEvent()
        )
        ));
        assertEquals(0, brazeClient.trackRequests.size());
        assertEquals(0, brazeClient.identifyRequests.size());
    }

    @Test
    void testValidBrazeEventsAreProcessed() {
        var expectedEvent = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(
                "my-user-id",
                "my@email.com",
                "2349092974444",
                "John Doe"
        );
        expectedEvent.setApplicationID("app");
        expectedEvent.setAppDomain("domain");


        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                expectedEvent
        )));

        assertEquals(1, brazeClient.trackRequests.size());
        var r = brazeClient.trackRequests.getFirst();
        assertEquals(1, r.getEvents().size());
        var event = r.getEvents().iterator().next();
        assertEquals(HashUtil.sha256Hex("my-user-id"), event.getExternalID());
        assertNull(event.getBrazeID());
        assertNull(event.getUserAlias());

        assertEquals(ANDROID_APP_ID, event.getAppID());
        assertEquals(expectedEvent.getTimestamp().toInstant().truncatedTo(ChronoUnit.MILLIS).toString(), event.getTime());

        ObjectNode data = (ObjectNode) expectedEvent.getData();
        assertEquals(data.get("eventName").asText(), event.getName());

        assertEquals(1, r.getAttributes().size());
        var userAttributes = r.getAttributes().iterator().next();
        assertEquals(HashUtil.sha256Hex("my-user-id"), userAttributes.getExternalID());
        assertNull(userAttributes.getBrazeID());
        assertNull(userAttributes.getUserAlias());

        assertEquals(1, brazeClient.identifyRequests.size());
        var i = brazeClient.identifyRequests.getFirst();
        assertEquals(1, i.getAliases().size());
        var alias = i.getAliases().iterator().next();
        assertEquals(HashUtil.sha256Hex("my-user-id"), alias.getExternalID());
        assertNotNull(alias.getUserAlias());
        assertEquals(BrazeUserAlias.SESSION_ID_LABEL, alias.getUserAlias().label());
        assertEquals(expectedEvent.getUserIdentifiers().getSessionID(), alias.getUserAlias().value());
    }

    @Test
    void testFailedEventsAreSubmittedForRetry() {
        brazeClient.allowedTokens = List.of();
        var expectedEvent = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(
                "user-id-34",
                null,
                null,
                null
        );
        expectedEvent.setApplicationID("app");
        expectedEvent.setAppDomain("domain");


        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                expectedEvent
        )));

        assertEquals(1, retryStorage.data.size());
        var event = retryStorage.data.values().iterator().next();
        assertEquals(expectedEvent.getId(), event.getEventId());
        assertEquals(EventProvider.BRAZE, event.getEventProvider());
        List<VerifiedAnalyticsEventDTO> verifiedAnalyticsEvents = objectMapperHelper.deserializeStringToObject(
                JsonUtils.normalizeJsonToArray(event.getEventData()),
                new TypeReference<>() {
                }
        );
        var e = verifiedAnalyticsEvents.getFirst();
        expectedEvent.setTimestamp(null);
        e.setTimestamp(null);
        assertEquals(expectedEvent.getId(), e.getId());
        assertNotNull(event.getLastFailureReason());
    }

    @Test
    void validUserAttributesUpdateEventIsProcessed() {
        var expectedEvent = VerifiedAnalyticsEventFactory.userAttributesEventRequest("my-user-id");
        expectedEvent.setApplicationID("app");
        expectedEvent.setAppDomain("domain");


        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                expectedEvent
        )));

        assertEquals(1, brazeClient.trackRequests.size());
        var r = brazeClient.trackRequests.getFirst();
        assertEquals(1, r.getAttributes().size());
        var attributes = r.getAttributes().iterator().next();
        assertEquals(HashUtil.sha256Hex("my-user-id"), attributes.getExternalID());
        assertNull(attributes.getBrazeID());
        assertNull(attributes.getUserAlias());
        assertFalse(attributes.getUpdateExistingOnly());

        assertEquals(1, brazeClient.identifyRequests.size());
        var i = brazeClient.identifyRequests.getFirst();
        assertEquals(1, i.getAliases().size());
        var alias = i.getAliases().iterator().next();
        assertEquals(HashUtil.sha256Hex("my-user-id"), alias.getExternalID());
        assertNotNull(alias.getUserAlias());
        assertEquals(BrazeUserAlias.SESSION_ID_LABEL, alias.getUserAlias().label());
        assertEquals(expectedEvent.getUserIdentifiers().getSessionID(), alias.getUserAlias().value());
        assertFalse(attributes.getUpdateExistingOnly());
    }

    @Test
    void eventsWithoutUserIdNotSentToBraze() {
        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(
                        null,
                        "my@email.com",
                        null,
                        null
                )
        )));

        assertEquals(0, brazeClient.trackRequests.size());

    }

    @Test
    void eventsWithPhoneIdentificationAreProperlyProcessed_NotSentToBraze() {
        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(
                        null,
                        null,
                        "45846546546",
                        null
                )
        )));

        assertEquals(0, brazeClient.trackRequests.size());
    }
}
