package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.TestDtoGenerator;
import com.moniepoint.loans.cas.module.analytics.dto.mapper.AnalyticsEventV3Mapper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.entity.SupportedEvent;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.service.AnalyticsEventProviderRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.impl.*;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.service.KafkaEventPublisher;
import com.moniepoint.loans.cas.module.kafka.listener.CustomerAnalyticsEventListener;
import com.moniepoint.loans.cas.testdoubles.*;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

class CustomerAnalyticsEventListenerTests {
    private static final String VERIFIED_TOPIC = "verified-analytics-event";
    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    private FakeAnalyticsEventProviderRepository providerStorage;
    private FakeKafkaTemplate kafkaTemplate;
    private FakeValidator validator;

    private CustomerAnalyticsEventListener listener;

    @BeforeEach
    void setup() {
        providerStorage = new FakeAnalyticsEventProviderRepository(new HashMap<>() {{
            put(1L, AnalyticsEventProvider.builder().providerKey(EventProvider.BRAZE).build());
            put(2L, AnalyticsEventProvider.builder().providerKey(EventProvider.MIX).build());
        }});
        kafkaTemplate = new FakeKafkaTemplate(List.of(VERIFIED_TOPIC));
        validator = new FakeValidator(Set.of());

        var cacheService = new FakeCacheService(new HashMap<>());

        listener = new CustomerAnalyticsEventListener(
                objectMapperHelper,
                new AnalyticsServiceImpl(
                        mock(RawAnalyticsEventKafkaEventPublisher.class),
                        mock(CustomerAnalyticsKafkaEventPublisher.class),
                        new VerifiedAnalyticsEventKafkaEventPublisher(VERIFIED_TOPIC, kafkaTemplate, objectMapperHelper, new Telemetry(new SimpleMeterRegistry())),
                        new AnalyticsEventProviderRepositoryService(
                                providerStorage,
                                cacheService,
                                objectMapperHelper
                        ),
                        spy(ModelMapper.class),
                        mock(KafkaEventPublisher.class),
                        mock(AnalyticsEventV3Mapper.class),
                        new Telemetry(new SimpleMeterRegistry())
                ),
                validator,
                new ModelMapper(),
                new AnalyticsEventV3Mapper(new ObjectMapper()),
                new SessionServiceImpl(cacheService)

        );
    }

    @Test
    void allVersionEventsAreSupported() {
        var v2Event = TestDtoGenerator.getAnalyticsEventV2RequestDTO();
        v2Event.setEventType("v2_event_type");
        var v3Event = TestDtoGenerator.getAnalyticsEventV3RequestDTO();
        v3Event.getData().setEventName("v3_event_type");
        var v1Event = TestDtoGenerator.getAnalyticsEventV1RequestDTO();
        v1Event.setEventType("v1_event_type");

        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(List.of(v2Event, v3Event))
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(2, messagesSent.size());
        List<VerifiedAnalyticsEventDTO> events = objectMapperHelper.deserializeStringToObject(
                messagesSent.getFirst().getRight(),
                new TypeReference<>() {
                });

        assertEquals(1, events.size());
        events.forEach(e -> assertEquals(2, e.getEventProviders().size())
        );
    }

    @Test
    void invalidEventsAreIgnored() {
        validator.violations = Set.of(new FakeConstraintViolation());

        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(TestDtoGenerator.getAnalyticsEventV2RequestDTO())
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(0, messagesSent.size());
    }

    @Test
    void emptyEventListIsIgnored() {
        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(List.of())
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(0, messagesSent.size());
    }

    @Test
    void nonBrazeEventsAreNotSentToBraze() {
        var braze = AnalyticsEventProvider.builder().providerKey(EventProvider.BRAZE).events(Set.of(
                SupportedEvent.builder().eventType("prequalification").build()
        )).build();
        providerStorage.data = Map.of(
                1L, braze,
                2L, AnalyticsEventProvider.builder().providerKey(EventProvider.MIX).build()
        );

        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(TestDtoGenerator.getAnalyticsEventV3RequestDTO())
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(1, messagesSent.size());

        List<VerifiedAnalyticsEventDTO> events = objectMapperHelper.deserializeStringToObject(
                messagesSent.getFirst().getRight(),
                new TypeReference<>() {
                });
        assertEquals(1, events.size());
        var eventProviders = events.getFirst().getEventProviders();

        assertEquals(1, eventProviders.size(), "Only one provider expected");
        var iter = eventProviders.iterator();
        assertEquals(EventProvider.MIX, iter.next());
        assertFalse(iter.hasNext());
    }

    @Test
    void sessionIDGeneratedForBackendAnonymousV3Events() {
        var v3Event = TestDtoGenerator.getAnalyticsEventV3RequestDTO();
        v3Event.setUserIdentifiers(null);

        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(List.of(v3Event))
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(1, messagesSent.size());

        List<VerifiedAnalyticsEventDTO> events = objectMapperHelper.deserializeStringToObject(
                messagesSent.getFirst().getRight(),
                new TypeReference<>() {
                });
        assertEquals(1, events.size());
        assertNotNull(events.getFirst().getUserIdentifiers().getSessionID());

    }

    @Test
    void userIDMaintainedForKnownUsers() {
        var v3Event = TestDtoGenerator.getAnalyticsEventV3RequestDTO();
        v3Event.setUserIdentifiers(new UserEventIdentifier("my-session-ID", "user-ID", null, null, null));

        listener.handleEvent(new ConsumerRecord<>(
                "customer-analytics-event",
                0,
                1,
                "key",
                objectMapperHelper.serializeToString(List.of(v3Event))
        ));

        var messagesSent = kafkaTemplate.topics.get(VERIFIED_TOPIC);
        assertEquals(1, messagesSent.size());

        List<VerifiedAnalyticsEventDTO> events = objectMapperHelper.deserializeStringToObject(
                messagesSent.getFirst().getRight(),
                new TypeReference<>() {
                });
        assertEquals(1, events.size());
        assertEquals("user-ID", events.getFirst().getUserIdentifiers().getUserID());

    }

}
