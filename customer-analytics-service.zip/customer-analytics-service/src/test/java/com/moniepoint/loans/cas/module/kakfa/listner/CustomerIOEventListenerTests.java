package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.CustomerIOEventListener;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerIOEventListenerTests {

    private CustomerIOEventListener customerIOEventListener;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventProviderHandler eventProviderHandler;

    @Mock
    private Validator validator;

    @BeforeEach
    void setup() {
        customerIOEventListener = new CustomerIOEventListener(
                objectMapperHelper, validator, eventProviderHandler
        );
    }

    @Test
    void handleEvent_success() {
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class)))
                .thenReturn(List.of(VerifiedAnalyticsEventDTO.builder().eventProviders(Set.of(EventProvider.CIO)).build()));
        when(validator.validate(any(VerifiedAnalyticsEventDTO.class))).thenReturn(Set.of());
        when(eventProviderHandler.support(EventProvider.CIO))
                .thenReturn(true);

        customerIOEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(VerifiedAnalyticsEventDTO.class));
        verify(eventProviderHandler, times(1)).processEvent(any(VerifiedAnalyticsEventDTO.class));
    }

    @Test
    void handleEvent_withUnsupportedEventProvider_shouldNotProcessEvent() {
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class)))
                .thenReturn(List.of(VerifiedAnalyticsEventDTO.builder().eventProviders(Set.of(EventProvider.CIO)).build()));
        when(validator.validate(any(VerifiedAnalyticsEventDTO.class))).thenReturn(Set.of());
        when(eventProviderHandler.support(EventProvider.CIO))
                .thenReturn(false);

        customerIOEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(VerifiedAnalyticsEventDTO.class));
        verify(eventProviderHandler, never()).processEvent(any(VerifiedAnalyticsEventDTO.class));
    }

    @Test
    void handleEvent_withInvalidAnalyticsEvent_verifiesNoHandlerExecution() {
        ConstraintViolation<VerifiedAnalyticsEventDTO> violation = mock(ConstraintViolation.class);

        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class)))
                .thenReturn(List.of(VerifiedAnalyticsEventDTO.builder().build()));
        when(validator.validate(any(VerifiedAnalyticsEventDTO.class))).thenReturn(Set.of(violation));

        customerIOEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(VerifiedAnalyticsEventDTO.class));
        verify(eventProviderHandler, never()).support(any(EventProvider.class));
        verify(eventProviderHandler, never()).processEvent(any(VerifiedAnalyticsEventDTO.class));
    }

}
