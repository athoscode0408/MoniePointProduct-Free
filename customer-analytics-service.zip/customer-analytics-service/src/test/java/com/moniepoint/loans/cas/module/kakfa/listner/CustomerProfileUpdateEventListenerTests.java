package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerIOResponse;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerProfileUpdateRequest;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import com.moniepoint.loans.cas.module.kafka.dto.CustomerProfileUpdatesEventDTO;
import com.moniepoint.loans.cas.module.kafka.enums.CustomerProfileUpdatesEventType;
import com.moniepoint.loans.cas.module.kafka.listener.CustomerProfileUpdateEventListener;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerProfileUpdateEventListenerTests {

    @InjectMocks
    private CustomerProfileUpdateEventListener customerProfileUpdateEventListener;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private CustomerIOIntegrationService customerIOIntegrationService;

    @Mock
    private Validator validator;

    @Mock
    private CustomerIOConfig customerIOConfig;

    private static final String TOPIC = "CUSTOMER_PROFILE_UPDATES_TP";
    private ObjectMapper objectMapper;
    private CustomerProfileUpdatesEventDTO customerProfileUpdatesEventDTO;

    @BeforeEach
    void setup() {
        objectMapper = ObjectMapperConfiguration.constructObjectMapper();
        customerProfileUpdatesEventDTO = getCustomerProfileUpdatesEventDTO();
    }

    @Test
    void handleEvent_success() {
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                TOPIC, 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(customerProfileUpdatesEventDTO);
        when(validator.validate(any(CustomerProfileUpdatesEventDTO.class))).thenReturn(Set.of());
        when(customerIOIntegrationService.updateCustomerProfile(eq(customerProfileUpdatesEventDTO.getCustomerIdentifier()), any(CustomerProfileUpdateRequest.class)))
                .thenReturn(CustomerIOResponse.builder().success(true).build());
        when(customerIOConfig.isUpdateCustomerProfile()).thenReturn(true);

        customerProfileUpdateEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(CustomerProfileUpdatesEventDTO.class));
        verify(customerIOIntegrationService, times(1)).updateCustomerProfile(anyString(), any(CustomerProfileUpdateRequest.class));
    }

    @Test
    void handleEvent_withInvalidEvent_verifiesNoExecution() {
        ConstraintViolation<CustomerProfileUpdatesEventDTO> violation = mock(ConstraintViolation.class);

        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                TOPIC, 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(CustomerProfileUpdatesEventDTO.builder().build());
        when(validator.validate(any(CustomerProfileUpdatesEventDTO.class))).thenReturn(Set.of(violation));
        when(customerIOConfig.isUpdateCustomerProfile()).thenReturn(true);

        customerProfileUpdateEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(CustomerProfileUpdatesEventDTO.class));
        verify(customerIOIntegrationService, never()).updateCustomerProfile(anyString(), any(CustomerProfileUpdateRequest.class));
    }

    private CustomerProfileUpdatesEventDTO getCustomerProfileUpdatesEventDTO() {
        Map<String, Object> customerProfileUpdates = new HashMap<>();
        customerProfileUpdates.put("email", "test@test.com");
        customerProfileUpdates.put("firstName", "John");
        customerProfileUpdates.put("lastName", true);

        return CustomerProfileUpdatesEventDTO.builder()
                .customerIdentifier("testuser")
                .eventDate(LocalDateTime.now())
                .eventType(CustomerProfileUpdatesEventType.CUSTOMER_PROFILE_UPDATE)
                .data(objectMapper.convertValue(customerProfileUpdates, JsonNode.class))
                .build();
    }
}
