package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.common.util.TestDtoGenerator;
import com.moniepoint.loans.cas.integrations.customerio.config.CustomerIOConfig;
import com.moniepoint.loans.cas.integrations.customerio.dto.CustomerEventRequest;
import com.moniepoint.loans.cas.integrations.customerio.service.CustomerIOIntegrationService;
import com.moniepoint.loans.cas.integrations.googleanalytics.config.GoogleAnalyticsConfig;
import com.moniepoint.loans.cas.integrations.googleanalytics.dto.GoogleAnalyticsEventRequest;
import com.moniepoint.loans.cas.integrations.googleanalytics.service.GoogleAnalyticsIntegrationService;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelIntegrationService;
import com.moniepoint.loans.cas.integrations.mixpanel.service.impl.MixpanelIntegrationServiceImpl;
import com.moniepoint.loans.cas.module.analytics.dto.BaseAnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.mapper.AnalyticsEventV3Mapper;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.MixpanelApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.service.AnalyticsEventProviderRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.analytics.service.impl.*;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.CustomerAnalyticsEventListener;
import com.moniepoint.loans.cas.module.kafka.listener.CustomerIOEventListener;
import com.moniepoint.loans.cas.module.kafka.listener.GoogleAnalyticsEventListener;
import com.moniepoint.loans.cas.module.kafka.listener.MixpanelEventListener;
import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EndToEndIntegrationListenersTest {

    @InjectMocks
    private ObjectMapperHelper objectMapperHelper;
    @InjectMocks
    private AnalyticsServiceImpl analyticsService;
    @InjectMocks
    private AnalyticsEventV3Mapper analyticsEventV3Mapper;

    @Spy
    private ObjectMapper objectMapper;
    @Spy
    private Validator validator;
    @Spy
    private ModelMapper modelMapper;

    @Mock
    private AnalyticsEventProviderRepositoryService analyticsEventProviderRepositoryService;
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    @Mock
    private MixpanelClient mixpanelClient;
    @Mock
    private CustomerIOIntegrationService customerIOIntegrationService;
    @Mock
    private GoogleAnalyticsIntegrationService googleAnalyticsIntegrationService;
    @Mock
    private EventRetryService eventRetryService;
    @Mock
    private RateLimiterService rateLimiterService;

    @Mock
    private CacheService cacheService;

    @Mock
    private MixpanelApiKeyStorage mixpanelApiKeyStorage;

    @Mock
    private com.moniepoint.loans.cas.common.util.Telemetry telemetry;

    private VerifiedAnalyticsEventKafkaEventPublisher verifiedAnalyticsEventKafkaEventPublisher;
    private CustomerAnalyticsEventListener customerAnalyticsEventListener;
    private MixpanelEventListener mixpanelEventListener;
    private MixpanelIntegrationService mixpanelIntegrationService;
    private GoogleAnalyticsEventListener googleAnalyticsEventListener;
    private CustomerIOEventListener customerIOEventListener;

    private static final MixpanelEventResponse SUCCESS_RESPONSE = MixpanelEventResponse.builder()
            .code(HttpStatus.OK.value())
            .status("OK")
            .numRecordsImported(1)
            .build();

    @BeforeEach
    void setup() {
        customerAnalyticsEventListener = new CustomerAnalyticsEventListener(
                objectMapperHelper,
                analyticsService,
                validator,
                modelMapper,
                analyticsEventV3Mapper,
                new SessionServiceImpl(spy(CacheService.class))
        );

        verifiedAnalyticsEventKafkaEventPublisher = spy(new VerifiedAnalyticsEventKafkaEventPublisher(
                "verified-analytics-event",
                kafkaTemplate,
                objectMapperHelper,
                telemetry
        ));

        ReflectionTestUtils.setField(analyticsService, "verifiedAnalyticsEventKafkaEventPublisher", verifiedAnalyticsEventKafkaEventPublisher);

        lenient().when(mixpanelClient.sendImportEventRequest(anyList(), anyString())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(SUCCESS_RESPONSE));

        mixpanelIntegrationService = spy(new MixpanelIntegrationServiceImpl("", "", mixpanelClient, null, objectMapperHelper, eventRetryService, rateLimiterService, cacheService, mixpanelApiKeyStorage));

        MixpanelEventProviderHandler mixpanelEventProviderHandler = new MixpanelEventProviderHandler(true, "", (MixpanelIntegrationServiceImpl) mixpanelIntegrationService, objectMapperHelper, objectMapper);
        mixpanelEventListener = new MixpanelEventListener(objectMapperHelper, validator, mixpanelEventProviderHandler);

        // initialize CustomerIO event handler
        CustomerIOConfig customerIOConfig = new CustomerIOConfig();
        ReflectionTestUtils.setField(customerIOConfig, "enable", true);
        CustomerIOEventProviderHandler customerIOEventProviderHandler = new CustomerIOEventProviderHandler(customerIOIntegrationService, customerIOConfig, objectMapperHelper);
        customerIOEventListener = new CustomerIOEventListener(objectMapperHelper, validator, customerIOEventProviderHandler);

        // initialize GoogleAnalytics event handler
        GoogleAnalyticsConfig googleAnalyticsConfig = new GoogleAnalyticsConfig();
        ReflectionTestUtils.setField(googleAnalyticsConfig, "enable", true);
        GoogleAnalyticsEventProviderHandler googleAnalyticsEventProviderHandler = new GoogleAnalyticsEventProviderHandler(googleAnalyticsIntegrationService, googleAnalyticsConfig, objectMapperHelper);
        googleAnalyticsEventListener = new GoogleAnalyticsEventListener(objectMapperHelper, validator, googleAnalyticsEventProviderHandler);
    }

    @Test
    void v3EventsProcessingWithAllHandlers_success() {
        lenient().when(analyticsEventProviderRepositoryService.getAllAnalyticsEventProviders()).thenReturn(TestDtoGenerator.getAllAnalyticsProviders());
        Map<String, Collection<EventProvider>> supported = new HashMap<>();
        supported.put("payment_success", EnumSet.of(EventProvider.CIO, EventProvider.MIX, EventProvider.GA));
        lenient().when(analyticsEventProviderRepositoryService.getSupportedEventProviders(any())).thenReturn(supported);
        executeEndToEndTest();
    }


    private void executeEndToEndTest() {
        List<BaseAnalyticsEventRequestDTO<?>> events = List.of(
                TestDtoGenerator.getAnalyticsEventV3RequestDTO(),
                TestDtoGenerator.getAnalyticsEventV3RequestDTO(),
                TestDtoGenerator.getAnalyticsEventV3RequestDTO());

        lenient().doAnswer(invocation -> {
            String key = invocation.getArgument(0, String.class);
            List<VerifiedAnalyticsEventDTO> verifiedEvents = invocation.getArgument(1, List.class);

            ConsumerRecord<String, String> verifiedEventsQueueEvent =
                    new ConsumerRecord<>("customer-analytics-event", 0, 1, key, objectMapperHelper.serializeToString(verifiedEvents));

            //call final events processing
            mixpanelEventListener.handleEvent(verifiedEventsQueueEvent);
            customerIOEventListener.handleEvent(verifiedEventsQueueEvent);
            googleAnalyticsEventListener.handleEvent(verifiedEventsQueueEvent);

            verify(mixpanelIntegrationService, times(1)).sendEventsToMixpanel(anyList(), anyString());
            verify(customerIOIntegrationService, times(3)).sendCustomerEventToCustomerIO(anyString(), any(CustomerEventRequest.class));
            verify(googleAnalyticsIntegrationService, times(3)).sendEventToGoogleAnalytics(any(GoogleAnalyticsEventRequest.class));

            return null;
        }).when(verifiedAnalyticsEventKafkaEventPublisher).publishEvents(anyString(), any());

        ConsumerRecord<String, String> customerAnalyticsQueueEvent =
                new ConsumerRecord<>("customer-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(events));

        customerAnalyticsEventListener.handleEvent(customerAnalyticsQueueEvent);
    }

}
