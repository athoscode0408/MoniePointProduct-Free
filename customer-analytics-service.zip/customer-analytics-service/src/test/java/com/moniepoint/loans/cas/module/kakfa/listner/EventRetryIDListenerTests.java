package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.braze.BrazeClient;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeIdentifyRequest;
import com.moniepoint.loans.cas.integrations.braze.dto.BrazeTrackRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventProperties;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventResponse;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelQueryAPIClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.impl.MixpanelIntegrationServiceImpl;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryDTO;
import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.BrazeApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryRepository;
import com.moniepoint.loans.cas.module.analytics.repository.MixpanelApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.SupportedUserAttributesRepository;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.EventProviderHandler;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.analytics.service.impl.BrazeEventProviderHandler;
import com.moniepoint.loans.cas.module.analytics.service.impl.MixpanelEventProviderHandler;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.listener.EventRetryIDListener;
import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryIDListenerTests {

    private static final String EVENT_ID = "test-id";
    private static final String FAILURE_REASON = "fail";

    private static final EventProvider MIXPANEL_PROVIDER = EventProvider.MIX;
    private static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(2024, 10, 23, 9, 11);

    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    @Mock
    private EventRetryRepository retryRepository;
    @Mock
    private EventRetryService retryService;
    @Mock
    private BrazeClient brazeClient;
    @Mock
    private MixpanelClient mixpanelClient;
    @Mock
    private BrazeApiKeyStorage brazeApiKeyStorage;
    @Mock
    CacheService cacheService;
    @Mock
    SupportedUserAttributesRepository supportedUserAttributesRepository;

    @Mock
    private MixpanelApiKeyStorage mixpanelApiKeyStorage;

    @Mock
    private RateLimiterService rateLimiterService;

    @Spy
    private Validator validator;

    private EventRetryIDListener eventRetryIDListener;

    private static final EventRetry EVENT_RETRY = EventRetry.builder()
            .eventId(EVENT_ID)
            .eventProvider(MIXPANEL_PROVIDER)
            .eventData(objectMapperHelper.serializeToString(VerifiedAnalyticsEventFactory.anonymousAndroidEvent()))
            .attemptCount(2)
            .lastRetryTime(LOCAL_DATE_TIME)
            .nextRetryTime(LOCAL_DATE_TIME)
            .lastFailureReason(FAILURE_REASON)
            .build();

    private static final EventRetryDTO EVENT_RETRY_DTO = EventRetryDTO.builder().id(10L).build();

    @BeforeEach
    void setup() {
        eventRetryIDListener = new EventRetryIDListener(
                objectMapperHelper,
                new EventRetryRepositoryService(retryRepository),
                List.of(
                        new BrazeEventProviderHandler(true, "api-key", "android-id", "", "", brazeClient, objectMapperHelper, retryService, brazeApiKeyStorage, cacheService, supportedUserAttributesRepository),
                        new MixpanelEventProviderHandler(
                                true,
                                "project-token",
                                new MixpanelIntegrationServiceImpl(
                                        "",
                                        "",
                                        mixpanelClient,
                                        mock(MixpanelQueryAPIClient.class),
                                        objectMapperHelper,
                                        retryService, rateLimiterService, cacheService, mixpanelApiKeyStorage
                                ),
                                objectMapperHelper,
                                new ObjectMapper()
                        )
                ),
                validator
        );
    }

    @Test
    void handleBrazeEventRetry() {
        var expectedEvent = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");

        when(retryRepository.findById(EVENT_RETRY_DTO.getId())).thenReturn(Optional.of(EventRetry.builder()
                .eventId(EVENT_ID)
                .eventProvider(EventProvider.BRAZE)
                .eventData(objectMapperHelper.serializeToString(expectedEvent))
                .attemptCount(2)
                .lastRetryTime(LOCAL_DATE_TIME)
                .nextRetryTime(LOCAL_DATE_TIME)
                .lastFailureReason(FAILURE_REASON)
                .build()));
        when(brazeClient.trackEvent(any(BrazeTrackRequest.class), anyString())).thenReturn(ResponseEntity.status(HttpStatus.CREATED).build());

        eventRetryIDListener.handleEvent(new ConsumerRecord<>(
                "event-retry-id", 0, 1, "key", objectMapperHelper.serializeToString(EVENT_RETRY_DTO)
        ));

        verify(brazeClient, times(1)).trackEvent(argThat(r -> {
            assertEquals(1, r.getEvents().size());
            var event = r.getEvents().stream().findFirst().get();
            assertNull(event.getBrazeID());
            assertNotNull(event.getExternalID());
            assertNull(event.getUserAlias());

            assertEquals("android-id", event.getAppID());
            assertEquals(expectedEvent.getTimestamp().toInstant().truncatedTo(ChronoUnit.MILLIS).toString(), event.getTime());

            ObjectNode data = (ObjectNode) expectedEvent.getData();
            assertEquals(data.get("eventName").asText(), event.getName());

            assertEquals(1, r.getAttributes().size());
            var userAttributes = r.getAttributes().stream().findFirst().get();
            assertNull(userAttributes.getBrazeID());
            assertNotNull(userAttributes.getExternalID());
            assertNull(userAttributes.getUserAlias());

            assertNull(userAttributes.getEmail());
            assertNull(userAttributes.getPhone());
            assertNull(userAttributes.getFirstName());
            return true;
        }), anyString());
        verify(brazeClient, times(1)).identify(any(BrazeIdentifyRequest.class), eq(String.format("Bearer %s", "api-key")));
        verify(retryRepository, times(1)).deleteById(EVENT_RETRY_DTO.getId());
    }

    @Test
    void handleMixpanelEventRetry() {
        var expectedEvent = MixpanelEventRequest.builder().event("prequalification").properties(new MixpanelEventProperties()).build();
        when(retryRepository.findById(EVENT_RETRY_DTO.getId())).thenReturn(Optional.of(EventRetry.builder()
                .eventId(EVENT_ID)
                .eventProvider(EventProvider.MIX)
                .eventData(objectMapperHelper.serializeToString(expectedEvent))
                .attemptCount(2)
                .lastRetryTime(LOCAL_DATE_TIME)
                .nextRetryTime(LOCAL_DATE_TIME)
                .lastFailureReason(FAILURE_REASON)
                .build()));
        when(mixpanelClient.sendImportEventRequest(anyList(), any())).thenReturn(ResponseEntity
                .ok()
                .body(MixpanelEventResponse.builder().build()));

        eventRetryIDListener.handleEvent(new ConsumerRecord<>(
                "event-retry-id", 0, 1, "key", objectMapperHelper.serializeToString(EVENT_RETRY_DTO)
        ));

        verify(mixpanelClient, times(1)).sendImportEventRequest(argThat(r -> {
            assertEquals(1, r.size());
            var event = r.getFirst();
            assertEquals("prequalification", event.getEvent());
            return true;
        }), any());
        verify(retryRepository, times(1)).deleteById(EVENT_RETRY_DTO.getId());
    }

    @Test
    void invalidEventsAreNotProcessed() {
        when(validator.validate(any(EventRetryDTO.class))).thenReturn(Set.of(mock(ConstraintViolation.class)));
        var dummyHandler = spy(EventProviderHandler.class);

        new EventRetryIDListener(
                objectMapperHelper,
                new EventRetryRepositoryService(retryRepository),
                List.of(dummyHandler),
                validator
        ).handleEvent(new ConsumerRecord<>("event-retry-id", 0, 1, "key", "{}"
        ));

        verify(dummyHandler, never()).processEvent(anyString());
    }

    @Test
    void eventsNotFoundAreNotProcessed() {
        var dummyHandler = spy(EventProviderHandler.class);

        new EventRetryIDListener(
                objectMapperHelper,
                new EventRetryRepositoryService(retryRepository),
                List.of(dummyHandler),
                validator
        ).handleEvent(new ConsumerRecord<>(
                "event-retry-id", 0, 1, "key", objectMapperHelper.serializeToString(EVENT_RETRY_DTO)
        ));

        verify(dummyHandler, never()).processEvent(anyString());
    }

    @Test
    void eventsWithUnknownProviderAreNotProcessed() {
        when(retryRepository.findById(EVENT_RETRY_DTO.getId())).thenReturn(Optional.of(EVENT_RETRY));
        var dummyHandler = spy(EventProviderHandler.class);

        new EventRetryIDListener(
                objectMapperHelper,
                new EventRetryRepositoryService(retryRepository),
                List.of(dummyHandler),
                validator
        ).handleEvent(new ConsumerRecord<>(
                "event-retry-id", 0, 1, "key", objectMapperHelper.serializeToString(EVENT_RETRY_DTO)
        ));

        verify(dummyHandler, never()).processEvent(anyString());
    }

    @Test
    void retryEventIsNotDeletedIfProcessingFails() {
        when(retryRepository.findById(EVENT_RETRY_DTO.getId())).thenReturn(Optional.of(EVENT_RETRY));
        var dummyHandler = spy(EventProviderHandler.class);
        when(dummyHandler.support(EVENT_RETRY.getEventProvider())).thenReturn(true);
        when(dummyHandler.processEvent(anyString())).thenReturn(false);

        var eventString = objectMapperHelper.serializeToString(EVENT_RETRY_DTO);
        new EventRetryIDListener(
                objectMapperHelper,
                new EventRetryRepositoryService(retryRepository),
                List.of(dummyHandler),
                validator
        ).handleEvent(new ConsumerRecord<>(
                "event-retry-id", 0, 1, "key", eventString
        ));

        verify(dummyHandler, times(1)).processEvent(anyString());
        verify(retryRepository, never()).deleteById(anyLong());
    }
}
