package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.EventRetryIDRangeDTO;
import com.moniepoint.loans.cas.module.analytics.service.EventRetryService;
import com.moniepoint.loans.cas.module.kafka.listener.EventRetryIDRangeListener;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventRetryIDRangeListenerTests {

    @InjectMocks
    private EventRetryIDRangeListener eventRetryIDRangeListener;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private EventRetryService eventRetryService;

    @Mock
    private Validator validator;

    @Test
    void handleEvent_success() {
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "event-retry-id-range", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(EventRetryIDRangeDTO.builder().start(2L).end(10L).build());
        when(validator.validate(any(EventRetryIDRangeDTO.class))).thenReturn(Set.of());

        eventRetryIDRangeListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(EventRetryIDRangeDTO.class));
        verify(eventRetryService, times(1)).handleEventRetryIDRange(any(EventRetryIDRangeDTO.class));
    }

    @Test
    void handleEvent_withInvalidEventRetryIdRange_verifiesNoHandlerExecution() {
        ConstraintViolation<EventRetryIDRangeDTO> violation = mock(ConstraintViolation.class);

        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "event-retry-id-range", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(EventRetryIDRangeDTO.builder().build());
        when(validator.validate(any(EventRetryIDRangeDTO.class))).thenReturn(Set.of(violation));

        eventRetryIDRangeListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(EventRetryIDRangeDTO.class));
        verify(eventRetryService, never()).handleEventRetryIDRange(any(EventRetryIDRangeDTO.class));
    }

}
