package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventProperties;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelEventRequest;
import com.moniepoint.loans.cas.integrations.mixpanel.dto.MixpanelQueryUser;
import com.moniepoint.loans.cas.integrations.mixpanel.service.impl.MixpanelIntegrationServiceImpl;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.MixpanelApiKeyStorage;
import com.moniepoint.loans.cas.module.analytics.repository.service.EventRetryRepositoryService;
import com.moniepoint.loans.cas.module.analytics.service.impl.EventRetryServiceImpl;
import com.moniepoint.loans.cas.module.analytics.service.impl.MixpanelEventProviderHandler;
import com.moniepoint.loans.cas.module.cache.service.CacheService;
import com.moniepoint.loans.cas.module.kafka.listener.MixpanelEventListener;
import com.moniepoint.loans.cas.module.ratelimiter.service.RateLimiterService;
import com.moniepoint.loans.cas.testdoubles.FakeConstraintViolation;
import com.moniepoint.loans.cas.testdoubles.FakeEventRetryRepository;
import com.moniepoint.loans.cas.testdoubles.FakeMixpanelClient;
import com.moniepoint.loans.cas.testdoubles.FakeValidator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Clock;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MixpanelEventListenerTests {
    private static final String VALID_PROJECT_TOKEN = "some-random-project-token-789";
    private static final String API_SECRET = "some-random-api-secret-74111";
    private static final String PROJECT_ID = "7878456421";
    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    private FakeValidator validator;
    private FakeEventRetryRepository eventRetryRepository;
    private FakeMixpanelClient mixpanelClient;

    private MixpanelEventListener listener;
    @Mock
    CacheService cacheService;

    @Mock
    private MixpanelApiKeyStorage mixpanelApiKeyStorage;

    @Mock
    private RateLimiterService rateLimiterService;



    @BeforeEach
    void setup() {
        validator = new FakeValidator(Set.of());
        eventRetryRepository = new FakeEventRetryRepository(new HashMap<>());
        mixpanelClient = new FakeMixpanelClient(Set.of(VALID_PROJECT_TOKEN, API_SECRET));
        MixpanelIntegrationServiceImpl mixpanelIntegrationService =   new MixpanelIntegrationServiceImpl(
                PROJECT_ID,
                API_SECRET,
                mixpanelClient,
                mixpanelClient,
                objectMapperHelper,
                new EventRetryServiceImpl(
                        new EventRetryRepositoryService(eventRetryRepository),
                        null,
                        Clock.systemUTC(),
                        null,
                        null
                ), rateLimiterService, cacheService, mixpanelApiKeyStorage
        );
        listener = new MixpanelEventListener(
                objectMapperHelper,
                validator,
                new MixpanelEventProviderHandler(
                        true,
                        "project-token",
                        mixpanelIntegrationService
                      ,
                        objectMapperHelper,
                        new ObjectMapper()
                )
        );
                ReflectionTestUtils.setField(mixpanelIntegrationService, "rateLimitPerHour", 10000L);

    }

    @Test
    void unsupportedEventsAreNotProcessed() {
        var dto = VerifiedAnalyticsEventFactory.anonymousAndroidEvent();
        dto.setEventProviders(Set.of(EventProvider.BRAZE));
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        );

        listener.handleEvent(event);

        assertEquals(0, mixpanelClient.eventRequests.size());
        assertEquals(0, mixpanelClient.profileRequests.size());
    }

    @Test
    void eventsAreSkippedIfProviderIsDisabled() {
        listener = new MixpanelEventListener(
                objectMapperHelper,
                validator,
                new MixpanelEventProviderHandler(
                        false,
                        "project-token",
                        new MixpanelIntegrationServiceImpl(
                                "",
                                "",
                                mixpanelClient,
                                mixpanelClient,
                                objectMapperHelper,
                                new EventRetryServiceImpl(
                                        new EventRetryRepositoryService(eventRetryRepository),
                                        null,
                                        Clock.systemUTC(),
                                        null,
                                        null
                                ), rateLimiterService, cacheService, mixpanelApiKeyStorage
                        ),
                        objectMapperHelper,
                        new ObjectMapper()
                )
        );

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                VerifiedAnalyticsEventFactory.anonymousAndroidEvent()
        )
        ));
        assertEquals(0, mixpanelClient.eventRequests.size());
        assertEquals(0, mixpanelClient.profileRequests.size());
    }

    @Test
    void invalidEventsAreNotProcessed() {
        validator.violations = Set.of(new FakeConstraintViolation());
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", "{\"eventProviders\":[\"MIX\"]}"
        );
        listener.handleEvent(event);

        assertEquals(0, mixpanelClient.eventRequests.size());
        assertEquals(0, mixpanelClient.profileRequests.size());
    }

    @Test
    void testProcessAnonymousEvent() {
        var dto = VerifiedAnalyticsEventFactory.anonymousAndroidEvent();
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        );

        listener.handleEvent(event);

        assertEquals(1, mixpanelClient.eventRequests.size());
        var request = mixpanelClient.eventRequests.getFirst();
        assertEquals(dto.getId(), request.getProperties().getInsertID());
        assertEquals(dto.getData().get("device").get("id").asText(), request.getProperties().getDeviceID());
        assertMixpanelAnonymousRequest(request);
        assertNull(request.getProperties().getUserID());
    }

    @Test
    void testUserEvent() {
        var dto = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent("my-user-id", "my@email.com", "21649898", "My User");
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        );

        listener.handleEvent(event);

        assertEquals(1, mixpanelClient.eventRequests.size());
        var request = mixpanelClient.eventRequests.getFirst();
        assertEquals(dto.getId(), request.getProperties().getInsertID());
        assertMixpanelAnonymousRequest(request);
        assertEquals("my-user-id", request.getProperties().getUserID());
    }

    private static void assertMixpanelAnonymousRequest(MixpanelEventRequest request) {
        assertEquals("payment_success", request.getEvent());
        assertNotNull(request.getProperties());
        assertEquals("android", request.getProperties().getOs());
        assertEquals("13", request.getProperties().getOsVersion());
        assertNull(request.getProperties().getBrowser());
        assertNull(request.getProperties().getBrowserVersion());
        assertEquals("127.0.0.1", request.getProperties().getIp());
        assertNull(request.getProperties().getCurrentURL());
        assertNull(request.getProperties().getInitialReferrer());
        assertNull(request.getProperties().getInitialReferringDomain());
        assertEquals("98", request.getProperties().getAppBuildNumber());
        assertEquals("1.3.0", request.getProperties().getAppVersionString());
        assertEquals(100, request.getProperties().getScreenDPI());
        assertEquals(1200, request.getProperties().getScreenWidth());
        assertEquals(980, request.getProperties().getScreenHeight());
        assertEquals("1.3.0", request.getProperties().getAndroidAppVersion());
        assertNull(request.getProperties().getIOSAppVersion());
        assertNull(request.getProperties().getIOSAppRelease());
    }

    @Test
    void testFailedEventsAreSubmittedForRetry() {
        mixpanelClient.allowedTokens = Set.of();
        var expectedEvent = VerifiedAnalyticsEventFactory.anonymousAndroidEvent();

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(
                expectedEvent
        )));

        assertEquals(1, eventRetryRepository.data.size());
        var r = eventRetryRepository.data.values().iterator().next();
        assertEquals(expectedEvent.getId(), r.getEventId());
        assertEquals(EventProvider.MIX, r.getEventProvider());
        MixpanelEventRequest event = objectMapperHelper.deserializeStringToObject(
                r.getEventData(),
                new TypeReference<>() {
                }
        );
        assertEquals(expectedEvent.getId(), event.getProperties().getInsertID());
        assertNotNull(r.getLastFailureReason());
    }

    @Test
    void testUpdateUserPropertiesEvent() {
        var dto = VerifiedAnalyticsEventFactory.userAttributesEventRequest("mixpanel user");
        dto.getUserAttributes().setCustomAttributes(Map.of("$initial_referrer", "initial referrer"));
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        );

        listener.handleEvent(event);

        assertEquals(1, mixpanelClient.eventRequests.size());
        assertEquals(1, mixpanelClient.profileRequests.size());
        var request = mixpanelClient.profileRequests.getFirst();
        assertEquals("mixpanel user", request.getUserID());
        assertEquals("test@email.com", request.getProperties().getEmail());
    }

    @Test
    void canSendUserEventsByEmail() {

        when(rateLimiterService.tryAcquire(anyString(), anyLong(), anyLong())).thenReturn(true);

        mixpanelClient.users = Map.of(PROJECT_ID, List.of(
                new MixpanelQueryUser("my-user-id", MixpanelEventProperties.builder().userID(null).email("my@email.com").build())
        ));
        var dto = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(null, "my@email.com", null, null);

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        ));

        assertEquals(1, mixpanelClient.eventRequests.size());
        var request = mixpanelClient.eventRequests.getFirst();
        assertEquals(dto.getId(), request.getProperties().getInsertID());
        assertMixpanelAnonymousRequest(request);
        assertEquals("my-user-id", request.getProperties().getUserID());
    }

    @Test
    void canSendUserEventsByPhone() {
        when(rateLimiterService.tryAcquire(anyString(), anyLong(), anyLong())).thenReturn(true);
        mixpanelClient.users = Map.of(PROJECT_ID, List.of(
                new MixpanelQueryUser("my-user-id-2", MixpanelEventProperties.builder().userID(null).phone("+48782121").build())
        ));
        var dto = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent(null, null, "+48782121", null);

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(dto)
        ));

        assertEquals(1, mixpanelClient.eventRequests.size());
        var request = mixpanelClient.eventRequests.getFirst();
        assertEquals(dto.getId(), request.getProperties().getInsertID());
        assertMixpanelAnonymousRequest(request);
        assertEquals("my-user-id-2", request.getProperties().getUserID());
    }
}
