package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventRequestDTO;
import com.moniepoint.loans.cas.module.analytics.dto.AnalyticsEventV1RequestDTO;
import com.moniepoint.loans.cas.module.analytics.service.AnalyticsService;
import com.moniepoint.loans.cas.module.kafka.listener.RawAnalyticsEventListener;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RawAnalyticsEventListenerTests {

    @InjectMocks
    private RawAnalyticsEventListener rawAnalyticsEventListener;

    @Mock
    private ObjectMapperHelper objectMapperHelper;

    @Mock
    private AnalyticsService analyticsService;

    @Mock
    private Validator validator;

    @Mock
    private ModelMapper modelMapper;

    @Test
    void handleEvent_success() {
        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "raw-analytics-event", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(AnalyticsEventV1RequestDTO.builder().build());
        when(validator.validate(any(AnalyticsEventV1RequestDTO.class))).thenReturn(Set.of());
        when(modelMapper.map(any(), any())).thenReturn(AnalyticsEventRequestDTO.builder().build());

        rawAnalyticsEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(AnalyticsEventV1RequestDTO.class));
        verify(analyticsService, times(1)).handleRawAnalyticsEvent(any(AnalyticsEventRequestDTO.class));
    }

    @Test
    void handleEvent_withInvalidAnalyticsEvent_verifiesNoHandlerExecution() {
        ConstraintViolation<AnalyticsEventV1RequestDTO> violation = mock(ConstraintViolation.class);

        ConsumerRecord<String, String> event = new ConsumerRecord<>(
                "raw-analytics-event", 0, 1, "key", "content"
        );
        when(objectMapperHelper.deserializeStringToObject(anyString(), any(TypeReference.class))).thenReturn(AnalyticsEventV1RequestDTO.builder().build());
        when(validator.validate(any(AnalyticsEventV1RequestDTO.class))).thenReturn(Set.of(violation));

        rawAnalyticsEventListener.handleEvent(event);

        verify(objectMapperHelper, times(1)).deserializeStringToObject(anyString(), any(TypeReference.class));
        verify(validator, times(1)).validate(any(AnalyticsEventV1RequestDTO.class));
        verify(analyticsService, never()).handleRawAnalyticsEvent(any(AnalyticsEventRequestDTO.class));
    }

}
