package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.integrations.singular.service.SingularIntegrationService;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.service.impl.SingularEventProviderHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.SingularEventListener;
import com.moniepoint.loans.cas.testdoubles.FakeConstraintViolation;
import com.moniepoint.loans.cas.testdoubles.FakeValidator;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SingularEventListenerTests {

    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Mock
    private SingularIntegrationService singularIntegrationService;

    private FakeValidator validator;
    private SingularEventListener listener;
    private SingularEventProviderHandler singularEventProviderHandler;

    @BeforeEach
    void setup() {
        validator = new FakeValidator(Set.of());
        singularEventProviderHandler = new SingularEventProviderHandler(
                true,
                "test-api-key",
                singularIntegrationService,
                objectMapperHelper
        );
        listener = new SingularEventListener(objectMapperHelper, validator, singularEventProviderHandler);
    }

    @Test
    void unsupportedEventsAreNotProcessed() {
        VerifiedAnalyticsEventDTO dto = singularAndroidEvent();
        dto.setEventProviders(Set.of(EventProvider.BRAZE));

        listener.handleEvent(toConsumerRecord(dto));

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void invalidEventsAreNotProcessed() {
        validator.violations = Set.of(new FakeConstraintViolation());

        listener.handleEvent(new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key",
                "{\"eventProviders\":[\"SIN\"]}"
        ));

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void eventsAreSkippedIfProviderIsDisabled() {
        listener = new SingularEventListener(
                objectMapperHelper,
                validator,
                new SingularEventProviderHandler(
                        false,
                        "api-key",
                        singularIntegrationService,
                        objectMapperHelper
                )
        );

        listener.handleEvent(toConsumerRecord(singularAndroidEvent()));

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void validSingularEventsWithAndroidDeviceAreProcessed() {
        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        listener.handleEvent(toConsumerRecord(singularAndroidEvent()));

        verify(singularIntegrationService, times(1)).sendEvent(any());
    }

    @Test
    void validSingularEventsWithIosDeviceAreProcessed() {
        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        listener.handleEvent(toConsumerRecord(singularIosEvent()));

        verify(singularIntegrationService, times(1)).sendEvent(any());
    }

    @Test
    void eventsWithMissingDeviceIdentifiersAreNotSentToSingular() {
        // Event with no device_type, no device_id → identifiers all null → not sent
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "test_event");

        VerifiedAnalyticsEventDTO dto = VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("test_event")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .eventProviders(Set.of(EventProvider.SIN))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(data)
                .build();

        listener.handleEvent(toConsumerRecord(dto));

        verify(singularIntegrationService, never()).sendEvent(any());
    }

    @Test
    void eventsContainingMultipleProvidersSendOnlyToSingular() {
        when(singularIntegrationService.sendEvent(any())).thenReturn(true);

        VerifiedAnalyticsEventDTO dto = singularAndroidEvent();
        dto.setEventProviders(Set.of(EventProvider.SIN, EventProvider.MIX));

        listener.handleEvent(toConsumerRecord(dto));

        // Singular handler supports SIN, so it is processed once per event
        verify(singularIntegrationService, times(1)).sendEvent(any());
    }

    // ── helpers ────────────────────────────────────────────────────────────────

    private VerifiedAnalyticsEventDTO singularAndroidEvent() {
        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "payment_success");
        data.put("device_type", "android");
        data.put("device_id", "android-device-" + UUID.randomUUID());

        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("payment_success")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .platform("android")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.SIN))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(data)
                .build();
    }

    private VerifiedAnalyticsEventDTO singularIosEvent() {
        ObjectNode deviceMetadata = objectMapper.createObjectNode();
        deviceMetadata.put("identifierForVendor", "ios-idfv-" + UUID.randomUUID());

        ObjectNode data = objectMapper.createObjectNode();
        data.put("eventName", "payment_success");
        data.put("device_type", "ios");
        data.put("device_id", "ios-device-fallback");
        data.set("device_metadata", deviceMetadata);

        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("payment_success")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .platform("ios")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.SIN))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(data)
                .build();
    }

    private ConsumerRecord<String, String> toConsumerRecord(VerifiedAnalyticsEventDTO dto) {
        return new ConsumerRecord<>(
                "verified-analytics-event", 0, 1, "key",
                objectMapperHelper.serializeToString(dto)
        );
    }
}
