package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import com.moniepoint.loans.cas.module.analytics.service.SurveyRulesCache;
import com.moniepoint.loans.cas.module.analytics.service.impl.RuleParserHandler;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.SurveyEvaluatorListener;
import com.moniepoint.loans.cas.testdoubles.*;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SurveyEvaluatorListenerTests {
    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
    private VerifiedAnalyticsEventDTO surveyTriggeringEvent;

    @Captor
    ArgumentCaptor<Survey> surveyArgumentCaptor;

    @Captor
    ArgumentCaptor<VerifiedAnalyticsEventDTO> verifiedAnalyticsEventDTOArgumentCaptor;

    @Captor
    ArgumentCaptor<UserAttributes> userAttributesArgumentCaptor;

    private FakeSurveyStorage surveyStorage;
    private SurveyRulesCache surveyRulesCache;

    private SurveyEvaluatorListener listener;

    @Mock
    private RuleParserHandler ruleParserHandler;

    @BeforeEach
    void setup() {
        var rule = new Survey("event.eventType == 'trigger_survey_event'", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        rule.setId(3L);

        surveyStorage = new FakeSurveyStorage(new HashMap<>() {{
            put(3L, rule);
        }});

        surveyRulesCache = new SurveyRulesCache(surveyStorage);

        surveyTriggeringEvent = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        surveyTriggeringEvent.setEventType("trigger_survey_event");

        listener = new SurveyEvaluatorListener(
                surveyRulesCache,
                new FakeUserAttributesStorage(Map.of("known-test-user", UserAttributes.builder()
                        .email("test@email.com")
                        .phone("2169633555")
                        .name("Test user")
                        .build())),
                objectMapperHelper,
                ruleParserHandler
        );
    }

    @Test
    void eventsAreIgnoredIfNoRulesAreConfigured() {
        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(surveyTriggeringEvent));
        surveyStorage.deleteAll();

        listener.handleEvent(message);
        verify(ruleParserHandler, never()).parseRule(any(), any(), any());
    }

    @Test
    void eventIsParsedThroughAllAvailableRules() {
        var rule2 = new Survey("event.eventType == 'trigger_survey_event'", 7, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        rule2.setId(2L);
        surveyStorage.save(rule2);

        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(surveyTriggeringEvent));

        listener.handleEvent(message);
        verify(ruleParserHandler, times(surveyStorage.data.size())).parseRule(any(), any(), any());
    }

    @Test
    void eventUserAttributesOverrideStoredAttributes() {
        var event = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        event.setUserAttributes(UserAttributes.builder().email("other-test@gmail.com").build());
        event.setEventType("trigger_survey_user_event");

        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(event));

        listener.handleEvent(message);

        verify(ruleParserHandler).parseRule(surveyArgumentCaptor.capture(), verifiedAnalyticsEventDTOArgumentCaptor.capture(), userAttributesArgumentCaptor.capture());
        UserAttributes userAttributes = userAttributesArgumentCaptor.getValue();
//        assertEquals("2169633555", userAttributes.getPhone());
//        assertEquals("Test user", userAttributes.getName());
        assertEquals("other-test@gmail.com", userAttributes.getEmail());
    }
}
