package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.service.impl.SurveyEvaluatorKafkaEventPublisher;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.SurveyEventListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SurveyEventListenerTests {
    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    private VerifiedAnalyticsEventDTO surveyTriggeringEvent;

    private SurveyEventListener listener;

    @Mock
    SurveyEvaluatorKafkaEventPublisher surveyEvaluatorKafkaEventPublisher;

    @BeforeEach
    void setup() {
        surveyTriggeringEvent = VerifiedAnalyticsEventFactory.androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        listener = new SurveyEventListener(objectMapperHelper, surveyEvaluatorKafkaEventPublisher);
    }


    @Test
    void anonymousEventsDoNotTriggerSurveyPreprocessing() {
        var event = VerifiedAnalyticsEventFactory.anonymousAndroidEvent();
        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(event));

        listener.handleEvent(message);
        verify(surveyEvaluatorKafkaEventPublisher, never()).publishEvents(any(), any());
    }

    @Test
    void unanonymousEventsTriggerSurveyPreprocessing() {
        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(surveyTriggeringEvent));
        listener.handleEvent(message);
        verify(surveyEvaluatorKafkaEventPublisher, times(1)).publishEvents(any(), any());
    }

}
