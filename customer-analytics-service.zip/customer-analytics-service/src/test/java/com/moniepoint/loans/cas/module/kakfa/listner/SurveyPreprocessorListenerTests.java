package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.configuration.ObjectMapperConfiguration;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.EventPreprocessSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.PreprocessedSurveyDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.enums.SurveyCategory;
import com.moniepoint.loans.cas.module.analytics.service.impl.BannerService;
import com.moniepoint.loans.cas.module.analytics.service.impl.SurveyBodyLoader;
import com.moniepoint.loans.cas.module.analytics.service.impl.SurveyPushNotificationKafkaEventPublisher;
import com.moniepoint.loans.cas.module.cache.service.impl.RedisCacheServiceImpl;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.SurveyPreprocessorListener;
import com.moniepoint.loans.cas.testdoubles.*;
import org.apache.commons.io.IOUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SurveyPreprocessorListenerTests {
    private static final ObjectMapperHelper objectMapperHelper =
            new ObjectMapperHelper(ObjectMapperConfiguration.constructObjectMapper(), new Telemetry(new SimpleMeterRegistry()));

    private FakeSurveyStorage surveyStorage;
    private FakePreprocessedSurveyStorage preprocessedSurveyStorage;
    private FakeUserAttributesStorage userAttributesStorage;

    private SurveyPreprocessorListener listener;
    @Mock
    SurveyPushNotificationKafkaEventPublisher surveyPushNotificationKafkaEventPublisher;

    @Mock
    BannerService bannerService;

    @Mock
    private RedisCacheServiceImpl cacheService;

    @BeforeEach
    void setup() {
        var rule = new Survey("event.eventType == 'trigger_survey_event'", 10, "{}","","", SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(3L);
        surveyStorage = new FakeSurveyStorage(new HashMap<>() {{
            put(3L, rule);
        }});
        preprocessedSurveyStorage = new FakePreprocessedSurveyStorage(new HashMap<>());
        userAttributesStorage = new FakeUserAttributesStorage(new HashMap<>());

        VerifiedAnalyticsEventDTO surveyTriggeringEvent = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        surveyTriggeringEvent.setEventType("trigger_survey_event");

        listener = new SurveyPreprocessorListener(
                preprocessedSurveyStorage,
                objectMapperHelper,
                cacheService,
                surveyPushNotificationKafkaEventPublisher,
                bannerService,
                new SurveyBodyLoader(objectMapperHelper),
                userAttributesStorage
        );
    }

    @Test
    void surveysArePreprocessedWithUserAttributes() throws IOException {
        var surveyExample = IOUtils.toString(
                Objects.requireNonNull(this.getClass().getResourceAsStream("/example-survey.json")),
                StandardCharsets.UTF_8
        );
        var rule = new Survey("event.eventType == 'pre-processed-event'", 10, surveyExample,"","",SurveyCategory.NPS, Timestamp.from(Instant.now()),90);
        rule.setId(157L);
        surveyStorage.save(rule);

        var event = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "John");
        event.setUserAttributes(UserAttributes.builder().email("other-test@gmail.com").name("John").build());
        event.setEventType("pre-processed-event");
        event.setData(new ObjectMapper().convertValue(Map.of(
                "eventName", "cashback"
        ), JsonNode.class));
        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user(event.getUserIdentifiers().getUserID())
                .event(event.getId())
                .priority(rule.getPriority())
                .surveyId(rule.getId())
                .ttl(Timestamp.from(event.getTimestamp().toInstant().plus(Duration.of(15, ChronoUnit.MINUTES))))
                .location(event.getData().get("eventName").asText("")).build();
        EventPreprocessSurveyDTO preprocessEvent = EventPreprocessSurveyDTO.builder()
                .verifiedAnalyticsEventDTO(event)
                .userAttributes(event.getUserAttributes())
                .survey(rule)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(preprocessEvent));
        listener.handleEvent(message);
        Optional<PreprocessedSurvey> savedPreprocessedSurvey = preprocessedSurveyStorage.data.values().stream().findFirst();

        assertTrue(savedPreprocessedSurvey.isPresent());
        assertEquals(1, preprocessedSurveyStorage.data.size());
        assertEquals(event.getId(), savedPreprocessedSurvey.get().getEvent());
        assertEquals(rule.getId(), savedPreprocessedSurvey.get().getSurveyId());
        assertTrue(savedPreprocessedSurvey.get().getSurvey().toLowerCase().contains(("Good morning "+event.getUserAttributes().getName()+"! How do you feel about our rewards?").toLowerCase()));
    }

    @Test
    void nullVerifiedEvent_doesNotNpe() {
        var survey = new Survey("rule", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(99L);
        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user("nps-user-1")
                .event("NPS_WEEKLY_SAMPLE")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(10080, ChronoUnit.MINUTES))))
                .location("")
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(UserAttributes.builder().email("nps@test.com").name("NPS User").build())
                .verifiedAnalyticsEventDTO(null)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        assertDoesNotThrow(() -> listener.handleEvent(message));
        assertEquals(1, preprocessedSurveyStorage.data.size());
    }

    @Test
    void nonNullVerifiedEvent_populatesEventContextKeys() throws IOException {
        var surveyJson = IOUtils.toString(
                Objects.requireNonNull(this.getClass().getResourceAsStream("/example-survey.json")),
                StandardCharsets.UTF_8
        );
        var survey = new Survey("rule", 10, surveyJson, "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(157L);
        var event = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("brm-user", "brm@test.com", "1234567890", "BRM User");
        event.setUserAttributes(UserAttributes.builder().email("brm@test.com").name("BRM User").build());
        event.setEventType("brm_event");
        event.setData(new ObjectMapper().convertValue(Map.of("eventName", "cashback"), com.fasterxml.jackson.databind.JsonNode.class));
        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user(event.getUserIdentifiers().getUserID())
                .event(event.getId())
                .priority(survey.getPriority())
                .surveyId(survey.getId())
                .ttl(Timestamp.from(event.getTimestamp().toInstant().plus(Duration.of(15, ChronoUnit.MINUTES))))
                .location(event.getData().get("eventName").asText(""))
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .verifiedAnalyticsEventDTO(event)
                .userAttributes(event.getUserAttributes())
                .survey(survey)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        listener.handleEvent(message);

        Optional<PreprocessedSurvey> saved = preprocessedSurveyStorage.data.values().stream().findFirst();
        assertTrue(saved.isPresent());
        assertTrue(saved.get().getSurvey().toLowerCase().contains(
                ("Good morning " + event.getUserAttributes().getName() + "! How do you feel about our rewards?").toLowerCase()
        ));
    }

    @Test
    void isoWeekSet_existingActivePreprocessedSurvey_skipsDuplicateCreation() {
        var survey = new Survey("rule", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(88L);
        var existing = PreprocessedSurvey.builder()
                .user("nps-repeat-user")
                .event("NPS")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(10080, ChronoUnit.MINUTES))))
                .location("")
                .isoWeek("2026-W22")
                .state(com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState.NOT_COMPLETED)
                .build();
        preprocessedSurveyStorage.save(existing);

        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user("nps-repeat-user")
                .event("NPS")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(10080, ChronoUnit.MINUTES))))
                .location("")
                .isoWeek("2026-W22")
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(UserAttributes.builder().name("Repeat User").build())
                .verifiedAnalyticsEventDTO(null)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        listener.handleEvent(message);

        assertEquals(1, preprocessedSurveyStorage.data.size());
    }

    @Test
    void cohortId_propagatesFromDtoToEntity() {
        var survey = new Survey("rule", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(77L);
        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user("cohort-user")
                .event("NPS_WEEKLY_SAMPLE")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(10080, ChronoUnit.MINUTES))))
                .location("")
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(UserAttributes.builder().name("Cohort User").build())
                .verifiedAnalyticsEventDTO(null)
                .preprocessedSurvey(preprocessedSurvey)
                .cohortId(42L)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        listener.handleEvent(message);

        Optional<PreprocessedSurvey> saved = preprocessedSurveyStorage.data.values().stream().findFirst();
        assertTrue(saved.isPresent());
        assertEquals(42L, saved.get().getCohortId());
    }

    @Test
    void writePreprocessedSurveyToCache_evictsUserCache_whenIsoWeekPresent() {
        var survey = new Survey("rule", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(201L);
        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user("nps-cache-user")
                .event("NPS")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(10080, ChronoUnit.MINUTES))))
                .location("")
                .isoWeek("2026-W33")
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(UserAttributes.builder().name("NPS Cache User").build())
                .verifiedAnalyticsEventDTO(null)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        listener.handleEvent(message);

        // Regression test for the bug where a warm per-user cache prevented
        // PreprocessedSurveyRepositoryService.fetchSurveysByUserId() from ever reaching
        // serveNpsSurveyIfDue(), leaving NpsWeeklySample stuck at GENERATED forever.
        verify(cacheService, times(1)).evictAllPreprocessedSurveys("nps-cache-user");
        verify(cacheService, never()).appendPreprocessedSurvey(any(), any());
        verify(cacheService, never()).getAllPreprocessedSurveys("nps-cache-user");
    }

    @Test
    void writePreprocessedSurveyToCache_appendsToWarmCache_whenIsoWeekAbsent() {
        var survey = new Survey("rule", 10, "{}", "", "", SurveyCategory.NPS, Timestamp.from(Instant.now()), 90);
        survey.setId(202L);
        var existingDto = PreprocessedSurveyDTO.builder().user("event-cache-user").surveyId(99L).build();
        when(cacheService.getAllPreprocessedSurveys("event-cache-user")).thenReturn(java.util.List.of(existingDto));

        var preprocessedSurvey = PreprocessedSurvey.builder()
                .user("event-cache-user")
                .event("some-event-uuid")
                .priority(10)
                .surveyId(survey.getId())
                .ttl(Timestamp.from(Instant.now().plus(Duration.of(15, ChronoUnit.MINUTES))))
                .location("dashboard_load_success")
                .build();
        EventPreprocessSurveyDTO dto = EventPreprocessSurveyDTO.builder()
                .survey(survey)
                .userAttributes(UserAttributes.builder().name("Event Cache User").build())
                .verifiedAnalyticsEventDTO(null)
                .preprocessedSurvey(preprocessedSurvey)
                .build();
        var message = new ConsumerRecord<>("survey-preprocessor", 0, 1, "key", objectMapperHelper.serializeToString(dto));

        listener.handleEvent(message);

        // Non-NPS (event-triggered) surveys must keep the existing append-to-cache behaviour.
        verify(cacheService, times(1)).appendPreprocessedSurvey(eq("event-cache-user"), any());
        verify(cacheService, never()).evictAllPreprocessedSurveys(any());
    }
}
