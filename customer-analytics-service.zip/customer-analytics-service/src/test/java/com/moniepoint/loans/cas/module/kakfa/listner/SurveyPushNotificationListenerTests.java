package com.moniepoint.loans.cas.module.kakfa.listner;

import com.moniepoint.loans.cas.common.util.Telemetry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.loans.cas.common.util.ObjectMapperHelper;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.module.kafka.listener.SurveyPushNotificationListener;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import com.moniepoint.loans.cas.testdoubles.FakeNotificationService;
import org.apache.commons.io.IOUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SurveyPushNotificationListenerTests {
    private static final ObjectMapperHelper objectMapperHelper = new ObjectMapperHelper(new ObjectMapper(), new Telemetry(new SimpleMeterRegistry()));
    private VerifiedAnalyticsEventDTO surveyTriggeringEvent;

    private FakeNotificationService notificationService;

    private SurveyPushNotificationListener listener;

    @BeforeEach
    void setup() {
        notificationService = new FakeNotificationService();

        surveyTriggeringEvent = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "Test user");
        surveyTriggeringEvent.setEventType("trigger_survey_event");

        listener = new SurveyPushNotificationListener(
                notificationService,
                objectMapperHelper
        );
    }

    @Test
    void validSurveysTriggerMultipleNotifications() throws IOException {
        var processedSurvey = IOUtils.toString(
                Objects.requireNonNull(this.getClass().getResourceAsStream("/example-preprocessed-survey.json")),
                StandardCharsets.UTF_8
        );
        PreprocessedSurvey preprocessedSurvey =  objectMapperHelper.deserializeStringToObject(processedSurvey, new TypeReference<>() {
        });
        preprocessedSurvey.setTtl(Timestamp.from(Instant.now()));

        var event = VerifiedAnalyticsEventFactory
                .androidAuthenticatedEvent("known-test-user", "test@email.com", "2169633555", "John");
        event.setUserAttributes(UserAttributes.builder().email("other-test@gmail.com").name("John").build());
        event.setEventType("pre-processed-event");
        event.setData(new ObjectMapper().convertValue(Map.of(
                "eventName", "cashback"
        ), JsonNode.class));

        NotificationRequest notificationRequest=new NotificationRequest(preprocessedSurvey, event);
        var message = new ConsumerRecord<>("verified-analytics-event", 0, 1, "key", objectMapperHelper.serializeToString(notificationRequest));

        listener.handleEvent(message);

        assertEquals(1, notificationService.notificationsSent.size());
    }

}
