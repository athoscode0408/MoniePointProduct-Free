package com.moniepoint.loans.cas.module.kakfa.listner;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.moniepoint.loans.cas.module.analytics.dto.v3.AnalyticsEventV3DeviceInfoDTO;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class VerifiedAnalyticsEventFactory {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    private VerifiedAnalyticsEventFactory() {
    }

    static VerifiedAnalyticsEventDTO anonymousAndroidEvent() {
        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("attribution")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .platform("android")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.values()))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .userAttributes(new UserAttributes())
                .data(objectMapper.convertValue(Map.of(
                        "eventName", "payment_success",
                        "amount", "30000",
                        "device", androidApp()
                ), JsonNode.class))
                .build();
    }

    static VerifiedAnalyticsEventDTO anonymousWebEvent() {
        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("attribution")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .platform("web")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.values()))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(objectMapper.convertValue(Map.of(
                        "eventName", "payment_success",
                        "amount", "30000",
                        "device", androidApp()
                ), JsonNode.class))
                .build();
    }

    static VerifiedAnalyticsEventDTO anonymousWebEventWithProperties() {
        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("attribution")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.values()))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(objectMapper.convertValue(Map.of(
                        "eventName", "payment_success",
                        "amount", "30000",
                        "device", androidApp(),
                        "properties",webProperties()
                ), JsonNode.class))
                .build();
    }

    static VerifiedAnalyticsEventDTO anonymousEventWithNoPlatform() {
        return VerifiedAnalyticsEventDTO.builder()
                .id(UUID.randomUUID().toString())
                .eventType("attribution")
                .timestamp(Timestamp.from(Instant.now()))
                .appEnv("dev")
                .ip("127.0.0.1")
                .eventProviders(Set.of(EventProvider.values()))
                .userIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString()))
                .data(objectMapper.convertValue(Map.of(
                        "eventName", "payment_success",
                        "amount", "30000",
                        "device", androidApp()
                ), JsonNode.class))
                .build();
    }

    private static AnalyticsEventV3DeviceInfoDTO androidApp() {
        return AnalyticsEventV3DeviceInfoDTO.builder()
                .id(UUID.randomUUID().toString())
                .os("android")
                .osVersion("13")
                .type("android")
                .buildNumber("98")
                .version("1.3.0")
                .dpi(100)
                .width(1200)
                .height(980)
                .additionalInfo(Map.of("arch", "arm64"))
                .build();
    }

    private static JsonNode webProperties() {
        ObjectNode obj = JsonNodeFactory.instance.objectNode();
        obj.put("platform", "web");
        return obj;
    }

    public static VerifiedAnalyticsEventDTO androidAuthenticatedEvent(String userID, String email, String phone, String name) {
        var event = anonymousAndroidEvent();
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), userID, email, phone, name));
        return event;
    }

    public static VerifiedAnalyticsEventDTO webAuthenticatedEvent(String userID, String email, String phone, String name) {
        var event = anonymousWebEvent();
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), userID, email, phone, name));
        return event;
    }

    public static VerifiedAnalyticsEventDTO webAuthenticatedEventWithProperties(String userID, String email, String phone, String name) {
        var event = anonymousWebEventWithProperties();
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), userID, email, phone, name));
        return event;
    }

    public static VerifiedAnalyticsEventDTO authenticatedEventWithNoPlatform(String userID, String email, String phone, String name) {
        var event = anonymousEventWithNoPlatform();
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), userID, email, phone, name));
        return event;
    }

    static VerifiedAnalyticsEventDTO userAttributesEventRequest(String userID) {
        var event = anonymousAndroidEvent();
        event.setData(null);
        event.setUserIdentifiers(new UserEventIdentifier(UUID.randomUUID().toString(), userID, null, null, null));
        event.setUserAttributes(UserAttributes.builder()
                .name("My test name")
                .phone("123456789")
                .email("test@email.com")
                .build());
        return event;
    }
}
