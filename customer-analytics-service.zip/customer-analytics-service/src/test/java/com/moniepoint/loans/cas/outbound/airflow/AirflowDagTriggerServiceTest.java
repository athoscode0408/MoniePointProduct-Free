package com.moniepoint.loans.cas.outbound.airflow;

import com.moniepoint.loans.cas.common.exception.ServerException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AirflowDagTriggerServiceTest {

    @Mock
    private AirflowConfig config;

    @Mock
    private AirflowClient airflowClient;

    private AirflowDagTriggerService underTest;

    @BeforeEach
    void setUp() {
        when(config.dagId()).thenReturn("cas_nps_weekly_pipeline");
        when(config.apiToken()).thenReturn("test-token");

        underTest = new AirflowDagTriggerService(config, airflowClient);
    }

    @Test
    void triggerNpsPipeline_successfulTrigger_completesWithoutException() {
        when(airflowClient.triggerDagRun(anyString(), any(), anyString()))
                .thenReturn(ResponseEntity.ok().build());

        assertThatNoException().isThrownBy(() -> underTest.triggerNpsPipeline("2026-W22"));
    }

    @Test
    void triggerNpsPipeline_httpError_throwsServerException() {
        when(airflowClient.triggerDagRun(anyString(), any(), anyString()))
                .thenThrow(new RuntimeException("connection refused"));

        assertThatThrownBy(() -> underTest.triggerNpsPipeline("2026-W22"))
                .isInstanceOf(ServerException.class)
                .hasMessageContaining("connection refused");
    }

    @Test
    void buildRequest_nullIsoWeek_confExcludesIsoWeekField() {
        AirflowDagRunRequest request = underTest.buildRequest(null);

        assertThat(request.conf()).doesNotContainKey("iso_week");
        assertThat(request.conf()).containsEntry("triggered_by", "cas_admin");
    }

    @Test
    void buildRequest_nonNullIsoWeek_confContainsIsoWeekAndValue() {
        AirflowDagRunRequest request = underTest.buildRequest("2026-W22");

        assertThat(request.conf()).containsEntry("iso_week", "2026-W22");
        assertThat(request.conf()).containsEntry("triggered_by", "cas_admin");
    }
}