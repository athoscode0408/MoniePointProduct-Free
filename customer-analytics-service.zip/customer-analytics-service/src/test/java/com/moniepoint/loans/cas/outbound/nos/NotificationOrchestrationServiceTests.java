package com.moniepoint.loans.cas.outbound.nos;

import com.moniepoint.loans.cas.module.analytics.dto.v3.UserEventIdentifier;
import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.kafka.dto.VerifiedAnalyticsEventDTO;
import com.moniepoint.loans.cas.outbound.NotificationRequest;
import com.moniepoint.loans.cas.outbound.OutboundUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationOrchestrationServiceTests {
//    private static final String FAKE_CREDENTIALS = "some-fake-creds";

    @Spy
    private NOSClient nosClient;
    @Mock
    private OutboundUtils outboundUtils;
//    @Spy
//    private CosmosClient cosmosClient;

    private NotificationOrchestrationService service;
    private PreprocessedSurvey validSurvey;

    @BeforeEach
    void setup() {
        when(nosClient.notify(any(NOSNotificationRequest.class), eq("Bearer valid-token"), eq(null))).thenReturn(
                ResponseEntity.status(HttpStatus.OK).build()
        );

        when(outboundUtils.getToken()).thenReturn("valid-token");

//        when(cosmosClient.authorize("client_credentials", String.format("Basic %s", FAKE_CREDENTIALS))).thenReturn(
//                ResponseEntity.ok(new AuthorizeResponse(true, new AuthorizeResponseResult("valid-token", "bearer")))
//        );

        validSurvey = PreprocessedSurvey.builder().ttl(Timestamp.from(Instant.now())).build();
        validSurvey.setId(1L);

        service = new NotificationOrchestrationService(
//                FAKE_CREDENTIALS,
                nosClient,
                outboundUtils
//                cosmosClient
        );
    }

    @Test
    void sendValidPushNotification() {
        var event = VerifiedAnalyticsEventDTO.builder()
                .timestamp(Timestamp.from(Instant.now()))
                .userIdentifiers(new UserEventIdentifier("session-id", "user-id", null, null, null))
                .build();
        var result = service.sendPushNotification(new NotificationRequest(validSurvey, event));
        assertTrue(result);
    }

    @Test
    void invalidCosmosCredentialsReturnsFailedNotification() {
//        when(cosmosClient.authorize("client_credentials", String.format("Basic %s", FAKE_CREDENTIALS))).thenReturn(
//                ResponseEntity.internalServerError().build()
//        );

        when(outboundUtils.getToken()).thenReturn("");

        var event = VerifiedAnalyticsEventDTO.builder()
                .timestamp(Timestamp.from(Instant.now()))
                .userIdentifiers(new UserEventIdentifier("session-id", "user-id", null, null, null))
                .build();
        var result = service.sendPushNotification(new NotificationRequest(validSurvey, event));
        assertFalse(result);
    }
}
