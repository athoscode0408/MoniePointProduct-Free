package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.AnalyticsEventProvider;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.AnalyticsEventProviderRepository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FakeAnalyticsEventProviderRepository extends FakeInMemoryStorage<AnalyticsEventProvider> implements AnalyticsEventProviderRepository {
    public FakeAnalyticsEventProviderRepository(Map<Long, AnalyticsEventProvider> rules) {
        super(rules);
    }

    @Override
    public List<AnalyticsEventProvider> findAllWithEvents() {
        return findAll();
    }

    @Override
    public Optional<AnalyticsEventProvider> findByProviderKey(EventProvider providerKey) {
        return Optional.empty();
    }

}
