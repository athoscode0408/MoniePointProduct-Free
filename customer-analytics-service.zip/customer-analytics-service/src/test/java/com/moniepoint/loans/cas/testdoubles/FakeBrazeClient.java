package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.integrations.braze.BrazeClient;
import com.moniepoint.loans.cas.integrations.braze.dto.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

public class FakeBrazeClient implements BrazeClient {
    public ResponseEntity<BrazeTrackResponse> trackResponse;
    public ResponseEntity<BrazeIdentifyResponse> identifyResponse;
    public List<String> allowedTokens;

    public List<BrazeTrackRequest> trackRequests = new ArrayList<>();
    public List<BrazeIdentifyRequest> identifyRequests = new ArrayList<>();


    public FakeBrazeClient(List<String> allowedTokens) {
        this.allowedTokens = allowedTokens;
    }

    @Override
    public ResponseEntity<BrazeTrackResponse> trackEvent(BrazeTrackRequest request, String authorizationToken) {
        trackRequests.add(request);
        if (!allowedTokens.contains(authorizationToken)) {
            return ResponseEntity.status(401).build();
        }

        return trackResponse != null ? trackResponse : ResponseEntity.status(HttpStatus.CREATED).body(
                new BrazeTrackResponse(request.getAttributes().size(), request.getEvents().size(), "success")
        );
    }

    @Override
    public ResponseEntity<BrazeIdentifyResponse> identify(BrazeIdentifyRequest request, String authorizationToken) {
        identifyRequests.add(request);
        if (!allowedTokens.contains(authorizationToken)) {
            return ResponseEntity.status(401).build();
        }
        return identifyResponse != null ? identifyResponse : ResponseEntity.status(HttpStatus.CREATED).body(new BrazeIdentifyResponse(
                request.getAliases().size(), 0, 0, "success"
        ));
    }

    @Override
    public ResponseEntity<BrazeCanvasResponse> fetchCanvasDetails(String canvas_id, String authorizationToken) {
        return null;
    }


}
