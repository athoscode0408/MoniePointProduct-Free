package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.cache.service.CacheService;

import java.util.Map;

public class FakeCacheService implements CacheService {
    public Map<String, String> cache;

    public FakeCacheService(Map<String, String> cache) {
        this.cache = cache;
    }

    @Override
    public boolean doesKeyExist(String key) {
        return cache.containsKey(key);
    }

    @Override
    public void cacheString(String key, String value) {
        cache.put(key, value);
    }

    @Override
    public void cacheString(String key, String value, long durationInSeconds) {
        cache.put(key, value);
    }

    @Override
    public String getCachedString(String key) {
        return cache.get(key);
    }

    @Override
    public void deleteFromCache(String key) {
        cache.remove(key);
    }

}
