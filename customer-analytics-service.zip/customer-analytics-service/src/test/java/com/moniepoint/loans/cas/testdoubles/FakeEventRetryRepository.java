package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.EventRetry;
import com.moniepoint.loans.cas.module.analytics.enums.EventProvider;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryRepository;
import com.moniepoint.loans.cas.module.analytics.repository.EventRetryView;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FakeEventRetryRepository extends FakeInMemoryStorage<EventRetry> implements EventRetryRepository {
    public FakeEventRetryRepository(Map<Long, EventRetry> rules) {
        super(rules);
    }

    @Override
    public Optional<EventRetry> findByEventIdAndEventProvider(String eventId, EventProvider eventProvider) {
        return Optional.empty();
    }

    @Override
    public Long findMinId() {
        var min = Long.MAX_VALUE;
        for (Long k : data.keySet()) {
            if (k < min) {
                min = k;
            }
        }
        return min;
    }

    @Override
    public Long findMaxId(Long start, Long limit) {
        var max = 0L;
        for (Long k : data.keySet()) {
            if (k > max) {
                max = k;
            }
        }
        return max;
    }

    @Override
    public Page<Long> findIdsInRange(Long startId, Long endId, Pageable pageable) {
        return null;
    }

    @Override
    public List<EventRetryView> findBatchAfter(Long cursor, Pageable pageable) {
        return List.of();
    }
}
