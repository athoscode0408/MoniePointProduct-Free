package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.common.entity.BaseEntity;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FakeInMemoryStorage<T extends BaseEntity> extends FakeStorage<T, Long> {
    public Map<Long, T> data;

    public FakeInMemoryStorage(Map<Long, T> data) {
        this.data = data;
    }

    @Override
    public @NotNull T getReferenceById(@NotNull Long id) {
        return data.get(id);
    }

    @Override
    public <S extends T> @NotNull S save(@NotNull S entity) {
        data.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public boolean existsById(@NotNull Long id) {
        return data.containsKey(id);
    }

    @Override
    public @NotNull List<T> findAll() {
        return data.values().stream().toList();
    }

    @Override
    public @NotNull List<T> findAllById(Iterable<Long> longs) {
        var found = new ArrayList<T>();
        longs.forEach(l -> {
            var f = data.get(l);
            if (f != null) {
                found.add(f);
            }
        });
        return found;
    }

    @Override
    public long count() {
        return data.size();
    }

    @Override
    public void deleteById(@NotNull Long id) {
        data.remove(id);
    }

    @Override
    public void delete(T entity) {
        deleteById(entity.getId());
    }

    @Override
    public void deleteAll() {
        data.clear();
    }
}
