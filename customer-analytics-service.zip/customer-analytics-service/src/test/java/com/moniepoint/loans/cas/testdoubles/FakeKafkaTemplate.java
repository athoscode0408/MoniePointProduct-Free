package com.moniepoint.loans.cas.testdoubles;

import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.SendResult;
import org.springframework.lang.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.mock;

public class FakeKafkaTemplate extends KafkaTemplate<String, String> {
    public Map<String, List<Pair<String, String>>> topics = new HashMap<>();

    public FakeKafkaTemplate(List<String> topics) {
        super(mock(ProducerFactory.class));
        for (String topic : topics) {
            this.topics.put(topic, new ArrayList<>());
        }
    }

    @Override
    public @NotNull CompletableFuture<SendResult<String, String>> send(@NotNull String topic, @NotNull String key, @Nullable String data) {
        topics.get(topic).add(Pair.of(key, data));
        return new CompletableFuture<>();
    }

}
