package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.integrations.mixpanel.dto.*;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelClient;
import com.moniepoint.loans.cas.integrations.mixpanel.service.MixpanelQueryAPIClient;
import org.springframework.http.ResponseEntity;

import java.util.*;
import java.util.stream.Collectors;

public class FakeMixpanelClient implements MixpanelClient, MixpanelQueryAPIClient {
    public List<MixpanelEventRequest> eventRequests = new ArrayList<>();
    public List<MixpanelProfilePropertiesRequest> profileRequests = new ArrayList<>();
    public Set<String> allowedTokens;

    public Map<String, List<MixpanelQueryUser>> users;

    public FakeMixpanelClient(Set<String> allowedTokens) {
        this.allowedTokens = allowedTokens.stream().map(FakeMixpanelClient::encodeToken).collect(Collectors.toSet());
    }

    @Override
    public ResponseEntity<MixpanelEventResponse> sendImportEventRequest(List<MixpanelEventRequest> mixpanelEventRequests, String authorizationToken) {
        eventRequests.addAll((mixpanelEventRequests));
        if (!allowedTokens.contains(authorizationToken)) {
            var failedRecords = new ArrayList<MixpanelEventResponse.FailedRecord>();
            for (int i = 0; i < mixpanelEventRequests.size(); i++) {
                failedRecords.add(new MixpanelEventResponse.FailedRecord(i, mixpanelEventRequests.get(i).getEvent(), "some field", "ABORTED"));
            }
            return ResponseEntity.status(401).body(new MixpanelEventResponse(401, "some error", 0, "ABORTED", failedRecords));
        }

        return ResponseEntity.ok(new MixpanelEventResponse(200, null, mixpanelEventRequests.size(), "OK", null));
    }

    @Override
    public ResponseEntity<Void> setProfileProperties(List<MixpanelProfilePropertiesRequest> requests) {
        profileRequests.addAll((requests));
        for (var r : requests) {
            if (!allowedTokens.contains(r.getToken())) {
                return ResponseEntity.status(401).build();
            }
        }

        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<MixpanelQueryUserResponse> queryUserProfile(String projectID, MixpanelQueryUserRequest request, String token) {
        if (!allowedTokens.contains(token)) {
            return ResponseEntity.status(401).build();
        }

        if (!users.containsKey(projectID)) {
            return ResponseEntity.notFound().build();
        }

        var filteredUsers = new ArrayList<>(users.get(projectID));
        return ResponseEntity.ok(new MixpanelQueryUserResponse(filteredUsers, 1, 1000, 1, "ok"));
    }

    private static String encodeToken(String token) {
        return String.format("Basic %s", new String(Base64.getEncoder().encode(String.format("%s:", token).getBytes())));
    }
}
