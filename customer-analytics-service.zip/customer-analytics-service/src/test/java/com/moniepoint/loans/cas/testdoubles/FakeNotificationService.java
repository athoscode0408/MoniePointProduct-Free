package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.outbound.NotificationRequest;
import com.moniepoint.loans.cas.outbound.NotificationService;

import java.util.ArrayList;
import java.util.List;

public class FakeNotificationService implements NotificationService {
    public List<String> notificationsSent;

    public FakeNotificationService() {
        notificationsSent = new ArrayList<>();
    }

    @Override
    public boolean sendPushNotification(NotificationRequest request) {
        return notificationsSent.add(request.getSurveyID());
    }
}
