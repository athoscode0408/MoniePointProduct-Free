package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.NpsUserState;
import com.moniepoint.loans.cas.module.analytics.repository.NpsUserStateStorage;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.Optional;
import java.util.Random;

public class FakeNpsUserStateStorage extends FakeInMemoryStorage<NpsUserState> implements NpsUserStateStorage {

    public FakeNpsUserStateStorage(Map<Long, NpsUserState> data) {
        super(data);
    }

    @Override
    public <S extends NpsUserState> @NotNull S save(@NotNull S entity) {
        if (entity.getId() == null) {
            entity.setId(new Random().nextLong(1, Long.MAX_VALUE));
        }
        data.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Optional<NpsUserState> findByUserName(String userName) {
        return data.values().stream()
                .filter(s -> s.getUserName().equals(userName))
                .findFirst();
    }
}
