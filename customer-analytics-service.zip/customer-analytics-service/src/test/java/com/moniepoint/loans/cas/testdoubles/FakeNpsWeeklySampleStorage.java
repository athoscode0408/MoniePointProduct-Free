package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.NpsWeeklySample;
import com.moniepoint.loans.cas.module.analytics.enums.NpsSampleStatus;
import com.moniepoint.loans.cas.module.analytics.repository.NpsWeeklySampleStorage;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

public class FakeNpsWeeklySampleStorage extends FakeInMemoryStorage<NpsWeeklySample> implements NpsWeeklySampleStorage {

    public FakeNpsWeeklySampleStorage(Map<Long, NpsWeeklySample> data) {
        super(data);
    }

    @Override
    public <S extends NpsWeeklySample> @NotNull S save(@NotNull S entity) {
        if (entity.getId() == null) {
            entity.setId(new Random().nextLong(1, Long.MAX_VALUE));
        }
        data.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Optional<NpsWeeklySample> findByUserIdAndIsoWeek(Long userId, String isoWeek) {
        return data.values().stream()
                .filter(s -> s.getUserId().equals(userId) && s.getIsoWeek().equals(isoWeek))
                .findFirst();
    }

    @Override
    public Optional<NpsWeeklySample> findByUserNameAndIsoWeek(String userName, String isoWeek) {
        return data.values().stream()
                .filter(s -> s.getUserName().equals(userName) && s.getIsoWeek().equals(isoWeek))
                .findFirst();
    }

    @Override
    public List<NpsWeeklySample> findPendingByIsoWeek(String isoWeek, NpsSampleStatus status) {
        return data.values().stream()
                .filter(s -> s.getIsoWeek().equals(isoWeek) && s.getStatus() == status)
                .toList();
    }

    @Override
    public int updateStatusByIsoWeekLessThanEqualAndCurrentStatus(String isoWeek, NpsSampleStatus currentStatus, NpsSampleStatus newStatus) {
        int count = 0;
        for (NpsWeeklySample sample : data.values()) {
            if (sample.getIsoWeek().compareTo(isoWeek) <= 0 && sample.getStatus() == currentStatus) {
                sample.setStatus(newStatus);
                count++;
            }
        }
        return count;
    }

    @Override
    public int updateStatusByIds(List<Long> ids, NpsSampleStatus currentStatus, NpsSampleStatus newStatus) {
        var idSet = new HashSet<>(ids);
        var count = 0;
        for (NpsWeeklySample sample : data.values()) {
            if (idSet.contains(sample.getId()) && sample.getStatus() == currentStatus) {
                sample.setStatus(newStatus);
                count++;
            }
        }
        return count;
    }
}
