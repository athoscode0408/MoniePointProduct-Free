package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.PreprocessedSurvey;
import com.moniepoint.loans.cas.module.analytics.enums.PreprocessedSurveyState;
import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyStorage;
import org.jetbrains.annotations.NotNull;

import com.moniepoint.loans.cas.module.analytics.repository.PreprocessedSurveyExpiryView;
import org.springframework.data.domain.Pageable;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

public class FakePreprocessedSurveyStorage extends FakeInMemoryStorage<PreprocessedSurvey> implements PreprocessedSurveyStorage {
    public FakePreprocessedSurveyStorage(Map<Long, PreprocessedSurvey> rules) {
        super(rules);
    }

    @Override
    public <S extends PreprocessedSurvey> @NotNull S save(@NotNull S entity) {
        var id = new Random().nextLong();
        entity.setId(id);
        data.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Optional<PreprocessedSurvey> findPreprocessedSurveyByUserAndIdAndStateIn(String userI, Long surveyId, List<PreprocessedSurveyState> preprocessedSurveyStates) {
        return Optional.empty();
    }

    @Override
    public List<PreprocessedSurvey> findByUserAndStateInAndTtlAfter(String user, List<PreprocessedSurveyState> state, Timestamp now) {
        return List.of();
    }

    @Override
    public Optional<PreprocessedSurvey> findByIdAndStateInAndTtlAfter(Long id, List<PreprocessedSurveyState> state, Timestamp now) {
        return Optional.empty();
    }

    @Override
    public List<PreprocessedSurvey> findByUserAndStateInOrUserAndCompletedOnAfter(String user, List<PreprocessedSurveyState> preprocessedSurveyStates, String user2, Timestamp cutoff) {
        return findAll();

    }

    @Override
    public List<PreprocessedSurvey> findByUserAndSurveyIdAndLastModifiedOnBetween(String user, Long surveyId, Timestamp startDate, Timestamp endDate) {
        return List.of();
    }

    @Override
    public List<PreprocessedSurvey> findByUserAndSurveyIdAndStateInAndTtlAfterOrderByIdDesc(String user, Long surveyId, List<PreprocessedSurveyState> states, Timestamp now) {
        return List.of();
    }

    @Override
    public Optional<PreprocessedSurvey> findFirstByUserAndSurveyIdAndStateInAndTtlAfter(String user, Long surveyId, List<PreprocessedSurveyState> states, Timestamp now) {
        return Optional.empty();
    }

    @Override
    public int expirePreprocessedSurveys(Long limit) {
        return 0;
    }

    @Override
    public List<PreprocessedSurveyExpiryView> findBatchStartingAfter(Long startId, Collection<PreprocessedSurveyState> eligibleStates, Pageable pageable) {
        return List.of();
    }

    @Override
    public int expireByIds(Collection<Long> ids) {
        return 0;
    }
    @Override
    public Optional<PreprocessedSurvey> findFirstByUserAndIsoWeekAndStateIn(String user, String isoWeek, List<PreprocessedSurveyState> states) {
        return data.values().stream()
                .filter(ps -> ps.getUser().equals(user)
                        && isoWeek.equals(ps.getIsoWeek())
                        && states.contains(ps.getState()))
                .findFirst();
    }
}
