package com.moniepoint.loans.cas.testdoubles;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public abstract class FakeStorage<T, I> implements JpaRepository<T, I> {

    @Override
    public void flush() {
        // not required in in-memory db
    }

    @Override
    public <S extends T> @NotNull S saveAndFlush(@NotNull S entity) {
        return save(entity);
    }

    @Override
    public <S extends T> @NotNull List<S> saveAllAndFlush(@NotNull Iterable<S> entities) {
        return saveAll(entities);
    }

    @Override
    public void deleteAllInBatch(@NotNull Iterable<T> entities) {
        deleteAll(entities);
    }

    @Override
    public void deleteAllByIdInBatch(@NotNull Iterable<I> longs) {
        deleteAllById(longs);
    }

    @Override
    public void deleteAllInBatch() {
        deleteAll();
    }

    @Override
    public @NotNull T getById(@NotNull I id) {
        return getReferenceById(id);
    }

    @Override
    public <S extends T> @NotNull Optional<S> findOne(@NotNull Example<S> example) {
        return Optional.empty();
    }

    @Override
    public <S extends T> @NotNull List<S> findAll(@NotNull Example<S> example) {
        return (List<S>) findAll();
    }

    @Override
    public <S extends T> @NotNull List<S> findAll(@NotNull Example<S> example, @NotNull Sort sort) {
        return findAll(example);
    }

    @Override
    public <S extends T> @NotNull Page<S> findAll(@NotNull Example<S> example, @NotNull Pageable pageable) {
        return new PageImpl<>(findAll(example));
    }

    @Override
    public <S extends T> long count(@NotNull Example<S> example) {
        return count();
    }

    @Override
    public <S extends T, R> @NotNull R findBy(@NotNull Example<S> example, @NotNull Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction) {
        return null;
    }

    @Override
    public <S extends T> @NotNull List<S> saveAll(@NotNull Iterable<S> entities) {
        var l = new ArrayList<S>();
        entities.forEach(e -> {
            save(e);
            l.add(e);
        });
        return l;
    }

    @Override
    public @NotNull T getOne(@NotNull I id) {
        return getReferenceById(id);
    }

    @Override
    public @NotNull Optional<T> findById(@NotNull I id) {
        return Optional.of(getReferenceById(id));
    }

    @Override
    public void deleteAllById(Iterable<? extends I> ids) {
        ids.forEach(this::deleteById);
    }

    @Override
    public void deleteAll(Iterable<? extends T> entities) {
        entities.forEach(this::delete);
    }

    @Override
    public @NotNull List<T> findAll(@NotNull Sort sort) {
        return findAll();
    }

    @Override
    public @NotNull Page<T> findAll(@NotNull Pageable pageable) {
        return new PageImpl<>(findAll());
    }

    @Override
    public <S extends T> boolean exists(@NotNull Example<S> example) {
        return false;
    }
}
