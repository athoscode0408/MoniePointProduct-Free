package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.entity.Survey;
import com.moniepoint.loans.cas.module.analytics.repository.SurveyStorage;

import java.util.Map;

public class FakeSurveyStorage extends FakeInMemoryStorage<Survey> implements SurveyStorage {
    public FakeSurveyStorage(Map<Long, Survey> rules) {
        super(rules);
    }
}
