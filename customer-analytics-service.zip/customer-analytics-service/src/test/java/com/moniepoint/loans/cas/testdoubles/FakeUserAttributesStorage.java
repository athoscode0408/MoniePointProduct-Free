package com.moniepoint.loans.cas.testdoubles;

import com.moniepoint.loans.cas.module.analytics.dto.v3.UserAttributes;
import com.moniepoint.loans.cas.module.analytics.repository.UserAttributesStorage;
import java.util.Map;

public class FakeUserAttributesStorage implements UserAttributesStorage {
    private final Map<String, UserAttributes> users;

    public FakeUserAttributesStorage(Map<String, UserAttributes> users) {
        this.users = users;
    }

    public UserAttributes findUser(String userId, String businessAccountNumber) {
        return users.get(userId);
    }

//    public UserAttributes findUser(String userId) {
//        return users.get(userId);
//    }
}
