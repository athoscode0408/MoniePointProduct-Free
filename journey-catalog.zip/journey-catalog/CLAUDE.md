# Journey Catalogue Sync - Project Documentation

## Project Overview

Journey Catalogue Sync is a Spring Boot microservice that synchronizes journey catalogues from GitLab repositories. It receives webhook events from GitLab, fetches the repository files, parses them hierarchically (Platform → Capability → Journey), and upserts the data into the database.

## Architecture Overview

### Flow
1. **Webhook Reception**: Receive push event from GitLab
2. **Event Persistence**: Save entire event to `jcs_outbox_event` table with PENDING status
3. **Job Scheduling**: Immediately enqueue processing job via JobRunR
4. **Recurring Check**: ScheduledOutboxEventProcessor checks for pending events every minute
5. **File Fetching**: Fetch files from GitLab repo (compressed .tar.gz)
6. **File Parsing**: Recursively parse hierarchy (Platform → Capability → Journey)
   - Parse `platform-context.md` for platform metadata (name, channels, locales, url)
   - Parse `capability-spec.md` for capability details
   - Parse journey files for journey-level data
7. **Data Upsert**: Create or update Platform, Capability, and Journey entities
8. **Event Status Update**: Mark event as COMPLETED or FAILED (with retries)

### Data Model
- **JcsPlatform**: Top-level platform entity (name, externalId, channels, url, etc.)
- **JcsCapability**: Capabilities within a platform (name, externalId, status, etc.)
- **JcsJourney**: Journeys within a capability (name, externalId, persona, channels, metadata)
- **JcsOutboxEvent**: Stores incoming webhook events with status tracking and retry logic

### Layered Architecture
- **Controller**: REST endpoints (`WebhookController`) for webhook reception
- **Service**: Core business logic
  - `WebhookEventService`: Saves webhook events and enqueues jobs
  - `JourneyUpsertService`: Upserts platforms, capabilities, and journeys
  - `RepositoryFetchService`: Fetches and extracts GitLab repositories
  - `FileExtractionService`: Handles .tar.gz decompression
- **Job**: JobRunR job scheduling
  - `ProcessOutboxEventJob`: Processes individual outbox events
  - `ScheduledOutboxEventProcessor`: Recurring job (every minute) to check for pending events
- **Parser**: File parsing logic
  - `RepositoryHierarchyParser`: Parses repository structure and frontmatter
  - `YamlFrontmatterParser`: Extracts YAML frontmatter from markdown files
- **Repository**: Data access layer (JPA repositories)
- **Entity**: JPA entities with base class for audit fields
- **Mapper**: MapStruct-based DTO/Entity conversions
- **Helper**: Reusable utility functions (GitLab webhook parser)
- **Exception**: Custom exception handlers

## Development Setup

### Prerequisites
- Java 21
- Maven 3.6+
- Docker & Docker Compose
- Git

### Getting Started

1. **Start Docker Services**
   ```bash
   make up
   ```
   This starts MySQL and Redis containers.

2. **Build the Project**
   ```bash
   make build
   ```

3. **Run the Application**
   ```bash
   make run
   ```
   Application runs on `http://localhost:8080/api`

### Essential Commands

#### Build & Test
```bash
make compile          # Compile the project
make test             # Run all tests
make test-unit        # Run unit tests only
make build            # Build package
make verify           # Full verification (format, compile, test)
```

#### Development
```bash
make up               # Start Docker services
make down             # Stop Docker services
make logs             # View service logs
make run              # Run application
make restart          # Restart all services
```

#### Code Quality
```bash
make format           # Apply code formatting (Google Java Format)
make format-check     # Check formatting without changes
make dependency-tree  # Show Maven dependency tree
```

## Database

### Migrations
Database migrations are managed with Liquibase in YAML format:
- Master changelog: `src/main/resources/db/changelog/master.yml`
- Migrations: `src/main/resources/db/changelog/v*.yml`

### Entities
- All entities prefixed with `Jcs` (Journey Catalogue Sync)
- All entities extend `BaseEntity` for audit fields (`createdAt`, `updatedAt`)
- Foreign key relationships with cascade settings
- Entity names: nullable=false for externalId only; other fields (name, etc.) are nullable

## API Endpoints

### Webhook
- `POST /api/webhook/gitlab` - Receive GitLab webhook events

## Configuration

### Application Properties
- `application.yaml` - Main configuration (uses profiles)
- `.env.example` - Environment variable template

### Profiles
- `local` - Local development
- `dev` - Development environment
- `prod` - Production environment

## Key Dependencies

- **Spring Boot 4.1.1**: Framework
- **Spring Data JPA**: Data access
- **Liquibase**: Database migrations
- **MapStruct 1.5.5**: Object mapping
- **Apache Commons Compress**: File decompression
- **GitLab4j-API 4.19.1**: GitLab integration
- **JobRunR 8.7.0**: Job scheduling
- **Testcontainers 1.19.3**: Integration testing

## Code Standards

### Naming Conventions
- Entity classes: `Jcs*` (e.g., `JcsPlatform`, `JcsCapability`, `JcsJourney`, `JcsOutboxEvent`)
- Repository interfaces: `IJcs*Repository`
- DTO classes: `*Dto` suffix
- Service classes: `*Service` suffix
- Controller classes: `*Controller` suffix
- Job classes: `*Job` suffix
- Mapper interfaces: `*Mapper` suffix

### Layering Rules
- **Controller**: HTTP request handling → delegates to Facade/Service
- **Facade**: Orchestration → can call services and mappers
- **Service**: Business logic → can call repositories, helpers, providers, mappers
- **Repository**: Data access only
- **Helper**: Simple utility functions
- **Provider**: External service integration

## Testing

### Unit Tests
Located in `src/test/java`, use Mockito for mocking

### Integration Tests
Use Testcontainers for MySQL database testing

### Running Tests
```bash
make test              # All tests
make test-unit         # Unit tests only
make test-integration  # Integration tests
```

## Troubleshooting

### Database Connection Issues
1. Check MySQL container is running: `docker-compose ps`
2. Verify credentials in `application.yaml`
3. Check logs: `make logs`

### Port Conflicts
- Application: 8080
- MySQL: 3306
- Redis: 6379
- JobRunR Dashboard: 8081

If ports conflict, update `docker-compose.yml` or `application.yaml`

## Implemented Features

- ✅ GitLab file fetching and .tar.gz extraction
- ✅ File parsing with YAML frontmatter extraction
- ✅ Hierarchical parsing (Platform → Capability → Journey)
- ✅ Platform-context.md parsing for metadata
- ✅ Upsert logic for all artifact types
- ✅ JobRunR integration with immediate and recurring job processing
- ✅ Outbox event persistence with retry logic
- ✅ Name field as nullable (sourced only from context files)

## Future Enhancements

- Add authentication/authorization for webhook
- Add comprehensive logging and monitoring
- Add metrics/observability for job processing
- Implement event filtering and validation
- Add support for incremental updates
- Implement dead-letter queue for failed events
