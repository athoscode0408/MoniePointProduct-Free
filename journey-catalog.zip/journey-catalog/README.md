## Journey Catalogue Service

```
Phase 1: Webhook Reception
  ↓
GitLabWebhookParser extracts: projectId, branch, ref
  ↓
WebhookEventService saves to outbox (PENDING)
Return 200 OK to GitLab immediately
  ↓
Phase 2: File Fetching (async, triggered by JobRunR)
ProcessOutboxEventJob.processEvent(eventId)
  ├── Mark event as PROCESSING
  ├── Parse webhook payload
  │   ├── projectId = extracted from payload
  │   └── branch = extracted from ref field
  ↓
RepositoryFetchService.fetchAndExtractRepository(projectId, branch)
  ├── GitLabProvider.fetchRepositoryArchive()
  └── FileExtractionService.extractTarGz()
  ↓
Phase 3: File Parsing
RepositoryHierarchyParser.parseRepository()
  ├── YamlFrontmatterParser.parseFrontmatter()
  └── Build: List<PlatformDto> with complete hierarchy
  ↓
Phase 4: Upsert
JourneyUpsertService.upsertPlatforms(platforms)
  ├── For each platform:
  │   ├── findOrCreate
  │   ├── updateFields
  │   └── upsertCapabilities
  │       ├── For each capability:
  │       │   ├── findOrCreate
  │       │   ├── updateFields
  │       │   └── upsertJourneys
  │       │       └── For each journey:
  │       │           ├── findOrCreate
  │       │           └── updateFields
  ↓
Success:
  ├── Mark event as COMPLETED
  ├── Cleanup temp files
  └── Event stored with completion status
  
Failure:
  ├── Catch exception
  ├── Increment retry count
  ├── If retries < 3: Mark PENDING (retry later)
  ├── If retries >= 3: Mark FAILED
  └── Store error message
```