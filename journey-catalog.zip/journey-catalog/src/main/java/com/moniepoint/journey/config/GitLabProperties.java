package com.moniepoint.journey.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "gitlab")
@Getter
@Setter
public class GitLabProperties {
  private String url = "https://gitlab.com";
  private String token;
  private int connectionTimeout = 30000;
  private int readTimeout = 30000;

  public boolean hasValidToken() {
    return token != null && !token.isEmpty() && !token.equals("${GITLAB_TOKEN:}");
  }
}
