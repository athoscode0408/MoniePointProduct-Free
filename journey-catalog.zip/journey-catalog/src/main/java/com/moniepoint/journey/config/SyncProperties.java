package com.moniepoint.journey.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "sync")
@Getter
@Setter
public class SyncProperties {
  /** Matches any path segment shaped like an in-branch pre-release version folder. */
  private String branchExclusionPattern = "(^|/)in-branch-v\\d+\\.\\d+\\.\\d+(/|$)";

  private int lockTtlMinutes = 15;
}
