package com.moniepoint.journey.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

@Configuration
@RequiredArgsConstructor
public class WebClientConfig {
  private final GitLabProperties gitLabProperties;

  @Bean
  public RestClient restClient() {
    SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(gitLabProperties.getConnectionTimeout());
    factory.setReadTimeout(gitLabProperties.getReadTimeout());

    return RestClient.builder().requestFactory(factory).build();
  }
}
