package com.moniepoint.journey.controller;

import com.moniepoint.journey.facade.IntentCatalogueFacade;
import com.moniepoint.journey.model.dto.IntentGroupResponseDto;
import com.moniepoint.journey.model.dto.IntentResponseDto;
import com.moniepoint.journey.model.dto.PlatformResponseDto;
import com.moniepoint.journey.model.dto.ProductAreaResponseDto;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
public class IntentCatalogueController {
  private final IntentCatalogueFacade intentCatalogueFacade;

  @GetMapping("/intents")
  public Page<IntentResponseDto> searchIntents(
      @RequestParam(required = false) String platform,
      @RequestParam(required = false) String productArea,
      @RequestParam(required = false) String intentGroup,
      @RequestParam(required = false) String q,
      @RequestParam(defaultValue = "false") boolean includeInvalid,
      @PageableDefault(size = 20) Pageable pageable) {
    return intentCatalogueFacade.searchIntents(
        platform, productArea, intentGroup, q, includeInvalid, pageable);
  }

  @GetMapping("/intents/{code}")
  public IntentResponseDto getIntent(@PathVariable String code) {
    return intentCatalogueFacade.getIntent(code);
  }

  @GetMapping("/platforms")
  public List<PlatformResponseDto> listPlatforms(
      @RequestParam(defaultValue = "false") boolean includeInvalid) {
    return intentCatalogueFacade.listPlatforms(includeInvalid);
  }

  @GetMapping("/platforms/{code}")
  public PlatformResponseDto getPlatform(@PathVariable String code) {
    return intentCatalogueFacade.getPlatform(code);
  }

  @GetMapping("/product-areas")
  public List<ProductAreaResponseDto> listProductAreas(
      @RequestParam(required = false) String platform,
      @RequestParam(defaultValue = "false") boolean includeInvalid) {
    return intentCatalogueFacade.listProductAreas(platform, includeInvalid);
  }

  @GetMapping("/product-areas/{code}")
  public ProductAreaResponseDto getProductArea(@PathVariable String code) {
    return intentCatalogueFacade.getProductArea(code);
  }

  @GetMapping("/intent-groups")
  public List<IntentGroupResponseDto> listIntentGroups(
      @RequestParam(required = false) String productArea,
      @RequestParam(defaultValue = "false") boolean includeInvalid) {
    return intentCatalogueFacade.listIntentGroups(productArea, includeInvalid);
  }

  @GetMapping("/intent-groups/{code}")
  public IntentGroupResponseDto getIntentGroup(@PathVariable String code) {
    return intentCatalogueFacade.getIntentGroup(code);
  }
}
