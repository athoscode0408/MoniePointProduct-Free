package com.moniepoint.journey.controller;

import com.moniepoint.journey.helper.GitLabWebhookParser;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import com.moniepoint.journey.service.WebhookEventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/webhook")
@RequiredArgsConstructor
@Slf4j
public class WebhookController {
  private static final String PUSH_HOOK_EVENT = "Push Hook";

  private final WebhookEventService webhookEventService;
  private final GitLabWebhookParser gitLabWebhookParser;

  @PostMapping("/gitlab")
  public ResponseEntity<Void> handleGitlabWebhook(
      @RequestBody String payload,
      @RequestHeader(value = "X-Gitlab-Event", required = false) String gitlabEvent) {
    try {
      log.info("Received GitLab webhook event");

      if (!PUSH_HOOK_EVENT.equals(gitlabEvent)) {
        log.warn(
            "Ignoring webhook event with unsupported event type. Expected: {}, Received: {}",
            PUSH_HOOK_EVENT,
            gitlabEvent);
        return ResponseEntity.ok().build();
      }

      WebhookEventDto eventDto = gitLabWebhookParser.parseGitLabPushEvent(payload);
      webhookEventService.saveWebhookEvent(eventDto);

      return ResponseEntity.ok().build();
    } catch (Exception e) {
      log.error("Error processing webhook event", e);
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }
}
