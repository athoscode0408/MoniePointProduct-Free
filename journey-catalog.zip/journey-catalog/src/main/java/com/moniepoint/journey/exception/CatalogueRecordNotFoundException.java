package com.moniepoint.journey.exception;

public class CatalogueRecordNotFoundException extends RuntimeException {
  public CatalogueRecordNotFoundException(String message) {
    super(message);
  }
}
