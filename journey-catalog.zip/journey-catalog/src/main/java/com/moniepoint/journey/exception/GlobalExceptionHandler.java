package com.moniepoint.journey.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Scoped to the new read/search API; the existing webhook controller keeps its own try/catch. */
@RestControllerAdvice(basePackages = "com.moniepoint.journey.controller")
@Slf4j
public class GlobalExceptionHandler {
  @ExceptionHandler(CatalogueRecordNotFoundException.class)
  public ResponseEntity<String> handleNotFound(CatalogueRecordNotFoundException e) {
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<String> handleGeneric(Exception e) {
    log.error("Unhandled exception in catalogue API", e);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
  }
}
