package com.moniepoint.journey.exception;

public class ParseException extends RuntimeException {
  public ParseException(String message) {
    super(message);
  }

  public ParseException(String message, Throwable cause) {
    super(message, cause);
  }
}
