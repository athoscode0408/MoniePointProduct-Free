package com.moniepoint.journey.exception;

public class SystemicSyncFailureException extends RuntimeException {
  public SystemicSyncFailureException(String message) {
    super(message);
  }

  public SystemicSyncFailureException(String message, Throwable cause) {
    super(message, cause);
  }
}
