package com.moniepoint.journey.facade;

import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.notification.InvalidCatalogueRecord;
import com.moniepoint.journey.parser.ParsedRecordOutcome;
import com.moniepoint.journey.service.IntentCatalogueService;
import com.moniepoint.journey.service.PlatformCatalogueService;
import com.moniepoint.journey.service.ProductAreaCatalogueService;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
public class CatalogueSyncFacade {
  private final PlatformCatalogueService platformCatalogueService;
  private final ProductAreaCatalogueService productAreaCatalogueService;
  private final IntentCatalogueService intentCatalogueService;

  @Transactional
  public SyncRunResult syncCatalogue(List<ParsedRecordOutcome> records, String sourceProjectId) {
    List<InvalidCatalogueRecord> invalidRecords = new ArrayList<>();

    for (ParsedRecordOutcome record : records) {
      if (record instanceof ParsedRecordOutcome.Platform platformOutcome) {
        ValidationOutcome outcome =
            platformCatalogueService.upsert(platformOutcome.raw(), sourceProjectId);
        recordIfInvalid(
            invalidRecords,
            "PLATFORM",
            platformOutcome.raw().getCode(),
            platformOutcome.raw().getSourceFilePath(),
            outcome);
      }
    }

    for (ParsedRecordOutcome record : records) {
      if (record instanceof ParsedRecordOutcome.ProductArea productAreaOutcome) {
        ValidationOutcome outcome =
            productAreaCatalogueService.upsert(productAreaOutcome.raw(), sourceProjectId);
        recordIfInvalid(
            invalidRecords,
            "PRODUCT_AREA",
            productAreaOutcome.raw().getCode(),
            productAreaOutcome.raw().getSourceFilePath(),
            outcome);
      }
    }

    for (ParsedRecordOutcome record : records) {
      if (record instanceof ParsedRecordOutcome.Intent intentOutcome) {
        ValidationOutcome outcome =
            intentCatalogueService.upsert(intentOutcome.raw(), sourceProjectId);
        recordIfInvalid(
            invalidRecords,
            "INTENT",
            intentOutcome.raw().getCode(),
            intentOutcome.raw().getSourceFilePath(),
            outcome);
      }
    }

    return new SyncRunResult(invalidRecords);
  }

  private void recordIfInvalid(
      List<InvalidCatalogueRecord> sink,
      String entityType,
      String code,
      String sourceFilePath,
      ValidationOutcome outcome) {
    if (outcome.status() == ValidationStatus.INVALID) {
      sink.add(new InvalidCatalogueRecord(entityType, code, sourceFilePath, outcome.errors()));
    }
  }
}
