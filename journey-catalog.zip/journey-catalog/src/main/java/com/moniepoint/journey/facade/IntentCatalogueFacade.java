package com.moniepoint.journey.facade;

import com.moniepoint.journey.exception.CatalogueRecordNotFoundException;
import com.moniepoint.journey.model.dto.IntentGroupResponseDto;
import com.moniepoint.journey.model.dto.IntentResponseDto;
import com.moniepoint.journey.model.dto.NamedReferenceDto;
import com.moniepoint.journey.model.dto.PlatformResponseDto;
import com.moniepoint.journey.model.dto.ProductAreaResponseDto;
import com.moniepoint.journey.model.entity.Intent;
import com.moniepoint.journey.model.entity.IntentGroup;
import com.moniepoint.journey.model.entity.Platform;
import com.moniepoint.journey.model.entity.ProductArea;
import com.moniepoint.journey.service.IntentGroupQueryService;
import com.moniepoint.journey.service.IntentQueryService;
import com.moniepoint.journey.service.PlatformQueryService;
import com.moniepoint.journey.service.ProductAreaQueryService;
import com.moniepoint.journey.util.JsonSerializationUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class IntentCatalogueFacade {
  private final PlatformQueryService platformQueryService;
  private final ProductAreaQueryService productAreaQueryService;
  private final IntentGroupQueryService intentGroupQueryService;
  private final IntentQueryService intentQueryService;

  public Page<IntentResponseDto> searchIntents(
      String platformCode,
      String productAreaCode,
      String intentGroupCode,
      String query,
      boolean includeInvalid,
      Pageable pageable) {
    Page<Intent> page =
        intentQueryService.search(
            platformCode, productAreaCode, intentGroupCode, query, includeInvalid, pageable);

    Map<String, String> platformNames =
        platformNamesByCode(codesOf(page.getContent(), Intent::getPlatformCode));
    Map<String, String> productAreaNames =
        productAreaNamesByCode(codesOf(page.getContent(), Intent::getProductAreaCode));
    Map<String, String> intentGroupNames =
        intentGroupNamesByCode(codesOf(page.getContent(), Intent::getIntentGroupCode));

    return page.map(
        intent -> toIntentResponse(intent, platformNames, productAreaNames, intentGroupNames));
  }

  public IntentResponseDto getIntent(String code) {
    Intent intent =
        intentQueryService
            .findByCode(code)
            .orElseThrow(() -> new CatalogueRecordNotFoundException("Intent not found: " + code));
    return toIntentResponse(
        intent,
        platformNamesByCode(setOf(intent.getPlatformCode())),
        productAreaNamesByCode(setOf(intent.getProductAreaCode())),
        intentGroupNamesByCode(setOf(intent.getIntentGroupCode())));
  }

  public List<PlatformResponseDto> listPlatforms(boolean includeInvalid) {
    return platformQueryService.findAll(includeInvalid).stream()
        .map(this::toPlatformResponse)
        .toList();
  }

  public PlatformResponseDto getPlatform(String code) {
    return toPlatformResponse(
        platformQueryService
            .findByCode(code)
            .orElseThrow(
                () -> new CatalogueRecordNotFoundException("Platform not found: " + code)));
  }

  public List<ProductAreaResponseDto> listProductAreas(
      String platformCode, boolean includeInvalid) {
    List<ProductArea> productAreas = productAreaQueryService.search(platformCode, includeInvalid);
    Map<String, String> platformNames =
        platformNamesByCode(codesOf(productAreas, ProductArea::getPlatformCode));
    return productAreas.stream().map(pa -> toProductAreaResponse(pa, platformNames)).toList();
  }

  public ProductAreaResponseDto getProductArea(String code) {
    ProductArea productArea =
        productAreaQueryService
            .findByCode(code)
            .orElseThrow(
                () -> new CatalogueRecordNotFoundException("Product area not found: " + code));
    return toProductAreaResponse(
        productArea, platformNamesByCode(setOf(productArea.getPlatformCode())));
  }

  public List<IntentGroupResponseDto> listIntentGroups(
      String productAreaCode, boolean includeInvalid) {
    List<IntentGroup> intentGroups =
        intentGroupQueryService.search(productAreaCode, includeInvalid);
    Map<String, String> productAreaNames =
        productAreaNamesByCode(codesOf(intentGroups, IntentGroup::getProductAreaCode));
    return intentGroups.stream().map(ig -> toIntentGroupResponse(ig, productAreaNames)).toList();
  }

  public IntentGroupResponseDto getIntentGroup(String code) {
    IntentGroup intentGroup =
        intentGroupQueryService
            .findByCode(code)
            .orElseThrow(
                () -> new CatalogueRecordNotFoundException("Intent group not found: " + code));
    return toIntentGroupResponse(
        intentGroup, productAreaNamesByCode(setOf(intentGroup.getProductAreaCode())));
  }

  private IntentResponseDto toIntentResponse(
      Intent intent,
      Map<String, String> platformNames,
      Map<String, String> productAreaNames,
      Map<String, String> intentGroupNames) {
    return IntentResponseDto.builder()
        .code(intent.getCode())
        .name(intent.getName())
        .platform(reference(intent.getPlatformCode(), platformNames))
        .productArea(reference(intent.getProductAreaCode(), productAreaNames))
        .intentGroup(reference(intent.getIntentGroupCode(), intentGroupNames))
        .version(intent.getVersion())
        .status(intent.getStatus())
        .userTypes(JsonSerializationUtils.readListOrEmpty(intent.getUserTypes(), String.class))
        .channels(JsonSerializationUtils.readListOrEmpty(intent.getChannels(), String.class))
        .updatedAt(intent.getUpdatedAt())
        .build();
  }

  private PlatformResponseDto toPlatformResponse(Platform platform) {
    return PlatformResponseDto.builder()
        .code(platform.getCode())
        .name(platform.getName())
        .url(platform.getUrl())
        .channels(JsonSerializationUtils.readListOrEmpty(platform.getChannels(), String.class))
        .locales(JsonSerializationUtils.readListOrEmpty(platform.getLocales(), String.class))
        .updatedAt(platform.getUpdatedAt())
        .build();
  }

  private ProductAreaResponseDto toProductAreaResponse(
      ProductArea productArea, Map<String, String> platformNames) {
    return ProductAreaResponseDto.builder()
        .code(productArea.getCode())
        .name(productArea.getName())
        .platform(reference(productArea.getPlatformCode(), platformNames))
        .url(productArea.getUrl())
        .pagesUrl(productArea.getPagesUrl())
        .jiraProjectKey(productArea.getJiraProjectKey())
        .updatedAt(productArea.getUpdatedAt())
        .build();
  }

  private IntentGroupResponseDto toIntentGroupResponse(
      IntentGroup intentGroup, Map<String, String> productAreaNames) {
    return IntentGroupResponseDto.builder()
        .code(intentGroup.getCode())
        .name(intentGroup.getName())
        .productArea(reference(intentGroup.getProductAreaCode(), productAreaNames))
        .updatedAt(intentGroup.getUpdatedAt())
        .build();
  }

  private NamedReferenceDto reference(String code, Map<String, String> namesByCode) {
    if (code == null) {
      return null;
    }
    return NamedReferenceDto.builder().code(code).name(namesByCode.get(code)).build();
  }

  private Map<String, String> platformNamesByCode(Set<String> codes) {
    Map<String, String> names = new HashMap<>();
    platformQueryService.findByCodes(codes).forEach(p -> names.put(p.getCode(), p.getName()));
    return names;
  }

  private Map<String, String> productAreaNamesByCode(Set<String> codes) {
    Map<String, String> names = new HashMap<>();
    productAreaQueryService.findByCodes(codes).forEach(pa -> names.put(pa.getCode(), pa.getName()));
    return names;
  }

  private Map<String, String> intentGroupNamesByCode(Set<String> codes) {
    Map<String, String> names = new HashMap<>();
    intentGroupQueryService.findByCodes(codes).forEach(ig -> names.put(ig.getCode(), ig.getName()));
    return names;
  }

  private <T> Set<String> codesOf(
      List<T> items, java.util.function.Function<T, String> codeGetter) {
    return items.stream().map(codeGetter).filter(Objects::nonNull).collect(Collectors.toSet());
  }

  private Set<String> setOf(String code) {
    return code == null ? Set.of() : Set.of(code);
  }
}
