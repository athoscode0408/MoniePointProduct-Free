package com.moniepoint.journey.facade;

import com.moniepoint.journey.notification.InvalidCatalogueRecord;
import java.util.List;

public record SyncRunResult(List<InvalidCatalogueRecord> invalidRecords) {}
