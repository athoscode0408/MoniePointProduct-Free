package com.moniepoint.journey.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.model.dto.CommitAuthorDto;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class GitLabWebhookParser {
  private static final String REF = "ref";
  private static final String REFS_HEADS = "refs/heads/";
  private static final String SHA = "checkout_sha";
  private static final String USER_ID = "user_id";
  private static final String EVENT_TYPE = "push";
  private static final String EVENT_ID = "event_id";
  private static final String PROJECT_ID = "project_id";
  private static final String PROJECT = "project";
  private static final String PROJECT_NAME = "project_name";
  private static final String OBJECT_KIND = "object_kind";
  private static final String DEFAULT_VALUE = "webhook";
  private static final String ID = "id";
  private static final String NAME = "name";
  private static final String TAG = "tag";
  private static final String REFS_TAGS = "refs/tags/";
  private static final String COMMITS = "commits";
  private static final String AUTHOR = "author";
  private static final String EMAIL = "email";
  private final ObjectMapper objectMapper;

  public WebhookEventDto parseGitLabPushEvent(String payload) {
    try {
      JsonNode rootNode = objectMapper.readTree(payload);

      String eventId = extractEventId(rootNode);
      String projectId = extractProjectId(rootNode);
      String projectName = extractProjectName(rootNode);
      String ref = rootNode.path(REF).asText();
      String branch = ref.replace(REFS_HEADS, "");
      String checkoutSha = rootNode.path(SHA).asText();
      String userId = rootNode.path(USER_ID).asText("");
      List<CommitAuthorDto> commitAuthors = extractCommitAuthors(rootNode);

      log.info(
          "Parsed GitLab push webhook - eventId: {}, projectId: {}, branch: {}",
          eventId,
          projectId,
          branch);

      return WebhookEventDto.builder()
          .eventId(eventId)
          .eventType(EVENT_TYPE)
          .projectId(projectId)
          .projectName(projectName)
          .branch(branch)
          .ref(ref)
          .checkoutSha(checkoutSha)
          .userId(userId)
          .timestamp(System.currentTimeMillis())
          .rawPayload(payload)
          .commitAuthors(commitAuthors)
          .build();
    } catch (Exception e) {
      log.error("Error parsing GitLab webhook payload", e);
      throw new RuntimeException("Failed to parse GitLab webhook payload", e);
    }
  }

  private String extractEventId(JsonNode rootNode) {
    String gitLabEventId = rootNode.path(EVENT_ID).asText("");
    if (!gitLabEventId.isEmpty()) {
      return gitLabEventId;
    }

    String objectKind = rootNode.path(OBJECT_KIND).asText(DEFAULT_VALUE);
    String timestamp = String.valueOf(System.currentTimeMillis());
    return String.format("%s-%s-%s", objectKind, rootNode.path(PROJECT_ID).asText(), timestamp);
  }

  private String extractProjectId(JsonNode rootNode) {
    String projectId = rootNode.path(PROJECT_ID).asText("");
    if (projectId.isEmpty()) {
      projectId = rootNode.path(PROJECT).path(ID).asText("");
    }
    if (projectId.isEmpty()) {
      throw new IllegalArgumentException("project_id not found in webhook payload");
    }
    return projectId;
  }

  private String extractProjectName(JsonNode rootNode) {
    String projectName = rootNode.path(PROJECT).path(NAME).asText("");
    if (projectName.isEmpty()) {
      projectName = rootNode.path(PROJECT_NAME).asText("");
    }
    return projectName;
  }

  /**
   * GitLab only attributes authorship at the push (commit) level, not per file, so this is the
   * finest-grained attribution available for notifying about an invalid record.
   */
  private List<CommitAuthorDto> extractCommitAuthors(JsonNode rootNode) {
    List<CommitAuthorDto> authors = new ArrayList<>();
    for (JsonNode commit : rootNode.path(COMMITS)) {
      JsonNode author = commit.path(AUTHOR);
      String name = author.path(NAME).asText("");
      String email = author.path(EMAIL).asText("");
      if (!name.isEmpty() || !email.isEmpty()) {
        authors.add(CommitAuthorDto.builder().name(name).email(email).build());
      }
    }
    return authors;
  }

  public WebhookEventDto parseGitLabTagEvent(String payload) {
    try {
      JsonNode rootNode = objectMapper.readTree(payload);

      String eventId = extractEventId(rootNode);
      String projectId = extractProjectId(rootNode);
      String projectName = extractProjectName(rootNode);
      String ref = rootNode.path(REF).asText();
      String tag = ref.replace(REFS_TAGS, "");
      String checkoutSha = rootNode.path(SHA).asText();

      log.info(
          "Parsed GitLab tag webhook - eventId: {}, projectId: {}, tag: {}",
          eventId,
          projectId,
          tag);

      return WebhookEventDto.builder()
          .eventId(eventId)
          .eventType(TAG)
          .projectId(projectId)
          .projectName(projectName)
          .branch(tag)
          .ref(ref)
          .checkoutSha(checkoutSha)
          .timestamp(System.currentTimeMillis())
          .rawPayload(payload)
          .build();
    } catch (Exception e) {
      log.error("Error parsing GitLab tag webhook payload", e);
      throw new RuntimeException("Failed to parse GitLab tag webhook payload", e);
    }
  }
}
