package com.moniepoint.journey.helper;

import com.moniepoint.journey.model.dto.IntentGroupDeclarationDto;
import com.moniepoint.journey.model.entity.IntentGroup;
import com.moniepoint.journey.repository.IIntentGroupRepository;
import com.moniepoint.journey.util.JsonSerializationUtils;
import com.moniepoint.journey.validation.CatalogueValidationRules;
import com.moniepoint.journey.validation.ValidationOutcome;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
public class IntentGroupUpsertHelper {
  private final IIntentGroupRepository intentGroupRepository;

  @Transactional
  public void applyDeclaration(
      IntentGroupDeclarationDto declaration,
      String productAreaCode,
      String sourceProjectId,
      String sourceFilePath) {
    ValidationOutcome outcome =
        CatalogueValidationRules.validateIntentGroup(declaration.getName(), productAreaCode);

    IntentGroup group =
        intentGroupRepository
            .findByCode(declaration.getCode())
            .orElseGet(() -> IntentGroup.builder().code(declaration.getCode()).build());
    group.setName(declaration.getName());
    group.setProductAreaCode(productAreaCode);
    group.setValidationStatus(outcome.status());
    group.setValidationErrors(JsonSerializationUtils.toJsonOrNull(outcome.errors()));
    group.setSourceProjectId(sourceProjectId);
    group.setSourceFilePath(sourceFilePath);
    intentGroupRepository.saveAndFlush(group);
  }

  /** Never downgrades an already-declared group back to an unresolved shell. */
  @Transactional
  public void ensureShellExists(String code, String sourceProjectId) {
    if (intentGroupRepository.findByCode(code).isPresent()) {
      return;
    }
    ValidationOutcome outcome = CatalogueValidationRules.validateIntentGroup(null, null);
    IntentGroup shell =
        IntentGroup.builder()
            .code(code)
            .validationStatus(outcome.status())
            .validationErrors(JsonSerializationUtils.toJsonOrNull(outcome.errors()))
            .sourceProjectId(sourceProjectId)
            .build();
    intentGroupRepository.saveAndFlush(shell);
  }
}
