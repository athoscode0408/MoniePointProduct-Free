package com.moniepoint.journey.job;

public interface IJob {
  void execute();
}
