package com.moniepoint.journey.job;

import com.moniepoint.journey.exception.SystemicSyncFailureException;
import com.moniepoint.journey.facade.CatalogueSyncFacade;
import com.moniepoint.journey.facade.SyncRunResult;
import com.moniepoint.journey.helper.GitLabWebhookParser;
import com.moniepoint.journey.model.dto.RepositoryArchiveDto;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import com.moniepoint.journey.model.entity.OutboxEvent;
import com.moniepoint.journey.notification.InvalidCatalogueRecord;
import com.moniepoint.journey.notification.SyncFailureAlerter;
import com.moniepoint.journey.notification.SyncFailureContext;
import com.moniepoint.journey.notification.ValidationNotifier;
import com.moniepoint.journey.parser.CatalogueParseResult;
import com.moniepoint.journey.parser.IntentCatalogueRepositoryParser;
import com.moniepoint.journey.service.OutboxEventStatusService;
import com.moniepoint.journey.service.RepositoryFetchService;
import com.moniepoint.journey.service.SyncLockService;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.jobs.annotations.Job;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
@Slf4j
public class ProcessOutboxEventJob {
  private final OutboxEventStatusService outboxEventStatusService;
  private final RepositoryFetchService repositoryFetchService;
  private final IntentCatalogueRepositoryParser catalogueParser;
  private final CatalogueSyncFacade catalogueSyncFacade;
  private final GitLabWebhookParser webhookParser;
  private final SyncLockService syncLockService;
  private final ValidationNotifier validationNotifier;
  private final SyncFailureAlerter syncFailureAlerter;

  @Job(name = "Process outbox event")
  @Transactional
  public void execute(Long eventId) {
    if (!outboxEventStatusService.claimForProcessing(eventId)) {
      log.debug("Event {} is not PENDING (already claimed or processed), skipping", eventId);
      return;
    }

    OutboxEvent event = outboxEventStatusService.getEvent(eventId);
    String projectId = null;
    String branch = null;
    String lockToken = null;

    try {
      WebhookEventDto webhookEvent = webhookParser.parseGitLabPushEvent(event.getPayload());
      projectId = webhookEvent.getProjectId();
      branch = webhookEvent.getBranch();

      Optional<String> acquiredToken = syncLockService.tryAcquire(projectId);
      if (acquiredToken.isEmpty()) {
        log.info("Sync already in progress for project {}, deferring event {}", projectId, eventId);
        outboxEventStatusService.releaseBackToPendingWithoutPenalty(eventId);
        return;
      }
      lockToken = acquiredToken.get();

      if (!repositoryFetchService.isDefaultBranch(projectId, branch)) {
        log.info("Skipping non-default-branch push for project {} (branch: {})", projectId, branch);
        outboxEventStatusService.markCompleted(eventId);
        return;
      }

      processEventInternal(projectId, branch, webhookEvent);

      outboxEventStatusService.markCompleted(eventId);
      log.info("Successfully processed event: {}", eventId);
    } catch (Exception e) {
      handleEventFailure(eventId, projectId, branch, e);
    } finally {
      if (lockToken != null) {
        syncLockService.release(projectId, lockToken);
      }
    }
  }

  private void processEventInternal(String projectId, String branch, WebhookEventDto webhookEvent) {
    RepositoryArchiveDto archive = null;
    try {
      archive =
          repositoryFetchService.fetchAndExtractRepository(
              projectId, branch, null, webhookEvent.getCheckoutSha());

      CatalogueParseResult parseResult =
          catalogueParser.parseRepository(archive.getExtractedPath());

      if (parseResult.hasUnparseableFiles()) {
        throw new SystemicSyncFailureException(
            "Sync aborted for project "
                + projectId
                + ": "
                + parseResult.unparseableFiles().size()
                + " unparseable file(s): "
                + parseResult.unparseableFiles());
      }

      SyncRunResult syncRunResult =
          catalogueSyncFacade.syncCatalogue(parseResult.records(), projectId);

      for (InvalidCatalogueRecord invalidRecord : syncRunResult.invalidRecords()) {
        validationNotifier.notifyInvalidRecord(invalidRecord, webhookEvent.getCommitAuthors());
      }
    } finally {
      if (archive != null) {
        repositoryFetchService.cleanupExtractedRepository(archive.getExtractedPath());
      }
    }
  }

  private void handleEventFailure(Long eventId, String projectId, String branch, Exception e) {
    syncFailureAlerter.alertSyncFailure(
        new SyncFailureContext(projectId, branch, e.getMessage(), e));
    try {
      outboxEventStatusService.markFailed(eventId, e);
    } catch (Exception ex) {
      log.error("Error handling event failure for eventId: {}", eventId, ex);
    }
  }
}
