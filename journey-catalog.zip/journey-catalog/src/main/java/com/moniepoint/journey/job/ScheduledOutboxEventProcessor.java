package com.moniepoint.journey.job;

import com.moniepoint.journey.model.entity.OutboxEvent;
import com.moniepoint.journey.service.OutboxEventStatusService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.jobs.annotations.Recurring;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
@Slf4j
public class ScheduledOutboxEventProcessor implements IJob {
  private final OutboxEventStatusService outboxEventStatusService;
  private final JobScheduler jobScheduler;
  private final ProcessOutboxEventJob processOutboxEventJob;

  @Recurring(id = "scheduled-outbox-events-job", cron = "*/1 * * * *") // every minute
  @Job(name = "Scheduled outbox events job")
  @Transactional
  @Override
  public void execute() {
    try {
      log.debug("Checking for pending outbox events");
      List<OutboxEvent> pendingEvents = outboxEventStatusService.findPendingEvents();

      if (pendingEvents.isEmpty()) {
        log.debug("No pending events found");
      } else {
        log.info("Found {} pending events to process", pendingEvents.size());
        for (OutboxEvent event : pendingEvents) {
          jobScheduler.enqueue(() -> processOutboxEventJob.execute(event.getId()));
        }
      }
    } catch (Exception e) {
      log.error("Error processing pending events", e);
    }

    try {
      outboxEventStatusService.resetStaleProcessingEvents();
    } catch (Exception e) {
      log.error("Error resetting stale processing events", e);
    }
  }
}
