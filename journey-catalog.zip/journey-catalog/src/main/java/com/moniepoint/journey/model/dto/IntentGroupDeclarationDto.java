package com.moniepoint.journey.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** One {id, name} entry from a product-area.md's `intent_groups` list. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntentGroupDeclarationDto {
  private String code;
  private String name;
}
