package com.moniepoint.journey.model.dto;

import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntentGroupResponseDto {
  private String code;
  private String name;
  private NamedReferenceDto productArea;
  private OffsetDateTime updatedAt;
}
