package com.moniepoint.journey.model.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Structurally-extracted content of an intent.md file, before validation. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntentRawRecordDto {
  private String code;
  private String name;
  private String platformCode;
  private String productAreaCode;
  private String intentGroupCode;
  private String version;
  private String status;
  private List<String> userTypes;
  private List<String> channels;
  private String sourceFilePath;
}
