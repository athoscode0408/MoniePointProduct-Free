package com.moniepoint.journey.model.dto;

import java.time.OffsetDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntentResponseDto {
  private String code;
  private String name;
  private NamedReferenceDto platform;
  private NamedReferenceDto productArea;
  private NamedReferenceDto intentGroup;
  private String version;
  private String status;
  private List<String> userTypes;
  private List<String> channels;
  private OffsetDateTime updatedAt;
}
