package com.moniepoint.journey.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** A parent reference in an API response: the raw code, plus its name if resolvable. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NamedReferenceDto {
  private String code;
  private String name;
}
