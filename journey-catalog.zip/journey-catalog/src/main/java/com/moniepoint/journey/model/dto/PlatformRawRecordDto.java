package com.moniepoint.journey.model.dto;

import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Structurally-extracted content of a platform.md file, before validation. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlatformRawRecordDto {
  private String code;
  private String name;
  private String url;
  private List<String> channels;
  private List<String> locales;
  private Map<String, Object> metadata;
  private String sourceFilePath;
}
