package com.moniepoint.journey.model.dto;

import java.time.OffsetDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlatformResponseDto {
  private String code;
  private String name;
  private String url;
  private List<String> channels;
  private List<String> locales;
  private OffsetDateTime updatedAt;
}
