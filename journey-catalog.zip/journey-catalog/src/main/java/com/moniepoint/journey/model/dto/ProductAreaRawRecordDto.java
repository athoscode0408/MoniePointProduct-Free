package com.moniepoint.journey.model.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Structurally-extracted content of a product-area.md file, before validation. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductAreaRawRecordDto {
  private String code;
  private String platformCode;
  private String name;
  private String url;
  private String pagesUrl;
  private String jiraProjectKey;
  private List<IntentGroupDeclarationDto> intentGroups;
  private String sourceFilePath;
}
