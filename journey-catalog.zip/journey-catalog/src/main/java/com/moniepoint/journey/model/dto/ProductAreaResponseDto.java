package com.moniepoint.journey.model.dto;

import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductAreaResponseDto {
  private String code;
  private String name;
  private NamedReferenceDto platform;
  private String url;
  private String pagesUrl;
  private String jiraProjectKey;
  private OffsetDateTime updatedAt;
}
