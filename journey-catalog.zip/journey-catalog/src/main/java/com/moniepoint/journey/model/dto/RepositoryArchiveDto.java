package com.moniepoint.journey.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepositoryArchiveDto {
  private String extractedPath;
  private String branch;
  private String tag;
  private long timestamp;

  public RepositoryArchiveDto(String extractedPath, String branch) {
    this.extractedPath = extractedPath;
    this.branch = branch;
    this.timestamp = System.currentTimeMillis();
  }
}
