package com.moniepoint.journey.model.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WebhookEventDto {
  private String eventId;
  private String eventType;
  private String projectId;
  private String projectName;
  private String branch;
  private String ref;
  private String checkoutSha;
  private String userId;
  private long timestamp;
  private String rawPayload;
  private List<CommitAuthorDto> commitAuthors;
}
