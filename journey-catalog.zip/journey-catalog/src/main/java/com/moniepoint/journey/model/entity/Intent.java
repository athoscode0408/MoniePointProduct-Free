package com.moniepoint.journey.model.entity;

import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * platformCode/productAreaCode/intentGroupCode are plain references (no foreign-key constraint, no
 * JPA relationship) — the referenced parent row may not exist yet.
 */
@Entity
@Table(name = "intent")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Intent extends BaseEntity {
  @Column(name = "code", nullable = false, unique = true)
  private String code;

  @Column(name = "name")
  private String name;

  @Column(name = "platform_code")
  private String platformCode;

  @Column(name = "product_area_code")
  private String productAreaCode;

  @Column(name = "intent_group_code")
  private String intentGroupCode;

  @Column(name = "version", length = 50)
  private String version;

  @Column(name = "status", length = 50)
  private String status;

  @Column(name = "user_types", columnDefinition = "JSON")
  private String userTypes;

  @Column(name = "channels", columnDefinition = "JSON")
  private String channels;

  @Enumerated(EnumType.STRING)
  @Column(name = "validation_status", nullable = false, length = 20)
  private ValidationStatus validationStatus;

  @Column(name = "validation_errors", columnDefinition = "JSON")
  private String validationErrors;

  @Column(name = "source_project_id")
  private String sourceProjectId;

  @Column(name = "source_file_path", length = 1000)
  private String sourceFilePath;
}
