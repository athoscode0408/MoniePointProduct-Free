package com.moniepoint.journey.model.entity;

import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * There is no dedicated intent-group file type. name/productAreaCode are only ever set when a
 * product-area.md declares this group in its `intent_groups` list; a group referenced only by an
 * intent.md's `intent_group` field before any such declaration exists as a "shell" row with
 * name/productAreaCode left null, which is the correct unresolved-reference state, not a bug.
 */
@Entity
@Table(name = "intent_group")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IntentGroup extends BaseEntity {
  @Column(name = "code", nullable = false, unique = true)
  private String code;

  @Column(name = "name")
  private String name;

  @Column(name = "product_area_code")
  private String productAreaCode;

  @Enumerated(EnumType.STRING)
  @Column(name = "validation_status", nullable = false, length = 20)
  private ValidationStatus validationStatus;

  @Column(name = "validation_errors", columnDefinition = "JSON")
  private String validationErrors;

  @Column(name = "source_project_id")
  private String sourceProjectId;

  @Column(name = "source_file_path", length = 1000)
  private String sourceFilePath;
}
