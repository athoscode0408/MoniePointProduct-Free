package com.moniepoint.journey.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
    name = "outbox_event",
    indexes = {
      @Index(name = "idx_status", columnList = "status"),
      @Index(name = "idx_created_at", columnList = "created_at")
    })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutboxEvent extends BaseEntity {
  @Column(name = "event_type", nullable = false, length = 50)
  private String eventType;

  @Column(name = "payload", nullable = false, columnDefinition = "LONGTEXT")
  private String payload;

  @Column(name = "external_event_id", nullable = false, unique = true)
  private String externalEventId;

  @Enumerated(EnumType.STRING)
  @Column(name = "status", nullable = false, length = 50)
  private EventStatus status;

  @Column(name = "error_message", columnDefinition = "TEXT")
  private String errorMessage;

  @Column(name = "retry_count")
  private Integer retryCount;

  @Column(name = "next_retry_time")
  private Instant nextRetryTime;

  public enum EventStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
  }
}
