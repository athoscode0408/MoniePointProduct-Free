package com.moniepoint.journey.model.entity;

import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "platform")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Platform extends BaseEntity {
  @Column(name = "code", nullable = false, unique = true)
  private String code;

  @Column(name = "name")
  private String name;

  @Column(name = "url", length = 500)
  private String url;

  @Column(name = "channels", columnDefinition = "JSON")
  private String channels;

  @Column(name = "locales", columnDefinition = "JSON")
  private String locales;

  @Column(name = "metadata", columnDefinition = "JSON")
  private String metadata;

  @Enumerated(EnumType.STRING)
  @Column(name = "validation_status", nullable = false, length = 20)
  private ValidationStatus validationStatus;

  @Column(name = "validation_errors", columnDefinition = "JSON")
  private String validationErrors;

  @Column(name = "source_project_id")
  private String sourceProjectId;

  @Column(name = "source_file_path", length = 1000)
  private String sourceFilePath;
}
