package com.moniepoint.journey.model.entity;

import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * platformCode is a plain reference (the code as it appears in product-area.md's `platform` field)
 * with no foreign-key constraint and no JPA relationship — the referenced Platform row may not
 * exist yet.
 */
@Entity
@Table(name = "product_area")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductArea extends BaseEntity {
  @Column(name = "code", nullable = false, unique = true)
  private String code;

  @Column(name = "platform_code")
  private String platformCode;

  @Column(name = "name")
  private String name;

  @Column(name = "url", length = 500)
  private String url;

  @Column(name = "pages_url", length = 500)
  private String pagesUrl;

  @Column(name = "jira_project_key", length = 100)
  private String jiraProjectKey;

  @Enumerated(EnumType.STRING)
  @Column(name = "validation_status", nullable = false, length = 20)
  private ValidationStatus validationStatus;

  @Column(name = "validation_errors", columnDefinition = "JSON")
  private String validationErrors;

  @Column(name = "source_project_id")
  private String sourceProjectId;

  @Column(name = "source_file_path", length = 1000)
  private String sourceFilePath;
}
