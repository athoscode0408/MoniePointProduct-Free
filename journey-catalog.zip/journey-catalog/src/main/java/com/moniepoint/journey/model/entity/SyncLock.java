package com.moniepoint.journey.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "sync_lock")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncLock extends BaseEntity {
  @Column(name = "project_id", nullable = false, unique = true)
  private String projectId;

  @Column(name = "holder_token", nullable = false)
  private String holderToken;

  @Column(name = "acquired_at", nullable = false)
  private Instant acquiredAt;

  @Column(name = "expires_at", nullable = false)
  private Instant expiresAt;
}
