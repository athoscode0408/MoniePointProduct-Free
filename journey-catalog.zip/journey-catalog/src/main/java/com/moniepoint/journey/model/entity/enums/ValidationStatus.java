package com.moniepoint.journey.model.entity.enums;

public enum ValidationStatus {
  VALID,
  INVALID
}
