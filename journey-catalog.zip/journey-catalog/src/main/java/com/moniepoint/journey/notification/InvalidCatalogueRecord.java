package com.moniepoint.journey.notification;

import com.moniepoint.journey.model.dto.ValidationErrorDto;
import java.util.List;

public record InvalidCatalogueRecord(
    String entityType, String code, String sourceFilePath, List<ValidationErrorDto> errors) {}
