package com.moniepoint.journey.notification;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class LoggingSyncFailureAlerter implements SyncFailureAlerter {
  @Override
  public void alertSyncFailure(SyncFailureContext context) {
    log.error(
        "SYNC_FAILURE project: {}, branch: {}, reason: {}",
        context.projectId(),
        context.branch(),
        context.reason(),
        context.cause());
  }
}
