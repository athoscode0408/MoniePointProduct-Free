package com.moniepoint.journey.notification;

import com.moniepoint.journey.model.dto.CommitAuthorDto;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class LoggingValidationNotifier implements ValidationNotifier {
  @Override
  public void notifyInvalidRecord(
      InvalidCatalogueRecord record, List<CommitAuthorDto> possibleAuthors) {
    log.warn(
        "Invalid catalogue record synced - type: {}, code: {}, file: {}, errors: {}, possibleAuthors: {}",
        record.entityType(),
        record.code(),
        record.sourceFilePath(),
        record.errors(),
        possibleAuthors);
  }
}
