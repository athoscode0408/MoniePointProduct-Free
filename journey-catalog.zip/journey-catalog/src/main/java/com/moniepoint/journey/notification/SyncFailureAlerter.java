package com.moniepoint.journey.notification;

/**
 * Extension point for alerting on a systemic sync failure (as opposed to a single invalid record,
 * which is a normal outcome). No alerting infra exists yet — deliberately left as a placeholder
 * (see LoggingSyncFailureAlerter).
 */
public interface SyncFailureAlerter {
  void alertSyncFailure(SyncFailureContext context);
}
