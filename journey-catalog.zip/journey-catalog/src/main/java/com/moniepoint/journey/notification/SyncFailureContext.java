package com.moniepoint.journey.notification;

public record SyncFailureContext(String projectId, String branch, String reason, Throwable cause) {}
