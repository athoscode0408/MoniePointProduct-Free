package com.moniepoint.journey.notification;

import com.moniepoint.journey.model.dto.CommitAuthorDto;
import java.util.List;

/**
 * Extension point for notifying an author/team about a record that was synced with
 * validation_status=INVALID. No Slack/email integration exists yet — deliberately left as a
 * placeholder (see LoggingValidationNotifier).
 */
public interface ValidationNotifier {
  void notifyInvalidRecord(InvalidCatalogueRecord record, List<CommitAuthorDto> possibleAuthors);
}
