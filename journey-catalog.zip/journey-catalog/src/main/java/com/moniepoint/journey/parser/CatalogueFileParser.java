package com.moniepoint.journey.parser;

public interface CatalogueFileParser {
  boolean supports(String relativeFilePath);

  ParsedFileOutcome parse(String relativeFilePath, String fileContent);
}
