package com.moniepoint.journey.parser;

import java.util.List;

public record CatalogueParseResult(
    int matchedFileCount,
    List<ParsedRecordOutcome> records,
    List<UnparseableFileOutcome> unparseableFiles) {

  public boolean hasUnparseableFiles() {
    return !unparseableFiles.isEmpty();
  }
}
