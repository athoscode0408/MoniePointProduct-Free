package com.moniepoint.journey.parser;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Shared, tolerant field extraction used by all three CatalogueFileParser implementations. */
final class FrontmatterUtils {
  private FrontmatterUtils() {}

  static Optional<String> text(JsonNode frontmatter, String field) {
    JsonNode value = frontmatter.path(field);
    if (value.isMissingNode() || value.isNull()) {
      return Optional.empty();
    }
    String text = value.asText().trim();
    return text.isEmpty() ? Optional.empty() : Optional.of(text);
  }

  static List<String> stringList(JsonNode frontmatter, String field) {
    List<String> values = new ArrayList<>();
    JsonNode arrayNode = frontmatter.path(field);
    if (arrayNode.isArray()) {
      arrayNode.forEach(item -> values.add(item.asText()));
    }
    return values;
  }
}
