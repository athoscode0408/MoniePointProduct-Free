package com.moniepoint.journey.parser;

import com.moniepoint.journey.config.SyncProperties;
import com.moniepoint.journey.service.FileExtractionService;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class IntentCatalogueRepositoryParser {
  private static final String MARKDOWN_SUFFIX = ".md";

  private final FileExtractionService fileExtractionService;
  private final List<CatalogueFileParser> fileParsers;
  private final SyncProperties syncProperties;

  public CatalogueParseResult parseRepository(String extractedPath) {
    Set<String> allFiles =
        fileExtractionService.listFilesRecursively(extractedPath, MARKDOWN_SUFFIX);
    Pattern exclusionPattern = Pattern.compile(syncProperties.getBranchExclusionPattern());

    List<ParsedRecordOutcome> records = new ArrayList<>();
    List<UnparseableFileOutcome> unparseableFiles = new ArrayList<>();
    int matchedFileCount = 0;

    for (String relativePath : allFiles) {
      if (exclusionPattern.matcher(relativePath).find()) {
        log.debug("Excluding in-branch-version-folder file: {}", relativePath);
        continue;
      }

      CatalogueFileParser parser = findParser(relativePath);
      if (parser == null) {
        continue;
      }
      matchedFileCount++;

      String absolutePath = Path.of(extractedPath, relativePath).toString();
      Optional<String> content = fileExtractionService.readFileContentSilent(absolutePath);
      if (content.isEmpty()) {
        unparseableFiles.add(
            new UnparseableFileOutcome(relativePath, "Unable to read file content"));
        continue;
      }

      try {
        ParsedFileOutcome outcome = parser.parse(relativePath, content.get());
        if (outcome instanceof ParsedRecordOutcome recordOutcome) {
          records.add(recordOutcome);
        } else if (outcome instanceof UnparseableFileOutcome unparseableOutcome) {
          unparseableFiles.add(unparseableOutcome);
        }
      } catch (Exception e) {
        log.error("Unexpected error parsing file: {}", relativePath, e);
        unparseableFiles.add(new UnparseableFileOutcome(relativePath, e.getMessage()));
      }
    }

    if (matchedFileCount == 0) {
      log.info("Sync run found zero files of interest in repository at: {}", extractedPath);
    }

    return new CatalogueParseResult(matchedFileCount, records, unparseableFiles);
  }

  private CatalogueFileParser findParser(String relativePath) {
    for (CatalogueFileParser parser : fileParsers) {
      if (parser.supports(relativePath)) {
        return parser;
      }
    }
    return null;
  }
}
