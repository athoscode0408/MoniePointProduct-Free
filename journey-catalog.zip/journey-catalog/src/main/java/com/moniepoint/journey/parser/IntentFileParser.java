package com.moniepoint.journey.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.journey.exception.ParseException;
import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class IntentFileParser implements CatalogueFileParser {
  private static final String FILE_NAME = "intent.md";

  private final YamlFrontmatterParser yamlFrontmatterParser;

  @Override
  public boolean supports(String relativeFilePath) {
    return relativeFilePath.equals(FILE_NAME) || relativeFilePath.endsWith("/" + FILE_NAME);
  }

  @Override
  public ParsedFileOutcome parse(String relativeFilePath, String fileContent) {
    JsonNode frontmatter;
    try {
      frontmatter = yamlFrontmatterParser.parseFrontmatter(fileContent);
    } catch (ParseException e) {
      return new UnparseableFileOutcome(relativeFilePath, e.getMessage());
    }

    var code = FrontmatterUtils.text(frontmatter, "intent");
    if (code.isEmpty()) {
      return new UnparseableFileOutcome(
          relativeFilePath, "intent.md missing required 'intent' identity field");
    }

    IntentRawRecordDto raw =
        IntentRawRecordDto.builder()
            .code(code.get())
            .name(FrontmatterUtils.text(frontmatter, "name").orElse(null))
            .platformCode(FrontmatterUtils.text(frontmatter, "platform").orElse(null))
            .productAreaCode(FrontmatterUtils.text(frontmatter, "product_area").orElse(null))
            .intentGroupCode(FrontmatterUtils.text(frontmatter, "intent_group").orElse(null))
            .version(FrontmatterUtils.text(frontmatter, "version").orElse(null))
            .status(FrontmatterUtils.text(frontmatter, "status").orElse(null))
            .userTypes(FrontmatterUtils.stringList(frontmatter, "user_types"))
            .channels(FrontmatterUtils.stringList(frontmatter, "channels"))
            .sourceFilePath(relativeFilePath)
            .build();

    return new ParsedRecordOutcome.Intent(raw);
  }
}
