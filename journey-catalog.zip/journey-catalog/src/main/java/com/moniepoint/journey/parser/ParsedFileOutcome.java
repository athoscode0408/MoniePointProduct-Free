package com.moniepoint.journey.parser;

public sealed interface ParsedFileOutcome permits ParsedRecordOutcome, UnparseableFileOutcome {}
