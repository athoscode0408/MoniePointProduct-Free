package com.moniepoint.journey.parser;

import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;

public sealed interface ParsedRecordOutcome extends ParsedFileOutcome {
  record Platform(PlatformRawRecordDto raw) implements ParsedRecordOutcome {}

  record ProductArea(ProductAreaRawRecordDto raw) implements ParsedRecordOutcome {}

  record Intent(IntentRawRecordDto raw) implements ParsedRecordOutcome {}
}
