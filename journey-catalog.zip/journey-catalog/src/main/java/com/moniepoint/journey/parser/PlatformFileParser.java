package com.moniepoint.journey.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.exception.ParseException;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class PlatformFileParser implements CatalogueFileParser {
  private static final String FILE_NAME = "platform.md";
  private static final Set<String> KNOWN_FIELDS =
      Set.of("id", "platform", "name", "url", "channels", "locales");

  private final YamlFrontmatterParser yamlFrontmatterParser;
  private final ObjectMapper objectMapper;

  @Override
  public boolean supports(String relativeFilePath) {
    return relativeFilePath.equals(FILE_NAME) || relativeFilePath.endsWith("/" + FILE_NAME);
  }

  @Override
  public ParsedFileOutcome parse(String relativeFilePath, String fileContent) {
    JsonNode frontmatter;
    try {
      frontmatter = yamlFrontmatterParser.parseFrontmatter(fileContent);
    } catch (ParseException e) {
      return new UnparseableFileOutcome(relativeFilePath, e.getMessage());
    }

    var code =
        FrontmatterUtils.text(frontmatter, "id")
            .or(() -> FrontmatterUtils.text(frontmatter, "platform"));
    if (code.isEmpty()) {
      return new UnparseableFileOutcome(
          relativeFilePath, "platform.md missing required 'id' or 'platform' identity field");
    }

    PlatformRawRecordDto raw =
        PlatformRawRecordDto.builder()
            .code(code.get())
            .name(FrontmatterUtils.text(frontmatter, "name").orElse(null))
            .url(FrontmatterUtils.text(frontmatter, "url").orElse(null))
            .channels(FrontmatterUtils.stringList(frontmatter, "channels"))
            .locales(FrontmatterUtils.stringList(frontmatter, "locales"))
            .metadata(extractMetadata(frontmatter))
            .sourceFilePath(relativeFilePath)
            .build();

    return new ParsedRecordOutcome.Platform(raw);
  }

  private Map<String, Object> extractMetadata(JsonNode frontmatter) {
    Map<String, Object> metadata = new HashMap<>();
    Iterator<String> fieldNames = frontmatter.fieldNames();
    Set<String> seen = new HashSet<>(KNOWN_FIELDS);
    while (fieldNames.hasNext()) {
      String field = fieldNames.next();
      if (!seen.contains(field)) {
        metadata.put(field, objectMapper.convertValue(frontmatter.get(field), Object.class));
      }
    }
    return metadata;
  }
}
