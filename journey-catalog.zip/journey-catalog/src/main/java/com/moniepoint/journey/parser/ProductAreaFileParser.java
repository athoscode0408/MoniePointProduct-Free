package com.moniepoint.journey.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.journey.exception.ParseException;
import com.moniepoint.journey.model.dto.IntentGroupDeclarationDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ProductAreaFileParser implements CatalogueFileParser {
  private static final String FILE_NAME = "product-area.md";

  private final YamlFrontmatterParser yamlFrontmatterParser;

  @Override
  public boolean supports(String relativeFilePath) {
    return relativeFilePath.equals(FILE_NAME) || relativeFilePath.endsWith("/" + FILE_NAME);
  }

  @Override
  public ParsedFileOutcome parse(String relativeFilePath, String fileContent) {
    JsonNode frontmatter;
    try {
      frontmatter = yamlFrontmatterParser.parseFrontmatter(fileContent);
    } catch (ParseException e) {
      return new UnparseableFileOutcome(relativeFilePath, e.getMessage());
    }

    var code = FrontmatterUtils.text(frontmatter, "slug");
    if (code.isEmpty()) {
      return new UnparseableFileOutcome(
          relativeFilePath, "product-area.md missing required 'slug' identity field");
    }

    ProductAreaRawRecordDto raw =
        ProductAreaRawRecordDto.builder()
            .code(code.get())
            .platformCode(FrontmatterUtils.text(frontmatter, "platform").orElse(null))
            .name(FrontmatterUtils.text(frontmatter, "name").orElse(null))
            .url(FrontmatterUtils.text(frontmatter, "url").orElse(null))
            .pagesUrl(FrontmatterUtils.text(frontmatter, "pages_url").orElse(null))
            .jiraProjectKey(FrontmatterUtils.text(frontmatter, "jira_project_key").orElse(null))
            .intentGroups(extractIntentGroups(frontmatter))
            .sourceFilePath(relativeFilePath)
            .build();

    return new ParsedRecordOutcome.ProductArea(raw);
  }

  private List<IntentGroupDeclarationDto> extractIntentGroups(JsonNode frontmatter) {
    List<IntentGroupDeclarationDto> declarations = new ArrayList<>();
    JsonNode intentGroups = frontmatter.path("intent_groups");
    if (!intentGroups.isArray()) {
      return declarations;
    }
    for (JsonNode entry : intentGroups) {
      String groupCode = entry.path("id").asText("").trim();
      if (groupCode.isEmpty()) {
        log.warn("Skipping intent_groups entry with no 'id' in product-area.md");
        continue;
      }
      String groupName = entry.path("name").asText("").trim();
      declarations.add(
          IntentGroupDeclarationDto.builder()
              .code(groupCode)
              .name(groupName.isEmpty() ? null : groupName)
              .build());
    }
    return declarations;
  }
}
