package com.moniepoint.journey.parser;

public record UnparseableFileOutcome(String filePath, String reason) implements ParsedFileOutcome {}
