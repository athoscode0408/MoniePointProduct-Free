package com.moniepoint.journey.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.moniepoint.journey.exception.ParseException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class YamlFrontmatterParser {
  private static final String FRONTMATTER_DELIMITER = "---";
  private static final YAMLMapper yamlMapper = new YAMLMapper(new YAMLFactory());

  public JsonNode parseFrontmatter(String fileContent) {
    try {
      String frontmatterContent = extractFrontmatter(fileContent);
      if (frontmatterContent == null || frontmatterContent.trim().isEmpty()) {
        throw new ParseException("No frontmatter found in file");
      }

      JsonNode frontmatter = yamlMapper.readTree(frontmatterContent);
      log.debug("Successfully parsed frontmatter from file");
      return frontmatter;
    } catch (ParseException e) {
      throw e;
    } catch (Exception e) {
      log.error("Error parsing YAML frontmatter", e);
      throw new ParseException("Failed to parse YAML frontmatter", e);
    }
  }

  private String extractFrontmatter(String fileContent) {
    if (fileContent == null || !fileContent.startsWith(FRONTMATTER_DELIMITER)) {
      return null;
    }

    int firstDelimiterEnd =
        fileContent.indexOf(FRONTMATTER_DELIMITER) + FRONTMATTER_DELIMITER.length();
    int secondDelimiterStart = fileContent.indexOf(FRONTMATTER_DELIMITER, firstDelimiterEnd);

    if (secondDelimiterStart == -1) {
      log.warn("File has opening frontmatter delimiter but no closing delimiter");
      return null;
    }

    return fileContent.substring(firstDelimiterEnd, secondDelimiterStart).trim();
  }

  public String extractFileBody(String fileContent) {
    if (fileContent == null || !fileContent.startsWith(FRONTMATTER_DELIMITER)) {
      return fileContent;
    }

    int firstDelimiterEnd =
        fileContent.indexOf(FRONTMATTER_DELIMITER) + FRONTMATTER_DELIMITER.length();
    int secondDelimiterStart = fileContent.indexOf(FRONTMATTER_DELIMITER, firstDelimiterEnd);

    if (secondDelimiterStart == -1) {
      return fileContent;
    }

    // Strip leading whitespace entirely, but only trailing blank lines - not trailing spaces on
    // the body's last content line, which are meaningful in markdown (e.g. hard line breaks).
    String body =
        fileContent
            .substring(secondDelimiterStart + FRONTMATTER_DELIMITER.length())
            .replaceAll("^\\s+", "")
            .replaceAll("[\\r\\n]+$", "");
    return body.isEmpty() ? null : body;
  }
}
