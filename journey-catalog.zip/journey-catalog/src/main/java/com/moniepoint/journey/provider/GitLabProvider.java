package com.moniepoint.journey.provider;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.config.GitLabProperties;
import com.moniepoint.journey.exception.GitLabException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

@Component
@RequiredArgsConstructor
@Slf4j
public class GitLabProvider {
  private static final String TOKEN = "PRIVATE-TOKEN";
  private final GitLabProperties gitLabProperties;
  private final RestClient restClient;
  private final ObjectMapper objectMapper;

  public String fetchDefaultBranch(String projectId) {
    try {
      String encodedProjectId = URLEncoder.encode(projectId, StandardCharsets.UTF_8);
      String projectPath =
          String.format("%s/api/v4/projects/%s", gitLabProperties.getUrl(), encodedProjectId);

      String body =
          restClient
              .get()
              .uri(projectPath)
              .header(TOKEN, gitLabProperties.getToken())
              .retrieve()
              .body(String.class);

      JsonNode projectNode = objectMapper.readTree(body);
      String defaultBranch = projectNode.path("default_branch").asText("");
      if (defaultBranch.isEmpty()) {
        throw new GitLabException("GitLab project response missing default_branch: " + projectId);
      }
      return defaultBranch;
    } catch (GitLabException e) {
      throw e;
    } catch (HttpClientErrorException e) {
      throw mapGitLabError(e);
    } catch (Exception e) {
      log.error("Error fetching default branch from GitLab for project: {}", projectId, e);
      throw new GitLabException("Failed to fetch default branch from GitLab: " + projectId, e);
    }
  }

  public InputStream fetchRepositoryArchive(String projectId, String branch) {
    try {
      log.info(
          "Fetching repository archive from GitLab - project: {}, branch: {}", projectId, branch);

      String encodedProjectId = URLEncoder.encode(projectId, StandardCharsets.UTF_8);
      String archivePath =
          String.format(
              "%s/api/v4/projects/%s/repository/archive.tar.gz?sha=%s",
              gitLabProperties.getUrl(), encodedProjectId, branch);

      byte[] archiveBytes =
          restClient
              .get()
              .uri(archivePath)
              .header(TOKEN, gitLabProperties.getToken())
              .retrieve()
              .body(byte[].class);

      if (archiveBytes == null || archiveBytes.length == 0) {
        throw new GitLabException("Retrieved empty archive from GitLab");
      }

      log.info("Successfully fetched repository archive - size: {} bytes", archiveBytes.length);
      return new ByteArrayInputStream(archiveBytes);
    } catch (GitLabException e) {
      throw e;
    } catch (HttpClientErrorException e) {
      throw mapGitLabError(e);
    } catch (Exception e) {
      log.error("Error fetching repository archive from GitLab", e);
      throw new GitLabException("Failed to fetch repository archive from GitLab", e);
    }
  }

  public InputStream fetchFile(String projectId, String filePath, String branch) {
    try {
      log.info(
          "Fetching file from GitLab - project: {}, path: {}, branch: {}",
          projectId,
          filePath,
          branch);

      String encodedProjectId = URLEncoder.encode(projectId, StandardCharsets.UTF_8);
      String encodedPath = URLEncoder.encode(filePath, StandardCharsets.UTF_8);
      String fileFetchPath =
          String.format(
              "%s/api/v4/projects/%s/repository/files/%s/raw?ref=%s",
              gitLabProperties.getUrl(), encodedProjectId, encodedPath, branch);

      byte[] fileBytes =
          restClient
              .get()
              .uri(fileFetchPath)
              .header(TOKEN, gitLabProperties.getToken())
              .retrieve()
              .body(byte[].class);

      if (fileBytes == null) {
        throw new GitLabException("Retrieved null file from GitLab: " + filePath);
      }

      log.info("Successfully fetched file - path: {}, size: {} bytes", filePath, fileBytes.length);
      return new ByteArrayInputStream(fileBytes);
    } catch (GitLabException e) {
      throw e;
    } catch (HttpClientErrorException e) {
      throw mapGitLabError(e);
    } catch (Exception e) {
      log.error("Error fetching file from GitLab: {}", filePath, e);
      throw new GitLabException("Failed to fetch file from GitLab: " + filePath, e);
    }
  }

  private GitLabException mapGitLabError(HttpClientErrorException exception) {
    HttpStatusCode statusCode = exception.getStatusCode();

    return switch (statusCode.value()) {
      case 401 -> new GitLabException("GitLab authentication failed - invalid token", exception);
      case 403 ->
          new GitLabException("GitLab access forbidden - insufficient permissions", exception);
      case 404 ->
          new GitLabException("GitLab resource not found - check project ID and branch", exception);
      case 429 -> {
        log.warn("GitLab rate limit reached (429). Will retry with backoff.");
        yield new GitLabException(
            "GitLab rate limit exceeded - too many requests. Will retry with exponential backoff.",
            exception);
      }
      default ->
          new GitLabException(
              String.format(
                  "GitLab API error - status: %d, message: %s",
                  statusCode.value(), exception.getMessage()),
              exception);
    };
  }
}
