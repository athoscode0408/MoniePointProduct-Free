package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.IntentGroup;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IIntentGroupRepository extends JpaRepository<IntentGroup, Long> {
  Optional<IntentGroup> findByCode(String code);

  List<IntentGroup> findByCodeIn(Collection<String> codes);

  @Query(
      "SELECT g FROM IntentGroup g WHERE (:includeInvalid = true OR g.validationStatus = 'VALID')"
          + " AND (:productAreaCode IS NULL OR g.productAreaCode = :productAreaCode)")
  List<IntentGroup> search(
      @Param("productAreaCode") String productAreaCode,
      @Param("includeInvalid") boolean includeInvalid);
}
