package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.Intent;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IIntentRepository extends JpaRepository<Intent, Long> {
  Optional<Intent> findByCode(String code);

  @Query(
      "SELECT i FROM Intent i WHERE (:includeInvalid = true OR i.validationStatus = 'VALID')"
          + " AND (:platformCode IS NULL OR i.platformCode = :platformCode)"
          + " AND (:productAreaCode IS NULL OR i.productAreaCode = :productAreaCode)"
          + " AND (:intentGroupCode IS NULL OR i.intentGroupCode = :intentGroupCode)"
          + " AND (:query IS NULL OR LOWER(i.name) LIKE LOWER(CONCAT('%', :query, '%')))")
  Page<Intent> search(
      @Param("platformCode") String platformCode,
      @Param("productAreaCode") String productAreaCode,
      @Param("intentGroupCode") String intentGroupCode,
      @Param("query") String query,
      @Param("includeInvalid") boolean includeInvalid,
      Pageable pageable);
}
