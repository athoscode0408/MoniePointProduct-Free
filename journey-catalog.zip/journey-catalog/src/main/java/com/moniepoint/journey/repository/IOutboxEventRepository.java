package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.OutboxEvent;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IOutboxEventRepository extends JpaRepository<OutboxEvent, Long> {
  Optional<OutboxEvent> findByExternalEventId(String externalEventId);

  @Query(
      "SELECT e FROM OutboxEvent e WHERE e.status = 'PENDING' AND (e.nextRetryTime IS NULL OR e.nextRetryTime <= CURRENT_TIMESTAMP) ORDER BY e.createdAt ASC")
  List<OutboxEvent> findPendingEvents();

  @Query(
      "SELECT e FROM OutboxEvent e WHERE e.status = 'FAILED' AND e.retryCount < 3 ORDER BY e.createdAt ASC")
  List<OutboxEvent> findFailedEventsForRetry();

  @Modifying(clearAutomatically = true)
  @Query(
      "UPDATE OutboxEvent e SET e.status = 'PROCESSING' WHERE e.id = :id AND e.status = 'PENDING'")
  int claimEventForProcessing(@Param("id") Long id);

  @Modifying(clearAutomatically = true)
  @Query(
      "UPDATE OutboxEvent e SET e.status = 'PENDING' WHERE e.status = 'PROCESSING' AND e.updatedAt <= :threshold")
  int resetStaleProcessingEvents(@Param("threshold") OffsetDateTime threshold);
}
