package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.Platform;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IPlatformRepository extends JpaRepository<Platform, Long> {
  Optional<Platform> findByCode(String code);

  List<Platform> findByCodeIn(Collection<String> codes);

  @Query("SELECT p FROM Platform p WHERE (:includeInvalid = true OR p.validationStatus = 'VALID')")
  List<Platform> search(@Param("includeInvalid") boolean includeInvalid);
}
