package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.ProductArea;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IProductAreaRepository extends JpaRepository<ProductArea, Long> {
  Optional<ProductArea> findByCode(String code);

  List<ProductArea> findByCodeIn(Collection<String> codes);

  @Query(
      "SELECT p FROM ProductArea p WHERE (:includeInvalid = true OR p.validationStatus = 'VALID')"
          + " AND (:platformCode IS NULL OR p.platformCode = :platformCode)")
  List<ProductArea> search(
      @Param("platformCode") String platformCode, @Param("includeInvalid") boolean includeInvalid);
}
