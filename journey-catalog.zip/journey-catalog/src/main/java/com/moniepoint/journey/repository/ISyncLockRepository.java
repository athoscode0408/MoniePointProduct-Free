package com.moniepoint.journey.repository;

import com.moniepoint.journey.model.entity.SyncLock;
import java.time.Instant;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ISyncLockRepository extends JpaRepository<SyncLock, Long> {
  Optional<SyncLock> findByProjectId(String projectId);

  /** Steals an expired lock atomically; returns rows affected (0 or 1). */
  @Modifying(clearAutomatically = true)
  @Query(
      "UPDATE SyncLock l SET l.holderToken = :newToken, l.acquiredAt = :now, l.expiresAt ="
          + " :expiresAt WHERE l.projectId = :projectId AND l.expiresAt <= :now")
  int stealExpiredLock(
      @Param("projectId") String projectId,
      @Param("newToken") String newToken,
      @Param("now") Instant now,
      @Param("expiresAt") Instant expiresAt);

  @Modifying(clearAutomatically = true)
  @Query("DELETE FROM SyncLock l WHERE l.projectId = :projectId AND l.holderToken = :holderToken")
  int releaseIfHeldBy(
      @Param("projectId") String projectId, @Param("holderToken") String holderToken);
}
