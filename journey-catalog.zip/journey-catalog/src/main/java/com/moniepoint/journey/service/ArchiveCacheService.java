package com.moniepoint.journey.service;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.time.Duration;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ArchiveCacheService {
  private final Cache<String, byte[]> cache =
      Caffeine.newBuilder().expireAfterWrite(Duration.ofHours(1)).maximumSize(500).build();

  public Optional<byte[]> getCached(String cacheKey) {
    byte[] bytes = cache.getIfPresent(cacheKey);
    log.debug("Archive cache {} for key: {}", bytes != null ? "hit" : "miss", cacheKey);
    return Optional.ofNullable(bytes);
  }

  public void store(String cacheKey, byte[] archiveBytes) {
    cache.put(cacheKey, archiveBytes);
    log.debug("Stored archive in cache for key: {}", cacheKey);
  }
}
