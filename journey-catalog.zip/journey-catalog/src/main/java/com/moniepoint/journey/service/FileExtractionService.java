package com.moniepoint.journey.service;

import com.moniepoint.journey.exception.FileExtractionException;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FileExtractionService {
  public String extractTarGz(InputStream inputStream) {
    try {
      Path extractDir = Files.createTempDirectory("journey-extract-");
      log.info("Extracting tar.gz to temporary directory: {}", extractDir);

      Path extractDirNormalized = extractDir.toAbsolutePath().normalize();

      try (BufferedInputStream bi = new BufferedInputStream(inputStream);
          GzipCompressorInputStream gzip = new GzipCompressorInputStream(bi);
          TarArchiveInputStream tar = new TarArchiveInputStream(gzip)) {

        TarArchiveEntry entry;
        while ((entry = tar.getNextTarEntry()) != null) {
          Path entryPath = extractDir.resolve(entry.getName()).normalize();

          if (!entryPath.startsWith(extractDirNormalized)) {
            log.warn("Skipping tar entry escaping extraction directory: {}", entry.getName());
            continue;
          }

          if (entry.isDirectory()) {
            Files.createDirectories(entryPath);
          } else {
            Files.createDirectories(entryPath.getParent());
            Files.copy(tar, entryPath);
          }
        }
      }

      log.info("Successfully extracted tar.gz - entry count available");
      return extractDir.toString();
    } catch (IOException e) {
      log.error("Error extracting tar.gz file", e);
      throw new FileExtractionException("Failed to extract tar.gz file", e);
    }
  }

  public void deleteDirectory(String directoryPath) {
    try {
      Path path = Path.of(directoryPath);
      if (Files.exists(path)) {
        Files.walk(path)
            .sorted(Comparator.reverseOrder())
            .forEach(
                p -> {
                  try {
                    Files.delete(p);
                  } catch (IOException e) {
                    log.warn("Failed to delete file: {}", p, e);
                  }
                });
        log.info("Deleted temporary directory: {}", directoryPath);
      }
    } catch (IOException e) {
      log.warn("Error deleting temporary directory: {}", directoryPath, e);
    }
  }

  public Set<String> listFilesRecursively(String directoryPath, String suffix) {
    Set<String> files = new HashSet<>();
    try {
      Path rootPath = Path.of(directoryPath);
      Files.walk(rootPath)
          .filter(Files::isRegularFile)
          .filter(p -> p.toString().endsWith(suffix))
          .forEach(p -> files.add(rootPath.relativize(p).toString()));
      log.info(
          "Found {} files with suffix '{}' in directory: {}", files.size(), suffix, directoryPath);
    } catch (IOException e) {
      log.error("Error listing files in directory: {}", directoryPath, e);
      throw new FileExtractionException("Failed to list files in directory", e);
    }
    return files;
  }

  public String readFileContent(String filePath) {
    try {
      return Files.readString(Path.of(filePath));
    } catch (IOException e) {
      log.error("Error reading file content: {}", filePath, e);
      throw new FileExtractionException("Failed to read file content", e);
    }
  }

  public Optional<String> readFileContentSilent(String filePath) {
    try {
      return Optional.of(Files.readString(Path.of(filePath)));
    } catch (IOException e) {
      return Optional.empty();
    }
  }
}
