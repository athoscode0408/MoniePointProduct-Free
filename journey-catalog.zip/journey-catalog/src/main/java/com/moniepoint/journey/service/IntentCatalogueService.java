package com.moniepoint.journey.service;

import com.moniepoint.journey.helper.IntentGroupUpsertHelper;
import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.entity.Intent;
import com.moniepoint.journey.repository.IIntentRepository;
import com.moniepoint.journey.util.JsonSerializationUtils;
import com.moniepoint.journey.validation.CatalogueValidationRules;
import com.moniepoint.journey.validation.ValidationOutcome;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class IntentCatalogueService {
  private final IIntentRepository intentRepository;
  private final IntentGroupUpsertHelper intentGroupUpsertHelper;

  @Transactional
  public ValidationOutcome upsert(IntentRawRecordDto raw, String sourceProjectId) {
    ValidationOutcome outcome = CatalogueValidationRules.validateIntent(raw);

    Intent intent =
        intentRepository
            .findByCode(raw.getCode())
            .orElseGet(() -> Intent.builder().code(raw.getCode()).build());
    intent.setName(raw.getName());
    intent.setPlatformCode(raw.getPlatformCode());
    intent.setProductAreaCode(raw.getProductAreaCode());
    intent.setIntentGroupCode(raw.getIntentGroupCode());
    intent.setVersion(raw.getVersion());
    intent.setStatus(raw.getStatus());
    intent.setUserTypes(JsonSerializationUtils.toJsonOrNull(raw.getUserTypes()));
    intent.setChannels(JsonSerializationUtils.toJsonOrNull(raw.getChannels()));
    intent.setValidationStatus(outcome.status());
    intent.setValidationErrors(JsonSerializationUtils.toJsonOrNull(outcome.errors()));
    intent.setSourceProjectId(sourceProjectId);
    intent.setSourceFilePath(raw.getSourceFilePath());
    intentRepository.saveAndFlush(intent);

    if (raw.getIntentGroupCode() != null && !raw.getIntentGroupCode().isBlank()) {
      intentGroupUpsertHelper.ensureShellExists(raw.getIntentGroupCode(), sourceProjectId);
    }
    return outcome;
  }
}
