package com.moniepoint.journey.service;

import com.moniepoint.journey.model.entity.IntentGroup;
import com.moniepoint.journey.repository.IIntentGroupRepository;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class IntentGroupQueryService {
  private final IIntentGroupRepository intentGroupRepository;

  public List<IntentGroup> search(String productAreaCode, boolean includeInvalid) {
    return intentGroupRepository.search(productAreaCode, includeInvalid);
  }

  public Optional<IntentGroup> findByCode(String code) {
    return intentGroupRepository.findByCode(code);
  }

  public List<IntentGroup> findByCodes(Collection<String> codes) {
    return intentGroupRepository.findByCodeIn(codes);
  }
}
