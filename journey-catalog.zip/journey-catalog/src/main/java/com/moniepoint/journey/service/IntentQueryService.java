package com.moniepoint.journey.service;

import com.moniepoint.journey.model.entity.Intent;
import com.moniepoint.journey.repository.IIntentRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class IntentQueryService {
  private final IIntentRepository intentRepository;

  public Page<Intent> search(
      String platformCode,
      String productAreaCode,
      String intentGroupCode,
      String query,
      boolean includeInvalid,
      Pageable pageable) {
    return intentRepository.search(
        platformCode, productAreaCode, intentGroupCode, query, includeInvalid, pageable);
  }

  public Optional<Intent> findByCode(String code) {
    return intentRepository.findByCode(code);
  }
}
