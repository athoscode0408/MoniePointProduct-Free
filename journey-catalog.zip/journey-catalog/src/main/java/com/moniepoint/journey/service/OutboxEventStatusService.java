package com.moniepoint.journey.service;

import com.moniepoint.journey.model.entity.OutboxEvent;
import com.moniepoint.journey.repository.IOutboxEventRepository;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OutboxEventStatusService {
  private static final int MAX_RETRY_COUNT = 3;
  private static final int STALE_PROCESSING_THRESHOLD_MINUTES = 5;

  private final IOutboxEventRepository outboxEventRepository;

  @Transactional
  public List<OutboxEvent> findPendingEvents() {
    return outboxEventRepository.findPendingEvents();
  }

  /**
   * Atomically transitions the event from PENDING to PROCESSING in its own committed transaction,
   * so the claim is immediately visible to other schedulers/workers and a concurrently enqueued run
   * of the same event is rejected instead of double-processed.
   */
  @Transactional
  public boolean claimForProcessing(Long eventId) {
    return outboxEventRepository.claimEventForProcessing(eventId) > 0;
  }

  @Transactional
  public OutboxEvent getEvent(Long eventId) {
    return outboxEventRepository
        .findById(eventId)
        .orElseThrow(() -> new IllegalArgumentException("Event not found: " + eventId));
  }

  @Transactional
  public void markCompleted(Long eventId) {
    OutboxEvent event = getEvent(eventId);
    event.setStatus(OutboxEvent.EventStatus.COMPLETED);
    event.setErrorMessage(null);
    outboxEventRepository.saveAndFlush(event);
    log.info("event with id: {} completed successfully", eventId);
  }

  @Transactional
  public void markFailed(Long eventId, Exception e) {
    OutboxEvent event = getEvent(eventId);
    event.setErrorMessage(e.getMessage());
    event.setRetryCount((event.getRetryCount() != null ? event.getRetryCount() : 0) + 1);

    if (event.getRetryCount() >= MAX_RETRY_COUNT) {
      event.setStatus(OutboxEvent.EventStatus.FAILED);
      log.error("Event failed after {} retries: {}", event.getRetryCount(), eventId, e);
    } else {
      event.setStatus(OutboxEvent.EventStatus.PENDING);
      long backoffDelaySeconds = calculateBackoffDelay(event.getRetryCount());
      event.setNextRetryTime(Instant.now().plusSeconds(backoffDelaySeconds));
      log.warn(
          "Event processing failed, will retry after {} seconds: {} (attempt {})",
          backoffDelaySeconds,
          eventId,
          event.getRetryCount(),
          e);
    }

    outboxEventRepository.saveAndFlush(event);
  }

  /**
   * Sync-lock contention is a normal concurrency outcome, not a failure — sends the event back to
   * PENDING for the next scheduler tick without incrementing retryCount or applying backoff.
   */
  @Transactional
  public void releaseBackToPendingWithoutPenalty(Long eventId) {
    OutboxEvent event = getEvent(eventId);
    event.setStatus(OutboxEvent.EventStatus.PENDING);
    outboxEventRepository.saveAndFlush(event);
  }

  /**
   * Recovers events stuck in PROCESSING (e.g. worker crashed mid-job) by resetting them back to
   * PENDING once they've exceeded the staleness threshold.
   */
  @Transactional
  public int resetStaleProcessingEvents() {
    OffsetDateTime threshold =
        OffsetDateTime.now().minusMinutes(STALE_PROCESSING_THRESHOLD_MINUTES);
    int resetCount = outboxEventRepository.resetStaleProcessingEvents(threshold);
    if (resetCount > 0) {
      log.warn("Reset {} stale PROCESSING event(s) back to PENDING", resetCount);
    }
    return resetCount;
  }

  private long calculateBackoffDelay(int retryCount) {
    return Math.min(300, (long) Math.pow(2, retryCount) * 10);
  }
}
