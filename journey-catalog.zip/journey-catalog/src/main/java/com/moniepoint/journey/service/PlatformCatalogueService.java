package com.moniepoint.journey.service;

import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.entity.Platform;
import com.moniepoint.journey.repository.IPlatformRepository;
import com.moniepoint.journey.util.JsonSerializationUtils;
import com.moniepoint.journey.validation.CatalogueValidationRules;
import com.moniepoint.journey.validation.ValidationOutcome;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PlatformCatalogueService {
  private final IPlatformRepository platformRepository;

  @Transactional
  public ValidationOutcome upsert(PlatformRawRecordDto raw, String sourceProjectId) {
    ValidationOutcome outcome = CatalogueValidationRules.validatePlatform(raw);

    Platform platform =
        platformRepository
            .findByCode(raw.getCode())
            .orElseGet(() -> Platform.builder().code(raw.getCode()).build());
    platform.setName(raw.getName());
    platform.setUrl(raw.getUrl());
    platform.setChannels(JsonSerializationUtils.toJsonOrNull(raw.getChannels()));
    platform.setLocales(JsonSerializationUtils.toJsonOrNull(raw.getLocales()));
    platform.setMetadata(JsonSerializationUtils.toJsonOrNull(raw.getMetadata()));
    platform.setValidationStatus(outcome.status());
    platform.setValidationErrors(JsonSerializationUtils.toJsonOrNull(outcome.errors()));
    platform.setSourceProjectId(sourceProjectId);
    platform.setSourceFilePath(raw.getSourceFilePath());

    platformRepository.saveAndFlush(platform);
    return outcome;
  }
}
