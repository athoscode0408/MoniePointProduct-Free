package com.moniepoint.journey.service;

import com.moniepoint.journey.model.entity.Platform;
import com.moniepoint.journey.repository.IPlatformRepository;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PlatformQueryService {
  private final IPlatformRepository platformRepository;

  public List<Platform> findAll(boolean includeInvalid) {
    return platformRepository.search(includeInvalid);
  }

  public Optional<Platform> findByCode(String code) {
    return platformRepository.findByCode(code);
  }

  public List<Platform> findByCodes(Collection<String> codes) {
    return platformRepository.findByCodeIn(codes);
  }
}
