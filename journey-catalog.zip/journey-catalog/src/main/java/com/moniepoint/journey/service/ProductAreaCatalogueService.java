package com.moniepoint.journey.service;

import com.moniepoint.journey.helper.IntentGroupUpsertHelper;
import com.moniepoint.journey.model.dto.IntentGroupDeclarationDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import com.moniepoint.journey.model.entity.ProductArea;
import com.moniepoint.journey.repository.IProductAreaRepository;
import com.moniepoint.journey.util.JsonSerializationUtils;
import com.moniepoint.journey.validation.CatalogueValidationRules;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProductAreaCatalogueService {
  private final IProductAreaRepository productAreaRepository;
  private final IntentGroupUpsertHelper intentGroupUpsertHelper;

  @Transactional
  public ValidationOutcome upsert(ProductAreaRawRecordDto raw, String sourceProjectId) {
    ValidationOutcome outcome = CatalogueValidationRules.validateProductArea(raw);

    ProductArea productArea =
        productAreaRepository
            .findByCode(raw.getCode())
            .orElseGet(() -> ProductArea.builder().code(raw.getCode()).build());
    productArea.setPlatformCode(raw.getPlatformCode());
    productArea.setName(raw.getName());
    productArea.setUrl(raw.getUrl());
    productArea.setPagesUrl(raw.getPagesUrl());
    productArea.setJiraProjectKey(raw.getJiraProjectKey());
    productArea.setValidationStatus(outcome.status());
    productArea.setValidationErrors(JsonSerializationUtils.toJsonOrNull(outcome.errors()));
    productArea.setSourceProjectId(sourceProjectId);
    productArea.setSourceFilePath(raw.getSourceFilePath());
    productAreaRepository.saveAndFlush(productArea);

    List<IntentGroupDeclarationDto> intentGroups = raw.getIntentGroups();
    if (intentGroups != null) {
      for (IntentGroupDeclarationDto declaration : intentGroups) {
        intentGroupUpsertHelper.applyDeclaration(
            declaration, raw.getCode(), sourceProjectId, raw.getSourceFilePath());
      }
    }
    return outcome;
  }
}
