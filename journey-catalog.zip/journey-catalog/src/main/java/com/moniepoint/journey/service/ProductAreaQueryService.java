package com.moniepoint.journey.service;

import com.moniepoint.journey.model.entity.ProductArea;
import com.moniepoint.journey.repository.IProductAreaRepository;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProductAreaQueryService {
  private final IProductAreaRepository productAreaRepository;

  public List<ProductArea> search(String platformCode, boolean includeInvalid) {
    return productAreaRepository.search(platformCode, includeInvalid);
  }

  public Optional<ProductArea> findByCode(String code) {
    return productAreaRepository.findByCode(code);
  }

  public List<ProductArea> findByCodes(Collection<String> codes) {
    return productAreaRepository.findByCodeIn(codes);
  }
}
