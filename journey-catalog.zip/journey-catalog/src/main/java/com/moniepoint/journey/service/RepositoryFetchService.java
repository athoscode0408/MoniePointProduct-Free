package com.moniepoint.journey.service;

import com.moniepoint.journey.exception.GitLabException;
import com.moniepoint.journey.model.dto.RepositoryArchiveDto;
import com.moniepoint.journey.provider.GitLabProvider;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class RepositoryFetchService {
  private final GitLabProvider gitLabProvider;
  private final FileExtractionService fileExtractionService;
  private final ArchiveCacheService archiveCacheService;

  public RepositoryArchiveDto fetchAndExtractRepository(
      String projectId, String branch, String tag, String checkoutSha) {
    try {
      String ref = tag != null ? tag : branch;
      String cacheKey =
          projectId + ":" + (checkoutSha != null && !checkoutSha.isBlank() ? checkoutSha : ref);

      log.info(
          "Starting repository fetch and extraction - project: {}, branch: {}, tag: {}, checkoutSha: {}",
          projectId,
          branch,
          tag,
          checkoutSha);

      byte[] archiveBytes =
          archiveCacheService
              .getCached(cacheKey)
              .orElseGet(
                  () -> {
                    try (InputStream in = gitLabProvider.fetchRepositoryArchive(projectId, ref)) {
                      log.debug("Fetching repository archive from GitLab for: {}", cacheKey);
                      byte[] bytes = in.readAllBytes();
                      archiveCacheService.store(cacheKey, bytes);
                      return bytes;
                    } catch (IOException e) {
                      throw new RuntimeException("Failed to read archive stream", e);
                    }
                  });

      String extractedPath =
          fileExtractionService.extractTarGz(new ByteArrayInputStream(archiveBytes));

      log.info("Repository fetched and extracted successfully - path: {}", extractedPath);

      return RepositoryArchiveDto.builder()
          .extractedPath(extractedPath)
          .branch(branch)
          .tag(tag)
          .build();
    } catch (GitLabException e) {
      log.error("GitLab error during repository fetch", e);
      throw e;
    } catch (Exception e) {
      log.error("Unexpected error during repository fetch and extraction", e);
      throw new RuntimeException("Failed to fetch and extract repository", e);
    }
  }

  public boolean isDefaultBranch(String projectId, String branch) {
    String defaultBranch = gitLabProvider.fetchDefaultBranch(projectId);
    return defaultBranch.equals(branch);
  }

  public void cleanupExtractedRepository(String extractedPath) {
    try {
      fileExtractionService.deleteDirectory(extractedPath);
      log.info("Cleaned up extracted repository: {}", extractedPath);
    } catch (Exception e) {
      log.warn("Error cleaning up extracted repository: {}", extractedPath, e);
    }
  }
}
