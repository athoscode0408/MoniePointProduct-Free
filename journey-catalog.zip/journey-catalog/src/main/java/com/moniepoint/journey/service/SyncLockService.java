package com.moniepoint.journey.service;

import com.moniepoint.journey.config.SyncProperties;
import com.moniepoint.journey.model.entity.SyncLock;
import com.moniepoint.journey.repository.ISyncLockRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 * Prevents overlapping sync runs for the same GitLab project. Deliberately has no @Transactional on
 * tryAcquire: each repository call below is already its own default Spring Data transaction, and a
 * constraint-violation exception from an insert attempt would otherwise poison a single surrounding
 * transaction, making the follow-up steal-check call unsafe.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SyncLockService {
  private final ISyncLockRepository syncLockRepository;
  private final SyncProperties syncProperties;

  public Optional<String> tryAcquire(String projectId) {
    String token = UUID.randomUUID().toString();
    Instant now = Instant.now();
    Instant expiresAt = now.plus(syncProperties.getLockTtlMinutes(), ChronoUnit.MINUTES);

    if (syncLockRepository.findByProjectId(projectId).isEmpty()) {
      try {
        syncLockRepository.save(
            SyncLock.builder()
                .projectId(projectId)
                .holderToken(token)
                .acquiredAt(now)
                .expiresAt(expiresAt)
                .build());
        return Optional.of(token);
      } catch (DataIntegrityViolationException e) {
        log.debug(
            "Lost race to acquire sync lock for project {}, falling back to steal check",
            projectId);
      }
    }

    int stolen = syncLockRepository.stealExpiredLock(projectId, token, now, expiresAt);
    if (stolen > 0) {
      log.warn("Stole expired sync lock for project {}", projectId);
      return Optional.of(token);
    }

    return Optional.empty();
  }

  public void release(String projectId, String token) {
    syncLockRepository.releaseIfHeldBy(projectId, token);
  }
}
