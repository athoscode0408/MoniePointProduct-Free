package com.moniepoint.journey.service;

import com.moniepoint.journey.job.ProcessOutboxEventJob;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import com.moniepoint.journey.model.entity.OutboxEvent;
import com.moniepoint.journey.repository.IOutboxEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class WebhookEventService {
  private final IOutboxEventRepository outboxEventRepository;
  private final JobScheduler jobScheduler;
  private final ProcessOutboxEventJob processOutboxEventJob;

  @Transactional
  public void saveWebhookEvent(WebhookEventDto eventDto) {
    try {
      OutboxEvent event =
          OutboxEvent.builder()
              .eventType(eventDto.getEventType())
              .externalEventId(eventDto.getEventId())
              .payload(eventDto.getRawPayload())
              .status(OutboxEvent.EventStatus.PENDING)
              .retryCount(0)
              .build();

      OutboxEvent savedEvent = outboxEventRepository.save(event);
      log.info("Webhook event saved: {}", eventDto.getEventId());

      jobScheduler.enqueue(() -> processOutboxEventJob.execute(savedEvent.getId()));
      log.info("Scheduled processing job for event: {}", savedEvent.getId());
    } catch (Exception e) {
      log.error("Error saving webhook event: {}", eventDto.getEventId(), e);
      throw new RuntimeException("Failed to save webhook event", e);
    }
  }
}
