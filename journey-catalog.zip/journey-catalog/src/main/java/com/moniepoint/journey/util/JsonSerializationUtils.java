package com.moniepoint.journey.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public final class JsonSerializationUtils {
  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  private JsonSerializationUtils() {}

  public static String toJsonOrNull(Collection<?> value) {
    return (value == null || value.isEmpty()) ? null : writeValue(value);
  }

  public static String toJsonOrNull(Map<?, ?> value) {
    return (value == null || value.isEmpty()) ? null : writeValue(value);
  }

  public static String writeValue(Object value) {
    try {
      return OBJECT_MAPPER.writeValueAsString(value);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException("Failed to serialize to JSON", e);
    }
  }

  public static <T> List<T> readListOrEmpty(String json, Class<T> elementType) {
    if (json == null || json.isBlank()) {
      return List.of();
    }
    try {
      CollectionType type =
          OBJECT_MAPPER.getTypeFactory().constructCollectionType(List.class, elementType);
      return OBJECT_MAPPER.readValue(json, type);
    } catch (JsonProcessingException e) {
      throw new IllegalStateException("Failed to deserialize JSON list", e);
    }
  }
}
