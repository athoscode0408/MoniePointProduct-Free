package com.moniepoint.journey.validation;

import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import com.moniepoint.journey.model.dto.ValidationErrorDto;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import java.util.ArrayList;
import java.util.List;

public final class CatalogueValidationRules {
  private CatalogueValidationRules() {}

  public static ValidationOutcome validatePlatform(PlatformRawRecordDto raw) {
    List<ValidationErrorDto> errors = new ArrayList<>();
    requireNonBlank(raw.getName(), "name", errors);
    return outcome(errors);
  }

  public static ValidationOutcome validateProductArea(ProductAreaRawRecordDto raw) {
    List<ValidationErrorDto> errors = new ArrayList<>();
    requireNonBlank(raw.getName(), "name", errors);
    requireNonBlank(raw.getPlatformCode(), "platform", errors);
    return outcome(errors);
  }

  public static ValidationOutcome validateIntentGroup(String name, String productAreaCode) {
    List<ValidationErrorDto> errors = new ArrayList<>();
    requireNonBlank(name, "name", errors);
    requireNonBlank(productAreaCode, "product_area", errors);
    return outcome(errors);
  }

  public static ValidationOutcome validateIntent(IntentRawRecordDto raw) {
    List<ValidationErrorDto> errors = new ArrayList<>();
    requireNonBlank(raw.getName(), "name", errors);
    requireNonBlank(raw.getPlatformCode(), "platform", errors);
    requireNonBlank(raw.getProductAreaCode(), "product_area", errors);
    requireNonBlank(raw.getIntentGroupCode(), "intent_group", errors);
    return outcome(errors);
  }

  private static void requireNonBlank(String value, String field, List<ValidationErrorDto> errors) {
    if (value == null || value.isBlank()) {
      errors.add(ValidationErrorDto.builder().field(field).message(field + " is required").build());
    }
  }

  private static ValidationOutcome outcome(List<ValidationErrorDto> errors) {
    return errors.isEmpty()
        ? new ValidationOutcome(ValidationStatus.VALID, errors)
        : new ValidationOutcome(ValidationStatus.INVALID, errors);
  }
}
