package com.moniepoint.journey.validation;

import com.moniepoint.journey.model.dto.ValidationErrorDto;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import java.util.List;

public record ValidationOutcome(ValidationStatus status, List<ValidationErrorDto> errors) {}
