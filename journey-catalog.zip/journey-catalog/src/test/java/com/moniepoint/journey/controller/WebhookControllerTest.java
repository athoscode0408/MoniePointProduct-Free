package com.moniepoint.journey.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.helper.GitLabWebhookParser;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import com.moniepoint.journey.service.WebhookEventService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class WebhookControllerTest {
  @Mock private WebhookEventService webhookEventService;
  @Mock private GitLabWebhookParser gitLabWebhookParser;

  @InjectMocks private WebhookController webhookController;

  private static final String VALID_PAYLOAD =
      "{\"object_kind\": \"push\", \"project_id\": 123, \"project_name\": \"test-project\"}";

  @Test
  void handleGitlabWebhook_WithPushHookHeader_ShouldProcessEvent() {
    WebhookEventDto eventDto =
        WebhookEventDto.builder()
            .eventId("event-123")
            .eventType("push")
            .projectId("123")
            .projectName("test-project")
            .build();

    when(gitLabWebhookParser.parseGitLabPushEvent(VALID_PAYLOAD)).thenReturn(eventDto);

    ResponseEntity<Void> response =
        webhookController.handleGitlabWebhook(VALID_PAYLOAD, "Push Hook");

    assert response.getStatusCode().is2xxSuccessful();
    verify(gitLabWebhookParser).parseGitLabPushEvent(VALID_PAYLOAD);
    verify(webhookEventService).saveWebhookEvent(eventDto);
  }

  @Test
  void handleGitlabWebhook_WithoutHeader_ShouldNotProcessEvent() {
    ResponseEntity<Void> response = webhookController.handleGitlabWebhook(VALID_PAYLOAD, null);

    assert response.getStatusCode().is2xxSuccessful();
    verify(gitLabWebhookParser, never()).parseGitLabPushEvent(VALID_PAYLOAD);
    verify(webhookEventService, never()).saveWebhookEvent(any());
  }

  @Test
  void handleGitlabWebhook_WithWrongEventType_ShouldNotProcessEvent() {
    ResponseEntity<Void> response =
        webhookController.handleGitlabWebhook(VALID_PAYLOAD, "Tag Push Hook");

    assert response.getStatusCode().is2xxSuccessful();
    verify(gitLabWebhookParser, never()).parseGitLabPushEvent(VALID_PAYLOAD);
    verify(webhookEventService, never()).saveWebhookEvent(any());
  }

  @Test
  void handleGitlabWebhook_WithParseError_ShouldReturn500() {
    when(gitLabWebhookParser.parseGitLabPushEvent(VALID_PAYLOAD))
        .thenThrow(new RuntimeException("Parse error"));

    ResponseEntity<Void> response =
        webhookController.handleGitlabWebhook(VALID_PAYLOAD, "Push Hook");

    assert response.getStatusCode().is5xxServerError();
    verify(webhookEventService, never()).saveWebhookEvent(any());
  }
}
