package com.moniepoint.journey.facade;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import com.moniepoint.journey.model.dto.ValidationErrorDto;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.parser.ParsedRecordOutcome;
import com.moniepoint.journey.service.IntentCatalogueService;
import com.moniepoint.journey.service.PlatformCatalogueService;
import com.moniepoint.journey.service.ProductAreaCatalogueService;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("CatalogueSyncFacade Tests")
class CatalogueSyncFacadeTest {
  @Mock private PlatformCatalogueService platformCatalogueService;
  @Mock private ProductAreaCatalogueService productAreaCatalogueService;
  @Mock private IntentCatalogueService intentCatalogueService;
  @InjectMocks private CatalogueSyncFacade facade;

  private static final ValidationOutcome VALID =
      new ValidationOutcome(ValidationStatus.VALID, List.of());

  @Test
  @DisplayName("dispatches each record type to its own service")
  void shouldDispatchEachRecordType() {
    PlatformRawRecordDto platformRaw =
        PlatformRawRecordDto.builder().code("P1").name("Platform 1").build();
    ProductAreaRawRecordDto productAreaRaw = ProductAreaRawRecordDto.builder().code("pa1").build();
    IntentRawRecordDto intentRaw = IntentRawRecordDto.builder().code("I1").build();

    when(platformCatalogueService.upsert(platformRaw, "123")).thenReturn(VALID);
    when(productAreaCatalogueService.upsert(productAreaRaw, "123")).thenReturn(VALID);
    when(intentCatalogueService.upsert(intentRaw, "123")).thenReturn(VALID);

    List<ParsedRecordOutcome> records =
        List.of(
            new ParsedRecordOutcome.Platform(platformRaw),
            new ParsedRecordOutcome.ProductArea(productAreaRaw),
            new ParsedRecordOutcome.Intent(intentRaw));

    SyncRunResult result = facade.syncCatalogue(records, "123");

    verify(platformCatalogueService).upsert(platformRaw, "123");
    verify(productAreaCatalogueService).upsert(productAreaRaw, "123");
    verify(intentCatalogueService).upsert(intentRaw, "123");
    assertTrue(result.invalidRecords().isEmpty());
  }

  @Test
  @DisplayName("an INVALID record is collected for notification, not thrown")
  void shouldCollectInvalidRecordWithoutThrowing() {
    IntentRawRecordDto intentRaw =
        IntentRawRecordDto.builder().code("I1").sourceFilePath("intent.md").build();
    ValidationErrorDto error =
        ValidationErrorDto.builder().field("name").message("name is required").build();
    when(intentCatalogueService.upsert(intentRaw, "123"))
        .thenReturn(new ValidationOutcome(ValidationStatus.INVALID, List.of(error)));

    SyncRunResult result =
        facade.syncCatalogue(List.of(new ParsedRecordOutcome.Intent(intentRaw)), "123");

    assertEquals(1, result.invalidRecords().size());
    assertEquals("INTENT", result.invalidRecords().get(0).entityType());
    assertEquals("I1", result.invalidRecords().get(0).code());
    assertEquals("intent.md", result.invalidRecords().get(0).sourceFilePath());
  }
}
