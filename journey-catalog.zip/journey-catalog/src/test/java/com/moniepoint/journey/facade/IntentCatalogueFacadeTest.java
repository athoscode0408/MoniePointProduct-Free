package com.moniepoint.journey.facade;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.model.dto.IntentResponseDto;
import com.moniepoint.journey.model.entity.Intent;
import com.moniepoint.journey.model.entity.Platform;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.service.IntentGroupQueryService;
import com.moniepoint.journey.service.IntentQueryService;
import com.moniepoint.journey.service.PlatformQueryService;
import com.moniepoint.journey.service.ProductAreaQueryService;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("IntentCatalogueFacade Tests")
class IntentCatalogueFacadeTest {
  @Mock private PlatformQueryService platformQueryService;
  @Mock private ProductAreaQueryService productAreaQueryService;
  @Mock private IntentGroupQueryService intentGroupQueryService;
  @Mock private IntentQueryService intentQueryService;
  @InjectMocks private IntentCatalogueFacade facade;

  @Test
  @DisplayName(
      "resolves a parent's name whenever the row exists, even if that parent is itself INVALID,"
          + " and leaves name null only when the row is entirely absent")
  void shouldResolveParentNameRegardlessOfParentValidity() {
    Intent intent =
        Intent.builder()
            .code("I1")
            .name("Do the thing")
            .platformCode("P1")
            .productAreaCode("pa1")
            .intentGroupCode("G1")
            .validationStatus(ValidationStatus.VALID)
            .build();
    intent.setUpdatedAt(OffsetDateTime.now());
    when(intentQueryService.findByCode("I1")).thenReturn(Optional.of(intent));

    Platform invalidPlatform =
        Platform.builder()
            .code("P1")
            .name("Platform One")
            .validationStatus(ValidationStatus.INVALID)
            .build();
    when(platformQueryService.findByCodes(Set.of("P1"))).thenReturn(List.of(invalidPlatform));
    when(productAreaQueryService.findByCodes(Set.of("pa1"))).thenReturn(List.of());
    when(intentGroupQueryService.findByCodes(Set.of("G1"))).thenReturn(List.of());

    IntentResponseDto response = facade.getIntent("I1");

    assertEquals("P1", response.getPlatform().getCode());
    assertEquals("Platform One", response.getPlatform().getName());
    assertEquals("pa1", response.getProductArea().getCode());
    assertNull(response.getProductArea().getName());
    assertEquals("G1", response.getIntentGroup().getCode());
    assertNull(response.getIntentGroup().getName());
  }
}
