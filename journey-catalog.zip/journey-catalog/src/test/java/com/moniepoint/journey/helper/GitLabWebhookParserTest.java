package com.moniepoint.journey.helper;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.model.dto.WebhookEventDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("GitLabWebhookParser Tests")
class GitLabWebhookParserTest {
  private GitLabWebhookParser parser;
  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() {
    objectMapper = new ObjectMapper();
    parser = new GitLabWebhookParser(objectMapper);
  }

  @Nested
  @DisplayName("parseGitLabPushEvent")
  class ParsePushEventTests {
    @Test
    @DisplayName("should parse standard push event payload correctly")
    void shouldParsePushEventPayload() {
      String payload =
          "{\n"
              + "  \"object_kind\": \"push\",\n"
              + "  \"event_name\": \"push\",\n"
              + "  \"event_id\": \"12345\",\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\n"
              + "    \"id\": 123,\n"
              + "    \"name\": \"Test Project\",\n"
              + "    \"path_with_namespace\": \"group/test-project\"\n"
              + "  },\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123def456\",\n"
              + "  \"user_id\": 456\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertNotNull(result);
      assertEquals("push", result.getEventType());
      assertEquals("123", result.getProjectId());
      assertEquals("Test Project", result.getProjectName());
      assertEquals("main", result.getBranch());
      assertEquals("refs/heads/main", result.getRef());
      assertEquals("abc123def456", result.getCheckoutSha());
      assertEquals("456", result.getUserId());
    }

    @Test
    @DisplayName("should extract branch name from refs/heads/ prefix")
    void shouldExtractBranchFromRef() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/feature/my-feature\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertEquals("feature/my-feature", result.getBranch());
      assertEquals("refs/heads/feature/my-feature", result.getRef());
    }

    @Test
    @DisplayName("should handle project_id at nested project level")
    void shouldHandleNestedProjectId() {
      String payload =
          "{\n"
              + "  \"project\": {\n"
              + "    \"id\": 789,\n"
              + "    \"name\": \"Nested Project\"\n"
              + "  },\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertEquals("789", result.getProjectId());
      assertEquals("Nested Project", result.getProjectName());
    }

    @Test
    @DisplayName("should generate event_id when not provided")
    void shouldGenerateEventIdWhenNotProvided() {
      String payload =
          "{\n"
              + "  \"object_kind\": \"push\",\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertNotNull(result.getEventId());
      assertTrue(result.getEventId().contains("push-123-"));
    }

    @Test
    @DisplayName("should use provided event_id when available")
    void shouldUseProvidedEventId() {
      String payload =
          "{\n"
              + "  \"event_id\": \"custom-event-123\",\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertEquals("custom-event-123", result.getEventId());
    }

    @Test
    @DisplayName("should handle missing optional fields gracefully")
    void shouldHandleMissingOptionalFields() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertNotNull(result);
      assertEquals("", result.getUserId());
    }

    @Test
    @DisplayName("should throw exception when project_id is missing")
    void shouldThrowExceptionWhenProjectIdMissing() {
      String payload =
          "{\n" + "  \"ref\": \"refs/heads/main\",\n" + "  \"checkout_sha\": \"abc123\"\n" + "}";

      assertThrows(RuntimeException.class, () -> parser.parseGitLabPushEvent(payload));
    }

    @Test
    @DisplayName("should throw exception for malformed JSON")
    void shouldThrowExceptionForMalformedJson() {
      String payload = "{ invalid json }";

      assertThrows(RuntimeException.class, () -> parser.parseGitLabPushEvent(payload));
    }

    @Test
    @DisplayName("should throw exception when payload is null")
    void shouldThrowExceptionWhenPayloadNull() {
      assertThrows(RuntimeException.class, () -> parser.parseGitLabPushEvent(null));
    }

    @Test
    @DisplayName("should store raw payload for audit trail")
    void shouldStoreRawPayload() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertNotNull(result.getRawPayload());
      assertEquals(payload, result.getRawPayload());
    }

    @Test
    @DisplayName("should set timestamp to current time")
    void shouldSetCurrentTimestamp() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      long beforeParse = System.currentTimeMillis();
      WebhookEventDto result = parser.parseGitLabPushEvent(payload);
      long afterParse = System.currentTimeMillis();

      assertTrue(result.getTimestamp() >= beforeParse);
      assertTrue(result.getTimestamp() <= afterParse + 1000); // Allow 1 second margin
    }
  }

  @Nested
  @DisplayName("parseGitLabTagEvent")
  class ParseTagEventTests {
    @Test
    @DisplayName("should parse tag push event payload correctly")
    void shouldParseTagEventPayload() {
      String payload =
          "{\n"
              + "  \"object_kind\": \"tag_push\",\n"
              + "  \"event_id\": \"67890\",\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test Project\"},\n"
              + "  \"ref\": \"refs/tags/v1.0.0\",\n"
              + "  \"checkout_sha\": \"tag123sha\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabTagEvent(payload);

      assertNotNull(result);
      assertEquals("tag", result.getEventType());
      assertEquals("v1.0.0", result.getBranch());
      assertEquals("refs/tags/v1.0.0", result.getRef());
      assertEquals("tag123sha", result.getCheckoutSha());
    }

    @Test
    @DisplayName("should extract tag name from refs/tags/ prefix")
    void shouldExtractTagFromRef() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/tags/release-v1.2.3\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabTagEvent(payload);

      assertEquals("release-v1.2.3", result.getBranch());
    }
  }

  @Nested
  @DisplayName("Edge Cases")
  class EdgeCasesTests {
    @Test
    @DisplayName("should handle namespace/project format in project_id")
    void shouldHandleNamespaceProjectFormat() {
      String payload =
          "{\n"
              + "  \"project_id\": \"group/my-project\",\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertEquals("group/my-project", result.getProjectId());
    }

    @Test
    @DisplayName("should handle feature branch names with slashes")
    void shouldHandleFeatureBranchesWithSlashes() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"Test\"},\n"
              + "  \"ref\": \"refs/heads/feature/JC-123/add-functionality\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertEquals("feature/JC-123/add-functionality", result.getBranch());
    }

    @Test
    @DisplayName("should handle empty project name")
    void shouldHandleEmptyProjectName() {
      String payload =
          "{\n"
              + "  \"project_id\": 123,\n"
              + "  \"project\": {\"name\": \"\"},\n"
              + "  \"ref\": \"refs/heads/main\",\n"
              + "  \"checkout_sha\": \"abc123\"\n"
              + "}";

      WebhookEventDto result = parser.parseGitLabPushEvent(payload);

      assertNotNull(result);
      assertEquals("", result.getProjectName());
    }
  }
}
