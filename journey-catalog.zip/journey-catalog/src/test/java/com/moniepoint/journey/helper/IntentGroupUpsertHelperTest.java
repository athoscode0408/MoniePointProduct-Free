package com.moniepoint.journey.helper;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.model.dto.IntentGroupDeclarationDto;
import com.moniepoint.journey.model.entity.IntentGroup;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.repository.IIntentGroupRepository;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("IntentGroupUpsertHelper Tests")
class IntentGroupUpsertHelperTest {
  @Mock private IIntentGroupRepository intentGroupRepository;
  @InjectMocks private IntentGroupUpsertHelper helper;

  @Test
  @DisplayName("applyDeclaration creates a valid, named row when declared by a product-area.md")
  void shouldApplyDeclaration() {
    when(intentGroupRepository.findByCode("GROUP-1")).thenReturn(Optional.empty());

    helper.applyDeclaration(
        IntentGroupDeclarationDto.builder().code("GROUP-1").name("Market configuration").build(),
        "savings-engine",
        "123",
        "product-area.md");

    verify(intentGroupRepository)
        .saveAndFlush(
            org.mockito.ArgumentMatchers.argThat(
                g ->
                    g.getCode().equals("GROUP-1")
                        && "Market configuration".equals(g.getName())
                        && "savings-engine".equals(g.getProductAreaCode())
                        && g.getValidationStatus() == ValidationStatus.VALID));
  }

  @Test
  @DisplayName("ensureShellExists creates an unresolved INVALID shell when no row exists yet")
  void shouldCreateShellWhenAbsent() {
    when(intentGroupRepository.findByCode("GROUP-1")).thenReturn(Optional.empty());

    helper.ensureShellExists("GROUP-1", "123");

    verify(intentGroupRepository)
        .saveAndFlush(
            org.mockito.ArgumentMatchers.argThat(
                g ->
                    g.getCode().equals("GROUP-1")
                        && g.getName() == null
                        && g.getValidationStatus() == ValidationStatus.INVALID));
  }

  @Test
  @DisplayName("ensureShellExists never downgrades an already-declared group")
  void shouldNotDowngradeExistingGroup() {
    IntentGroup existing =
        IntentGroup.builder()
            .code("GROUP-1")
            .name("Market configuration")
            .productAreaCode("savings-engine")
            .validationStatus(ValidationStatus.VALID)
            .build();
    when(intentGroupRepository.findByCode("GROUP-1")).thenReturn(Optional.of(existing));

    helper.ensureShellExists("GROUP-1", "123");

    verify(intentGroupRepository, never()).saveAndFlush(any());
  }
}
