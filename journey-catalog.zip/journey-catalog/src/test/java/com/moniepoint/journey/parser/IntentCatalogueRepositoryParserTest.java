package com.moniepoint.journey.parser;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.config.SyncProperties;
import com.moniepoint.journey.service.FileExtractionService;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

@DisplayName("IntentCatalogueRepositoryParser Tests")
class IntentCatalogueRepositoryParserTest {
  @TempDir Path repoRoot;

  private IntentCatalogueRepositoryParser parser;

  @BeforeEach
  void setUp() {
    FileExtractionService fileExtractionService = new FileExtractionService();
    YamlFrontmatterParser yamlFrontmatterParser = new YamlFrontmatterParser();
    List<CatalogueFileParser> fileParsers =
        List.of(
            new PlatformFileParser(yamlFrontmatterParser, new ObjectMapper()),
            new ProductAreaFileParser(yamlFrontmatterParser),
            new IntentFileParser(yamlFrontmatterParser));
    parser =
        new IntentCatalogueRepositoryParser(
            fileExtractionService, fileParsers, new SyncProperties());
  }

  @Test
  @DisplayName("excludes files under an in-branch-vX.Y.Z folder even when otherwise valid")
  void shouldExcludeInBranchVersionFolder() throws IOException {
    write("platform.md", "---\nplatform: PLATFORM-SVNG\nname: Savings\n---\n");
    write(
        "in-branch-v1.2.3/platform.md", "---\nplatform: PLATFORM-EXCLUDED\nname: Excluded\n---\n");

    CatalogueParseResult result = parser.parseRepository(repoRoot.toString());

    assertEquals(1, result.matchedFileCount());
    assertEquals(1, result.records().size());
    assertFalse(result.hasUnparseableFiles());
  }

  @Test
  @DisplayName("one malformed file does not stop other files from being parsed")
  void shouldIsolatePerFileFailures() throws IOException {
    write("platform.md", "---\nplatform: PLATFORM-SVNG\nname: Savings\n---\n");
    write("broken/product-area.md", "not frontmatter at all");
    write(
        "intent.md",
        "---\nplatform: PLATFORM-SVNG\nproduct_area: savings-engine\nintent_group: G1\nintent: INTENT-1\nname: Do the thing\n---\n");

    CatalogueParseResult result = parser.parseRepository(repoRoot.toString());

    assertEquals(3, result.matchedFileCount());
    assertEquals(2, result.records().size());
    assertEquals(1, result.unparseableFiles().size());
  }

  @Test
  @DisplayName("zero matched files is a valid, non-erroring outcome")
  void shouldHandleZeroMatchedFiles() throws IOException {
    write("README.md", "# Not a catalogue file");

    CatalogueParseResult result = parser.parseRepository(repoRoot.toString());

    assertEquals(0, result.matchedFileCount());
    assertTrue(result.records().isEmpty());
    assertFalse(result.hasUnparseableFiles());
  }

  private void write(String relativePath, String content) throws IOException {
    Path filePath = repoRoot.resolve(relativePath);
    Files.createDirectories(filePath.getParent());
    Files.writeString(filePath, content);
  }
}
