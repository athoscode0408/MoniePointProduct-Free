package com.moniepoint.journey.parser;

import static org.junit.jupiter.api.Assertions.*;

import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("IntentFileParser Tests")
class IntentFileParserTest {
  private IntentFileParser parser;

  @BeforeEach
  void setUp() {
    parser = new IntentFileParser(new YamlFrontmatterParser());
  }

  @Test
  @DisplayName("supports intent.md at any depth")
  void shouldSupportIntentMd() {
    assertTrue(parser.supports("intent.md"));
    assertTrue(parser.supports("savings-engine/intents/review-rate-code/intent.md"));
    assertFalse(parser.supports("product-area.md"));
  }

  @Test
  @DisplayName("parses identity from 'intent', not 'id', and captures all fields")
  void shouldParseValidFile() {
    String content =
        "---\n"
            + "platform: PLATFORM-SVNG\n"
            + "product_area: savings-engine\n"
            + "intent_group: INTENTGROUP-SVNG-MKCN\n"
            + "intent: INTENT-SVNG-MKCN-IN005\n"
            + "name: Review a Rate Code Pending Publication\n"
            + "version: 1.0.0\n"
            + "user_types:\n"
            + "  - USERTYPE-SVNG-INTU\n"
            + "channels:\n"
            + "  - WEB\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("intent.md", content);

    assertInstanceOf(ParsedRecordOutcome.Intent.class, outcome);
    IntentRawRecordDto raw = ((ParsedRecordOutcome.Intent) outcome).raw();
    assertEquals("INTENT-SVNG-MKCN-IN005", raw.getCode());
    assertEquals("Review a Rate Code Pending Publication", raw.getName());
    assertEquals("PLATFORM-SVNG", raw.getPlatformCode());
    assertEquals("savings-engine", raw.getProductAreaCode());
    assertEquals("INTENTGROUP-SVNG-MKCN", raw.getIntentGroupCode());
    assertEquals("1.0.0", raw.getVersion());
    assertEquals(1, raw.getUserTypes().size());
    assertEquals(1, raw.getChannels().size());
  }

  @Test
  @DisplayName("returns UnparseableFileOutcome when 'intent' identity field is missing")
  void shouldReturnUnparseableWhenIntentIdMissing() {
    String content = "---\n" + "platform: PLATFORM-SVNG\n" + "name: Review a rate code\n" + "---\n";

    ParsedFileOutcome outcome = parser.parse("intent.md", content);

    assertInstanceOf(UnparseableFileOutcome.class, outcome);
  }

  @Test
  @DisplayName("still returns a keyed record when a non-key required field (e.g. name) is missing")
  void shouldStillReturnRecordWhenNonKeyFieldMissing() {
    String content =
        "---\n"
            + "platform: PLATFORM-SVNG\n"
            + "product_area: savings-engine\n"
            + "intent_group: INTENTGROUP-SVNG-MKCN\n"
            + "intent: INTENT-SVNG-MKCN-IN005\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("intent.md", content);

    assertInstanceOf(ParsedRecordOutcome.Intent.class, outcome);
    assertNull(((ParsedRecordOutcome.Intent) outcome).raw().getName());
  }
}
