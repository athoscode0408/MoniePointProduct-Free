package com.moniepoint.journey.parser;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("PlatformFileParser Tests")
class PlatformFileParserTest {
  private PlatformFileParser parser;

  @BeforeEach
  void setUp() {
    parser = new PlatformFileParser(new YamlFrontmatterParser(), new ObjectMapper());
  }

  @Test
  @DisplayName("supports platform.md at any depth")
  void shouldSupportPlatformMdAtAnyDepth() {
    assertTrue(parser.supports("platform.md"));
    assertTrue(parser.supports("platforms/savings/platform.md"));
    assertFalse(parser.supports("product-area.md"));
  }

  @Test
  @DisplayName("parses a valid platform.md into a keyed record")
  void shouldParseValidFile() {
    String content =
        "---\n"
            + "platform: PLATFORM-SVNG\n"
            + "name: Savings\n"
            + "url: https://gitlab.local/savings\n"
            + "channels:\n"
            + "  - WEB\n"
            + "  - MOBILE_APP\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    assertInstanceOf(ParsedRecordOutcome.Platform.class, outcome);
    PlatformRawRecordDto raw = ((ParsedRecordOutcome.Platform) outcome).raw();
    assertEquals("PLATFORM-SVNG", raw.getCode());
    assertEquals("Savings", raw.getName());
    assertEquals("https://gitlab.local/savings", raw.getUrl());
    assertEquals(2, raw.getChannels().size());
  }

  @Test
  @DisplayName("captures unrecognized fields in metadata rather than dropping them")
  void shouldCaptureUnknownFieldsInMetadata() {
    String content =
        "---\n" + "platform: PLATFORM-SVNG\n" + "name: Savings\n" + "jira_key: PNPSAV\n" + "---\n";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    PlatformRawRecordDto raw = ((ParsedRecordOutcome.Platform) outcome).raw();
    assertEquals("PNPSAV", raw.getMetadata().get("jira_key"));
  }

  @Test
  @DisplayName("parses with 'id' field as priority over 'platform'")
  void shouldPrioritizeIdOverPlatform() {
    String content =
        "---\n"
            + "id: PLATFORM-SVNG-PRIMARY\n"
            + "platform: PLATFORM-SVNG-FALLBACK\n"
            + "name: Savings\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    assertInstanceOf(ParsedRecordOutcome.Platform.class, outcome);
    PlatformRawRecordDto raw = ((ParsedRecordOutcome.Platform) outcome).raw();
    assertEquals("PLATFORM-SVNG-PRIMARY", raw.getCode());
  }

  @Test
  @DisplayName("parses with 'id' field when 'platform' is missing")
  void shouldParseWithIdField() {
    String content = "---\n" + "id: PLATFORM-SVNG\n" + "name: Savings\n" + "---\n";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    assertInstanceOf(ParsedRecordOutcome.Platform.class, outcome);
    PlatformRawRecordDto raw = ((ParsedRecordOutcome.Platform) outcome).raw();
    assertEquals("PLATFORM-SVNG", raw.getCode());
  }

  @Test
  @DisplayName(
      "returns UnparseableFileOutcome when both 'id' and 'platform' identity fields are missing")
  void shouldReturnUnparseableWhenIdentityMissing() {
    String content = "---\n" + "name: Savings\n" + "---\n";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    assertInstanceOf(UnparseableFileOutcome.class, outcome);
  }

  @Test
  @DisplayName("returns UnparseableFileOutcome for malformed YAML rather than throwing")
  void shouldReturnUnparseableForMalformedYaml() {
    String content = "not frontmatter at all";

    ParsedFileOutcome outcome = parser.parse("platform.md", content);

    assertInstanceOf(UnparseableFileOutcome.class, outcome);
  }
}
