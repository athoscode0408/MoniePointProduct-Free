package com.moniepoint.journey.parser;

import static org.junit.jupiter.api.Assertions.*;

import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("ProductAreaFileParser Tests")
class ProductAreaFileParserTest {
  private ProductAreaFileParser parser;

  @BeforeEach
  void setUp() {
    parser = new ProductAreaFileParser(new YamlFrontmatterParser());
  }

  @Test
  @DisplayName("supports product-area.md at any depth")
  void shouldSupportProductAreaMd() {
    assertTrue(parser.supports("product-area.md"));
    assertTrue(parser.supports("savings-new-aipm/product-area.md"));
    assertFalse(parser.supports("platform.md"));
  }

  @Test
  @DisplayName(
      "parses identity from 'slug', not 'id' or 'product_area', and extracts nested intent_groups")
  void shouldParseValidFileWithIntentGroups() {
    String content =
        "---\n"
            + "platform: PLATFORM-SVNG\n"
            + "name: Savings Engine\n"
            + "slug: savings-engine\n"
            + "url: https://gitlab.local/savings-new-aipm/savings-engine\n"
            + "jira_project_key: PNPSAVSEN\n"
            + "intent_groups:\n"
            + "  - id: INTENTGROUP-SVNG-MKCN\n"
            + "    name: Market configuration\n"
            + "  - id: INTENTGROUP-SVNG-SPCN\n"
            + "    name: Savings product configuration\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("product-area.md", content);

    assertInstanceOf(ParsedRecordOutcome.ProductArea.class, outcome);
    ProductAreaRawRecordDto raw = ((ParsedRecordOutcome.ProductArea) outcome).raw();
    assertEquals("savings-engine", raw.getCode());
    assertEquals("PLATFORM-SVNG", raw.getPlatformCode());
    assertEquals("Savings Engine", raw.getName());
    assertEquals("PNPSAVSEN", raw.getJiraProjectKey());
    assertEquals(2, raw.getIntentGroups().size());
    assertEquals("INTENTGROUP-SVNG-MKCN", raw.getIntentGroups().get(0).getCode());
    assertEquals("Market configuration", raw.getIntentGroups().get(0).getName());
  }

  @Test
  @DisplayName("returns UnparseableFileOutcome when 'slug' is missing")
  void shouldReturnUnparseableWhenSlugMissing() {
    String content = "---\n" + "platform: PLATFORM-SVNG\n" + "name: Savings Engine\n" + "---\n";

    ParsedFileOutcome outcome = parser.parse("product-area.md", content);

    assertInstanceOf(UnparseableFileOutcome.class, outcome);
  }

  @Test
  @DisplayName("tolerates an empty or absent intent_groups list")
  void shouldToleratesMissingIntentGroups() {
    String content =
        "---\n"
            + "platform: PLATFORM-SVNG\n"
            + "name: Savings Engine\n"
            + "slug: savings-engine\n"
            + "---\n";

    ParsedFileOutcome outcome = parser.parse("product-area.md", content);

    ProductAreaRawRecordDto raw = ((ParsedRecordOutcome.ProductArea) outcome).raw();
    assertTrue(raw.getIntentGroups().isEmpty());
  }
}
