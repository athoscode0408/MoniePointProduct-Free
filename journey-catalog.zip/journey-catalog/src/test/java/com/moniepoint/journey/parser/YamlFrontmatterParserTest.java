package com.moniepoint.journey.parser;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.moniepoint.journey.exception.ParseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("YamlFrontmatterParser Tests")
class YamlFrontmatterParserTest {
  private YamlFrontmatterParser parser;

  @BeforeEach
  void setUp() {
    parser = new YamlFrontmatterParser();
  }

  @Nested
  @DisplayName("parseFrontmatter")
  class ParseFrontmatterTests {
    @Test
    @DisplayName("should parse valid YAML frontmatter successfully")
    void shouldParseValidFrontmatter() {
      String content =
          "---\n"
              + "platform: PLATFORM-TEST\n"
              + "capability: CAPABILITY-TEST\n"
              + "id: JOURNEY-TEST\n"
              + "name: Test Journey\n"
              + "---\n"
              + "# Content after frontmatter";

      JsonNode result = parser.parseFrontmatter(content);

      assertNotNull(result);
      assertEquals("PLATFORM-TEST", result.get("platform").asText());
      assertEquals("CAPABILITY-TEST", result.get("capability").asText());
      assertEquals("JOURNEY-TEST", result.get("id").asText());
      assertEquals("Test Journey", result.get("name").asText());
    }

    @Test
    @DisplayName("should parse complex YAML structures with arrays")
    void shouldParseComplexYaml() {
      String content =
          "---\n"
              + "platform: PLATFORM-TEST\n"
              + "id: JOURNEY-TEST\n"
              + "channels:\n"
              + "  - MOBILE_APP\n"
              + "  - WEB\n"
              + "---\n"
              + "Content";

      JsonNode result = parser.parseFrontmatter(content);

      assertNotNull(result);
      assertTrue(result.get("channels").isArray());
      assertEquals(2, result.get("channels").size());
      assertEquals("MOBILE_APP", result.get("channels").get(0).asText());
      assertEquals("WEB", result.get("channels").get(1).asText());
    }

    @Test
    @DisplayName("should throw ParseException when frontmatter is missing")
    void shouldThrowExceptionWhenNoFrontmatter() {
      String content = "No frontmatter here\nJust content";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }

    @Test
    @DisplayName("should throw ParseException when closing delimiter is missing")
    void shouldThrowExceptionWhenNoClosingDelimiter() {
      String content = "---\nplatform: TEST\nNo closing delimiter";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }

    @Test
    @DisplayName("should throw ParseException when frontmatter is empty")
    void shouldThrowExceptionWhenFrontmatterEmpty() {
      String content = "---\n---\nContent";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }

    @Test
    @DisplayName("should throw ParseException when YAML is malformed")
    void shouldThrowExceptionWhenYamlMalformed() {
      String content = "---\ninvalid: yaml: structure: bad\n---\nContent";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }

    @Test
    @DisplayName("should throw ParseException when content is null")
    void shouldThrowExceptionWhenContentNull() {
      assertThrows(ParseException.class, () -> parser.parseFrontmatter(null));
    }
  }

  @Nested
  @DisplayName("extractFileBody")
  class ExtractFileBodyTests {
    @Test
    @DisplayName("should extract content after frontmatter")
    void shouldExtractBodyAfterFrontmatter() {
      String content = "---\nkey: value\n---\n# Markdown Content\nSome text here\nMore text";

      String result = parser.extractFileBody(content);

      assertNotNull(result);
      assertEquals("# Markdown Content\nSome text here\nMore text", result);
    }

    @Test
    @DisplayName("should return null when no content after frontmatter")
    void shouldReturnNullWhenNoBody() {
      String content = "---\nkey: value\n---\n";

      String result = parser.extractFileBody(content);

      assertNull(result);
    }

    @Test
    @DisplayName("should return entire content when no frontmatter")
    void shouldReturnContentWhenNoFrontmatter() {
      String content = "No frontmatter\nJust content";

      String result = parser.extractFileBody(content);

      assertEquals(content, result);
    }

    @Test
    @DisplayName("should return null when input is null")
    void shouldReturnNullWhenInputNull() {
      String result = parser.extractFileBody(null);

      assertNull(result);
    }

    @Test
    @DisplayName("should handle missing closing delimiter gracefully")
    void shouldHandleMissingClosingDelimiter() {
      String content = "---\nkey: value\nNo closing delimiter\nContent here";

      String result = parser.extractFileBody(content);

      assertEquals(content, result);
    }

    @Test
    @DisplayName("should trim whitespace from body")
    void shouldTrimWhitespaceFromBody() {
      String content = "---\nkey: value\n---\n\n\n  Trimmed content  \n\n";

      String result = parser.extractFileBody(content);

      assertEquals("Trimmed content  ", result);
    }
  }

  @Nested
  @DisplayName("Edge Cases")
  class EdgeCasesTests {
    @Test
    @DisplayName("should handle multiple consecutive delimiters")
    void shouldHandleConsecutiveDelimiters() {
      String content = "------\nkey: value\n------\nContent";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }

    @Test
    @DisplayName("should handle YAML with special characters")
    void shouldHandleSpecialCharacters() {
      String content =
          "---\n"
              + "name: \"Journey with 'quotes' and \\\"escaped\\\"\"\n"
              + "description: \"Line 1\\nLine 2\"\n"
              + "---\n"
              + "Content";

      JsonNode result = parser.parseFrontmatter(content);

      assertNotNull(result);
      assertTrue(result.has("name"));
      assertTrue(result.has("description"));
    }

    @Test
    @DisplayName("should handle empty string input")
    void shouldHandleEmptyString() {
      assertThrows(ParseException.class, () -> parser.parseFrontmatter(""));
    }

    @Test
    @DisplayName("should handle whitespace-only frontmatter")
    void shouldHandleWhitespaceOnly() {
      String content = "---\n   \n---\nContent";

      assertThrows(ParseException.class, () -> parser.parseFrontmatter(content));
    }
  }
}
