package com.moniepoint.journey.service;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("FileExtractionService Tests")
class FileExtractionServiceTest {
  private final FileExtractionService service = new FileExtractionService();

  @Test
  @DisplayName("skips a tar entry that would escape the extraction directory (zip-slip)")
  void shouldSkipZipSlipEntry() throws IOException {
    byte[] archive = buildTarGzWithEntries("../../evil.txt", "safe/platform.md");

    String extractedPath = service.extractTarGz(new java.io.ByteArrayInputStream(archive));

    try {
      assertTrue(Files.exists(Path.of(extractedPath, "safe", "platform.md")));
      boolean escapedFileExtractedAnywhere =
          Files.walk(Path.of(extractedPath))
              .anyMatch(p -> p.getFileName().toString().equals("evil.txt"));
      assertFalse(
          escapedFileExtractedAnywhere,
          "The zip-slip entry must be skipped entirely, not extracted under any name");
      assertFalse(
          Files.exists(Path.of(extractedPath).getParent().getParent().resolve("evil.txt")),
          "The zip-slip entry must not have escaped the extraction directory");
    } finally {
      service.deleteDirectory(extractedPath);
    }
  }

  private byte[] buildTarGzWithEntries(String... entryNames) throws IOException {
    ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
    try (GzipCompressorOutputStream gzip = new GzipCompressorOutputStream(byteStream);
        TarArchiveOutputStream tar = new TarArchiveOutputStream(gzip)) {
      for (String entryName : entryNames) {
        byte[] content = "content".getBytes();
        TarArchiveEntry entry = new TarArchiveEntry(entryName);
        entry.setSize(content.length);
        tar.putArchiveEntry(entry);
        tar.write(content);
        tar.closeArchiveEntry();
      }
    }
    return byteStream.toByteArray();
  }
}
