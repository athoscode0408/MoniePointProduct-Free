package com.moniepoint.journey.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.helper.IntentGroupUpsertHelper;
import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.entity.Intent;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.repository.IIntentRepository;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("IntentCatalogueService Tests")
class IntentCatalogueServiceTest {
  @Mock private IIntentRepository intentRepository;
  @Mock private IntentGroupUpsertHelper intentGroupUpsertHelper;
  @InjectMocks private IntentCatalogueService service;

  @Test
  @DisplayName("upserts the intent by its 'intent'-derived code")
  void shouldUpsertIntent() {
    when(intentRepository.findByCode("INTENT-1")).thenReturn(Optional.empty());
    IntentRawRecordDto raw =
        IntentRawRecordDto.builder()
            .code("INTENT-1")
            .name("Do the thing")
            .platformCode("PLATFORM-SVNG")
            .productAreaCode("savings-engine")
            .intentGroupCode("GROUP-1")
            .build();

    ValidationOutcome outcome = service.upsert(raw, "123");

    assertEquals(ValidationStatus.VALID, outcome.status());
    verify(intentRepository).saveAndFlush(any(Intent.class));
  }

  @Test
  @DisplayName("ensures an intent-group shell exists when intent_group is referenced")
  void shouldEnsureIntentGroupShellExists() {
    when(intentRepository.findByCode(any())).thenReturn(Optional.empty());
    IntentRawRecordDto raw =
        IntentRawRecordDto.builder()
            .code("INTENT-1")
            .name("Do the thing")
            .platformCode("PLATFORM-SVNG")
            .productAreaCode("savings-engine")
            .intentGroupCode("GROUP-1")
            .build();

    service.upsert(raw, "123");

    verify(intentGroupUpsertHelper).ensureShellExists(eq("GROUP-1"), eq("123"));
  }

  @Test
  @DisplayName("does not call the shell-creation helper when intent_group is blank")
  void shouldNotEnsureShellWhenIntentGroupBlank() {
    when(intentRepository.findByCode(any())).thenReturn(Optional.empty());
    IntentRawRecordDto raw =
        IntentRawRecordDto.builder().code("INTENT-1").name("Do the thing").build();

    service.upsert(raw, "123");

    verify(intentGroupUpsertHelper, never()).ensureShellExists(any(), any());
  }

  @Test
  @DisplayName("persists as INVALID with structured errors when required fields are missing")
  void shouldPersistInvalidWhenRequiredFieldsMissing() {
    when(intentRepository.findByCode(any())).thenReturn(Optional.empty());
    IntentRawRecordDto raw = IntentRawRecordDto.builder().code("INTENT-1").build();

    ValidationOutcome outcome = service.upsert(raw, "123");

    assertEquals(ValidationStatus.INVALID, outcome.status());
    assertEquals(4, outcome.errors().size());
  }
}
