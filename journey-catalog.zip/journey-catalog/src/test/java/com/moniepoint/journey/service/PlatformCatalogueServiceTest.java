package com.moniepoint.journey.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.entity.Platform;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.repository.IPlatformRepository;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("PlatformCatalogueService Tests")
class PlatformCatalogueServiceTest {
  @Mock private IPlatformRepository platformRepository;
  @InjectMocks private PlatformCatalogueService service;

  @Test
  @DisplayName("creates a new platform by code when no row exists")
  void shouldCreateNewPlatform() {
    when(platformRepository.findByCode("PLATFORM-SVNG")).thenReturn(Optional.empty());
    PlatformRawRecordDto raw =
        PlatformRawRecordDto.builder().code("PLATFORM-SVNG").name("Savings").build();

    ValidationOutcome outcome = service.upsert(raw, "123");

    assertEquals(ValidationStatus.VALID, outcome.status());
    verify(platformRepository)
        .saveAndFlush(
            org.mockito.ArgumentMatchers.argThat(
                p ->
                    p.getCode().equals("PLATFORM-SVNG")
                        && p.getName().equals("Savings")
                        && p.getValidationStatus() == ValidationStatus.VALID));
  }

  @Test
  @DisplayName("upserts by code, mutating the existing row rather than creating a duplicate")
  void shouldUpdateExistingPlatform() {
    Platform existing = Platform.builder().code("PLATFORM-SVNG").name("Old Name").build();
    when(platformRepository.findByCode("PLATFORM-SVNG")).thenReturn(Optional.of(existing));
    PlatformRawRecordDto raw =
        PlatformRawRecordDto.builder().code("PLATFORM-SVNG").name("New Name").build();

    service.upsert(raw, "123");

    assertEquals("New Name", existing.getName());
    verify(platformRepository).saveAndFlush(existing);
  }

  @Test
  @DisplayName(
      "persists as INVALID with structured errors when name is missing, never dropping the row")
  void shouldPersistInvalidWhenNameMissing() {
    when(platformRepository.findByCode(any())).thenReturn(Optional.empty());
    PlatformRawRecordDto raw = PlatformRawRecordDto.builder().code("PLATFORM-SVNG").build();

    ValidationOutcome outcome = service.upsert(raw, "123");

    assertEquals(ValidationStatus.INVALID, outcome.status());
    verify(platformRepository).saveAndFlush(any(Platform.class));
  }
}
