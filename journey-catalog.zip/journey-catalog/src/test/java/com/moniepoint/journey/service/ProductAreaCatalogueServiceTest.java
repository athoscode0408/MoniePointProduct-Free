package com.moniepoint.journey.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.helper.IntentGroupUpsertHelper;
import com.moniepoint.journey.model.dto.IntentGroupDeclarationDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import com.moniepoint.journey.model.entity.ProductArea;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import com.moniepoint.journey.repository.IProductAreaRepository;
import com.moniepoint.journey.validation.ValidationOutcome;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("ProductAreaCatalogueService Tests")
class ProductAreaCatalogueServiceTest {
  @Mock private IProductAreaRepository productAreaRepository;
  @Mock private IntentGroupUpsertHelper intentGroupUpsertHelper;
  @InjectMocks private ProductAreaCatalogueService service;

  @Test
  @DisplayName("upserts the product area by its 'slug'-derived code")
  void shouldUpsertProductArea() {
    when(productAreaRepository.findByCode("savings-engine")).thenReturn(Optional.empty());
    ProductAreaRawRecordDto raw =
        ProductAreaRawRecordDto.builder()
            .code("savings-engine")
            .platformCode("PLATFORM-SVNG")
            .name("Savings Engine")
            .intentGroups(List.of())
            .build();

    ValidationOutcome outcome = service.upsert(raw, "123");

    assertEquals(ValidationStatus.VALID, outcome.status());
    verify(productAreaRepository).saveAndFlush(any(ProductArea.class));
  }

  @Test
  @DisplayName("applies every declared intent_groups entry via the shared helper")
  void shouldApplyEachIntentGroupDeclaration() {
    when(productAreaRepository.findByCode(any())).thenReturn(Optional.empty());
    ProductAreaRawRecordDto raw =
        ProductAreaRawRecordDto.builder()
            .code("savings-engine")
            .platformCode("PLATFORM-SVNG")
            .name("Savings Engine")
            .intentGroups(
                List.of(
                    IntentGroupDeclarationDto.builder()
                        .code("INTENTGROUP-SVNG-MKCN")
                        .name("Market configuration")
                        .build(),
                    IntentGroupDeclarationDto.builder()
                        .code("INTENTGROUP-SVNG-SPCN")
                        .name("Savings product configuration")
                        .build()))
            .build();

    service.upsert(raw, "123");

    verify(intentGroupUpsertHelper, times(2))
        .applyDeclaration(any(), org.mockito.ArgumentMatchers.eq("savings-engine"), any(), any());
  }

  @Test
  @DisplayName("does not call the intent-group helper when intent_groups is empty")
  void shouldNotCallHelperWhenNoIntentGroups() {
    when(productAreaRepository.findByCode(any())).thenReturn(Optional.empty());
    ProductAreaRawRecordDto raw =
        ProductAreaRawRecordDto.builder()
            .code("savings-engine")
            .platformCode("PLATFORM-SVNG")
            .name("Savings Engine")
            .intentGroups(List.of())
            .build();

    service.upsert(raw, "123");

    verify(intentGroupUpsertHelper, never()).applyDeclaration(any(), any(), any(), any());
  }
}
