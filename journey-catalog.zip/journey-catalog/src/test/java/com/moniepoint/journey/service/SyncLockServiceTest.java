package com.moniepoint.journey.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.moniepoint.journey.config.SyncProperties;
import com.moniepoint.journey.model.entity.SyncLock;
import com.moniepoint.journey.repository.ISyncLockRepository;
import java.time.Instant;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

@ExtendWith(MockitoExtension.class)
@DisplayName("SyncLockService Tests")
class SyncLockServiceTest {
  @Mock private ISyncLockRepository syncLockRepository;
  private SyncLockService service;

  @BeforeEach
  void setUp() {
    service = new SyncLockService(syncLockRepository, new SyncProperties());
  }

  @Test
  @DisplayName("acquires a new lock when none exists")
  void shouldAcquireWhenNoLockExists() {
    when(syncLockRepository.findByProjectId("123")).thenReturn(Optional.empty());

    Optional<String> token = service.tryAcquire("123");

    assertTrue(token.isPresent());
    verify(syncLockRepository).save(any(SyncLock.class));
  }

  @Test
  @DisplayName("fails to acquire when an active (non-expired) lock exists")
  void shouldFailToAcquireWhenActiveLockExists() {
    SyncLock activeLock =
        SyncLock.builder().projectId("123").expiresAt(Instant.now().plusSeconds(600)).build();
    when(syncLockRepository.findByProjectId("123")).thenReturn(Optional.of(activeLock));
    when(syncLockRepository.stealExpiredLock(eq("123"), any(), any(), any())).thenReturn(0);

    Optional<String> token = service.tryAcquire("123");

    assertTrue(token.isEmpty());
  }

  @Test
  @DisplayName("steals an expired lock")
  void shouldStealExpiredLock() {
    SyncLock expiredLock =
        SyncLock.builder().projectId("123").expiresAt(Instant.now().minusSeconds(60)).build();
    when(syncLockRepository.findByProjectId("123")).thenReturn(Optional.of(expiredLock));
    when(syncLockRepository.stealExpiredLock(eq("123"), any(), any(), any())).thenReturn(1);

    Optional<String> token = service.tryAcquire("123");

    assertTrue(token.isPresent());
  }

  @Test
  @DisplayName("falls back to a steal-check when the insert attempt loses a race")
  void shouldFallBackToStealWhenInsertLosesRace() {
    when(syncLockRepository.findByProjectId("123")).thenReturn(Optional.empty());
    when(syncLockRepository.save(any())).thenThrow(new DataIntegrityViolationException("dup"));
    when(syncLockRepository.stealExpiredLock(eq("123"), any(), any(), any())).thenReturn(0);

    Optional<String> token = service.tryAcquire("123");

    assertTrue(token.isEmpty());
  }

  @Test
  @DisplayName("release delegates to the holder-scoped repository delete")
  void shouldReleaseByDelegatingToRepository() {
    service.release("123", "token-abc");

    verify(syncLockRepository).releaseIfHeldBy("123", "token-abc");
  }
}
