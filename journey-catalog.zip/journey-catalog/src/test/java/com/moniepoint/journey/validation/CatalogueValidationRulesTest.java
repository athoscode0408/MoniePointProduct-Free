package com.moniepoint.journey.validation;

import static org.junit.jupiter.api.Assertions.*;

import com.moniepoint.journey.model.dto.IntentRawRecordDto;
import com.moniepoint.journey.model.dto.PlatformRawRecordDto;
import com.moniepoint.journey.model.dto.ProductAreaRawRecordDto;
import com.moniepoint.journey.model.entity.enums.ValidationStatus;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("CatalogueValidationRules Tests")
class CatalogueValidationRulesTest {
  @Test
  @DisplayName("platform is valid when name is present")
  void shouldValidatePlatform() {
    var outcome =
        CatalogueValidationRules.validatePlatform(
            PlatformRawRecordDto.builder().code("PLATFORM-SVNG").name("Savings").build());
    assertEquals(ValidationStatus.VALID, outcome.status());
    assertTrue(outcome.errors().isEmpty());
  }

  @Test
  @DisplayName("platform is invalid when name is missing")
  void shouldInvalidatePlatformMissingName() {
    var outcome =
        CatalogueValidationRules.validatePlatform(
            PlatformRawRecordDto.builder().code("PLATFORM-SVNG").build());
    assertEquals(ValidationStatus.INVALID, outcome.status());
    assertEquals("name", outcome.errors().get(0).getField());
  }

  @Test
  @DisplayName("product area requires both name and platform ref")
  void shouldInvalidateProductAreaMissingFields() {
    var outcome =
        CatalogueValidationRules.validateProductArea(
            ProductAreaRawRecordDto.builder().code("savings-engine").build());
    assertEquals(ValidationStatus.INVALID, outcome.status());
    assertEquals(2, outcome.errors().size());
  }

  @Test
  @DisplayName(
      "an undeclared intent group 'shell' naturally fails validation with no special-casing")
  void shouldInvalidateUndeclaredIntentGroupShell() {
    var outcome = CatalogueValidationRules.validateIntentGroup(null, null);
    assertEquals(ValidationStatus.INVALID, outcome.status());
    assertEquals(2, outcome.errors().size());
  }

  @Test
  @DisplayName("a declared intent group with name and product area is valid")
  void shouldValidateDeclaredIntentGroup() {
    var outcome =
        CatalogueValidationRules.validateIntentGroup("Market configuration", "savings-engine");
    assertEquals(ValidationStatus.VALID, outcome.status());
  }

  @Test
  @DisplayName("intent requires name, platform, product_area, and intent_group")
  void shouldInvalidateIntentMissingRequiredFields() {
    var outcome =
        CatalogueValidationRules.validateIntent(
            IntentRawRecordDto.builder().code("INTENT-1").build());
    assertEquals(ValidationStatus.INVALID, outcome.status());
    assertEquals(4, outcome.errors().size());
  }

  @Test
  @DisplayName("intent does not require version, user_types, or channels")
  void shouldValidateIntentWithOnlyRequiredFields() {
    var outcome =
        CatalogueValidationRules.validateIntent(
            IntentRawRecordDto.builder()
                .code("INTENT-1")
                .name("Do the thing")
                .platformCode("PLATFORM-SVNG")
                .productAreaCode("savings-engine")
                .intentGroupCode("GROUP-1")
                .build());
    assertEquals(ValidationStatus.VALID, outcome.status());
  }
}
